<?php
require_once 'functions.php';
require_login();
if (is_admin()) redirect('admin_dashboard.php');

$userId = $_SESSION['user_id'];

$counts = $pdo->prepare("
    SELECT status, COUNT(*) AS total
    FROM rentals WHERE user_id = ?
    GROUP BY status
");
$counts->execute([$userId]);
$statusCounts = ['pending' => 0, 'approved' => 0, 'ongoing' => 0, 'completed' => 0, 'cancelled' => 0, 'rejected' => 0];
foreach ($counts->fetchAll() as $row) {
    $statusCounts[$row['status']] = (int)$row['total'];
}

$recent = $pdo->prepare("
    SELECT r.*, i.item_name, c.category_name
    FROM rentals r
    JOIN items i ON i.item_id = r.item_id
    JOIN categories c ON c.category_id = i.category_id
    WHERE r.user_id = ?
    ORDER BY r.created_at DESC
    LIMIT 5
");
$recent->execute([$userId]);
$recentRentals = $recent->fetchAll();

$pageTitle = 'Dashboard';
$activeMenu = 'dashboard';
require 'includes/header.php';
?>

<div class="row">
  <div class="col-md-4 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Pending Requests</h4>
        <h2 class="mb-0"><?= $statusCounts['pending'] ?></h2>
      </div>
    </div>
  </div>
  <div class="col-md-4 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Ongoing Rentals</h4>
        <h2 class="mb-0"><?= $statusCounts['ongoing'] + $statusCounts['approved'] ?></h2>
      </div>
    </div>
  </div>
  <div class="col-md-4 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Completed Rentals</h4>
        <h2 class="mb-0"><?= $statusCounts['completed'] ?></h2>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center">
          <h4 class="card-title">My Recent Rental Requests</h4>
          <a href="browse_items.php" class="btn btn-primary btn-sm">Browse Items</a>
        </div>
        <div class="table-responsive">
          <table class="table table-striped">
            <thead>
              <tr>
                <th>Item</th>
                <th>Sector</th>
                <th>Dates</th>
                <th>Total</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!$recentRentals): ?>
                <tr><td colspan="5" class="text-center text-muted">No rental requests yet.</td></tr>
              <?php endif; ?>
              <?php foreach ($recentRentals as $r): ?>
                <tr>
                  <td><?= clean($r['item_name']) ?></td>
                  <td><?= clean($r['category_name']) ?></td>
                  <td><?= clean($r['start_date']) ?> &rarr; <?= clean($r['end_date']) ?></td>
                  <td><?= format_money($r['total_amount']) ?></td>
                  <td><?= status_badge($r['status']) ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
