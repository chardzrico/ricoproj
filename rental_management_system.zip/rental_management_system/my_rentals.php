<?php
require_once 'functions.php';
require_login();
if (is_admin()) redirect('admin_dashboard.php');

$stmt = $pdo->prepare("
    SELECT r.*, i.item_name, c.category_name
    FROM rentals r
    JOIN items i ON i.item_id = r.item_id
    JOIN categories c ON c.category_id = i.category_id
    WHERE r.user_id = ?
    ORDER BY r.created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$rentals = $stmt->fetchAll();

$pageTitle = 'My Rentals';
$activeMenu = 'my_rentals';
require 'includes/header.php';
?>

<div class="row">
  <div class="col-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">My Rental Requests</h4>
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>Item</th>
                <th>Sector</th>
                <th>Qty</th>
                <th>Start</th>
                <th>End</th>
                <th>Total</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!$rentals): ?>
                <tr><td colspan="8" class="text-center text-muted">No rental requests yet. <a href="browse_items.php">Browse items</a> to get started.</td></tr>
              <?php endif; ?>
              <?php foreach ($rentals as $r): ?>
                <tr>
                  <td><?= clean($r['item_name']) ?></td>
                  <td><?= clean($r['category_name']) ?></td>
                  <td><?= (int)$r['quantity'] ?></td>
                  <td><?= clean($r['start_date']) ?></td>
                  <td><?= clean($r['end_date']) ?></td>
                  <td><?= format_money($r['total_amount']) ?></td>
                  <td><?= status_badge($r['status']) ?></td>
                  <td>
                    <?php if ($r['status'] === 'pending'): ?>
                      <a href="rental_cancel.php?id=<?= $r['rental_id'] ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Cancel this request?')">Cancel</a>
                    <?php else: ?>
                      &mdash;
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
