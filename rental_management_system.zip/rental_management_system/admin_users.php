<?php
require_once 'functions.php';
require_admin();

$users = $pdo->query("SELECT * FROM users ORDER BY role, full_name")->fetchAll();

$pageTitle = 'Users';
$activeMenu = 'users';
require 'includes/header.php';
?>

<div class="row">
  <div class="col-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center">
          <h4 class="card-title">Users</h4>
          <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addModal">
            <i class="mdi mdi-plus"></i> Add User
          </button>
        </div>
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>Full Name</th>
                <th>Username</th>
                <th>Email</th>
                <th>Contact</th>
                <th>Role</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($users as $u): ?>
                <tr>
                  <td><?= clean($u['full_name']) ?></td>
                  <td><?= clean($u['username']) ?></td>
                  <td><?= clean($u['email']) ?></td>
                  <td><?= clean($u['contact_number']) ?></td>
                  <td><span class="badge <?= $u['role'] === 'admin' ? 'badge-primary' : 'badge-light' ?>"><?= ucfirst($u['role']) ?></span></td>
                  <td><?= status_badge($u['status']) ?></td>
                  <td class="text-nowrap">
                    <button class="btn btn-outline-info btn-sm" data-toggle="modal" data-target="#editModal<?= $u['user_id'] ?>">
                      <i class="mdi mdi-pencil"></i>
                    </button>
                    <?php if ($u['user_id'] != $_SESSION['user_id']): ?>
                      <a href="admin_user_action.php?action=toggle_status&id=<?= $u['user_id'] ?>" class="btn btn-outline-warning btn-sm">
                        <?= $u['status'] === 'active' ? 'Deactivate' : 'Activate' ?>
                      </a>
                      <a href="admin_user_action.php?action=delete&id=<?= $u['user_id'] ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Delete this user?')">
                        <i class="mdi mdi-delete"></i>
                      </a>
                    <?php endif; ?>
                  </td>
                </tr>

                <!-- Edit Modal -->
                <div class="modal fade" id="editModal<?= $u['user_id'] ?>" tabindex="-1" role="dialog">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <form method="POST" action="admin_user_action.php">
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" name="id" value="<?= $u['user_id'] ?>">
                        <div class="modal-header">
                          <h5 class="modal-title">Edit User</h5>
                          <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                        </div>
                        <div class="modal-body">
                          <div class="form-group">
                            <label>Full Name</label>
                            <input type="text" name="full_name" class="form-control" value="<?= clean($u['full_name']) ?>" required>
                          </div>
                          <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" class="form-control" value="<?= clean($u['email']) ?>" required>
                          </div>
                          <div class="form-group">
                            <label>Contact Number</label>
                            <input type="text" name="contact_number" class="form-control" value="<?= clean($u['contact_number']) ?>">
                          </div>
                          <div class="form-group">
                            <label>Address</label>
                            <input type="text" name="address" class="form-control" value="<?= clean($u['address']) ?>">
                          </div>
                          <div class="form-group">
                            <label>Role</label>
                            <select name="role" class="form-control" <?= $u['user_id'] == $_SESSION['user_id'] ? 'disabled' : '' ?>>
                              <option value="customer" <?= $u['role'] === 'customer' ? 'selected' : '' ?>>Customer</option>
                              <option value="admin" <?= $u['role'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                            </select>
                            <?php if ($u['user_id'] == $_SESSION['user_id']): ?>
                              <input type="hidden" name="role" value="<?= $u['role'] ?>">
                              <small class="text-muted">You can't change your own role.</small>
                            <?php endif; ?>
                          </div>
                          <div class="form-group">
                            <label>New Password (leave blank to keep current)</label>
                            <input type="password" name="password" class="form-control">
                          </div>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
                          <button type="submit" class="btn btn-primary">Save Changes</button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Add Modal -->
<div class="modal fade" id="addModal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <form method="POST" action="admin_user_action.php">
        <input type="hidden" name="action" value="add">
        <div class="modal-header">
          <h5 class="modal-title">Add User</h5>
          <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>Full Name</label>
            <input type="text" name="full_name" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Contact Number</label>
            <input type="text" name="contact_number" class="form-control">
          </div>
          <div class="form-group">
            <label>Role</label>
            <select name="role" class="form-control">
              <option value="customer">Customer</option>
              <option value="admin">Admin</option>
            </select>
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" class="form-control" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save User</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
