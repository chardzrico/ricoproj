<?php
require_once 'functions.php';
require_login();
if (is_admin()) redirect('admin_dashboard.php');

$categories = $pdo->query("SELECT * FROM categories ORDER BY category_name")->fetchAll();

$categoryFilter = isset($_GET['category']) ? (int)$_GET['category'] : 0;

$sql = "SELECT i.*, c.category_name FROM items i JOIN categories c ON c.category_id = i.category_id WHERE i.status = 'available' AND i.quantity_available > 0";
$params = [];
if ($categoryFilter) {
    $sql .= " AND i.category_id = ?";
    $params[] = $categoryFilter;
}
$sql .= " ORDER BY c.category_name, i.item_name";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$items = $stmt->fetchAll();

$pageTitle = 'Browse Items';
$activeMenu = 'browse';
require 'includes/header.php';
?>

<div class="row">
  <div class="col-12 grid-margin">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Browse Rental Items</h4>
        <ul class="nav nav-pills">
          <li class="nav-item">
            <a class="nav-link <?= $categoryFilter === 0 ? 'active' : '' ?>" href="browse_items.php">All Sectors</a>
          </li>
          <?php foreach ($categories as $cat): ?>
            <li class="nav-item">
              <a class="nav-link <?= $categoryFilter === (int)$cat['category_id'] ? 'active' : '' ?>" href="browse_items.php?category=<?= $cat['category_id'] ?>">
                <?= clean($cat['category_name']) ?>
              </a>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <?php if (!$items): ?>
    <div class="col-12"><div class="card"><div class="card-body text-center text-muted">No items available in this sector right now.</div></div></div>
  <?php endif; ?>
  <?php foreach ($items as $item): ?>
    <div class="col-md-4 grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <span class="badge badge-info mb-2"><?= clean($item['category_name']) ?></span>
          <h4 class="card-title"><?= clean($item['item_name']) ?></h4>
          <p class="card-description"><?= clean($item['description']) ?></p>
          <h3 class="mb-1"><?= format_money($item['price']) ?> <small class="text-muted"><?= clean($item['price_unit']) ?></small></h3>
          <p class="text-muted mb-2"><?= (int)$item['quantity_available'] ?> unit(s) available</p>
          <a href="item_details.php?id=<?= $item['item_id'] ?>" class="btn btn-primary btn-block">View &amp; Rent</a>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<?php require 'includes/footer.php'; ?>
