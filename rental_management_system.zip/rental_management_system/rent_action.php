<?php
require_once 'functions.php';
require_login();
if (is_admin()) redirect('admin_dashboard.php');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('browse_items.php');

$itemId    = (int)($_POST['item_id'] ?? 0);
$quantity  = max(1, (int)($_POST['quantity'] ?? 1));
$startDate = $_POST['start_date'] ?? '';
$endDate   = $_POST['end_date'] ?? '';

$stmt = $pdo->prepare("SELECT * FROM items WHERE item_id = ?");
$stmt->execute([$itemId]);
$item = $stmt->fetch();

if (!$item) {
    set_flash('danger', 'Item not found.');
    redirect('browse_items.php');
}

$start = DateTime::createFromFormat('Y-m-d', $startDate);
$end   = DateTime::createFromFormat('Y-m-d', $endDate);

if (!$start || !$end || $end < $start) {
    set_flash('danger', 'Please provide a valid date range.');
    redirect('item_details.php?id=' . $itemId);
}

if ($quantity > (int)$item['quantity_available']) {
    set_flash('danger', 'Requested quantity exceeds available stock.');
    redirect('item_details.php?id=' . $itemId);
}

$days = max(1, $start->diff($end)->days + 1);

switch ($item['price_unit']) {
    case 'per week':
        $units = ceil($days / 7);
        break;
    case 'per month':
        $units = ceil($days / 30);
        break;
    case 'per event':
        $units = 1;
        break;
    default: // per day
        $units = $days;
}

$totalAmount = $item['price'] * $quantity * $units;

$stmt = $pdo->prepare("
    INSERT INTO rentals (user_id, item_id, quantity, start_date, end_date, total_amount, status)
    VALUES (?, ?, ?, ?, ?, ?, 'pending')
");
$stmt->execute([
    $_SESSION['user_id'], $itemId, $quantity,
    $start->format('Y-m-d'), $end->format('Y-m-d'), $totalAmount
]);

set_flash('success', 'Rental request submitted! Waiting for admin approval.');
redirect('my_rentals.php');
