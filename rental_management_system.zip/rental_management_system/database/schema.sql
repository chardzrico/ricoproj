-- ============================================================
-- Design and Development of Multi-Sector Rental Management System
-- Database Schema
-- Import this file directly in MySQL Workbench:
--   Server > Data Import > Import from Self-Contained File
--   or run:  mysql -u root -p < schema.sql
-- ============================================================

DROP DATABASE IF EXISTS rental_management_db;
CREATE DATABASE rental_management_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE rental_management_db;

-- ------------------------------------------------------------
-- Table: users
-- Stores both admin and customer accounts
-- ------------------------------------------------------------
CREATE TABLE users (
    user_id         INT AUTO_INCREMENT PRIMARY KEY,
    full_name       VARCHAR(100) NOT NULL,
    email           VARCHAR(100) NOT NULL UNIQUE,
    username        VARCHAR(50)  NOT NULL UNIQUE,
    password        VARCHAR(255) NOT NULL,
    contact_number  VARCHAR(20)  DEFAULT NULL,
    address         VARCHAR(255) DEFAULT NULL,
    role            ENUM('admin','customer') NOT NULL DEFAULT 'customer',
    status          ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: categories
-- The rental "sectors": Boarding House, Event Equipment, Construction Materials
-- ------------------------------------------------------------
CREATE TABLE categories (
    category_id     INT AUTO_INCREMENT PRIMARY KEY,
    category_name   VARCHAR(100) NOT NULL UNIQUE,
    description     VARCHAR(255) DEFAULT NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: items
-- Rentable units belonging to a sector/category
-- ------------------------------------------------------------
CREATE TABLE items (
    item_id             INT AUTO_INCREMENT PRIMARY KEY,
    category_id         INT NOT NULL,
    item_name           VARCHAR(150) NOT NULL,
    description          TEXT,
    price               DECIMAL(10,2) NOT NULL,
    price_unit          ENUM('per day','per week','per month','per event') NOT NULL DEFAULT 'per day',
    quantity_available  INT NOT NULL DEFAULT 1,
    image               VARCHAR(255) DEFAULT NULL,
    status              ENUM('available','unavailable') NOT NULL DEFAULT 'available',
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_items_category FOREIGN KEY (category_id) REFERENCES categories(category_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: rentals
-- A customer's request/booking for a specific item
-- ------------------------------------------------------------
CREATE TABLE rentals (
    rental_id       INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT NOT NULL,
    item_id         INT NOT NULL,
    quantity        INT NOT NULL DEFAULT 1,
    start_date      DATE NOT NULL,
    end_date        DATE NOT NULL,
    total_amount    DECIMAL(10,2) NOT NULL,
    status          ENUM('pending','approved','ongoing','completed','cancelled','rejected') NOT NULL DEFAULT 'pending',
    remarks         VARCHAR(255) DEFAULT NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_rentals_user FOREIGN KEY (user_id) REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_rentals_item FOREIGN KEY (item_id) REFERENCES items(item_id)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: payments
-- Payment records tied to a rental
-- ------------------------------------------------------------
CREATE TABLE payments (
    payment_id      INT AUTO_INCREMENT PRIMARY KEY,
    rental_id       INT NOT NULL,
    amount          DECIMAL(10,2) NOT NULL,
    payment_method  ENUM('cash','gcash','bank_transfer') NOT NULL DEFAULT 'cash',
    payment_date    DATE NOT NULL,
    status          ENUM('unpaid','partial','paid') NOT NULL DEFAULT 'unpaid',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_payments_rental FOREIGN KEY (rental_id) REFERENCES rentals(rental_id)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- Seed data
-- ============================================================

-- NOTE: The default admin account is NOT inserted here because passwords
-- must be hashed with PHP's password_hash() to log in correctly.
-- After importing this schema, open setup_admin.php once in your browser
-- to create the admin account (username: admin / password: Admin@123),
-- then delete setup_admin.php from the server for security.

-- Sectors
INSERT INTO categories (category_name, description) VALUES
('Boarding House', 'Rooms and bed spaces for short or long term stay'),
('Event Equipment', 'Chairs, tables, sound systems, tents, and other event needs'),
('Construction Materials', 'Tools, scaffolding, and heavy equipment for construction');

-- Sample items
INSERT INTO items (category_id, item_name, description, price, price_unit, quantity_available, status) VALUES
(1, 'Single Room (Fan Room)', 'Good for 1 person, shared comfort room', 2500.00, 'per month', 5, 'available'),
(1, 'Room with Aircon', 'Good for 1-2 persons, private comfort room', 4500.00, 'per month', 3, 'available'),
(1, 'Bed Space (Shared)', 'Shared room, good for students/workers', 1500.00, 'per month', 8, 'available'),
(2, 'Plastic Chairs (set of 50)', 'White monobloc chairs', 750.00, 'per event', 10, 'available'),
(2, 'Round Table (seats 8)', 'With table cloth', 300.00, 'per event', 15, 'available'),
(2, 'Sound System Package', 'Speakers, mixer, and 2 microphones', 3500.00, 'per event', 4, 'available'),
(2, 'Event Tent (5x5m)', 'White canopy tent', 1500.00, 'per event', 6, 'available'),
(3, 'Scaffolding Set', 'Steel scaffolding, 2 meters per frame', 500.00, 'per day', 20, 'available'),
(3, 'Concrete Mixer', 'One-bagger concrete mixer, gas powered', 1200.00, 'per day', 5, 'available'),
(3, 'Jackhammer', 'Electric demolition jackhammer', 900.00, 'per day', 4, 'available');
