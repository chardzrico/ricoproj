<?php
require_once 'functions.php';
require_admin();

$action = $_POST['action'] ?? $_GET['action'] ?? '';

if ($action === 'add' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['category_name'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    if ($name === '') {
        set_flash('danger', 'Sector name is required.');
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO categories (category_name, description) VALUES (?, ?)");
            $stmt->execute([$name, $desc]);
            set_flash('success', 'Sector added successfully.');
        } catch (PDOException $e) {
            set_flash('danger', 'That sector name already exists.');
        }
    }
} elseif ($action === 'edit' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $name = trim($_POST['category_name'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    if ($name === '') {
        set_flash('danger', 'Sector name is required.');
    } else {
        $stmt = $pdo->prepare("UPDATE categories SET category_name = ?, description = ? WHERE category_id = ?");
        $stmt->execute([$name, $desc, $id]);
        set_flash('success', 'Sector updated successfully.');
    }
} elseif ($action === 'delete') {
    $id = (int)($_GET['id'] ?? 0);
    $check = $pdo->prepare("SELECT COUNT(*) FROM items WHERE category_id = ?");
    $check->execute([$id]);
    if ($check->fetchColumn() > 0) {
        set_flash('danger', 'Cannot delete a sector that still has items assigned to it.');
    } else {
        $stmt = $pdo->prepare("DELETE FROM categories WHERE category_id = ?");
        $stmt->execute([$id]);
        set_flash('success', 'Sector deleted.');
    }
}

redirect('admin_categories.php');
