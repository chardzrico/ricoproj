# Design and Development of Multi-Sector Rental Management System

A PHP + MySQL web system for managing rentals across three sectors:
**Boarding House, Event Equipment, and Construction Materials.**
Built on the Spica admin template design, with customer-facing pages
(login/register/dashboard/browse/rent) and a full admin panel with CRUD.

## Tech stack
- Apache 2.4 + PHP (plain PHP, PDO for MySQL — no framework)
- MySQL (schema provided for import via MySQL Workbench)
- Front-end: Spica Bootstrap admin template (Bootstrap 4)

## Folder structure
```
rental_management/
├── config.php              -- DB connection settings (edit this first)
├── functions.php           -- session/auth helpers
├── setup_admin.php         -- run once to create the admin login
├── index.php / login.php / register.php / logout.php
├── dashboard.php           -- customer dashboard
├── browse_items.php        -- customer: browse items per sector
├── item_details.php        -- customer: view item + submit rental request
├── rent_action.php         -- handles rental request submission
├── my_rentals.php          -- customer: view/cancel own requests
├── rental_cancel.php
├── admin_dashboard.php      -- admin: stats overview
├── admin_categories.php / admin_category_action.php   -- CRUD: sectors
├── admin_items.php / admin_item_action.php             -- CRUD: rental items
├── admin_rentals.php / admin_rental_action.php         -- approve/reject/complete
├── admin_users.php / admin_user_action.php             -- CRUD: user accounts
├── includes/                -- shared header/footer (template layout)
├── css/ js/ vendors/ images/ fonts/   -- Spica template assets
├── uploads/items/           -- uploaded item photos (writable)
└── database/schema.sql      -- import this into MySQL Workbench
```

## Setup (XAMPP / Apache2.4 + PHP)

1. Copy the `rental_management` folder into your web root
   (e.g. `htdocs/rental_management` for XAMPP).
2. Open **MySQL Workbench** → Server → Data Import → "Import from
   Self-Contained File" → select `database/schema.sql` → Start Import.
   This creates the `rental_management_db` database with all tables
   and sample categories/items already seeded.
3. Open `config.php` and confirm `DB_USER` / `DB_PASS` match your
   MySQL Workbench login (defaults to `root` with no password).
4. In your browser, visit `http://localhost/rental_management/setup_admin.php`
   **once** — this creates the admin account:
   - username: `admin`
   - password: `Admin@123`
   Then delete `setup_admin.php` from the server.
5. Go to `http://localhost/rental_management/login.php` and log in.
   Register a second account (role: customer) to test the customer side.

## Default accounts
- **Admin:** created via `setup_admin.php` (see above)
- **Customer:** register your own via `register.php`

## Notes / things you may want to adjust for your defense
- Passwords are hashed with PHP's `password_hash()` (bcrypt) — never
  stored in plain text.
- All database queries use PDO prepared statements to prevent SQL
  injection.
- Stock (`quantity_available`) is automatically deducted when the
  admin **approves** a request, and restored when it's marked
  **completed**.
- An item or sector can't be deleted once it has related rental
  history — this protects data integrity (a common thesis
  panel question). Use "unavailable"/"deactivate" instead.
- Uploaded item images are stored in `uploads/items/` — make sure
  this folder is writable by Apache.
