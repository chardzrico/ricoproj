<?php
require_once 'functions.php';
require_admin();

$action = $_POST['action'] ?? $_GET['action'] ?? '';

function handle_image_upload($file) {
    if (empty($file) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return null;
    }
    $allowed = ['jpg', 'jpeg', 'png', 'webp'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) {
        return null;
    }
    if (!is_dir(UPLOAD_DIR)) {
        mkdir(UPLOAD_DIR, 0755, true);
    }
    $filename = 'item_' . uniqid() . '.' . $ext;
    move_uploaded_file($file['tmp_name'], UPLOAD_DIR . $filename);
    return $filename;
}

if ($action === 'add' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $categoryId = (int)($_POST['category_id'] ?? 0);
    $name       = trim($_POST['item_name'] ?? '');
    $desc       = trim($_POST['description'] ?? '');
    $price      = (float)($_POST['price'] ?? 0);
    $priceUnit  = $_POST['price_unit'] ?? 'per day';
    $qty        = (int)($_POST['quantity_available'] ?? 0);

    if ($name === '' || $categoryId === 0 || $price <= 0) {
        set_flash('danger', 'Please fill out all required item fields.');
    } else {
        $image = handle_image_upload($_FILES['image'] ?? null);
        $stmt = $pdo->prepare("
            INSERT INTO items (category_id, item_name, description, price, price_unit, quantity_available, image, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'available')
        ");
        $stmt->execute([$categoryId, $name, $desc, $price, $priceUnit, $qty, $image]);
        set_flash('success', 'Item added successfully.');
    }
} elseif ($action === 'edit' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id         = (int)($_POST['id'] ?? 0);
    $categoryId = (int)($_POST['category_id'] ?? 0);
    $name       = trim($_POST['item_name'] ?? '');
    $desc       = trim($_POST['description'] ?? '');
    $price      = (float)($_POST['price'] ?? 0);
    $priceUnit  = $_POST['price_unit'] ?? 'per day';
    $qty        = (int)($_POST['quantity_available'] ?? 0);
    $status     = $_POST['status'] ?? 'available';

    $image = handle_image_upload($_FILES['image'] ?? null);

    if ($image) {
        $stmt = $pdo->prepare("
            UPDATE items SET category_id=?, item_name=?, description=?, price=?, price_unit=?, quantity_available=?, status=?, image=?
            WHERE item_id=?
        ");
        $stmt->execute([$categoryId, $name, $desc, $price, $priceUnit, $qty, $status, $image, $id]);
    } else {
        $stmt = $pdo->prepare("
            UPDATE items SET category_id=?, item_name=?, description=?, price=?, price_unit=?, quantity_available=?, status=?
            WHERE item_id=?
        ");
        $stmt->execute([$categoryId, $name, $desc, $price, $priceUnit, $qty, $status, $id]);
    }
    set_flash('success', 'Item updated successfully.');
} elseif ($action === 'delete') {
    $id = (int)($_GET['id'] ?? 0);
    $check = $pdo->prepare("SELECT COUNT(*) FROM rentals WHERE item_id = ?");
    $check->execute([$id]);
    if ($check->fetchColumn() > 0) {
        set_flash('danger', 'Cannot delete an item that has rental history. Set it to "unavailable" instead.');
    } else {
        $stmt = $pdo->prepare("DELETE FROM items WHERE item_id = ?");
        $stmt->execute([$id]);
        set_flash('success', 'Item deleted.');
    }
}

redirect('admin_items.php');
