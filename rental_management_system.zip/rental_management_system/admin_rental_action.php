<?php
require_once 'functions.php';
require_admin();

$rentalId  = (int)($_GET['id'] ?? 0);
$newStatus = $_GET['status'] ?? '';

$allowed = ['approved', 'rejected', 'ongoing', 'completed'];
if (!in_array($newStatus, $allowed)) {
    set_flash('danger', 'Invalid action.');
    redirect('admin_rentals.php');
}

$stmt = $pdo->prepare("SELECT * FROM rentals WHERE rental_id = ?");
$stmt->execute([$rentalId]);
$rental = $stmt->fetch();

if (!$rental) {
    set_flash('danger', 'Rental request not found.');
    redirect('admin_rentals.php');
}

$pdo->beginTransaction();
try {
    if ($newStatus === 'approved' && $rental['status'] === 'pending') {
        $item = $pdo->prepare("SELECT quantity_available FROM items WHERE item_id = ? FOR UPDATE");
        $item->execute([$rental['item_id']]);
        $available = (int)$item->fetchColumn();
        if ($available < $rental['quantity']) {
            throw new Exception('Not enough stock left to approve this request.');
        }
        $pdo->prepare("UPDATE items SET quantity_available = quantity_available - ? WHERE item_id = ?")
            ->execute([$rental['quantity'], $rental['item_id']]);
    }

    if ($newStatus === 'completed' && in_array($rental['status'], ['ongoing', 'approved'])) {
        $pdo->prepare("UPDATE items SET quantity_available = quantity_available + ? WHERE item_id = ?")
            ->execute([$rental['quantity'], $rental['item_id']]);
    }

    $pdo->prepare("UPDATE rentals SET status = ? WHERE rental_id = ?")
        ->execute([$newStatus, $rentalId]);

    $pdo->commit();
    set_flash('success', 'Rental status updated to ' . ucfirst($newStatus) . '.');
} catch (Exception $e) {
    $pdo->rollBack();
    set_flash('danger', $e->getMessage());
}

redirect('admin_rentals.php');
