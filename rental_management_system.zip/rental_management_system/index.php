<?php
require_once 'functions.php';

if (is_logged_in()) {
    redirect(is_admin() ? 'admin_dashboard.php' : 'dashboard.php');
} else {
    redirect('login.php');
}
