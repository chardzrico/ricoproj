<?php
require_once 'functions.php';
$_SESSION = [];
session_destroy();
redirect('login.php');
