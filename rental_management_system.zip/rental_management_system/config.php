<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
/**
 * Database configuration
 * Update these values to match your local MySQL / Workbench setup.
 */
define('DB_HOST', 'localhost');
define('DB_NAME', 'rental_management_db');
define('DB_USER', 'root');
define('DB_PASS', 'ricopogi18jr');       // set your MySQL root password here if you have one

define('SITE_NAME', 'Multi-Sector Rental Management System');
define('UPLOAD_DIR', __DIR__ . '/uploads/items/');
define('UPLOAD_URL', 'uploads/items/');

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    die("Database connection failed: " . htmlspecialchars($e->getMessage()) .
        "<br>Make sure you imported database/schema.sql and the credentials above are correct.");
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
