<?php
require_once __DIR__ . '/config.php';

function clean($value) {
    return htmlspecialchars(trim($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function is_admin() {
    return is_logged_in() && $_SESSION['role'] === 'admin';
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

function require_admin() {
    require_login();
    if (!is_admin()) {
        header('Location: dashboard.php');
        exit;
    }
}

function set_flash($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash() {
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

function redirect($url) {
    header("Location: $url");
    exit;
}

function format_money($amount) {
    return '₱' . number_format((float)$amount, 2);
}

function status_badge($status) {
    $map = [
        'available'  => 'badge-success',
        'unavailable'=> 'badge-secondary',
        'pending'    => 'badge-warning',
        'approved'   => 'badge-info',
        'ongoing'    => 'badge-primary',
        'completed'  => 'badge-success',
        'cancelled'  => 'badge-secondary',
        'rejected'   => 'badge-danger',
        'active'     => 'badge-success',
        'inactive'   => 'badge-secondary',
        'paid'       => 'badge-success',
        'unpaid'     => 'badge-danger',
        'partial'    => 'badge-warning',
    ];
    $class = $map[$status] ?? 'badge-secondary';
    return "<span class=\"badge $class\">" . ucfirst($status) . "</span>";
}
