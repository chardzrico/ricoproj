<?php
require_once 'functions.php';
require_admin();

$categories = $pdo->query("SELECT * FROM categories ORDER BY category_name")->fetchAll();

$items = $pdo->query("
    SELECT i.*, c.category_name
    FROM items i
    JOIN categories c ON c.category_id = i.category_id
    ORDER BY c.category_name, i.item_name
")->fetchAll();

$pageTitle = 'Rental Items';
$activeMenu = 'items';
require 'includes/header.php';
?>

<div class="row">
  <div class="col-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center">
          <h4 class="card-title">Rental Items</h4>
          <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addModal">
            <i class="mdi mdi-plus"></i> Add Item
          </button>
        </div>
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>Image</th>
                <th>Item Name</th>
                <th>Sector</th>
                <th>Price</th>
                <th>Qty</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!$items): ?>
                <tr><td colspan="7" class="text-center text-muted">No items yet.</td></tr>
              <?php endif; ?>
              <?php foreach ($items as $item): ?>
                <tr>
                  <td>
                    <?php if ($item['image']): ?>
                      <img src="<?= UPLOAD_URL . clean($item['image']) ?>" alt="" style="width:50px;height:50px;object-fit:cover;border-radius:6px;">
                    <?php else: ?>
                      <i class="mdi mdi-image-off text-muted"></i>
                    <?php endif; ?>
                  </td>
                  <td><?= clean($item['item_name']) ?></td>
                  <td><?= clean($item['category_name']) ?></td>
                  <td><?= format_money($item['price']) ?> <small class="text-muted"><?= clean($item['price_unit']) ?></small></td>
                  <td><?= (int)$item['quantity_available'] ?></td>
                  <td><?= status_badge($item['status']) ?></td>
                  <td>
                    <button class="btn btn-outline-info btn-sm" data-toggle="modal" data-target="#editModal<?= $item['item_id'] ?>">
                      <i class="mdi mdi-pencil"></i>
                    </button>
                    <a href="admin_item_action.php?action=delete&id=<?= $item['item_id'] ?>"
                       class="btn btn-outline-danger btn-sm"
                       onclick="return confirm('Delete this item?')">
                      <i class="mdi mdi-delete"></i>
                    </a>
                  </td>
                </tr>

                <!-- Edit Modal -->
                <div class="modal fade" id="editModal<?= $item['item_id'] ?>" tabindex="-1" role="dialog">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <form method="POST" action="admin_item_action.php" enctype="multipart/form-data">
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" name="id" value="<?= $item['item_id'] ?>">
                        <div class="modal-header">
                          <h5 class="modal-title">Edit Item</h5>
                          <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                        </div>
                        <div class="modal-body">
                          <div class="form-group">
                            <label>Sector</label>
                            <select name="category_id" class="form-control" required>
                              <?php foreach ($categories as $cat): ?>
                                <option value="<?= $cat['category_id'] ?>" <?= $cat['category_id'] == $item['category_id'] ? 'selected' : '' ?>>
                                  <?= clean($cat['category_name']) ?>
                                </option>
                              <?php endforeach; ?>
                            </select>
                          </div>
                          <div class="form-group">
                            <label>Item Name</label>
                            <input type="text" name="item_name" class="form-control" value="<?= clean($item['item_name']) ?>" required>
                          </div>
                          <div class="form-group">
                            <label>Description</label>
                            <textarea name="description" class="form-control" rows="2"><?= clean($item['description']) ?></textarea>
                          </div>
                          <div class="form-row">
                            <div class="form-group col-md-6">
                              <label>Price</label>
                              <input type="number" step="0.01" name="price" class="form-control" value="<?= clean($item['price']) ?>" required>
                            </div>
                            <div class="form-group col-md-6">
                              <label>Price Unit</label>
                              <select name="price_unit" class="form-control">
                                <?php foreach (['per day','per week','per month','per event'] as $u): ?>
                                  <option value="<?= $u ?>" <?= $item['price_unit'] === $u ? 'selected' : '' ?>><?= $u ?></option>
                                <?php endforeach; ?>
                              </select>
                            </div>
                          </div>
                          <div class="form-row">
                            <div class="form-group col-md-6">
                              <label>Quantity Available</label>
                              <input type="number" name="quantity_available" class="form-control" value="<?= (int)$item['quantity_available'] ?>" required>
                            </div>
                            <div class="form-group col-md-6">
                              <label>Status</label>
                              <select name="status" class="form-control">
                                <option value="available" <?= $item['status'] === 'available' ? 'selected' : '' ?>>Available</option>
                                <option value="unavailable" <?= $item['status'] === 'unavailable' ? 'selected' : '' ?>>Unavailable</option>
                              </select>
                            </div>
                          </div>
                          <div class="form-group">
                            <label>Replace Image (optional)</label>
                            <input type="file" name="image" class="form-control" accept="image/*">
                          </div>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
                          <button type="submit" class="btn btn-primary">Save Changes</button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Add Modal -->
<div class="modal fade" id="addModal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <form method="POST" action="admin_item_action.php" enctype="multipart/form-data">
        <input type="hidden" name="action" value="add">
        <div class="modal-header">
          <h5 class="modal-title">Add Item</h5>
          <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>Sector</label>
            <select name="category_id" class="form-control" required>
              <?php foreach ($categories as $cat): ?>
                <option value="<?= $cat['category_id'] ?>"><?= clean($cat['category_name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label>Item Name</label>
            <input type="text" name="item_name" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Description</label>
            <textarea name="description" class="form-control" rows="2"></textarea>
          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label>Price</label>
              <input type="number" step="0.01" name="price" class="form-control" required>
            </div>
            <div class="form-group col-md-6">
              <label>Price Unit</label>
              <select name="price_unit" class="form-control">
                <option value="per day">per day</option>
                <option value="per week">per week</option>
                <option value="per month">per month</option>
                <option value="per event">per event</option>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label>Quantity Available</label>
            <input type="number" name="quantity_available" class="form-control" value="1" required>
          </div>
          <div class="form-group">
            <label>Image (optional)</label>
            <input type="file" name="image" class="form-control" accept="image/*">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save Item</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
