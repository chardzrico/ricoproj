<?php
require_once 'functions.php';
require_admin();

$totalItems = $pdo->query("SELECT COUNT(*) FROM items")->fetchColumn();
$totalUsers = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn();
$pendingRentals = $pdo->query("SELECT COUNT(*) FROM rentals WHERE status = 'pending'")->fetchColumn();
$ongoingRentals = $pdo->query("SELECT COUNT(*) FROM rentals WHERE status IN ('approved','ongoing')")->fetchColumn();
$totalRevenue = $pdo->query("SELECT COALESCE(SUM(total_amount),0) FROM rentals WHERE status = 'completed'")->fetchColumn();

$bySector = $pdo->query("
    SELECT c.category_name, COUNT(r.rental_id) AS total
    FROM categories c
    LEFT JOIN items i ON i.category_id = c.category_id
    LEFT JOIN rentals r ON r.item_id = i.item_id
    GROUP BY c.category_id, c.category_name
    ORDER BY c.category_name
")->fetchAll();

$recentRentals = $pdo->query("
    SELECT r.*, i.item_name, u.full_name, c.category_name
    FROM rentals r
    JOIN items i ON i.item_id = r.item_id
    JOIN users u ON u.user_id = r.user_id
    JOIN categories c ON c.category_id = i.category_id
    ORDER BY r.created_at DESC
    LIMIT 8
")->fetchAll();

$pageTitle = 'Admin Dashboard';
$activeMenu = 'admin_dashboard';
require 'includes/header.php';
?>

<div class="row">
  <div class="col-md-3 grid-margin stretch-card">
    <div class="card"><div class="card-body">
      <h4 class="card-title">Total Items</h4>
      <h2 class="mb-0"><?= (int)$totalItems ?></h2>
    </div></div>
  </div>
  <div class="col-md-3 grid-margin stretch-card">
    <div class="card"><div class="card-body">
      <h4 class="card-title">Registered Customers</h4>
      <h2 class="mb-0"><?= (int)$totalUsers ?></h2>
    </div></div>
  </div>
  <div class="col-md-3 grid-margin stretch-card">
    <div class="card"><div class="card-body">
      <h4 class="card-title">Pending Requests</h4>
      <h2 class="mb-0 text-warning"><?= (int)$pendingRentals ?></h2>
    </div></div>
  </div>
  <div class="col-md-3 grid-margin stretch-card">
    <div class="card"><div class="card-body">
      <h4 class="card-title">Revenue (Completed)</h4>
      <h2 class="mb-0 text-success"><?= format_money($totalRevenue) ?></h2>
    </div></div>
  </div>
</div>

<div class="row">
  <div class="col-md-5 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Rental Requests per Sector</h4>
        <div class="table-responsive">
          <table class="table">
            <thead><tr><th>Sector</th><th>Requests</th></tr></thead>
            <tbody>
              <?php foreach ($bySector as $s): ?>
                <tr><td><?= clean($s['category_name']) ?></td><td><?= (int)$s['total'] ?></td></tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-7 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center">
          <h4 class="card-title">Recent Rental Requests</h4>
          <a href="admin_rentals.php" class="btn btn-primary btn-sm">Manage All</a>
        </div>
        <div class="table-responsive">
          <table class="table table-striped">
            <thead>
              <tr><th>Customer</th><th>Item</th><th>Status</th></tr>
            </thead>
            <tbody>
              <?php if (!$recentRentals): ?>
                <tr><td colspan="3" class="text-center text-muted">No rental requests yet.</td></tr>
              <?php endif; ?>
              <?php foreach ($recentRentals as $r): ?>
                <tr>
                  <td><?= clean($r['full_name']) ?></td>
                  <td><?= clean($r['item_name']) ?> <small class="text-muted">(<?= clean($r['category_name']) ?>)</small></td>
                  <td><?= status_badge($r['status']) ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
