<?php
require_once 'functions.php';
require_login();
if (is_admin()) redirect('admin_dashboard.php');

$rentalId = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM rentals WHERE rental_id = ? AND user_id = ?");
$stmt->execute([$rentalId, $_SESSION['user_id']]);
$rental = $stmt->fetch();

if (!$rental) {
    set_flash('danger', 'Rental request not found.');
} elseif ($rental['status'] !== 'pending') {
    set_flash('danger', 'Only pending requests can be cancelled.');
} else {
    $update = $pdo->prepare("UPDATE rentals SET status = 'cancelled' WHERE rental_id = ?");
    $update->execute([$rentalId]);
    set_flash('success', 'Rental request cancelled.');
}

redirect('my_rentals.php');
