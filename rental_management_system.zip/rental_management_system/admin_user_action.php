<?php
require_once 'functions.php';
require_admin();

$action = $_POST['action'] ?? $_GET['action'] ?? '';

if ($action === 'add' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $contact  = trim($_POST['contact_number'] ?? '');
    $role     = $_POST['role'] === 'admin' ? 'admin' : 'customer';
    $password = $_POST['password'] ?? '';

    if ($fullName === '' || $username === '' || $email === '' || $password === '') {
        set_flash('danger', 'Please fill out all required fields.');
    } else {
        try {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("
                INSERT INTO users (full_name, email, username, password, contact_number, role, status)
                VALUES (?, ?, ?, ?, ?, ?, 'active')
            ");
            $stmt->execute([$fullName, $email, $username, $hash, $contact, $role]);
            set_flash('success', 'User added successfully.');
        } catch (PDOException $e) {
            set_flash('danger', 'That username or email is already in use.');
        }
    }
} elseif ($action === 'edit' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id       = (int)($_POST['id'] ?? 0);
    $fullName = trim($_POST['full_name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $contact  = trim($_POST['contact_number'] ?? '');
    $address  = trim($_POST['address'] ?? '');
    $role     = $_POST['role'] === 'admin' ? 'admin' : 'customer';
    $password = $_POST['password'] ?? '';

    // Prevent an admin from demoting/locking themselves out by accident via the disabled field
    if ($id == $_SESSION['user_id']) {
        $role = $_SESSION['role'];
    }

    if ($password !== '') {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("
            UPDATE users SET full_name=?, email=?, contact_number=?, address=?, role=?, password=?
            WHERE user_id=?
        ");
        $stmt->execute([$fullName, $email, $contact, $address, $role, $hash, $id]);
    } else {
        $stmt = $pdo->prepare("
            UPDATE users SET full_name=?, email=?, contact_number=?, address=?, role=?
            WHERE user_id=?
        ");
        $stmt->execute([$fullName, $email, $contact, $address, $role, $id]);
    }
    set_flash('success', 'User updated successfully.');
} elseif ($action === 'toggle_status') {
    $id = (int)($_GET['id'] ?? 0);
    if ($id != $_SESSION['user_id']) {
        $stmt = $pdo->prepare("UPDATE users SET status = IF(status='active','inactive','active') WHERE user_id = ?");
        $stmt->execute([$id]);
        set_flash('success', 'User status updated.');
    }
} elseif ($action === 'delete') {
    $id = (int)($_GET['id'] ?? 0);
    if ($id != $_SESSION['user_id']) {
        $check = $pdo->prepare("SELECT COUNT(*) FROM rentals WHERE user_id = ?");
        $check->execute([$id]);
        if ($check->fetchColumn() > 0) {
            set_flash('danger', 'Cannot delete a user with existing rental history. Deactivate instead.');
        } else {
            $stmt = $pdo->prepare("DELETE FROM users WHERE user_id = ?");
            $stmt->execute([$id]);
            set_flash('success', 'User deleted.');
        }
    }
}

redirect('admin_users.php');
