<?php
/**
 * Run this file ONCE in your browser after importing database/schema.sql
 * to create the default admin account. Delete this file afterwards.
 */
require_once 'config.php';

$username = 'admin';
$defaultPassword = 'Admin@123';

$check = $pdo->prepare("SELECT user_id FROM users WHERE username = ?");
$check->execute([$username]);

if ($check->fetch()) {
    echo "Admin account already exists. Nothing to do. You may delete this file.";
    exit;
}

$hash = password_hash($defaultPassword, PASSWORD_DEFAULT);

$stmt = $pdo->prepare(
    "INSERT INTO users (full_name, email, username, password, role, status)
     VALUES (?, ?, ?, ?, 'admin', 'active')"
);
$stmt->execute(['System Administrator', 'admin@rentalsystem.com', $username, $hash]);

echo "Admin account created successfully!<br>";
echo "Username: <b>admin</b><br>";
echo "Password: <b>Admin@123</b><br><br>";
echo "<strong>Please delete setup_admin.php now and log in, then change this password.</strong>";
