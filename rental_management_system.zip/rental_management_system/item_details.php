<?php
require_once 'functions.php';
require_login();
if (is_admin()) redirect('admin_dashboard.php');

$itemId = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT i.*, c.category_name FROM items i JOIN categories c ON c.category_id = i.category_id WHERE i.item_id = ?");
$stmt->execute([$itemId]);
$item = $stmt->fetch();

if (!$item) {
    set_flash('danger', 'Item not found.');
    redirect('browse_items.php');
}

$pageTitle = $item['item_name'];
$activeMenu = 'browse';
require 'includes/header.php';
?>

<div class="row">
  <div class="col-md-7 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <span class="badge badge-info mb-2"><?= clean($item['category_name']) ?></span>
        <h3 class="card-title"><?= clean($item['item_name']) ?></h3>
        <p><?= nl2br(clean($item['description'])) ?></p>
        <h3 class="text-primary"><?= format_money($item['price']) ?> <small class="text-muted"><?= clean($item['price_unit']) ?></small></h3>
        <p class="text-muted"><?= (int)$item['quantity_available'] ?> unit(s) available</p>
      </div>
    </div>
  </div>
  <div class="col-md-5 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Request this Rental</h4>
        <form method="POST" action="rent_action.php">
          <input type="hidden" name="item_id" value="<?= $item['item_id'] ?>">
          <div class="form-group">
            <label>Quantity</label>
            <input type="number" name="quantity" class="form-control" min="1" max="<?= (int)$item['quantity_available'] ?>" value="1" required>
          </div>
          <div class="form-group">
            <label>Start Date</label>
            <input type="date" name="start_date" class="form-control" required min="<?= date('Y-m-d') ?>">
          </div>
          <div class="form-group">
            <label>End Date</label>
            <input type="date" name="end_date" class="form-control" required min="<?= date('Y-m-d') ?>">
          </div>
          <button type="submit" class="btn btn-primary btn-block">Submit Request</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
