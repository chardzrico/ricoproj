<?php
require_once 'functions.php';
require_admin();

$categories = $pdo->query("
    SELECT c.*, COUNT(i.item_id) AS item_count
    FROM categories c
    LEFT JOIN items i ON i.category_id = c.category_id
    GROUP BY c.category_id
    ORDER BY c.category_name
")->fetchAll();

$pageTitle = 'Sectors / Categories';
$activeMenu = 'categories';
require 'includes/header.php';
?>

<div class="row">
  <div class="col-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center">
          <h4 class="card-title">Rental Sectors / Categories</h4>
          <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addModal">
            <i class="mdi mdi-plus"></i> Add Sector
          </button>
        </div>
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>#</th>
                <th>Sector Name</th>
                <th>Description</th>
                <th>Items</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!$categories): ?>
                <tr><td colspan="5" class="text-center text-muted">No sectors yet.</td></tr>
              <?php endif; ?>
              <?php foreach ($categories as $i => $cat): ?>
                <tr>
                  <td><?= $i + 1 ?></td>
                  <td><?= clean($cat['category_name']) ?></td>
                  <td><?= clean($cat['description']) ?></td>
                  <td><?= (int)$cat['item_count'] ?></td>
                  <td>
                    <button class="btn btn-outline-info btn-sm" data-toggle="modal" data-target="#editModal<?= $cat['category_id'] ?>">
                      <i class="mdi mdi-pencil"></i> Edit
                    </button>
                    <a href="admin_category_action.php?action=delete&id=<?= $cat['category_id'] ?>"
                       class="btn btn-outline-danger btn-sm"
                       onclick="return confirm('Delete this sector? This is only possible if it has no items.')">
                      <i class="mdi mdi-delete"></i> Delete
                    </a>
                  </td>
                </tr>

                <!-- Edit Modal -->
                <div class="modal fade" id="editModal<?= $cat['category_id'] ?>" tabindex="-1" role="dialog">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <form method="POST" action="admin_category_action.php">
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" name="id" value="<?= $cat['category_id'] ?>">
                        <div class="modal-header">
                          <h5 class="modal-title">Edit Sector</h5>
                          <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                        </div>
                        <div class="modal-body">
                          <div class="form-group">
                            <label>Sector Name</label>
                            <input type="text" name="category_name" class="form-control" value="<?= clean($cat['category_name']) ?>" required>
                          </div>
                          <div class="form-group">
                            <label>Description</label>
                            <textarea name="description" class="form-control" rows="3"><?= clean($cat['description']) ?></textarea>
                          </div>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
                          <button type="submit" class="btn btn-primary">Save Changes</button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Add Modal -->
<div class="modal fade" id="addModal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <form method="POST" action="admin_category_action.php">
        <input type="hidden" name="action" value="add">
        <div class="modal-header">
          <h5 class="modal-title">Add Sector</h5>
          <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>Sector Name</label>
            <input type="text" name="category_name" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Description</label>
            <textarea name="description" class="form-control" rows="3"></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save Sector</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
