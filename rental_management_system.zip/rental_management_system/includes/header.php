<?php
// Expects $pageTitle to be set by the including page.
// Expects $activeMenu to be set to highlight the current sidebar link.
if (!isset($pageTitle)) { $pageTitle = SITE_NAME; }
if (!isset($activeMenu)) { $activeMenu = ''; }

function nav_active($menu, $activeMenu) {
    return $menu === $activeMenu ? 'active' : '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title><?= clean($pageTitle) ?> | <?= SITE_NAME ?></title>
  <link rel="stylesheet" href="vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="shortcut icon" href="images/favicon.png" />
</head>
<body>
  <div class="container-scroller d-flex">
    <nav class="sidebar sidebar-offcanvas" id="sidebar">
      <ul class="nav">
        <li class="nav-item sidebar-category">
          <p><?= SITE_NAME ?></p>
          <span></span>
        </li>

        <?php if (is_admin()): ?>
          <li class="nav-item <?= nav_active('admin_dashboard', $activeMenu) ?>">
            <a class="nav-link" href="admin_dashboard.php">
              <i class="mdi mdi-view-quilt menu-icon"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>
          <li class="nav-item sidebar-category">
            <p>Management</p>
            <span></span>
          </li>
          <li class="nav-item <?= nav_active('categories', $activeMenu) ?>">
            <a class="nav-link" href="admin_categories.php">
              <i class="mdi mdi-shape menu-icon"></i>
              <span class="menu-title">Sectors / Categories</span>
            </a>
          </li>
          <li class="nav-item <?= nav_active('items', $activeMenu) ?>">
            <a class="nav-link" href="admin_items.php">
              <i class="mdi mdi-package-variant-closed menu-icon"></i>
              <span class="menu-title">Rental Items</span>
            </a>
          </li>
          <li class="nav-item <?= nav_active('rentals', $activeMenu) ?>">
            <a class="nav-link" href="admin_rentals.php">
              <i class="mdi mdi-calendar-check menu-icon"></i>
              <span class="menu-title">Rental Requests</span>
            </a>
          </li>
          <li class="nav-item <?= nav_active('users', $activeMenu) ?>">
            <a class="nav-link" href="admin_users.php">
              <i class="mdi mdi-account-multiple menu-icon"></i>
              <span class="menu-title">Users</span>
            </a>
          </li>
        <?php else: ?>
          <li class="nav-item <?= nav_active('dashboard', $activeMenu) ?>">
            <a class="nav-link" href="dashboard.php">
              <i class="mdi mdi-view-quilt menu-icon"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>
          <li class="nav-item sidebar-category">
            <p>Rentals</p>
            <span></span>
          </li>
          <li class="nav-item <?= nav_active('browse', $activeMenu) ?>">
            <a class="nav-link" href="browse_items.php">
              <i class="mdi mdi-storefront menu-icon"></i>
              <span class="menu-title">Browse Items</span>
            </a>
          </li>
          <li class="nav-item <?= nav_active('my_rentals', $activeMenu) ?>">
            <a class="nav-link" href="my_rentals.php">
              <i class="mdi mdi-calendar-text menu-icon"></i>
              <span class="menu-title">My Rentals</span>
            </a>
          </li>
        <?php endif; ?>

        <li class="nav-item sidebar-category">
          <p>Account</p>
          <span></span>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="logout.php">
            <i class="mdi mdi-logout menu-icon"></i>
            <span class="menu-title">Logout</span>
          </a>
        </li>
      </ul>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <nav class="navbar col-lg-12 col-12 px-0 py-0 py-lg-4 d-flex flex-row">
        <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
          <div class="navbar-brand-wrapper">
            <a class="navbar-brand brand-logo" href="<?= is_admin() ? 'admin_dashboard.php' : 'dashboard.php' ?>"><img src="images/logo.svg" alt="logo"/></a>
            <a class="navbar-brand brand-logo-mini" href="<?= is_admin() ? 'admin_dashboard.php' : 'dashboard.php' ?>"><img src="images/logo-mini.svg" alt="logo"/></a>
          </div>
          <h4 class="font-weight-bold mb-0 d-none d-md-block mt-1">
            Welcome back, <?= clean($_SESSION['full_name'] ?? '') ?>
          </h4>
          <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-profile dropdown">
              <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-toggle="dropdown">
                <div class="nav-profile-img">
                  <img src="images/faces/face1.jpg" alt="profile">
                  <span class="availability-status online"></span>
                </div>
                <div class="nav-profile-text">
                  <p class="mb-1 text-black"><?= clean($_SESSION['full_name'] ?? '') ?></p>
                </div>
              </a>
              <div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">
                <a class="dropdown-item">
                  <i class="mdi mdi-account-outline text-primary"></i>
                  Role: <?= ucfirst($_SESSION['role'] ?? '') ?>
                </a>
                <a class="dropdown-item" href="logout.php">
                  <i class="mdi mdi-logout text-primary"></i>
                  Logout
                </a>
              </div>
            </li>
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <?php $flash = get_flash(); if ($flash): ?>
            <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show" role="alert">
              <?= clean($flash['message']) ?>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
          <?php endif; ?>
