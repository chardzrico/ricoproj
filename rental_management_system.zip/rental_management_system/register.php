<?php
require_once 'functions.php';

if (is_logged_in()) {
    redirect(is_admin() ? 'admin_dashboard.php' : 'dashboard.php');
}

$errors = [];
$old = ['full_name' => '', 'email' => '', 'username' => '', 'contact_number' => '', 'address' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old['full_name']      = trim($_POST['full_name'] ?? '');
    $old['email']          = trim($_POST['email'] ?? '');
    $old['username']       = trim($_POST['username'] ?? '');
    $old['contact_number'] = trim($_POST['contact_number'] ?? '');
    $old['address']        = trim($_POST['address'] ?? '');
    $password              = $_POST['password'] ?? '';
    $confirmPassword       = $_POST['confirm_password'] ?? '';

    if ($old['full_name'] === '' || $old['email'] === '' || $old['username'] === '' || $password === '') {
        $errors[] = 'Please fill out all required fields.';
    }
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }
    if (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters.';
    }
    if ($password !== $confirmPassword) {
        $errors[] = 'Passwords do not match.';
    }

    if (!$errors) {
        $stmt = $pdo->prepare("SELECT user_id FROM users WHERE email = ? OR username = ?");
        $stmt->execute([$old['email'], $old['username']]);
        if ($stmt->fetch()) {
            $errors[] = 'Email or username is already registered.';
        }
    }

    if (!$errors) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare(
            "INSERT INTO users (full_name, email, username, password, contact_number, address, role, status)
             VALUES (?, ?, ?, ?, ?, ?, 'customer', 'active')"
        );
        $stmt->execute([
            $old['full_name'], $old['email'], $old['username'], $hash,
            $old['contact_number'], $old['address']
        ]);
        set_flash('success', 'Registration successful! You may now log in.');
        redirect('login.php');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Register | <?= SITE_NAME ?></title>
  <link rel="stylesheet" href="vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="shortcut icon" href="images/favicon.png" />
</head>
<body>
  <div class="container-scroller d-flex">
    <div class="container-fluid page-body-wrapper full-page-wrapper d-flex">
      <div class="content-wrapper d-flex align-items-center auth px-0">
        <div class="row w-100 mx-0">
          <div class="col-lg-5 mx-auto">
            <div class="auth-form-light text-left py-5 px-4 px-sm-5">
              <div class="brand-logo">
                <img src="images/logo.svg" alt="logo">
              </div>
              <h4>New here?</h4>
              <h6 class="font-weight-light">Sign up to start renting with <?= SITE_NAME ?></h6>

              <?php if ($errors): ?>
                <div class="alert alert-danger mt-3">
                  <?php foreach ($errors as $e) echo clean($e) . '<br>'; ?>
                </div>
              <?php endif; ?>

              <form class="pt-3" method="POST" action="register.php">
                <div class="form-group">
                  <input type="text" name="full_name" class="form-control form-control-lg" placeholder="Full Name" value="<?= clean($old['full_name']) ?>" required>
                </div>
                <div class="form-group">
                  <input type="text" name="username" class="form-control form-control-lg" placeholder="Username" value="<?= clean($old['username']) ?>" required>
                </div>
                <div class="form-group">
                  <input type="email" name="email" class="form-control form-control-lg" placeholder="Email" value="<?= clean($old['email']) ?>" required>
                </div>
                <div class="form-group">
                  <input type="text" name="contact_number" class="form-control form-control-lg" placeholder="Contact Number" value="<?= clean($old['contact_number']) ?>">
                </div>
                <div class="form-group">
                  <input type="text" name="address" class="form-control form-control-lg" placeholder="Address" value="<?= clean($old['address']) ?>">
                </div>
                <div class="form-group">
                  <input type="password" name="password" class="form-control form-control-lg" placeholder="Password" required>
                </div>
                <div class="form-group">
                  <input type="password" name="confirm_password" class="form-control form-control-lg" placeholder="Confirm Password" required>
                </div>
                <div class="mt-3">
                  <button type="submit" class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn">SIGN UP</button>
                </div>
                <div class="text-center mt-4 font-weight-light">
                  Already have an account? <a href="login.php" class="text-primary">Login</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/template.js"></script>
</body>
</html>
