<?php
require_once 'functions.php';
require_admin();

$statusFilter = $_GET['status'] ?? '';
$sql = "
    SELECT r.*, i.item_name, i.category_id, u.full_name, u.email, c.category_name
    FROM rentals r
    JOIN items i ON i.item_id = r.item_id
    JOIN users u ON u.user_id = r.user_id
    JOIN categories c ON c.category_id = i.category_id
";
$params = [];
if ($statusFilter !== '' && in_array($statusFilter, ['pending','approved','ongoing','completed','cancelled','rejected'])) {
    $sql .= " WHERE r.status = ?";
    $params[] = $statusFilter;
}
$sql .= " ORDER BY r.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rentals = $stmt->fetchAll();

$statuses = ['' => 'All', 'pending' => 'Pending', 'approved' => 'Approved', 'ongoing' => 'Ongoing', 'completed' => 'Completed', 'cancelled' => 'Cancelled', 'rejected' => 'Rejected'];

$pageTitle = 'Rental Requests';
$activeMenu = 'rentals';
require 'includes/header.php';
?>

<div class="row">
  <div class="col-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Rental Requests</h4>
        <ul class="nav nav-pills mb-3">
          <?php foreach ($statuses as $key => $label): ?>
            <li class="nav-item">
              <a class="nav-link <?= $statusFilter === $key ? 'active' : '' ?>" href="admin_rentals.php<?= $key !== '' ? '?status=' . $key : '' ?>">
                <?= $label ?>
              </a>
            </li>
          <?php endforeach; ?>
        </ul>
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>Customer</th>
                <th>Item</th>
                <th>Sector</th>
                <th>Qty</th>
                <th>Dates</th>
                <th>Total</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!$rentals): ?>
                <tr><td colspan="8" class="text-center text-muted">No rental requests found.</td></tr>
              <?php endif; ?>
              <?php foreach ($rentals as $r): ?>
                <tr>
                  <td><?= clean($r['full_name']) ?><br><small class="text-muted"><?= clean($r['email']) ?></small></td>
                  <td><?= clean($r['item_name']) ?></td>
                  <td><?= clean($r['category_name']) ?></td>
                  <td><?= (int)$r['quantity'] ?></td>
                  <td><?= clean($r['start_date']) ?> &rarr; <?= clean($r['end_date']) ?></td>
                  <td><?= format_money($r['total_amount']) ?></td>
                  <td><?= status_badge($r['status']) ?></td>
                  <td class="text-nowrap">
                    <?php if ($r['status'] === 'pending'): ?>
                      <a href="admin_rental_action.php?id=<?= $r['rental_id'] ?>&status=approved" class="btn btn-outline-success btn-sm">Approve</a>
                      <a href="admin_rental_action.php?id=<?= $r['rental_id'] ?>&status=rejected" class="btn btn-outline-danger btn-sm" onclick="return confirm('Reject this request?')">Reject</a>
                    <?php elseif ($r['status'] === 'approved'): ?>
                      <a href="admin_rental_action.php?id=<?= $r['rental_id'] ?>&status=ongoing" class="btn btn-outline-primary btn-sm">Mark Ongoing</a>
                    <?php elseif ($r['status'] === 'ongoing'): ?>
                      <a href="admin_rental_action.php?id=<?= $r['rental_id'] ?>&status=completed" class="btn btn-outline-success btn-sm">Mark Completed</a>
                    <?php else: ?>
                      &mdash;
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
