<?php
if (!function_exists('getCurrentUser')) {
    require_once __DIR__ . '/../config/session.php';
}
$currentUser   = $currentUser ?? getCurrentUser();
$userFullName  = trim($currentUser['full_name'] ?? '');
$userFirstName = $userFullName !== '' ? explode(' ', $userFullName)[0] : 'Guest';
$baseUrl       = defined('BASE_URL') ? BASE_URL : '';

$notifRole = isPatient() ? 'patient' : 'staff';
$notifications = [];
$notifUnreadCount = 0;
if (!empty($currentUser['id'])) {
    $notifConn = getDBConnection();
    $notifications = getVisibleNotifications($notifConn, (int)$currentUser['id'], $notifRole, 8);
    $notifUnreadCount = getUnreadNotificationCount($notifConn, (int)$currentUser['id'], $notifRole);
}

if (!function_exists('prmsTimeAgo')) {
    function prmsTimeAgo($datetime) {
        $diff = time() - strtotime($datetime);
        if ($diff < 60) return 'just now';
        if ($diff < 3600) return floor($diff / 60) . 'm ago';
        if ($diff < 86400) return floor($diff / 3600) . 'h ago';
        if ($diff < 604800) return floor($diff / 86400) . 'd ago';
        return date('M d, Y', strtotime($datetime));
    }
}
?>
<style>
    .prms-topbar {
        position: fixed;
        top: 0;
        left: var(--sidebar-width, 264px);
        right: 0;
        height: 50px;
        background: linear-gradient(90deg, #1e3a5f 0%, #1a5276 60%, #0d6efd 100%);
        border-bottom: none;
        box-shadow: 0 2px 8px rgba(13,110,253,0.18);
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 20px;
        z-index: 1030;
    }
    @media (max-width: 1023px) { .prms-topbar { left: 0; } }
    @media (min-width: 1024px) {
        .pc-sidebar.pc-sidebar-hide ~ .prms-topbar { left: 0; }
    }

    .prms-hamburger {
        background: none;
        border: none;
        cursor: pointer;
        padding: 6px 8px;
        border-radius: 8px;
        color: rgba(255,255,255,0.85);
        display: flex;
        align-items: center;
        line-height: 1;
        transition: background 0.15s;
    }
    .prms-hamburger:hover { background: rgba(255,255,255,0.12); color: #fff; }

    .prms-greeting {
        position: absolute;
        left: 50%;
        transform: translateX(-50%);
        display: flex;
        align-items: center;
        gap: 8px;
        pointer-events: none;
    }
    .prms-greeting-icon { font-size: 1rem; }
    .prms-greeting-text {
        font-size: 0.82rem;
        font-weight: 600;
        color: rgba(255,255,255,0.95);
        white-space: nowrap;
        letter-spacing: 0.3px;
    }
    .prms-greeting-name {
        color: #ffd166;
    }

    .prms-profile-area { position: relative; }
    .prms-profile-toggle {
        display: flex;
        align-items: center;
        gap: 8px;
        background: rgba(255,255,255,0.12);
        border: 1px solid rgba(255,255,255,0.2);
        cursor: pointer;
        padding: 4px 10px 4px 5px;
        border-radius: 20px;
        white-space: nowrap;
        transition: background 0.15s;
    }
    .prms-profile-toggle:hover { background: rgba(255,255,255,0.22); }
    .prms-avatar {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        background: rgba(255,255,255,0.25);
        border: 1.5px solid rgba(255,255,255,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }
    .prms-profile-name {
        font-size: 0.8rem;
        font-weight: 600;
        color: #fff;
    }
    .prms-dropdown {
        position: absolute;
        top: calc(100% + 8px);
        right: 0;
        background: #fff;
        border: 0.5px solid #e9ecef;
        border-radius: 10px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.12);
        min-width: 140px;
        overflow: hidden;
        z-index: 9999;
        /* Opened/closed dozens of times a session — an instant display
           toggle here reads as broken. Scales in from the trigger corner
           (top-right, where this dropdown actually hangs from) instead of
           the center, since it's a popover anchored to a button, not a
           modal. */
        opacity: 0;
        transform: scale(0.95) translateY(-4px);
        transform-origin: top right;
        transition: opacity 120ms ease-out, transform 120ms ease-out, visibility 120ms;
        visibility: hidden;
        pointer-events: none;
    }
    .prms-dropdown.show {
        opacity: 1;
        transform: scale(1) translateY(0);
        visibility: visible;
        pointer-events: auto;
    }
    .prms-dropdown a {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 10px 14px;
        font-size: 0.875rem;
        font-weight: 600;
        color: #dc3545;
        text-decoration: none;
    }
    .prms-dropdown a:hover { background: #fff5f5; }

    .pc-container { top: 50px !important; }
    .pc-footer { margin-top: 50px !important; }

    .prms-notif-area { position: relative; }
    .prms-notif-toggle {
        position: relative;
        background: none;
        border: none;
        cursor: pointer;
        padding: 6px 8px;
        border-radius: 8px;
        color: rgba(255,255,255,0.85);
        display: flex;
        align-items: center;
        line-height: 1;
        transition: background 0.15s;
    }
    .prms-notif-toggle:hover { background: rgba(255,255,255,0.12); color: #fff; }
    .prms-notif-badge {
        position: absolute;
        top: 2px;
        right: 2px;
        background: #dc3545;
        color: #fff;
        font-size: 0.62rem;
        font-weight: 700;
        min-width: 16px;
        height: 16px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0 3px;
        border: 1.5px solid #1a5276;
    }
    .prms-notif-dropdown {
        position: absolute;
        top: calc(100% + 8px);
        right: 0;
        background: #fff;
        border: 0.5px solid #e9ecef;
        border-radius: 10px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.12);
        width: 340px;
        max-width: 90vw;
        overflow: hidden;
        z-index: 9999;
        opacity: 0;
        transform: scale(0.95) translateY(-4px);
        transform-origin: top right;
        transition: opacity 120ms ease-out, transform 120ms ease-out, visibility 120ms;
        visibility: hidden;
        pointer-events: none;
    }
    .prms-notif-dropdown.show {
        opacity: 1;
        transform: scale(1) translateY(0);
        visibility: visible;
        pointer-events: auto;
    }
    .prms-notif-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px 14px;
        border-bottom: 1px solid #f0f0f0;
        font-size: 0.85rem;
        font-weight: 700;
        color: #333;
    }
    .prms-notif-header a { font-size: 0.75rem; font-weight: 600; color: #0d6efd; text-decoration: none; }
    .prms-notif-list { max-height: 360px; overflow-y: auto; }
    .prms-notif-item {
        display: block;
        padding: 10px 14px;
        border-bottom: 1px solid #f5f5f5;
        text-decoration: none;
        color: inherit;
    }
    .prms-notif-item:hover { background: #f8f9fa; }
    .prms-notif-item.unread { background: #eef6ff; }
    .prms-notif-item.unread:hover { background: #e3f0ff; }
    .prms-notif-title { font-size: 0.82rem; font-weight: 700; color: #222; }
    .prms-notif-msg { font-size: 0.78rem; color: #555; margin-top: 2px; }
    .prms-notif-time { font-size: 0.7rem; color: #999; margin-top: 4px; }
    .prms-notif-empty { padding: 24px 14px; text-align: center; color: #999; font-size: 0.82rem; }
</style>

<div class="prms-topbar">
    <!-- Left: Hamburger -->
    <button class="prms-hamburger" id="sidebar-hide">
        <i class="ti ti-menu-2" style="font-size:1.2rem;"></i>
    </button>

    <!-- Center: Greeting -->
    <div class="prms-greeting">
        <span class="prms-greeting-icon" id="greetIcon"></span>
        <span class="prms-greeting-text">
            <span id="greetText"></span>,&nbsp;<span class="prms-greeting-name"><?= htmlspecialchars($userFirstName) ?>!</span>
        </span>
    </div>

    <!-- Right: Notifications + Profile -->
    <div class="d-flex align-items-center gap-2">
    <?php if (!empty($currentUser['id'])): ?>
    <div class="prms-notif-area">
        <button class="prms-notif-toggle" id="prmsNotifBtn">
            <i class="ti ti-bell" style="font-size:1.15rem;"></i>
            <?php if ($notifUnreadCount > 0): ?>
            <span class="prms-notif-badge"><?= $notifUnreadCount > 9 ? '9+' : $notifUnreadCount ?></span>
            <?php endif; ?>
        </button>
        <div class="prms-notif-dropdown" id="prmsNotifDropdown">
            <div class="prms-notif-header">
                <span>Notifications</span>
                <?php if ($notifUnreadCount > 0): ?>
                <a href="<?= csrfUrl($baseUrl . '/notifications_read.php?all=1&return=' . urlencode($_SERVER['REQUEST_URI'] ?? ($baseUrl . '/dashboard.php'))) ?>">Mark all as read</a>
                <?php endif; ?>
            </div>
            <div class="prms-notif-list">
                <?php if (empty($notifications)): ?>
                <div class="prms-notif-empty"><i class="ti ti-bell-off mb-1" style="font-size:1.3rem;opacity:.4;display:block;"></i>Nothing yet.</div>
                <?php else: foreach ($notifications as $n): ?>
                <a class="prms-notif-item <?= $n['is_read'] ? '' : 'unread' ?>" href="<?= csrfUrl($baseUrl . '/notifications_read.php?id=' . $n['id'] . '&return=' . urlencode($n['link'] ?: $baseUrl . '/dashboard.php')) ?>">
                    <div class="prms-notif-title"><?= htmlspecialchars($n['title']) ?></div>
                    <?php if ($n['message']): ?><div class="prms-notif-msg"><?= htmlspecialchars($n['message']) ?></div><?php endif; ?>
                    <div class="prms-notif-time"><?= prmsTimeAgo($n['created_at']) ?></div>
                </a>
                <?php endforeach; endif; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Profile -->
    <div class="prms-profile-area">
        <button class="prms-profile-toggle" id="prmsProfileBtn">
            <div class="prms-avatar">
                <i class="ti ti-user" style="font-size:0.85rem;color:#fff;"></i>
            </div>
            <span class="prms-profile-name"><?= htmlspecialchars($userFullName ?: 'Guest') ?></span>
            <i class="ti ti-chevron-down" style="font-size:0.65rem;color:rgba(255,255,255,0.7);"></i>
        </button>
        <div class="prms-dropdown" id="prmsProfileDropdown">
            <a href="<?= $baseUrl ?>/logout.php">
                <i class="ti ti-logout" style="font-size:1rem;"></i>
                Logout
            </a>
        </div>
    </div>
    </div>
</div>

<script>
(function(){
    // Greeting by time
    var h = new Date().getHours();
    var greet, icon;
    if (h >= 5 && h < 12)       { greet = 'Good morning';   icon = '🌤️'; }
    else if (h >= 12 && h < 17) { greet = 'Good afternoon'; icon = '☀️'; }
    else if (h >= 17 && h < 21) { greet = 'Good evening';   icon = '🌇'; }
    else                         { greet = 'Good night';     icon = '🌙'; }
    document.getElementById('greetText').textContent = greet;
    document.getElementById('greetIcon').textContent = icon;

    // Dropdown toggle
    var btn = document.getElementById('prmsProfileBtn');
    var dd  = document.getElementById('prmsProfileDropdown');
    if (btn && dd) {
        btn.addEventListener('click', function(e){
            e.stopPropagation();
            dd.classList.toggle('show');
        });
    }

    // Notification dropdown toggle
    var nbtn = document.getElementById('prmsNotifBtn');
    var ndd  = document.getElementById('prmsNotifDropdown');
    if (nbtn && ndd) {
        nbtn.addEventListener('click', function(e){
            e.stopPropagation();
            ndd.classList.toggle('show');
        });
    }

    document.addEventListener('click', function(){
        if (dd) dd.classList.remove('show');
        if (ndd) ndd.classList.remove('show');
    });
})();
</script>

<div class="pc-container">
    <div class="pc-content">