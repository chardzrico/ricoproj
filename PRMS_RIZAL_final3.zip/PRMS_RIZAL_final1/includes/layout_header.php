<?php
// includes/layout_header.php
if (!function_exists('getCurrentUser')) {
    require_once __DIR__ . '/../config/session.php';
}
if (!function_exists('getDBConnection')) {
    require_once __DIR__ . '/../config/database.php';
}
$currentUser = getCurrentUser();
$pageTitle   = $pageTitle ?? 'PRMS';
$baseUrl     = defined('BASE_URL') ? BASE_URL : '';
$assetsUrl   = defined('ASSETS_URL') ? ASSETS_URL : ($baseUrl ? $baseUrl . '/assets' : '/assets');
?>
<!doctype html>
<html lang="en" data-pc-preset="preset-1" data-pc-sidebar-caption="true" data-pc-direction="ltr" dir="ltr" data-pc-theme="light">
<head>
    <title><?= htmlspecialchars($pageTitle) ?> | PRMS</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <link rel="icon" href="<?= $assetsUrl ?>/images/favicon.svg" type="image/x-icon"/>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
    <link rel="stylesheet" href="<?= $assetsUrl ?>/fonts/phosphor/duotone/style.css"/>
    <link rel="stylesheet" href="<?= $assetsUrl ?>/fonts/tabler-icons.min.css"/>
    <link rel="stylesheet" href="<?= $assetsUrl ?>/fonts/feather.css"/>
    <link rel="stylesheet" href="<?= $assetsUrl ?>/fonts/fontawesome.css"/>
    <link rel="stylesheet" href="<?= $assetsUrl ?>/fonts/material.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="<?= $assetsUrl ?>/css/style.css" id="main-style-link"/>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css"/>
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.bootstrap5.min.css"/>
    <style>
        :root {
            --primary-color: #0d6efd;
            --sidebar-bg: #1e3a5f;
            --sidebar-hover: rgba(255, 255, 255, 0.1);
            --sidebar-active: rgba(255, 255, 255, 0.15);
            --text-main: #212529;
            --text-muted: #6c757d;
            --card-shadow: 0 2px 12px rgba(0, 0, 0, 0.05);
            /* Matches the Able Pro template's own .w-sidebar-width (264px,
               baked into assets/css/style.css) — named here so topbar.php's
               fixed offset stays in sync instead of repeating the number. */
            --sidebar-width: 264px;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: #f4f7fa;
            color: var(--text-main);
        }

        /* ── Sidebar Styling ── */
        .pc-sidebar {
            background: var(--sidebar-bg);
            border-right: none;
            box-shadow: 2px 0 10px rgba(0,0,0,0.05);
        }
        .sidebar-brand-text { font-weight: 700; font-size: 1.2rem; color: #fff; letter-spacing: 0.5px; }
        .sidebar-brand-sub { font-size: 0.7rem; opacity: 0.7; color: #fff; text-transform: uppercase; letter-spacing: 1px; }
        
        .pc-navbar > .pc-item > .pc-link {
            padding: 12px 20px;
            font-size: 0.875rem;
            font-weight: 500;
            color: rgba(255, 255, 255, 0.75);
            border-left: 3px solid transparent;
            transition: all 0.2s ease;
        }
        .pc-navbar > .pc-item > .pc-link:hover {
            background: var(--sidebar-hover);
            color: #fff;
        }
        .pc-navbar > .pc-item.active > .pc-link {
            background: var(--sidebar-active);
            color: #fff;
            border-left-color: #fff;
            font-weight: 600;
        }
        .pc-micon { font-size: 1.1rem; margin-right: 12px; width: 20px; text-align: center; }
        .pc-caption { 
            padding: 20px 20px 8px; 
            font-size: 0.65rem; 
            font-weight: 700; 
            text-transform: uppercase; 
            color: rgba(255, 255, 255, 0.4); 
            letter-spacing: 1.2px;
        }

        /* ── Header Styling ── */
        .pc-header {
            top: 0 !important;
            height: 44px !important;
            min-height: 44px !important;
            background: #fff !important;
            border-bottom: 1px solid #e9ecef;
            box-shadow: 0 1px 4px rgba(0,0,0,0.06);
        }
        .header-wrapper {
            height: 44px !important;
        }
        /* Push content up to match the new smaller header */
        .pc-container {
            top: 44px !important;
            min-height: calc(100vh - 105px) !important;
        }
        .pc-footer {
            margin-top: 44px !important;
        }
        .pc-head-link {
            color: var(--text-main);
            padding: 0.25rem 0.5rem;
            border-radius: 8px;
            transition: background 0.2s;
        }
        .pc-head-link:hover { background: #f8f9fa; }

        /* ── Card & Content Styling ── */
        .card {
            border: none;
            border-radius: 12px;
            box-shadow: var(--card-shadow);
            margin-bottom: 24px;
            transition: transform 150ms ease-out, box-shadow 150ms ease-out;
        }
        /* renderStatCards() wraps a card in <a class="text-decoration-none">
           when it's given a 'link' — otherwise there's no visual cue at all
           that a stat card is clickable until the cursor happens to be over
           it and the browser shows a pointer. */
        a.text-decoration-none:hover .card {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(0,0,0,0.1);
        }
        .card-header {
            background: #fff;
            border-bottom: 1px solid #f0f0f0;
            padding: 18px 24px;
            border-radius: 12px 12px 0 0 !important;
        }
        .card-body { padding: 24px; }
        .section-title { font-weight: 700; font-size: 1.1rem; color: var(--sidebar-bg); margin: 0; }

        /* ── Table Styling ── */
        .table thead th {
            background: #f8f9fa;
            font-weight: 600;
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            color: var(--text-muted);
            border-bottom: 2px solid #e9ecef;
            padding: 12px 16px;
        }
        .table td {
            padding: 14px 16px;
            vertical-align: middle;
            font-size: 0.875rem;
            border-bottom: 1px solid #f0f0f0;
        }

        /* ── Stat Cards ── */
        .stat-card {
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 16px;
        }
        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
        }
        .stat-label { font-size: 0.8rem; color: var(--text-muted); font-weight: 500; margin-bottom: 2px; }
        .stat-value { font-size: 1.5rem; font-weight: 700; color: var(--text-main); line-height: 1; }

        /* ── Buttons ──
           Bootstrap's own .btn transition list is color/background/border/
           box-shadow only — it deliberately excludes transform, so a hover
           lift or press feedback added on top needs its own transition or
           it just snaps. 150ms/ease-out keeps it under the button-feedback
           budget (100-160ms) while still reading as smooth. */
        .btn { border-radius: 8px; font-weight: 500; padding: 8px 16px; font-size: 0.875rem; transition: transform 150ms ease-out, background-color 150ms ease-out, box-shadow 150ms ease-out; }
        .btn-sm { padding: 5px 12px; font-size: 0.8rem; }
        .btn:active { transform: scale(0.97); }
        .btn-primary { background: var(--primary-color); border: none; box-shadow: 0 2px 6px rgba(13, 110, 253, 0.2); }
        .btn-primary:hover { background: #0b5ed7; transform: translateY(-1px); }
        .btn-primary:active { transform: scale(0.97); }

        /* ── Alignment Utilities ── */
        .text-align-center { text-align: center; }
        .text-align-right { text-align: right; }
        .flex-center { display: flex; align-items: center; justify-content: center; }
        .flex-between { display: flex; align-items: center; justify-content: space-between; }

        /* ── MODAL GLOBAL STYLES ── */
        .modal-header {
            background: linear-gradient(135deg, #1e3a5f 0%, #2563a8 100%);
            color: #fff;
            border-bottom: none;
            border-radius: 12px 12px 0 0;
            padding: 1rem 1.4rem;
        }
        .modal-header .modal-title { font-weight: 600; font-size: 1rem; }
        .modal-header .btn-close-white { filter: brightness(0) invert(1); opacity: .8; }
        .modal-content {
            border: none;
            border-radius: 14px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.18);
        }
        .modal-body { padding: 1.4rem 1.5rem 0.5rem; }
        .modal-footer {
            border-top: 1px solid #e9ecef;
            padding: 1rem 1.5rem;
            border-radius: 0 0 14px 14px;
            background: #f8f9fa;
        }
        /* Section headers inside modal body */
        .modal-section-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid #e9ecef;
        }
        .modal-section-icon {
            width: 30px; height: 30px;
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            flex-shrink: 0;
        }
        .modal-section-header h6 {
            margin: 0;
            font-weight: 700;
            color: #1e3a5f;
            font-size: .9rem;
        }
        /* Ensure backdrop is always on top of content */
        .modal-backdrop { z-index: 1040; }
        .modal          { z-index: 1050; }
        /* Modal open/close. Deliberately asymmetric: entrance settles in
           with a strong custom ease-out (opening is occasional, worth a
           beat of polish); exit snaps faster since the user has already
           decided to leave and shouldn't wait on it. Each state declares
           its own transition rather than sharing one, so opening and
           closing genuinely use different timing, not just different
           transforms. (Bootstrap's own opacity/backdrop fade is untouched
           here — this rule only ever changed transform, so the old
           "opacity .2s" in the transition list never did anything.) */
        .modal.fade .modal-dialog { transform: translateY(-16px) scale(0.97); transition: transform 150ms cubic-bezier(0.4, 0, 1, 1); }
        .modal.show .modal-dialog { transform: translateY(0) scale(1); transition: transform 220ms cubic-bezier(0.23, 1, 0.32, 1); }
    </style>
</head>
<body>
<noscript><style>html body{opacity:1 !important;}</style></noscript>
<div class="loader-bg fixed inset-0 bg-white dark:bg-themedark-cardbg z-[1034]">
    <div class="loader-track h-[5px] w-full inline-block absolute overflow-hidden top-0">
        <div class="loader-fill w-[300px] h-[5px] bg-primary-500 absolute top-0 left-0 animate-[hitZak_0.6s_ease-in-out_infinite_alternate]"></div>
    </div>
</div>

<!-- ══════════ SIDEBAR ══════════ -->
<nav class="pc-sidebar">
    <div class="navbar-wrapper">
        <div class="m-header flex items-center py-4 px-4 h-header-height">
            <a href="<?= $baseUrl ?>/dashboard.php" class="b-brand flex items-center gap-3">
                <div style="width:42px;height:42px;min-width:42px;border-radius:50%;background:#fff;border:2px solid rgba(255,255,255,0.6);overflow:hidden;display:flex;align-items:center;justify-content:center;">
                    <img src="<?= $assetsUrl ?>/images/rhu_logo.png" alt="RHU Rizal logo" style="width:100%;height:100%;object-fit:cover;display:block;">
                </div>
                <div class="logo logo-lg">
                    <div class="sidebar-brand-text">PRMS</div>
                    <div class="sidebar-brand-sub">RHU Rizal</div>
                </div>
            </a>
        </div>

        <div class="navbar-content h-[calc(100vh_-_74px)] py-2.5">
            <ul class="pc-navbar">
                <li class="pc-item pc-caption"><label>Main Navigation</label></li>
                <li class="pc-item">
                    <a href="<?= $baseUrl ?>/dashboard.php" class="pc-link">
                        <span class="pc-micon"><i data-feather="home"></i></span>
                        <span class="pc-mtext">Dashboard</span>
                    </a>
                </li>
                <li class="pc-item">
                    <a href="<?= $baseUrl ?>/patients.php" class="pc-link">
                        <span class="pc-micon"><i data-feather="users"></i></span>
                        <span class="pc-mtext">Patients</span>
                    </a>
                </li>
                <li class="pc-item">
                    <a href="<?= $baseUrl ?>/modules/checkups/consultation_notes.php" class="pc-link">
                        <span class="pc-micon"><i data-feather="clipboard"></i></span>
                        <span class="pc-mtext">Consultation (ITR)</span>
                    </a>
                </li>
                <li class="pc-item">
                    <a href="<?= $baseUrl ?>/modules/checkups/patient_history.php" class="pc-link">
                        <span class="pc-micon"><i data-feather="file-text"></i></span>
                        <span class="pc-mtext">Patient History</span>
                    </a>
                </li>
                <li class="pc-item">
                    <a href="<?= $baseUrl ?>/modules/checkups/referrals.php" class="pc-link">
                        <span class="pc-micon"><i data-feather="send"></i></span>
                        <span class="pc-mtext">Referrals / Lab Orders</span>
                    </a>
                </li>
                <li class="pc-item">
                    <a href="<?= $baseUrl ?>/modules/community/households.php" class="pc-link">
                        <span class="pc-micon"><i data-feather="home"></i></span>
                        <span class="pc-mtext">Households</span>
                    </a>
                </li>

                <li class="pc-item pc-caption"><label>Modules</label></li>
                <li class="pc-item pc-hasmenu">
                    <a href="#!" class="pc-link">
                        <span class="pc-micon"><i data-feather="calendar"></i></span>
                        <span class="pc-mtext">Front Desk</span>
                        <span class="pc-arrow"><i data-feather="chevron-right"></i></span>
                    </a>
                    <ul class="pc-submenu">
                        <li class="pc-item">
                            <a href="<?= $baseUrl ?>/modules/appointments/list.php" class="pc-link">
                                <span class="pc-micon"><i data-feather="calendar"></i></span>
                                <span class="pc-mtext">Appointments</span>
                            </a>
                        </li>
                        <li class="pc-item">
                            <a href="<?= $baseUrl ?>/modules/services/queueing.php" class="pc-link">
                                <span class="pc-micon"><i data-feather="users"></i></span>
                                <span class="pc-mtext">Queueing</span>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="pc-item pc-hasmenu">
                    <a href="#!" class="pc-link">
                        <span class="pc-micon"><i data-feather="activity"></i></span>
                        <span class="pc-mtext">Clinical Services</span>
                        <span class="pc-arrow"><i data-feather="chevron-right"></i></span>
                    </a>
                    <ul class="pc-submenu">
                        <li class="pc-item">
                            <a href="<?= $baseUrl ?>/modules/services/category.php?cat=Medical" class="pc-link">
                                <span class="pc-micon"><i data-feather="activity"></i></span>
                                <span class="pc-mtext">Medical</span>
                            </a>
                        </li>
                        <li class="pc-item">
                            <a href="<?= $baseUrl ?>/modules/services/category.php?cat=Dental" class="pc-link">
                                <span class="pc-micon"><i data-feather="smile"></i></span>
                                <span class="pc-mtext">Dental</span>
                            </a>
                        </li>
                        <li class="pc-item">
                            <a href="<?= $baseUrl ?>/modules/services/category.php?cat=Mental" class="pc-link">
                                <span class="pc-micon"><i data-feather="heart"></i></span>
                                <span class="pc-mtext">Mental</span>
                            </a>
                        </li>
                        <li class="pc-item">
                            <a href="<?= $baseUrl ?>/modules/services/category.php?cat=Physical" class="pc-link">
                                <span class="pc-micon"><i data-feather="zap"></i></span>
                                <span class="pc-mtext">Physical</span>
                            </a>
                        </li>
                        <li class="pc-item">
                            <a href="<?= $baseUrl ?>/modules/certificates/certificate_log.php" class="pc-link">
                                <span class="pc-micon"><i data-feather="award"></i></span>
                                <span class="pc-mtext">Certificates</span>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="pc-item pc-hasmenu">
                    <a href="#!" class="pc-link">
                        <span class="pc-micon"><i data-feather="package"></i></span>
                        <span class="pc-mtext">Medicine</span>
                        <span class="pc-arrow"><i data-feather="chevron-right"></i></span>
                    </a>
                    <ul class="pc-submenu">
                        <li class="pc-item">
                            <a href="<?= $baseUrl ?>/modules/medicine/list.php" class="pc-link">
                                <span class="pc-micon"><i data-feather="package"></i></span>
                                <span class="pc-mtext">Medicine List</span>
                            </a>
                        </li>
                        <li class="pc-item">
                            <a href="<?= $baseUrl ?>/modules/medicine/prescription_log.php" class="pc-link">
                                <span class="pc-micon"><i data-feather="edit-3"></i></span>
                                <span class="pc-mtext">Prescription Log</span>
                            </a>
                        </li>
                    </ul>
                </li>

                <?php if (isAdmin() || hasRole('nurse')): ?>
                <li class="pc-item pc-hasmenu">
                    <a href="#!" class="pc-link">
                        <span class="pc-micon"><i data-feather="bar-chart-2"></i></span>
                        <span class="pc-mtext">Reports</span>
                        <span class="pc-arrow"><i data-feather="chevron-right"></i></span>
                    </a>
                    <ul class="pc-submenu">
                        <li class="pc-item">
                            <a href="<?= $baseUrl ?>/modules/reports/fhsis.php" class="pc-link">
                                <span class="pc-micon"><i data-feather="bar-chart-2"></i></span>
                                <span class="pc-mtext">FHSIS Report</span>
                            </a>
                        </li>
                        <li class="pc-item">
                            <a href="<?= $baseUrl ?>/modules/reports/morbidity.php" class="pc-link">
                                <span class="pc-micon"><i data-feather="activity"></i></span>
                                <span class="pc-mtext">Morbidity Report</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if (isAdmin()): ?>
                <li class="pc-item pc-hasmenu">
                    <a href="#!" class="pc-link">
                        <span class="pc-micon"><i data-feather="shield"></i></span>
                        <span class="pc-mtext">Administration</span>
                        <span class="pc-arrow"><i data-feather="chevron-right"></i></span>
                    </a>
                    <ul class="pc-submenu">
                        <li class="pc-item">
                            <a href="<?= $baseUrl ?>/modules/admin/users.php" class="pc-link">
                                <span class="pc-micon"><i data-feather="users"></i></span>
                                <span class="pc-mtext">User Management</span>
                            </a>
                        </li>
                        <li class="pc-item">
                            <a href="<?= $baseUrl ?>/modules/admin/audit_log.php" class="pc-link">
                                <span class="pc-micon"><i data-feather="shield"></i></span>
                                <span class="pc-mtext">Audit Log</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <!--
                    vaccination and nutritional are pulled from navigation again
                    on purpose — pending the capstone adviser's go/no-go on
                    whether these belong in the system at all. Files, schema,
                    audit logging, and doctor-scope guards are all intact and
                    working in /modules/vaccination/ and /modules/nutritional/;
                    this is just a nav-visibility toggle — re-add a "Vaccination"
                    caption linking immunization_record.php / schedule.php /
                    vaccine_list.php, and a "Nutritional Status" caption linking
                    growth_recording.php / monthly_tracking.php /
                    status_assessment.php, once decided.
                    (medicine/prescriptions, admin/users + audit log, and
                    appointments/queueing remain re-enabled above.
                    modules/services/patient_services.php and modules/services/list.php
                    were superseded by modules/services/category.php and have been
                    deleted — their functionality lives in category.php now)
                -->
            </ul>
        </div>
    </div>
</nav>
<!-- ══════════ END SIDEBAR ══════════ -->
<script>
// Auto-expand whichever collapsible sidebar group (.pc-hasmenu/.pc-submenu,
// template-provided) contains the current page, and mark it active. Runs
// before the template's own script.js menu_click() (registered later, in
// layout_footer.php), which hides every .pc-submenu not already flagged
// .pc-trigger — so this has to run first to keep the right group open.
//
// Written separately from the template's own active-link detection because
// that one compares full link.href against the current URL with the query
// string stripped off only the CURRENT page, not the link itself — so it
// silently never matches links like category.php?cat=Medical (Clinical
// Services). Comparing pathname+search on both sides fixes that.
document.addEventListener('DOMContentLoaded', function () {
    var current = window.location.pathname + window.location.search;
    var links = document.querySelectorAll('.pc-navbar .pc-submenu a.pc-link');
    for (var i = 0; i < links.length; i++) {
        if (links[i].pathname + links[i].search !== current) continue;
        var subItem = links[i].closest('li.pc-item');
        if (subItem) subItem.classList.add('active');
        var submenu = links[i].closest('ul.pc-submenu');
        if (submenu) {
            submenu.style.display = 'block';
            var group = submenu.closest('li.pc-hasmenu');
            if (group) {
                group.classList.add('pc-trigger');
                group.classList.add('active');
            }
        }
        break;
    }
});
</script>