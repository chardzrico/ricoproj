<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';
requirePatientOnly();

$conn = getDBConnection();
$currentUser = getCurrentUser();

$stmt = $conn->prepare("SELECT * FROM patients WHERE user_id = ? LIMIT 1");
$stmt->bind_param('i', $currentUser['id']);
$stmt->execute();
$patient = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$patient) {
    $conn->close();
    header('Location: ' . BASE_URL . '/patient/portal.php');
    exit;
}
$patientId = (int)$patient['id'];

// ── Fetch this patient's service history ─────────────────────────────────────
// Note: injury_map (medico-legal) and odontogram (dental chart) are staff-only
// clinical/legal artifacts and are intentionally not selected or shown here.
$services = [];
$stmt = $conn->prepare("
    SELECT ps.id, ps.service_date, ps.notes, ps.status, ps.created_at,
           s.service_name, s.category,
           u.full_name as administered_by_name
    FROM patient_services ps
    JOIN services s ON s.id = ps.service_id
    LEFT JOIN users u ON u.id = ps.administered_by
    WHERE ps.patient_id = ?
    ORDER BY COALESCE(ps.service_date, ps.created_at) DESC, ps.id DESC
");
$stmt->bind_param('i', $patientId);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $services[] = $row;
$stmt->close();

$conn->close();

$pageTitle = 'My Services';
include __DIR__ . '/includes/patient_header.php';
include __DIR__ . '/../includes/topbar.php';

$statusBadge = [
    'pending'   => 'bg-warning text-dark',
    'done'      => 'bg-success',
    'cancelled' => 'bg-secondary',
];
$categoryColor = [
    'Dental'   => ['bg' => '#e3f2fd', 'color' => '#1565c0', 'icon' => 'ti-mood-smile'],
    'Physical' => ['bg' => '#e8f5e9', 'color' => '#2e7d32', 'icon' => 'ti-run'],
    'Mental'   => ['bg' => '#f3e5f5', 'color' => '#7b1fa2', 'icon' => 'ti-heart'],
    'Medical'  => ['bg' => '#fff3e0', 'color' => '#e65100', 'icon' => 'ti-stethoscope'],
];
?>

<!-- ══ Breadcrumb ══ -->
<div class="page-header">
    <div class="page-block">
        <div class="row align-items-center">
            <div class="col-md-12">
                <h5 class="m-b-10">My Services</h5>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/patient/portal.php">Home</a></li>
                    <li class="breadcrumb-item active">My Services</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0">
            <i class="ti ti-activity me-2" style="color:#0d6efd;"></i>Service History
        </h6>
        <a href="<?= BASE_URL ?>/patient/appointments.php?action=request" class="btn btn-primary btn-sm">
            <i class="ti ti-calendar-plus me-1"></i>Request a Service
        </a>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0" style="font-size:.88rem;">
                <thead>
                    <tr>
                        <th>Category</th>
                        <th>Service</th>
                        <th>Date</th>
                        <th>Administered By</th>
                        <th>Notes</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($services)): ?>
                    <tr><td colspan="6" class="text-center text-muted py-4">You have no service records yet.</td></tr>
                    <?php else: foreach ($services as $s): $cat = $categoryColor[$s['category']] ?? ['bg' => '#f5f5f5', 'color' => '#555', 'icon' => 'ti-activity']; ?>
                    <tr>
                        <td>
                            <span class="badge rounded-pill" style="background:<?= $cat['bg'] ?>;color:<?= $cat['color'] ?>;font-weight:600;">
                                <i class="ti <?= $cat['icon'] ?> me-1"></i><?= htmlspecialchars($s['category']) ?>
                            </span>
                        </td>
                        <td class="fw-semibold"><?= htmlspecialchars($s['service_name']) ?></td>
                        <td><?= $s['service_date'] ? date('M d, Y', strtotime($s['service_date'])) : date('M d, Y', strtotime($s['created_at'])) ?></td>
                        <td><?= htmlspecialchars($s['administered_by_name'] ?: 'RHU Staff') ?></td>
                        <td style="max-width:220px;">
                            <div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= htmlspecialchars($s['notes'] ?? '') ?>">
                                <?= htmlspecialchars($s['notes'] ?: '—') ?>
                            </div>
                        </td>
                        <td><span class="badge <?= $statusBadge[$s['status']] ?? 'bg-secondary' ?>"><?= ucfirst($s['status']) ?></span></td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../includes/layout_footer.php'; ?>
