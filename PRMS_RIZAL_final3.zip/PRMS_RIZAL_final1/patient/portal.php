<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/auth.php';
requirePatientOnly();

$conn = getDBConnection();
$currentUser = getCurrentUser();

// ── Load this patient's record ──────────────────────────────────────────────
$stmt = $conn->prepare("SELECT * FROM patients WHERE user_id = ? LIMIT 1");
$stmt->bind_param('i', $currentUser['id']);
$stmt->execute();
$patient = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$patient) {
    // Safety net: a patient-role account somehow has no linked patient record.
    $conn->close();
    $pageTitle = 'My Dashboard';
    include __DIR__ . '/includes/patient_header.php';
    include __DIR__ . '/../includes/topbar.php';
    echo '<div class="alert alert-danger">We could not find a patient record linked to your account. Please contact RHU staff for assistance.</div>';
    include __DIR__ . '/../includes/layout_footer.php';
    exit;
}

$patientId = (int)$patient['id'];

// ── Stats (drafts are staff-side works-in-progress, never shown to patients) ─
$totalConsultations = 0;
$visitsThisYear      = 0;
$lastVisitDate        = null;

$r = $conn->prepare("SELECT COUNT(*) as cnt FROM checkups WHERE patient_id = ? AND status != 'draft'");
$r->bind_param('i', $patientId);
$r->execute();
$totalConsultations = (int)($r->get_result()->fetch_assoc()['cnt'] ?? 0);
$r->close();

$r = $conn->prepare("SELECT COUNT(*) as cnt FROM checkups WHERE patient_id = ? AND status != 'draft' AND YEAR(checkup_date) = YEAR(CURDATE())");
$r->bind_param('i', $patientId);
$r->execute();
$visitsThisYear = (int)($r->get_result()->fetch_assoc()['cnt'] ?? 0);
$r->close();

$r = $conn->prepare("SELECT checkup_date FROM checkups WHERE patient_id = ? AND status != 'draft' ORDER BY checkup_date DESC, id DESC LIMIT 1");
$r->bind_param('i', $patientId);
$r->execute();
$row = $r->get_result()->fetch_assoc();
$lastVisitDate = $row['checkup_date'] ?? null;
$r->close();

// ── The single most relevant appointment to surface on arrival: a pending
//    request awaiting review, or the nearest upcoming approved visit. This
//    is the whole reason the appointments system exists — it shouldn't be
//    invisible unless the patient thinks to click "My Appointments" first.
$upcomingAppointment = null;
$r = $conn->prepare("
    SELECT category, status, preferred_date, scheduled_date, scheduled_time
    FROM appointments
    WHERE patient_id = ? AND (status = 'pending' OR (status = 'approved' AND scheduled_date >= CURDATE()))
    ORDER BY FIELD(status,'pending','approved'), COALESCE(scheduled_date, preferred_date) ASC
    LIMIT 1
");
$r->bind_param('i', $patientId);
$r->execute();
$upcomingAppointment = $r->get_result()->fetch_assoc() ?: null;
$r->close();

// ── Nearest upcoming immunization dose, if any ──────────────────────────────
$upcomingDose = null;
$r = $conn->prepare("
    SELECT v.vaccine_name, ir.next_dose_date
    FROM immunization_records ir
    JOIN vaccines v ON v.id = ir.vaccine_id
    WHERE ir.patient_id = ? AND ir.next_dose_date IS NOT NULL AND ir.next_dose_date >= CURDATE()
    ORDER BY ir.next_dose_date ASC
    LIMIT 1
");
$r->bind_param('i', $patientId);
$r->execute();
$upcomingDose = $r->get_result()->fetch_assoc() ?: null;
$r->close();

// ── Active (not yet dispensed) prescriptions ────────────────────────────────
$activeRxCount = 0;
$r = $conn->prepare("SELECT COUNT(*) as cnt FROM prescriptions WHERE patient_id = ? AND status = 'active'");
$r->bind_param('i', $patientId);
$r->execute();
$activeRxCount = (int)($r->get_result()->fetch_assoc()['cnt'] ?? 0);
$r->close();

// ── Certificates issued but not yet printed/downloaded ──────────────────────
$unprintedCertCount = 0;
$r = $conn->prepare("SELECT COUNT(*) as cnt FROM medical_certificates WHERE patient_id = ? AND status = 'active' AND printed_at IS NULL");
$r->bind_param('i', $patientId);
$r->execute();
$unprintedCertCount = (int)($r->get_result()->fetch_assoc()['cnt'] ?? 0);
$r->close();

// ── Recent consultations (ITR history) ───────────────────────────────────────
$consultations = [];
$stmt = $conn->prepare("
    SELECT id, checkup_date, checkup_time, nature_of_visit, chief_complaint, diagnosis, follow_up_date, status
    FROM checkups
    WHERE patient_id = ? AND status != 'draft'
    ORDER BY checkup_date DESC, id DESC
    LIMIT 10
");
$stmt->bind_param('i', $patientId);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $consultations[] = $row;
$stmt->close();
$conn->close();

$pageTitle = 'My Dashboard';
include __DIR__ . '/includes/patient_header.php';
include __DIR__ . '/../includes/topbar.php';

$statusBadge = [
    'pending'   => 'bg-warning text-dark',
    'completed' => 'bg-success',
    'cancelled' => 'bg-secondary',
];
?>

<!-- ══ Breadcrumb ══ -->
<div class="page-header">
    <div class="page-block">
        <div class="row align-items-center">
            <div class="col-md-12">
                <h5 class="m-b-10">My Dashboard</h5>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/patient/portal.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- ══ Welcome / Patient Info ══ -->
<div class="card mb-4" style="border-left:4px solid #0d6efd;">
    <div class="card-body d-flex flex-wrap align-items-center justify-content-between gap-3">
        <div class="d-flex align-items-center gap-3">
            <div style="width:48px;height:48px;border-radius:50%;background:#e3f2fd;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                <i class="ti ti-user" style="color:#0d6efd;font-size:1.4rem;"></i>
            </div>
            <div>
                <h5 class="fw-bold mb-1" style="color:#1e3a5f;">
                    Welcome, <?= htmlspecialchars($patient['first_name']) ?>!
                </h5>
                <p class="text-muted mb-0" style="font-size:.88rem;">
                    Patient No: <span class="fw-semibold"><?= htmlspecialchars($patient['patient_no']) ?></span>
                </p>
            </div>
        </div>
    </div>
</div>

<!-- ══ Upcoming/Pending Appointment ══ -->
<?php if ($upcomingAppointment): ?>
<div class="alert <?= $upcomingAppointment['status'] === 'pending' ? 'alert-warning' : 'alert-info' ?> d-flex align-items-center gap-2 mb-4" role="alert">
    <i class="ti <?= $upcomingAppointment['status'] === 'pending' ? 'ti-clock' : 'ti-calendar-event' ?> fs-5"></i>
    <?php if ($upcomingAppointment['status'] === 'pending'): ?>
    <span>Your <?= htmlspecialchars($upcomingAppointment['category']) ?> appointment request (preferred date: <?= date('M d, Y', strtotime($upcomingAppointment['preferred_date'])) ?>) is awaiting review by RHU staff.</span>
    <?php else: ?>
    <span>Your <?= htmlspecialchars($upcomingAppointment['category']) ?> appointment is scheduled for <strong><?= date('M d, Y', strtotime($upcomingAppointment['scheduled_date'])) ?><?= $upcomingAppointment['scheduled_time'] ? ' at ' . date('h:i A', strtotime($upcomingAppointment['scheduled_time'])) : '' ?></strong>.</span>
    <?php endif; ?>
    <a href="<?= BASE_URL ?>/patient/appointments.php" class="btn btn-sm <?= $upcomingAppointment['status'] === 'pending' ? 'btn-warning' : 'btn-info text-white' ?> ms-auto">View</a>
</div>
<?php endif; ?>

<!-- ══ Upcoming Immunization Dose ══ -->
<?php if ($upcomingDose): ?>
<div class="alert alert-success d-flex align-items-center gap-2 mb-4" role="alert">
    <i class="ti ti-vaccine fs-5"></i>
    <span>Your next <strong><?= htmlspecialchars($upcomingDose['vaccine_name']) ?></strong> dose is due on <strong><?= date('M d, Y', strtotime($upcomingDose['next_dose_date'])) ?></strong>.</span>
    <a href="<?= BASE_URL ?>/patient/immunizations.php" class="btn btn-sm btn-success ms-auto">View</a>
</div>
<?php endif; ?>

<!-- ══ Active Prescriptions ══ -->
<?php if ($activeRxCount > 0): ?>
<div class="alert alert-primary d-flex align-items-center gap-2 mb-4" role="alert">
    <i class="ti ti-pill fs-5"></i>
    <span>You have <strong><?= $activeRxCount ?></strong> active prescription<?= $activeRxCount > 1 ? 's' : '' ?> not yet marked as dispensed.</span>
    <a href="<?= BASE_URL ?>/patient/prescriptions.php" class="btn btn-sm btn-primary ms-auto">View</a>
</div>
<?php endif; ?>

<!-- ══ Certificate Ready ══ -->
<?php if ($unprintedCertCount > 0): ?>
<div class="alert d-flex align-items-center gap-2 mb-4" style="background:#f3e5f5;border:1px solid #e1bee7;color:#6a1b9a;" role="alert">
    <i class="ti ti-certificate fs-5"></i>
    <span>You have <strong><?= $unprintedCertCount ?></strong> medical certificate<?= $unprintedCertCount > 1 ? 's' : '' ?> ready to print or download.</span>
    <a href="<?= BASE_URL ?>/patient/certificates.php" class="btn btn-sm ms-auto" style="background:#8e24aa;color:#fff;">View</a>
</div>
<?php endif; ?>

<!-- ══ Quick Actions ══ -->
<div class="row g-2 mb-4">
    <div class="col-6 col-md-3">
        <a href="<?= BASE_URL ?>/patient/appointments.php?action=request" class="btn btn-primary w-100 d-flex flex-column align-items-center gap-1 py-3">
            <i class="ti ti-calendar-plus fs-4"></i>
            <span style="font-size:.8rem;">Request Appointment</span>
        </a>
    </div>
    <div class="col-6 col-md-3">
        <a href="<?= BASE_URL ?>/patient/prescriptions.php" class="btn btn-outline-primary w-100 d-flex flex-column align-items-center gap-1 py-3">
            <i class="ti ti-pill fs-4"></i>
            <span style="font-size:.8rem;">My Prescriptions</span>
        </a>
    </div>
    <div class="col-6 col-md-3">
        <a href="<?= BASE_URL ?>/patient/immunizations.php" class="btn btn-outline-primary w-100 d-flex flex-column align-items-center gap-1 py-3">
            <i class="ti ti-vaccine fs-4"></i>
            <span style="font-size:.8rem;">My Immunizations</span>
        </a>
    </div>
    <div class="col-6 col-md-3">
        <a href="<?= BASE_URL ?>/patient/services.php" class="btn btn-outline-primary w-100 d-flex flex-column align-items-center gap-1 py-3">
            <i class="ti ti-heart fs-4"></i>
            <span style="font-size:.8rem;">My Services</span>
        </a>
    </div>
</div>

<!-- ══ Stat Cards ══ -->
<div class="row g-3 mb-4">
    <?php
    $cards = [
        ['icon'=>'ti-file-text','color'=>'#1565c0','bg'=>'#e3f2fd','value'=>$totalConsultations,'label'=>'Total Consultations'],
        ['icon'=>'ti-calendar-stats',  'color'=>'#2e7d32','bg'=>'#e8f5e9','value'=>$visitsThisYear,     'label'=>'Visits This Year'],
        ['icon'=>'ti-clock',           'color'=>'#e65100','bg'=>'#fff3e0','value'=>$lastVisitDate ? date('M d, Y', strtotime($lastVisitDate)) : '—','label'=>'Last Visit'],
    ];
    foreach ($cards as $c):
    ?>
    <div class="col-xl-4 col-md-6">
        <div class="card stat-card h-100">
            <div class="card-body d-flex align-items-center gap-3 py-3">
                <div class="stat-icon" style="background:<?= $c['bg'] ?>;flex-shrink:0;">
                    <i class="ti <?= $c['icon'] ?>" style="color:<?= $c['color'] ?>;font-size:1.45rem;"></i>
                </div>
                <div>
                    <div class="fw-bold" style="font-size:1.5rem;color:<?= $c['color'] ?>;line-height:1.1;"><?= htmlspecialchars((string)$c['value']) ?></div>
                    <div class="text-muted" style="font-size:.82rem;"><?= $c['label'] ?></div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- ══ Recent Consultations ══ -->
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0">
            <i class="ti ti-file-text me-2" style="color:#0d6efd;"></i>Recent Consultations
        </h6>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0" style="font-size:.88rem;">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Nature of Visit</th>
                        <th>Chief Complaint</th>
                        <th>Diagnosis</th>
                        <th>Follow-up</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($consultations)): ?>
                    <tr><td colspan="6" class="text-center text-muted py-5">
                        <i class="ti ti-file-text mb-2" style="font-size:2.5rem;opacity:.25;display:block;"></i>
                        You have no consultation records yet.
                    </td></tr>
                    <?php else: foreach ($consultations as $c): ?>
                    <tr>
                        <td>
                            <div><?= date('M d, Y', strtotime($c['checkup_date'])) ?></div>
                            <div class="text-muted" style="font-size:.78rem;"><?= $c['checkup_time'] ? date('h:i A', strtotime($c['checkup_time'])) : '' ?></div>
                        </td>
                        <td><?= htmlspecialchars($c['nature_of_visit'] ?: '—') ?></td>
                        <td style="max-width:180px;"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= htmlspecialchars($c['chief_complaint'] ?? '') ?>"><?= htmlspecialchars($c['chief_complaint'] ?: '—') ?></div></td>
                        <td style="max-width:180px;"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= htmlspecialchars($c['diagnosis'] ?? '') ?>"><?= htmlspecialchars($c['diagnosis'] ?: '—') ?></div></td>
                        <td><?= $c['follow_up_date'] ? date('M d, Y', strtotime($c['follow_up_date'])) : '—' ?></td>
                        <td><span class="badge <?= $statusBadge[$c['status']] ?? 'bg-secondary' ?>"><?= ucfirst($c['status']) ?></span></td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../includes/layout_footer.php'; ?>
