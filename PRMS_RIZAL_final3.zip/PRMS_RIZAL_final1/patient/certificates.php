<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/helpers.php';
requirePatientOnly();

$conn = getDBConnection();
$currentUser = getCurrentUser();
$uid = (int)$currentUser['id'];

$stmt = $conn->prepare("SELECT * FROM patients WHERE user_id = ? LIMIT 1");
$stmt->bind_param('i', $uid);
$stmt->execute();
$patient = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$patient) {
    $conn->close();
    header('Location: ' . BASE_URL . '/patient/portal.php');
    exit;
}
$patientId = (int)$patient['id'];

// ── Fetch this patient's certificates ───────────────────────────────────────
$certificates = [];
$stmt = $conn->prepare("
    SELECT mc.*, u.full_name as issued_by_name
    FROM medical_certificates mc
    LEFT JOIN users u ON u.id = mc.issued_by
    WHERE mc.patient_id = ?
    ORDER BY mc.issued_date DESC, mc.id DESC
");
$stmt->bind_param('i', $patientId);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $certificates[] = $row;
$stmt->close();

// ── Print preview — same stamp-on-first-view pattern as the staff side, but
//    scoped with "AND patient_id = ?" everywhere: a patient must never be
//    able to view another patient's certificate just by changing the id in
//    the URL (the staff version doesn't need this check since staff are
//    already scoped by doctorScopeSql() at the list level, not per-request).
$printData = null;
if (isset($_GET['print']) && is_numeric($_GET['print'])) {
    verifyCsrf();
    $certPrintId = (int)$_GET['print'];
    $stmt = $conn->prepare("UPDATE medical_certificates SET printed_at=NOW(), printed_by=? WHERE id=? AND patient_id=? AND printed_at IS NULL");
    $stmt->bind_param('iii', $uid, $certPrintId, $patientId);
    $stmt->execute();
    $stmt->close();

    $stmt = $conn->prepare("
        SELECT mc.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no, p.date_of_birth, p.gender,
               u.full_name as issued_by_name, u.role, u.license_number
        FROM medical_certificates mc
        LEFT JOIN patients p ON mc.patient_id = p.id
        LEFT JOIN users u ON mc.issued_by = u.id
        WHERE mc.id = ? AND mc.patient_id = ? LIMIT 1
    ");
    $stmt->bind_param('ii', $certPrintId, $patientId);
    $stmt->execute();
    $printData = $stmt->get_result()->fetch_assoc() ?: null;
    if ($printData) logAudit('view_certificate', 'medical_certificate', $certPrintId, $printData['cert_number']);
}
$conn->close();

$pageTitle = 'My Certificates';
include __DIR__ . '/includes/patient_header.php';
include __DIR__ . '/../includes/topbar.php';
?>

<!-- ══ Breadcrumb ══ -->
<div class="page-header">
    <div class="page-block">
        <div class="row align-items-center">
            <div class="col-md-12">
                <h5 class="m-b-10">My Certificates</h5>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/patient/portal.php">Home</a></li>
                    <li class="breadcrumb-item active">My Certificates</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="alert d-flex align-items-center gap-2" style="background:#e3f2fd;border:1px solid #bbdefb;color:#1565c0;border-radius:8px;font-size:.85rem;">
    <i class="ti ti-info-circle fs-5"></i>
    <span>These are medical certificates issued to you by RHU Rizal. You can print or save a copy at any time.</span>
</div>

<?php if (empty($certificates)): ?>
<div class="card">
    <div class="card-body text-center text-muted py-5">
        <i class="ti ti-certificate mb-2" style="font-size:2.5rem;opacity:.3;"></i>
        <div>You have no certificates on record yet.</div>
    </div>
</div>
<?php else: foreach ($certificates as $c): ?>
<div class="card"<?= $c['status'] === 'voided' ? ' style="opacity:.65;"' : '' ?>>
    <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
        <div>
            <h6 class="section-title mb-1">
                <i class="ti ti-certificate me-2" style="color:#0d6efd;"></i><?= htmlspecialchars($c['cert_type']) ?>
            </h6>
            <div class="text-muted" style="font-size:.82rem;">
                Cert #<?= htmlspecialchars($c['cert_number']) ?>
                &bull; Issued <?= date('M d, Y', strtotime($c['issued_date'])) ?>
                &bull; by <?= htmlspecialchars($c['issued_by_name'] ?: 'RHU Staff') ?>
            </div>
        </div>
        <?php if ($c['status'] === 'voided'): ?>
        <span class="badge bg-secondary rounded-pill" style="font-size:.78rem;" title="<?= htmlspecialchars($c['void_reason'] ?: '') ?>">Voided</span>
        <?php else: ?>
        <a href="<?= csrfUrl('certificates.php?print=' . $c['id']) ?>" class="btn btn-primary btn-sm"><i class="ti ti-printer me-1"></i>Print / View</a>
        <?php endif; ?>
    </div>
    <?php if ($c['valid_from'] || $c['valid_until']): ?>
    <div class="card-body py-2" style="font-size:.85rem;">
        <span class="text-muted">Valid:</span>
        <?= $c['valid_from'] ? date('M d, Y', strtotime($c['valid_from'])) : '—' ?>
        to
        <?= $c['valid_until'] ? date('M d, Y', strtotime($c['valid_until'])) : '—' ?>
    </div>
    <?php endif; ?>
</div>
<?php endforeach; endif; ?>

<?php if ($printData): ?>
<!-- Print Preview Modal (auto-opened) -->
<div class="modal fade" id="printModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" style="color:#d5dbe2;"><i class="ti ti-certificate me-2"></i>Medical Certificate — <?= htmlspecialchars($printData['cert_number']) ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" style="background:#e9edf1;padding:24px;">
                <?= renderCertificatePrintHtml($printData) ?>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="printCert()"><i class="ti ti-printer me-1"></i>Print / Save PDF</button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php
$extraJS = '<script>
' . ($printData ? 'window.addEventListener("load",function(){ new bootstrap.Modal(document.getElementById("printModal")).show(); });' : '') . '
function printCert(){
    const content=document.getElementById("certPrintContent").innerHTML;
    const w=window.open("","_blank","width=800,height=700");
    w.document.write(`<!DOCTYPE html><html><head><title>Medical Certificate</title><style>body{font-family:Open Sans,sans-serif;margin:32px;}@media print{body{margin:0;}}</style></head><body>${content}</body></html>`);
    w.document.close();
    w.focus();
    setTimeout(()=>w.print(),500);
}
</script>';
include __DIR__ . '/../includes/layout_footer.php';
?>
