<?php
require_once __DIR__ . '/config/session.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/mail.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . (isPatient() ? '/patient/portal.php' : '/dashboard.php'));
    exit;
}

$error = '';
$sent  = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $email = trim($_POST['email'] ?? '');

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        $conn = getDBConnection();
        $stmt = $conn->prepare("SELECT id, full_name, email FROM users WHERE email = ? AND status = 'active' LIMIT 1");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($user) {
            $token = bin2hex(random_bytes(32));

            // Expiry computed by MySQL itself (NOW() + 1 hour), not PHP's
            // time() — PHP's clock (UTC) and MySQL's clock (server
            // timezone) don't agree, so a PHP-computed timestamp compared
            // later against MySQL's NOW() in reset_password.php would be
            // off by that gap and could read as already-expired.
            $upd = $conn->prepare("UPDATE users SET reset_token = ?, reset_token_expires = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE id = ?");
            $upd->bind_param('si', $token, $user['id']);
            $upd->execute();
            $upd->close();

            $resetLink = BASE_URL . '/reset_password.php?token=' . urlencode($token);
            sendPasswordResetEmail($user['email'], $user['full_name'], $resetLink);
        }
        $conn->close();

        // Same message whether or not the email is registered — otherwise
        // this form becomes a way to check which emails have accounts.
        $sent = true;
    }
}
?>
<!doctype html>
<html lang="en" data-pc-preset="preset-1" data-pc-direction="ltr" dir="ltr" data-pc-theme="light">
<head>
    <title>Forgot Password | PRMS - Patient Record Management System</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <link rel="icon" href="<?= ASSETS_URL ?>/images/favicon.svg" type="image/x-icon"/>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/fonts/tabler-icons.min.css"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/fonts/feather.css"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/fonts/fontawesome.css"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/css/style.css" id="main-style-link"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/css/auth.css"/>
    <style>
        body { margin: 0; padding: 0; }
        .auth-main {
            background: linear-gradient(135deg, #005fdb 0%, #88a7d8 50%, #ffffff 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .auth-wrapper { width: 100%; max-width: 440px; }
        .auth-card { border-radius: 18px; box-shadow: 0 24px 64px rgba(0,0,0,.35); border: none; overflow: hidden; }
        .auth-logo-area {
            background: linear-gradient(135deg, #1e3a5f, #0d6efd);
            padding: 36px 30px 28px;
            text-align: center;
            color: white;
        }
        .rhu-logo-circle {
            width: 88px; height: 88px;
            border-radius: 50%;
            background: #fff;
            border: 3px solid rgba(255,255,255,.85);
            box-shadow: 0 4px 14px rgba(0,0,0,.25);
            margin: 0 auto 18px;
            display: flex; align-items: center; justify-content: center;
            overflow: hidden;
        }
        .rhu-logo-circle img { width: 100%; height: 100%; object-fit: cover; border-radius: 50%; display: block; }
        .prms-badge {
            background: rgba(255,255,255,.2);
            border-radius: 50px; padding: 5px 20px;
            display: inline-block; font-size: .78rem;
            font-weight: 600; letter-spacing: 2px; margin-bottom: 12px;
        }
        .auth-logo-area h2 { font-weight: 700; font-size: 1.7rem; margin-bottom: 4px; }
        .auth-logo-area p  { opacity: .85; font-size: .88rem; margin: 0; }
        .auth-body { padding: 32px 36px 36px; text-align: center; }
        .auth-body .form-group-wrap { text-align: left; }
        .form-control { border-radius: 8px; padding: 12px 16px; border: 1.5px solid #e0e0e0; font-size: .95rem; transition: all .2s; }
        .form-control:focus { border-color: #0d6efd; box-shadow: 0 0 0 3px rgba(13,110,253,.1); }
        .input-group-text { border: 1.5px solid #e0e0e0; background: #f8f9fa; }
        .input-group .form-control { border-right: none; border-radius: 8px 0 0 8px !important; }
        .input-group .input-group-text:first-child { border-right: none; border-radius: 8px 0 0 8px !important; }
        .icon-prefix { border-right: none !important; border-radius: 8px 0 0 8px !important; }
        .field-with-icon { border-left: none !important; border-radius: 0 8px 8px 0 !important; }
        .btn-login {
            background: linear-gradient(135deg, #1e3a5f, #0d6efd);
            border: none; padding: 13px; font-size: 1rem; font-weight: 600;
            border-radius: 10px; letter-spacing: .5px; transition: all .3s;
            width: 100%; color: #fff; margin: 0 auto; display: block;
        }
        .btn-login:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(13,110,253,.4); color: #fff; }
        .error-alert { border-radius: 8px; padding: 12px 16px; background: #fff3f3; border: 1px solid #ffcdd2; color: #c62828; font-size: .9rem; text-align: left; }
        .success-alert { border-radius: 8px; padding: 12px 16px; background: #f0fff4; border: 1px solid #a5d6a7; color: #2e7d32; font-size: .9rem; text-align: left; }
        .label-text { font-weight: 600; font-size: .87rem; color: #444; margin-bottom: 6px; display: block; }
    </style>
</head>
<body>
<noscript><style>html body{opacity:1 !important;}</style></noscript>
<div class="loader-bg fixed inset-0 bg-white z-[1034]">
    <div class="loader-track h-[5px] w-full inline-block absolute overflow-hidden top-0">
        <div class="loader-fill w-[300px] h-[5px] bg-primary-500 absolute top-0 left-0 animate-[hitZak_0.6s_ease-in-out_infinite_alternate]"></div>
    </div>
</div>

<div class="auth-main">
    <div class="floating-shapes" aria-hidden="true" style="position:fixed;inset:0;overflow:hidden;pointer-events:none;z-index:0;">
        <span style="width:300px;height:300px;background:rgba(255,255,255,.05);top:-50px;left:-100px;animation-delay:0s"></span>
        <span style="width:200px;height:200px;background:rgba(255,255,255,.07);bottom:50px;right:-50px;animation-delay:3s"></span>
        <span style="width:100px;height:100px;background:rgba(255,255,255,.05);top:40%;left:10%;animation-delay:1.5s"></span>
    </div>

    <div class="auth-wrapper" style="position:relative;z-index:10;">
        <div class="auth-card card">
            <div class="auth-logo-area">
                <div class="rhu-logo-circle" title="RHU Rizal Logo">
                    <img src="<?= ASSETS_URL ?>/images/rhu_logo.png" alt="Rural Health Unit of Rizal logo">
                </div>
                <div class="prms-badge">
                    <i class="ti ti-activity me-1"></i> PRMS
                </div>
                <h2 style="color: #e0e0e0;">Reset Your Password</h2>
                <p>Rural Health Unit &bull; Rizal</p>
            </div>

            <div class="auth-body">
                <div class="form-group-wrap">
                    <?php if ($sent): ?>
                        <h5 class="fw-bold mb-1" style="color:#1e3a5f;">Check Your Email</h5>
                        <p class="text-muted mb-4" style="font-size:.9rem;">If an account exists for that address, we've sent a link to reset your password. It expires in 1 hour.</p>
                        <div class="success-alert mb-3 d-flex align-items-center gap-2">
                            <i class="ti ti-mail"></i> You can close this page once you've opened the email.
                        </div>
                        <div class="d-flex justify-content-center">
                            <a href="<?= BASE_URL ?>/login.php" class="btn btn-outline-primary" style="border-radius:8px;padding:10px 40px;font-weight:600;">
                                <i class="ti ti-arrow-left me-2"></i>Back to Sign In
                            </a>
                        </div>
                    <?php else: ?>
                        <h5 class="fw-bold mb-1" style="color:#1e3a5f;">Forgot Password?</h5>
                        <p class="text-muted mb-4" style="font-size:.9rem;">Enter the email on your account and we'll send you a reset link.</p>

                        <?php if ($error): ?>
                            <div class="error-alert mb-3 d-flex align-items-center gap-2">
                                <i class="ti ti-alert-circle"></i> <?= htmlspecialchars($error) ?>
                            </div>
                        <?php endif; ?>

                        <form method="POST" action="">
                            <?= csrfField() ?>
                            <div class="mb-4">
                                <label class="label-text">Email Address</label>
                                <div class="input-group">
                                    <span class="input-group-text icon-prefix">
                                        <i class="ti ti-mail" style="color:#0d6efd;"></i>
                                    </span>
                                    <input type="email" class="form-control field-with-icon" name="email"
                                           placeholder="you@example.com"
                                           value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center">
                                <button type="submit" class="btn-login">
                                    <i class="ti ti-send me-2"></i>Send Reset Link
                                </button>
                            </div>
                        </form>

                        <div class="mt-4">
                            <a href="<?= BASE_URL ?>/login.php" class="text-decoration-none fw-semibold" style="font-size:.88rem;color:#0d6efd;">
                                <i class="ti ti-arrow-left me-1"></i>Back to Sign In
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <p class="text-center text-white mt-3" style="font-size:.8rem;opacity:.7;">
            &copy; <?= date('Y') ?> PRMS &bull; Rural Health Unit, Rizal &bull; All rights reserved
        </p>
    </div>
</div>

<script src="<?= ASSETS_URL ?>/js/plugins/popper.min.js"></script>
<script src="<?= ASSETS_URL ?>/js/plugins/feather.min.js"></script>
<script src="<?= ASSETS_URL ?>/js/component.js"></script>
<script src="<?= ASSETS_URL ?>/js/theme.js"></script>
<script src="<?= ASSETS_URL ?>/js/script.js"></script>
<script src="<?= ASSETS_URL ?>/js/page-transitions.js"></script>
<script>
preset_change('preset-1');
main_layout_change('vertical');
</script>
</body>
</html>
