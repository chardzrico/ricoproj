<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();

$conn = getDBConnection();
$msg = '';

// ── DELETE ───────────────────────────────────────────────────────────────
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    verifyCsrf();
    $conn->query("DELETE FROM checkups WHERE id=".(int)$_GET['delete']);
    header('Location: consultation_notes.php?msg=deleted'); exit;
}

// ── ADD / EDIT (single ITR encounter) ───────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $id          = (int)($_POST['id'] ?? 0);
    $patient_id  = (int)($_POST['patient_id'] ?? 0);
    $date        = $_POST['checkup_date'] ?: date('Y-m-d');
    $time        = $_POST['checkup_time'] ?: null;

    // "Save as Draft" skips client-side required checks, but a record still
    // needs to know which patient it belongs to — bounce back with a message
    // instead of hitting the FK constraint on checkups.patient_id.
    if ($patient_id <= 0) {
        header('Location: consultation_notes.php?msg=nopatient'); exit;
    }

    $mode_of_transaction = $_POST['mode_of_transaction'] ?: null;
    $nature_of_visit     = $_POST['nature_of_visit'] ?? null;
    $age_at_visit        = $_POST['age_at_visit'] !== '' ? (int)$_POST['age_at_visit'] : null;
    $sex_at_visit        = $_POST['sex_at_visit'] ?: null;

    $bp      = trim($_POST['blood_pressure'] ?? '');
    $temp    = $_POST['temperature'] !== '' ? $_POST['temperature'] : null;
    $pulse   = $_POST['pulse_rate'] !== '' ? (int)$_POST['pulse_rate'] : null;
    $rr      = $_POST['respiratory_rate'] !== '' ? (int)$_POST['respiratory_rate'] : null;
    $weight  = $_POST['weight'] !== '' ? $_POST['weight'] : null;
    $height  = $_POST['height'] !== '' ? $_POST['height'] : null;
    $spo2    = trim($_POST['oxygen_saturation'] ?? '');

    $chief_complaint = trim($_POST['chief_complaint'] ?? '');
    $history_illness = trim($_POST['history_of_illness'] ?? '');
    $past_hx         = trim($_POST['past_medical_family_history'] ?? '');
    $pertinent_pe    = trim($_POST['pertinent_pe'] ?? '');
    $diagnosis       = trim($_POST['diagnosis'] ?? '');
    $treatment       = trim($_POST['treatment_plan'] ?? '');
    // Diagnosis & treatment are doctor-only to write — admin/nurse/staff can
    // view them but never enter or change them, even if the request is forged.
    if (!isDoctor()) {
        if ($id > 0) {
            $existingStmt = $conn->prepare("SELECT diagnosis, treatment_plan FROM checkups WHERE id=?");
            $existingStmt->bind_param('i', $id);
            $existingStmt->execute();
            $existing = $existingStmt->get_result()->fetch_assoc();
            $existingStmt->close();
            $diagnosis = $existing['diagnosis'] ?? '';
            $treatment = $existing['treatment_plan'] ?? '';
        } else {
            $diagnosis = '';
            $treatment = '';
        }
    }
    $lab_findings    = trim($_POST['laboratory_findings'] ?? '');
    // Follow-up scheduling is an admin action (see appointments/list.php) —
    // the doctor can only flag that a follow-up is needed, not set the date.
    $needs_followup  = isset($_POST['needs_follow_up']) ? 1 : 0;
    // A doctor can be pulled away mid-encounter — "Save as Draft" stores whatever
    // has been entered so far without forcing the record to look finished.
    $status          = (($_POST['save_action'] ?? '') === 'draft') ? 'draft' : ($_POST['status'] ?? 'completed');
    $staff_id        = getCurrentUser()['id'];

    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE checkups SET
            patient_id=?, checkup_date=?, checkup_time=?, mode_of_transaction=?, nature_of_visit=?,
            age_at_visit=?, sex_at_visit=?, blood_pressure=?, temperature=?, pulse_rate=?, respiratory_rate=?,
            weight=?, height=?, oxygen_saturation=?, chief_complaint=?, history_of_illness=?,
            past_medical_family_history=?, pertinent_pe=?, diagnosis=?, treatment_plan=?, laboratory_findings=?,
            needs_follow_up=?, status=?, attending_staff=?
            WHERE id=?");
        $stmt->bind_param('issssissdiiddssssssssisii',
            $patient_id,$date,$time,$mode_of_transaction,$nature_of_visit,
            $age_at_visit,$sex_at_visit,$bp,$temp,$pulse,$rr,
            $weight,$height,$spo2,$chief_complaint,$history_illness,
            $past_hx,$pertinent_pe,$diagnosis,$treatment,$lab_findings,
            $needs_followup,$status,$staff_id,$id);
    } else {
        $stmt = $conn->prepare("INSERT INTO checkups
            (patient_id, checkup_date, checkup_time, mode_of_transaction, nature_of_visit,
             age_at_visit, sex_at_visit, blood_pressure, temperature, pulse_rate, respiratory_rate,
             weight, height, oxygen_saturation, chief_complaint, history_of_illness,
             past_medical_family_history, pertinent_pe, diagnosis, treatment_plan, laboratory_findings,
             needs_follow_up, status, attending_staff)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param('issssissdiiddssssssssisi',
            $patient_id,$date,$time,$mode_of_transaction,$nature_of_visit,
            $age_at_visit,$sex_at_visit,$bp,$temp,$pulse,$rr,
            $weight,$height,$spo2,$chief_complaint,$history_illness,
            $past_hx,$pertinent_pe,$diagnosis,$treatment,$lab_findings,
            $needs_followup,$status,$staff_id);
    }
    $stmt->execute();

    // Doctor assignment used to be a separate action on patients.php; it now
    // happens right here, while the admin is already looking at who's being
    // seen — admin-only, same as before, just relocated.
    if (isAdmin() && isset($_POST['doctor_id'])) {
        $doctorId = $_POST['doctor_id'] !== '' ? (int)$_POST['doctor_id'] : null;
        $docStmt = $conn->prepare("UPDATE patients SET assigned_doctor_id=? WHERE id=?");
        $docStmt->bind_param('ii', $doctorId, $patient_id);
        $docStmt->execute();
        $docStmt->close();
        logAudit('assign_doctor', 'patient', $patient_id, $doctorId ? "doctor_id=$doctorId" : 'unassigned');
    }

    $redirectMsg = ($status === 'draft') ? 'draft' : ($id > 0 ? 'updated' : 'added');
    header('Location: consultation_notes.php?msg=' . $redirectMsg); exit;
}

// ── FETCH ────────────────────────────────────────────────────────────────
$patients = [];
$r = $conn->query("SELECT id, patient_no, folder_number, tn_number, date_of_birth, estimated_age, is_dob_estimated, gender, address, assigned_doctor_id, CONCAT(first_name,' ',last_name) as name FROM patients WHERE status='active'" . doctorScopeSql() . " ORDER BY last_name");
while ($row = $r->fetch_assoc()) $patients[] = $row;

// Only relevant to admins (see the assign_doctor block above), but cheap
// enough to just fetch unconditionally and gate the dropdown in the view.
$doctors = [];
$r = $conn->query("SELECT id, full_name FROM users WHERE role='doctor' AND status='active' ORDER BY full_name");
while ($row = $r->fetch_assoc()) $doctors[] = $row;

$records = [];
$r = $conn->query("SELECT c.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no, p.folder_number, u.full_name as staff_name
                    FROM checkups c
                    LEFT JOIN patients p ON c.patient_id = p.id
                    LEFT JOIN users u ON c.attending_staff = u.id
                    ORDER BY FIELD(c.status,'draft') DESC, c.checkup_date DESC, c.id DESC LIMIT 100");
while ($row = $r->fetch_assoc()) $records[] = $row;
$conn->close();

if (isset($_GET['msg'])) { $msg = ['added'=>'ITR consultation saved.','updated'=>'ITR consultation updated.','draft'=>'Saved as draft — you can finish this entry later.','deleted'=>'Record deleted.','nopatient'=>'Please select a patient before saving — even a draft needs to be linked to someone.'][$_GET['msg']] ?? ''; }
$msgType = ($_GET['msg'] ?? '') === 'nopatient' ? 'danger' : 'success';
$draftCount = 0;
foreach ($records as $rec) { if ($rec['status'] === 'draft') $draftCount++; }
$pageTitle = 'Consultation (ITR)';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<div class="page-header"><div class="page-block">
    <h5 class="m-b-10">Consultation &mdash; Individual Treatment Record (ITR)</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item active">Consultation (ITR)</li></ul>
</div></div>

<?php if ($msg): ?><div class="alert alert-<?= $msgType ?> alert-dismissible fade show"><i class="ti ti-circle-check me-2"></i><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h6 class="section-title mb-0">
            <i class="ti ti-file-text me-2" style="color:#0d6efd;"></i>Consultation Records
            <?php if ($draftCount > 0): ?>
            <span class="badge bg-warning text-dark ms-2" style="font-weight:600;"><?= $draftCount ?> draft<?= $draftCount > 1 ? 's' : '' ?> awaiting completion</span>
            <?php endif; ?>
        </h6>
        <button class="btn btn-primary btn-sm" onclick="openAddModal()">
            <i class="ti ti-plus me-1"></i>New ITR Entry
        </button>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0">
                <thead><tr><th>Patient</th><th>Folder No.</th><th>Date / Time</th><th>Nature of Visit</th><th>Chief Complaint</th><th>Diagnosis</th><th>Status</th><th>Staff</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php foreach ($records as $rec): $isDraft = $rec['status'] === 'draft'; ?>
                    <tr<?= $isDraft ? ' style="background:#fffbea;"' : '' ?>>
                        <td>
                            <div class="fw-semibold" style="font-size:.88rem;"><?= htmlspecialchars($rec['patient_name'] ?? '') ?></div>
                            <div class="text-muted" style="font-size:.78rem;"><?= htmlspecialchars($rec['patient_no'] ?? '') ?></div>
                        </td>
                        <td><?= htmlspecialchars($rec['folder_number'] ?: '—') ?></td>
                        <td>
                            <div><?= date('M d, Y', strtotime($rec['checkup_date'])) ?></div>
                            <div class="text-muted" style="font-size:.78rem;"><?= $rec['checkup_time'] ? date('h:i A', strtotime($rec['checkup_time'])) : '' ?></div>
                        </td>
                        <td><?= htmlspecialchars($rec['nature_of_visit'] ?: '—') ?></td>
                        <td style="max-width:160px;"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= htmlspecialchars($rec['chief_complaint'] ?? '') ?>"><?= htmlspecialchars($rec['chief_complaint'] ?: '—') ?></div></td>
                        <td style="max-width:160px;"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= htmlspecialchars($rec['diagnosis'] ?? '') ?>"><?= htmlspecialchars($rec['diagnosis'] ?: '—') ?></div></td>
                        <td>
                            <span class="badge <?= $isDraft ? 'bg-warning text-dark' : ($rec['status']==='completed' ? 'bg-success' : ($rec['status']==='pending' ? 'bg-warning text-dark' : 'bg-secondary')) ?>"><?= $isDraft ? '<i class="ti ti-pencil me-1"></i>Draft' : ucfirst($rec['status']) ?></span>
                            <?php if (!empty($rec['needs_follow_up'])): ?><span class="badge bg-info bg-opacity-15 text-info mt-1 d-block" title="Doctor flagged this for follow-up — admin schedules the date under Appointments"><i class="ti ti-calendar-plus me-1"></i>Follow-up flagged</span><?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($rec['staff_name'] ?: '—') ?></td>
                        <td>
                            <button class="btn-edit btn btn-sm me-1" onclick='openEditModal(<?= htmlspecialchars(json_encode($rec), ENT_QUOTES) ?>)' title="<?= $isDraft ? 'Resume draft' : 'Edit' ?>"><i class="ti <?= $isDraft ? 'ti-player-play' : 'ti-edit' ?>"></i></button>
                            <button class="btn-delete btn btn-sm" onclick="confirmDelete('<?= csrfUrl('consultation_notes.php?delete=' . $rec['id']) ?>','this record')"><i class="ti ti-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ══════════════════════ ITR MODAL (mirrors the paper form) ══════════════════════ -->
<div class="modal fade" id="consModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="consModalTitle" style="color:#fff;"><i class="ti ti-file-text me-2" style="color:#fff;"></i>New ITR Entry</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <?= csrfField() ?>
                <input type="hidden" name="id" id="consId" value="0">
                <div class="modal-body" style="max-height:72vh;overflow-y:auto;">

                    <!-- Section: Patient / Folder identity (read-only reference, from Patients CRUD) -->
                    <div class="mb-3">
                        <div class="d-flex align-items-center mb-3">
                            <div style="width:28px;height:28px;border-radius:50%;background:#e3f2fd;display:flex;align-items:center;justify-content:center;margin-right:10px;">
                                <i class="ti ti-user-check" style="color:#0d6efd;font-size:.9rem;"></i>
                            </div>
                            <h6 class="mb-0 fw-bold" style="color:#1e3a5f;">Patient / Folder</h6>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Patient (Last Name, First Name, Middle Name) <span class="text-danger">*</span></label>
                                <select class="form-select" name="patient_id" id="cPatient" required onchange="fillPatientRef()">
                                    <option value="">Select Patient</option>
                                    <?php foreach ($patients as $p): ?><option
                                        value="<?= $p['id'] ?>"
                                        data-folder="<?= htmlspecialchars($p['folder_number'] ?? '') ?>"
                                        data-tn="<?= htmlspecialchars($p['tn_number'] ?? '') ?>"
                                        data-address="<?= htmlspecialchars($p['address'] ?? '') ?>"
                                        data-gender="<?= htmlspecialchars($p['gender'] ?? '') ?>"
                                        data-dob="<?= htmlspecialchars($p['date_of_birth'] ?? '') ?>"
                                        data-estage="<?= htmlspecialchars($p['estimated_age'] ?? '') ?>"
                                        data-dobest="<?= (int)$p['is_dob_estimated'] ?>"
                                        data-doctor="<?= (int)($p['assigned_doctor_id'] ?? 0) ?>"
                                    ><?= htmlspecialchars($p['patient_no'].' - '.$p['name']) ?></option><?php endforeach; ?>
                                </select>
                            </div>
                            <?php if (isAdmin()): ?>
                            <div class="col-md-2">
                                <label class="form-label">Assign Doctor</label>
                                <select class="form-select" name="doctor_id" id="cDoctor" title="Sets this patient's assigned doctor">
                                    <option value="">— Unassigned —</option>
                                    <?php foreach ($doctors as $d): ?>
                                    <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['full_name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php endif; ?>
                            <div class="col-md-2"><label class="form-label">Folder Number</label><input type="text" class="form-control bg-light" id="cFolderNo" readonly></div>
                            <div class="col-md-2"><label class="form-label">TN #</label><input type="text" class="form-control bg-light" id="cTnNo" readonly></div>
                            <div class="col-md-2"><label class="form-label">Date of Birth</label><input type="text" class="form-control bg-light" id="cDobRef" readonly></div>
                            <div class="col-12"><label class="form-label">Complete Address</label><input type="text" class="form-control bg-light" id="cAddressRef" readonly></div>
                        </div>
                    </div>

                    <hr class="my-3">

                    <!-- Section: Mode of transaction / nature of visit -->
                    <div class="mb-3">
                        <div class="d-flex align-items-center mb-3">
                            <div style="width:28px;height:28px;border-radius:50%;background:#e8f5e9;display:flex;align-items:center;justify-content:center;margin-right:10px;">
                                <i class="ti ti-clipboard-list" style="color:#2e7d32;font-size:.9rem;"></i>
                            </div>
                            <h6 class="mb-0 fw-bold" style="color:#1e3a5f;">Mode of Transaction / Nature of Visit</h6>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-3">
                                <label class="form-label">Mode of Transaction</label>
                                <select class="form-select" name="mode_of_transaction" id="cMode">
                                    <option value="">Select</option>
                                    <option value="Walk-in">Walk-in</option>
                                    <option value="Visited">Visited</option>
                                    <option value="Referral">Referral</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Date of Consultation *</label>
                                <input type="date" class="form-control" name="checkup_date" id="cDate" value="<?= date('Y-m-d') ?>" required>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Time</label>
                                <input type="time" class="form-control" name="checkup_time" id="cTime" value="<?= date('H:i') ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Age</label>
                                <input type="number" min="0" max="130" class="form-control" name="age_at_visit" id="cAge" placeholder="Age">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Sex</label>
                                <select class="form-select" name="sex_at_visit" id="cSex">
                                    <option value="">—</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Nature of Visit</label><br>
                                <div class="btn-group" role="group">
                                    <input type="radio" class="btn-check" name="nature_of_visit" id="cNatureNew" value="New Consultation" autocomplete="off">
                                    <label class="btn btn-outline-primary btn-sm" for="cNatureNew">New Consultation</label>
                                    <input type="radio" class="btn-check" name="nature_of_visit" id="cNatureAdm" value="New Admission" autocomplete="off">
                                    <label class="btn btn-outline-primary btn-sm" for="cNatureAdm">New Admission</label>
                                    <input type="radio" class="btn-check" name="nature_of_visit" id="cNatureFollow" value="Follow-up Visit" autocomplete="off">
                                    <label class="btn btn-outline-primary btn-sm" for="cNatureFollow">Follow-up Visit</label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <hr class="my-3">

                    <!-- Section: Chief Complaints + Vitals (side-by-side, like the paper form) -->
                    <div class="mb-3">
                        <div class="row g-3">
                            <div class="col-md-8">
                                <label class="form-label fw-bold" style="color:#1e3a5f;">Chief Complaints</label>
                                <textarea class="form-control" name="chief_complaint" id="cComplaint" rows="4" placeholder="Chief complaints"></textarea>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold" style="color:#1e3a5f;">Vitals</label>
                                <div class="row g-2">
                                    <div class="col-6"><input type="number" step="0.1" class="form-control form-control-sm" name="height" id="cHt" placeholder="Ht (cms)"></div>
                                    <div class="col-6"><input type="number" step="0.1" class="form-control form-control-sm" name="weight" id="cWt" placeholder="Wt (kg)"></div>
                                    <div class="col-6"><input type="text" class="form-control form-control-sm" name="blood_pressure" id="cBP" placeholder="BP (mmHg)"></div>
                                    <div class="col-6"><input type="number" class="form-control form-control-sm" name="respiratory_rate" id="cRR" placeholder="RR (cpm)"></div>
                                    <div class="col-6"><input type="number" class="form-control form-control-sm" name="pulse_rate" id="cPR" placeholder="PR (bpm)"></div>
                                    <div class="col-6"><input type="number" step="0.1" class="form-control form-control-sm" name="temperature" id="cTemp" placeholder="Temp (°C)"></div>
                                    <div class="col-12"><input type="text" class="form-control form-control-sm" name="oxygen_saturation" id="cSpo2" placeholder="SpO2 (optional)"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <hr class="my-3">

                    <div class="mb-3">
                        <label class="form-label fw-bold" style="color:#1e3a5f;">History Of Patient Illness</label>
                        <textarea class="form-control" name="history_of_illness" id="cHistIllness" rows="3"></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold" style="color:#1e3a5f;">Family History</label>
                        <textarea class="form-control" name="past_medical_family_history" id="cPastHx" rows="3"></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold" style="color:#1e3a5f;">Pertinent P.E.</label>
                        <textarea class="form-control" name="pertinent_pe" id="cPE" rows="3"></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold" style="color:#1e3a5f;">
                            Diagnosis
                            <?php if (!isDoctor()): ?><span class="badge bg-secondary bg-opacity-50 text-dark ms-1" style="font-size:.68rem;font-weight:500;"><i class="ti ti-lock me-1"></i>Doctor-entered — view only</span><?php endif; ?>
                        </label>
                        <textarea class="form-control<?= isDoctor() ? '' : ' bg-light' ?>" name="diagnosis" id="cDiagnosis" rows="2" <?= isDoctor() ? '' : 'readonly' ?>></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold" style="color:#1e3a5f;">
                            Treatment
                            <?php if (!isDoctor()): ?><span class="badge bg-secondary bg-opacity-50 text-dark ms-1" style="font-size:.68rem;font-weight:500;"><i class="ti ti-lock me-1"></i>Doctor-entered — view only</span><?php endif; ?>
                        </label>
                        <textarea class="form-control<?= isDoctor() ? '' : ' bg-light' ?>" name="treatment_plan" id="cTreatment" rows="2" <?= isDoctor() ? '' : 'readonly' ?>></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold" style="color:#1e3a5f;">Laboratory Findings / Impression</label>
                        <textarea class="form-control" name="laboratory_findings" id="cLabFindings" rows="2"></textarea>
                    </div>

                    <div class="row g-3">
                        <div class="col-md-5 d-flex align-items-end">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="needs_follow_up" id="cNeedsFollowup" value="1">
                                <label class="form-check-label" for="cNeedsFollowup">
                                    Flag for Follow-up <span class="text-muted" style="font-size:.78rem;">(admin schedules the actual date)</span>
                                </label>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="status" id="cStatus">
                                <option value="completed">Completed</option>
                                <option value="pending">Pending</option>
                                <option value="draft">Draft</option>
                                <option value="cancelled">Cancelled</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="save_action" value="draft" formnovalidate class="btn btn-outline-warning" title="Save what's filled in so far — come back and finish later">
                        <i class="ti ti-pencil me-1"></i>Save as Draft
                    </button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save ITR Entry</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php
$extraJS = '<script>
function fillPatientRef(){
    const sel = document.getElementById("cPatient");
    const opt = sel.options[sel.selectedIndex];
    const cDoctor = document.getElementById("cDoctor"); // only rendered for admins
    if(!opt || !opt.value){
        ["cFolderNo","cTnNo","cAddressRef","cDobRef"].forEach(id=>document.getElementById(id).value="");
        if (cDoctor) cDoctor.value = "";
        return;
    }
    document.getElementById("cFolderNo").value = opt.dataset.folder || "";
    document.getElementById("cTnNo").value = opt.dataset.tn || "";
    document.getElementById("cAddressRef").value = opt.dataset.address || "";
    document.getElementById("cSex").value = opt.dataset.gender || "";
    if (cDoctor) cDoctor.value = opt.dataset.doctor && opt.dataset.doctor !== "0" ? opt.dataset.doctor : "";

    if (opt.dataset.dobest === "1") {
        document.getElementById("cDobRef").value = opt.dataset.estage ? (opt.dataset.estage + " yrs (estimated)") : "Unknown (estimated)";
        document.getElementById("cAge").value = opt.dataset.estage || "";
    } else if (opt.dataset.dob) {
        document.getElementById("cDobRef").value = opt.dataset.dob;
        const today = new Date();
        const birth = new Date(opt.dataset.dob);
        let age = today.getFullYear() - birth.getFullYear();
        const m = today.getMonth() - birth.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
        document.getElementById("cAge").value = age >= 0 ? age : "";
    } else {
        document.getElementById("cDobRef").value = "";
    }
}
function clearNature(){
    document.getElementById("cNatureNew").checked = false;
    document.getElementById("cNatureAdm").checked = false;
    document.getElementById("cNatureFollow").checked = false;
}
function openAddModal(){
    document.getElementById("consModalTitle").innerHTML=\'<i class="ti ti-file-text me-2"></i>New ITR Entry\';
    document.getElementById("consId").value="0";
    document.getElementById("cPatient").value="";
    ["cFolderNo","cTnNo","cAddressRef","cDobRef","cAge","cComplaint","cHt","cWt","cBP","cRR","cPR","cTemp","cSpo2","cHistIllness","cPastHx","cPE","cDiagnosis","cTreatment","cLabFindings"].forEach(id=>document.getElementById(id).value="");
    const cDoctorReset = document.getElementById("cDoctor");
    if (cDoctorReset) cDoctorReset.value = "";
    document.getElementById("cNeedsFollowup").checked=false;
    document.getElementById("cMode").value="";
    document.getElementById("cSex").value="";
    clearNature();
    document.getElementById("cDate").value="'.date('Y-m-d').'";
    document.getElementById("cTime").value="'.date('H:i').'";
    document.getElementById("cStatus").value="completed";
    new bootstrap.Modal(document.getElementById("consModal")).show();
}
function openEditModal(r){
    document.getElementById("consModalTitle").innerHTML=\'<i class="ti ti-edit me-2"></i>Edit ITR Entry\';
    document.getElementById("consId").value=r.id;
    document.getElementById("cPatient").value=r.patient_id;
    fillPatientRef();
    document.getElementById("cFolderNo").value = r.folder_number || document.getElementById("cFolderNo").value;
    document.getElementById("cMode").value=r.mode_of_transaction||"";
    document.getElementById("cDate").value=r.checkup_date||"";
    document.getElementById("cTime").value=r.checkup_time||"";
    document.getElementById("cAge").value=r.age_at_visit||"";
    document.getElementById("cSex").value=r.sex_at_visit||"";
    clearNature();
    if(r.nature_of_visit==="New Consultation") document.getElementById("cNatureNew").checked=true;
    if(r.nature_of_visit==="New Admission") document.getElementById("cNatureAdm").checked=true;
    if(r.nature_of_visit==="Follow-up Visit") document.getElementById("cNatureFollow").checked=true;
    document.getElementById("cComplaint").value=r.chief_complaint||"";
    document.getElementById("cHt").value=r.height||"";
    document.getElementById("cWt").value=r.weight||"";
    document.getElementById("cBP").value=r.blood_pressure||"";
    document.getElementById("cRR").value=r.respiratory_rate||"";
    document.getElementById("cPR").value=r.pulse_rate||"";
    document.getElementById("cTemp").value=r.temperature||"";
    document.getElementById("cSpo2").value=r.oxygen_saturation||"";
    document.getElementById("cHistIllness").value=r.history_of_illness||"";
    document.getElementById("cPastHx").value=r.past_medical_family_history||"";
    document.getElementById("cPE").value=r.pertinent_pe||"";
    document.getElementById("cDiagnosis").value=r.diagnosis||"";
    document.getElementById("cTreatment").value=r.treatment_plan||"";
    document.getElementById("cLabFindings").value=r.laboratory_findings||"";
    document.getElementById("cNeedsFollowup").checked=!!parseInt(r.needs_follow_up||0);
    document.getElementById("cStatus").value=r.status||"completed";
    new bootstrap.Modal(document.getElementById("consModal")).show();
}
</script>';
include __DIR__ . '/../../includes/layout_footer.php';
?>
