<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/helpers.php';
requireLogin();
requireStaffOnly();

$conn = getDBConnection();
$msg  = '';

// ── Category (Medical / Dental / Mental / Physical only) ───────────────────
$validCategories = ['Medical', 'Dental', 'Mental', 'Physical'];
$cat = $_GET['cat'] ?? 'Medical';
if (!in_array($cat, $validCategories, true)) $cat = 'Medical';

$catMeta = [
    'Medical'  => ['icon' => 'ti-activity',        'color' => '#1565c0'],
    'Dental'   => ['icon' => 'ti-mood-smile',       'color' => '#00897b'],
    'Mental'   => ['icon' => 'ti-heart',            'color' => '#8e24aa'],
    'Physical' => ['icon' => 'ti-stethoscope',      'color' => '#e65100'],
][$cat];

// ── Deactivate / Reactivate a sub-service (never hard-delete — patient ─────
//    service history rows reference it, and a real DELETE would cascade
//    and wipe that history out from under a patient's record).
if (isset($_GET['toggle_service']) && is_numeric($_GET['toggle_service'])) {
    verifyCsrf();
    $sid = (int)$_GET['toggle_service'];
    $conn->query("UPDATE services SET status = IF(status='active','inactive','active') WHERE id = $sid AND category = '" . $conn->real_escape_string($cat) . "'");
    logAudit('toggle_service', 'service', $sid);
    header("Location: category.php?cat=" . urlencode($cat) . "&msg=service_updated"); exit;
}

// ── Delete a sub-service (only when no patient history references it — ────
//    patient_services.service_id is ON DELETE CASCADE, so deleting a
//    sub-service that's already been used would silently wipe those
//    patients' service records. Use the Deactivate toggle for that case.
if (isset($_GET['delete_service']) && is_numeric($_GET['delete_service'])) {
    verifyCsrf();
    $sid = (int)$_GET['delete_service'];
    $check = $conn->prepare("SELECT COUNT(*) AS c FROM patient_services WHERE service_id = ?");
    $check->bind_param('i', $sid);
    $check->execute();
    $inUse = (int)$check->get_result()->fetch_assoc()['c'];
    $check->close();

    if ($inUse > 0) {
        header("Location: category.php?cat=" . urlencode($cat) . "&msg=service_in_use"); exit;
    }
    $del = $conn->prepare("DELETE FROM services WHERE id = ? AND category = ?");
    $del->bind_param('is', $sid, $cat);
    $del->execute();
    $del->close();
    logAudit('delete_service', 'service', $sid, $cat);
    header("Location: category.php?cat=" . urlencode($cat) . "&msg=service_deleted"); exit;
}

// ── Add / Edit a sub-service ────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_service'])) {
    verifyCsrf();
    $sid  = (int)($_POST['service_id'] ?? 0);
    $name = trim($_POST['service_name'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $fee  = $_POST['fee'] !== '' ? (float)$_POST['fee'] : 0.00;

    if ($name === '') {
        header("Location: category.php?cat=" . urlencode($cat) . "&msg=noname"); exit;
    }

    if ($sid > 0) {
        $stmt = $conn->prepare("UPDATE services SET service_name=?, description=?, fee=? WHERE id=? AND category=?");
        $stmt->bind_param('ssdis', $name, $desc, $fee, $sid, $cat);
        $stmt->execute();
        logAudit('update_service', 'service', $sid, $name);
    } else {
        $stmt = $conn->prepare("INSERT INTO services (service_name, description, category, fee, status) VALUES (?,?,?,?,'active')");
        $stmt->bind_param('sssd', $name, $desc, $cat, $fee);
        $stmt->execute();
        logAudit('create_service', 'service', $conn->insert_id, $name);
    }
    header("Location: category.php?cat=" . urlencode($cat) . "&msg=" . ($sid > 0 ? 'service_updated' : 'service_added')); exit;
}

// ── Delete a single patient-service encounter record ───────────────────────
if (isset($_GET['delete_record']) && is_numeric($_GET['delete_record'])) {
    verifyCsrf();
    $rid = (int)$_GET['delete_record'];
    $owner = $conn->prepare("SELECT patient_id FROM patient_services WHERE id = ?");
    $owner->bind_param('i', $rid);
    $owner->execute();
    $ownerRow = $owner->get_result()->fetch_assoc();
    $owner->close();
    if ($ownerRow) {
        assertPatientInDoctorScope($conn, $ownerRow['patient_id']);
        $del = $conn->prepare("DELETE FROM patient_services WHERE id = ?");
        $del->bind_param('i', $rid);
        $del->execute();
        $del->close();
        logAudit('delete_service_record', 'patient', (int)$ownerRow['patient_id'], "record #$rid ($cat)");
    }
    header("Location: category.php?cat=" . urlencode($cat) . "&msg=record_deleted"); exit;
}

// ── Record (or edit) a patient's service encounter ──────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_record'])) {
    verifyCsrf();
    $rid        = (int)($_POST['record_id'] ?? 0);
    $patient_id = (int)($_POST['patient_id'] ?? 0);
    $service_id = (int)($_POST['service_id'] ?? 0);
    $date       = $_POST['service_date'] ?: date('Y-m-d');
    $notes      = trim($_POST['notes'] ?? '');
    $status     = $_POST['status'] ?? 'done';
    $uid        = getCurrentUser()['id'];

    // Medico-Legal Examination body-diagram findings, submitted as JSON
    // from the injury map widget below (empty for every other service).
    // Each finding is a group of 1-2 marks sharing one description — a
    // simple single-point injury has 1 mark; a through-and-through injury
    // (e.g. "rod pierced through the arm") links a front entry mark with a
    // back exit mark under the same finding.
    $injuryMap = null;
    $rawMap = trim($_POST['injury_map'] ?? '');
    if ($rawMap !== '') {
        $decoded = json_decode($rawMap, true);
        if (is_array($decoded)) {
            $clean = [];
            foreach ($decoded as $f) {
                $rawMarks = is_array($f['marks'] ?? null) ? $f['marks'] : [$f]; // back-compat: flat old-format item
                $marks = [];
                foreach ($rawMarks as $m) {
                    $marks[] = [
                        'view' => ($m['view'] ?? 'front') === 'back' ? 'back' : 'front',
                        'x'    => round((float)($m['x'] ?? 0), 2),
                        'y'    => round((float)($m['y'] ?? 0), 2),
                        'zone' => trim((string)($m['zone'] ?? '')),
                        'role' => in_array($m['role'] ?? '', ['entry', 'exit'], true) ? $m['role'] : null,
                    ];
                }
                if (empty($marks)) continue;
                // Cap at 2 marks per finding (entry + exit) — anything beyond
                // that isn't a supported "linked injury" shape.
                $marks = array_slice($marks, 0, 2);
                $clean[] = [
                    'marks' => $marks,
                    'note'  => trim((string)($f['note'] ?? '')),
                ];
            }
            if (!empty($clean)) $injuryMap = json_encode($clean);
        }
    }

    // Dental odontogram — one entry per marked tooth (FDI two-digit
    // notation), each with a procedure and an optional note.
    $validTeeth = [];
    foreach (['1','2','3','4'] as $q) foreach (range(1,8) as $n) $validTeeth[] = $q . $n;
    $validProcedures = ['Caries','Filling','Extraction','Root Canal','Crown','Sealant','Missing','Other'];
    $odontogram = null;
    $rawOdo = trim($_POST['odontogram'] ?? '');
    if ($rawOdo !== '') {
        $decodedOdo = json_decode($rawOdo, true);
        if (is_array($decodedOdo)) {
            $cleanOdo = [];
            foreach ($decodedOdo as $t) {
                $tooth = trim((string)($t['tooth'] ?? ''));
                if (!in_array($tooth, $validTeeth, true)) continue;
                $proc = in_array($t['procedure'] ?? '', $validProcedures, true) ? $t['procedure'] : 'Other';
                $cleanOdo[] = [
                    'tooth'     => $tooth,
                    'procedure' => $proc,
                    'note'      => trim((string)($t['note'] ?? '')),
                ];
            }
            if (!empty($cleanOdo)) $odontogram = json_encode($cleanOdo);
        }
    }

    // Prenatal / Family Planning / TB-DOTS structured fields — see
    // modules/services/views/{prenatal,family_planning,tbdots}_section.php.
    // Only meaningful for their respective sub-service, but harmless to
    // store as NULL for every other one (same as injury_map/odontogram).
    $prenatalLmp     = $_POST['prenatal_lmp'] ?? null;
    $prenatalLmp     = $prenatalLmp !== '' ? $prenatalLmp : null;
    $prenatalEdd     = $_POST['prenatal_edd'] ?? null;
    $prenatalEdd     = $prenatalEdd !== '' ? $prenatalEdd : null;
    $prenatalGravida = ($_POST['prenatal_gravida'] ?? '') !== '' ? (int)$_POST['prenatal_gravida'] : null;
    $prenatalPara    = ($_POST['prenatal_para'] ?? '') !== '' ? (int)$_POST['prenatal_para'] : null;
    $prenatalBp      = trim($_POST['prenatal_bp'] ?? '') ?: null;
    $validTt         = ['TT1', 'TT2', 'TT3', 'TT4', 'TT5', 'Fully Immunized'];
    $prenatalTt      = in_array($_POST['prenatal_tt_status'] ?? '', $validTt, true) ? $_POST['prenatal_tt_status'] : null;

    $dangerSigns = null;
    if (!empty($_POST['prenatal_danger_signs']) && is_array($_POST['prenatal_danger_signs'])) {
        $clean = [];
        foreach ($_POST['prenatal_danger_signs'] as $v) {
            $v = trim((string)$v);
            if ($v !== '') $clean[] = $v;
        }
        if (!empty($clean)) $dangerSigns = json_encode($clean);
    }

    $validFpMethods = ['Pills (COC)', 'Pills (POP)', 'Injectable (DMPA)', 'IUD', 'Implant', 'Condom', 'Bilateral Tubal Ligation', 'Vasectomy', 'Natural Family Planning', 'LAM', 'Other'];
    $fpMethod       = in_array($_POST['fp_method'] ?? '', $validFpMethods, true) ? $_POST['fp_method'] : null;
    $validAcceptor  = ['new', 'current', 'switching', 'dropout'];
    $fpAcceptor     = in_array($_POST['fp_acceptor_type'] ?? '', $validAcceptor, true) ? $_POST['fp_acceptor_type'] : null;
    $fpNextVisit    = $_POST['fp_next_visit'] ?? null;
    $fpNextVisit    = $fpNextVisit !== '' ? $fpNextVisit : null;

    $validSputum     = ['Positive', 'Negative', 'Not Done'];
    $tbSputum        = in_array($_POST['tb_sputum_result'] ?? '', $validSputum, true) ? $_POST['tb_sputum_result'] : null;
    $validTbCat      = ['Category I', 'Category II', 'Category III'];
    $tbCategory      = in_array($_POST['tb_treatment_category'] ?? '', $validTbCat, true) ? $_POST['tb_treatment_category'] : null;
    $tbRegimen       = trim($_POST['tb_regimen'] ?? '') ?: null;
    $validAttendance = ['taken', 'missed'];
    $tbAttendance    = in_array($_POST['tb_attendance'] ?? '', $validAttendance, true) ? $_POST['tb_attendance'] : null;

    if ($patient_id <= 0 || $service_id <= 0) {
        header("Location: category.php?cat=" . urlencode($cat) . "&msg=norecord"); exit;
    }
    // Check both the patient being assigned AND (when editing) the record's
    // current owner — otherwise a doctor could "reassign" someone else's
    // encounter onto one of their own patients just by editing the hidden
    // patient_id field.
    assertPatientInDoctorScope($conn, $patient_id);
    if ($rid > 0) {
        $ownerCheck = $conn->prepare("SELECT patient_id FROM patient_services WHERE id = ?");
        $ownerCheck->bind_param('i', $rid);
        $ownerCheck->execute();
        $existingOwner = $ownerCheck->get_result()->fetch_assoc();
        $ownerCheck->close();
        if ($existingOwner) assertPatientInDoctorScope($conn, $existingOwner['patient_id']);
    }

    if ($rid > 0) {
        $stmt = $conn->prepare("UPDATE patient_services SET patient_id=?, service_id=?, service_date=?, notes=?, status=?, administered_by=?, injury_map=?, odontogram=?,
            prenatal_lmp=?, prenatal_edd=?, prenatal_gravida=?, prenatal_para=?, prenatal_bp=?, prenatal_tt_status=?, prenatal_danger_signs=?,
            fp_method=?, fp_acceptor_type=?, fp_next_visit=?,
            tb_sputum_result=?, tb_treatment_category=?, tb_regimen=?, tb_attendance=?
            WHERE id=?");
        if ($stmt) $stmt->bind_param(
            'iisssissssiissssssssssi',
            $patient_id, $service_id, $date, $notes, $status, $uid, $injuryMap, $odontogram,
            $prenatalLmp, $prenatalEdd, $prenatalGravida, $prenatalPara, $prenatalBp, $prenatalTt, $dangerSigns,
            $fpMethod, $fpAcceptor, $fpNextVisit,
            $tbSputum, $tbCategory, $tbRegimen, $tbAttendance,
            $rid
        );
    } else {
        $stmt = $conn->prepare("INSERT INTO patient_services (
            patient_id, service_id, service_date, notes, status, administered_by, injury_map, odontogram,
            prenatal_lmp, prenatal_edd, prenatal_gravida, prenatal_para, prenatal_bp, prenatal_tt_status, prenatal_danger_signs,
            fp_method, fp_acceptor_type, fp_next_visit,
            tb_sputum_result, tb_treatment_category, tb_regimen, tb_attendance
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        if ($stmt) $stmt->bind_param(
            'iisssissssiissssssssss',
            $patient_id, $service_id, $date, $notes, $status, $uid, $injuryMap, $odontogram,
            $prenatalLmp, $prenatalEdd, $prenatalGravida, $prenatalPara, $prenatalBp, $prenatalTt, $dangerSigns,
            $fpMethod, $fpAcceptor, $fpNextVisit,
            $tbSputum, $tbCategory, $tbRegimen, $tbAttendance
        );
    }
    // A false $stmt here means the query referenced a column that doesn't
    // exist yet (schema drift) — fail loudly with a redirect message
    // instead of a raw fatal error, which used to render as a blank page.
    if (!$stmt || !$stmt->execute()) {
        header("Location: category.php?cat=" . urlencode($cat) . "&msg=save_failed"); exit;
    }
    logAudit($rid > 0 ? 'update_service_record' : 'create_service_record', 'patient', $patient_id, $cat);
    header("Location: category.php?cat=" . urlencode($cat) . "&msg=" . ($rid > 0 ? 'record_updated' : 'record_added')); exit;
}

// ── Data for this category ──────────────────────────────────────────────────
$patients = [];
$r = $conn->query("SELECT id, patient_no, CONCAT(first_name,' ',last_name) as name FROM patients WHERE status='active'" . doctorScopeSql() . " ORDER BY last_name");
while ($row = $r->fetch_assoc()) $patients[] = $row;

$subServices = [];
$stmt = $conn->prepare("SELECT * FROM services WHERE category = ? ORDER BY status DESC, service_name");
$stmt->bind_param('s', $cat);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $subServices[] = $row;
$stmt->close();

// How many patient records reference each sub-service (blocks hard delete).
$serviceUsage = [];
$r = $conn->query("SELECT service_id, COUNT(*) AS c FROM patient_services GROUP BY service_id");
while ($row = $r->fetch_assoc()) $serviceUsage[$row['service_id']] = (int)$row['c'];

$records = [];
$stmt = $conn->prepare("
    SELECT ps.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no,
           s.service_name, u.full_name as staff_name
    FROM patient_services ps
    LEFT JOIN patients p ON ps.patient_id = p.id
    LEFT JOIN services s ON ps.service_id = s.id
    LEFT JOIN users u ON ps.administered_by = u.id
    WHERE s.category = ?" . doctorScopeSql('p') . "
    ORDER BY ps.service_date DESC, ps.id DESC
    LIMIT 100
");
$stmt->bind_param('s', $cat);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $records[] = $row;
$stmt->close();
$conn->close();

if (isset($_GET['msg'])) {
    $msg = [
        'service_added'   => 'Sub-service added.',
        'service_updated' => 'Sub-service updated.',
        'service_deleted' => 'Sub-service deleted.',
        'record_added'    => 'Service recorded to patient history.',
        'record_updated'  => 'Record updated.',
        'record_deleted'  => 'Record removed.',
        'noname'          => null,
        'norecord'        => null,
        'service_in_use'  => null,
        'save_failed'     => null,
    ][$_GET['msg']] ?? '';
}
$errMsg = null;
if (($_GET['msg'] ?? '') === 'noname')   $errMsg = 'Sub-service name is required.';
if (($_GET['msg'] ?? '') === 'norecord') $errMsg = 'Please select both a patient and a sub-service.';
if (($_GET['msg'] ?? '') === 'service_in_use') $errMsg = 'This sub-service already has patient records attached to it, so it can\'t be permanently deleted — use Deactivate instead to hide it from new records while keeping history intact.';
if (($_GET['msg'] ?? '') === 'save_failed') $errMsg = 'Could not save the record — please try again. If this keeps happening, contact your administrator.';

$pageTitle = "$cat Services";
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';

$statusBadge = ['done' => 'bg-success', 'pending' => 'bg-warning text-dark', 'cancelled' => 'bg-secondary'];
?>
<link rel="stylesheet" href="<?= ASSETS_URL ?>/css/services.css"/>
<style>:root{--cat-color:<?= $catMeta['color'] ?>;}</style>

<div class="page-header">
    <div class="page-block">
        <h5 class="m-b-10"><i class="ti <?= $catMeta['icon'] ?> me-2" style="color:<?= $catMeta['color'] ?>;"></i><?= htmlspecialchars($cat) ?> Services</h5>
        <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li>
            <li class="breadcrumb-item">Clinical Services</li>
            <li class="breadcrumb-item active"><?= htmlspecialchars($cat) ?></li>
        </ul>
    </div>
</div>

<!-- Category switcher -->
<div class="mb-3 d-flex gap-2 flex-wrap justify-content-between">
    <div class="d-flex gap-2 flex-wrap">
        <?php foreach ($validCategories as $c): ?>
        <a href="category.php?cat=<?= urlencode($c) ?>" class="btn btn-sm <?= $c === $cat ? 'btn-primary' : 'btn-outline-secondary' ?>"><?= $c ?></a>
        <?php endforeach; ?>
    </div>
    <?php if ($cat === 'Medical'): ?>
    <div class="d-flex gap-2 flex-wrap">
        <a href="fp_schedule.php" class="btn btn-sm btn-outline-secondary"><i class="ti ti-heart me-1"></i>Family Planning Schedule</a>
        <a href="tb_compliance.php" class="btn btn-sm btn-outline-secondary"><i class="ti ti-report-medical me-1"></i>TB-DOTS Compliance</a>
    </div>
    <?php endif; ?>
</div>

<?php if ($msg): ?><div class="alert alert-success alert-dismissible fade show"><i class="ti ti-circle-check me-2"></i><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
<?php if ($errMsg): ?><div class="alert alert-danger alert-dismissible fade show"><i class="ti ti-alert-circle me-2"></i><?= htmlspecialchars($errMsg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

<div class="row g-3">
    <?php include __DIR__ . '/views/service_list.php'; ?>
    <?php include __DIR__ . '/views/records_table.php'; ?>
</div>

<?php include __DIR__ . '/views/service_modal.php'; ?>
<?php include __DIR__ . '/views/record_modal.php'; ?>
<?php include __DIR__ . '/views/exam_view_modal.php'; ?>
<?php if ($cat === 'Dental') include __DIR__ . '/views/odontogram_view_modal.php'; ?>

<script>
// Values that used to be templated directly into the widget scripts —
// centralized here so body-diagram.js/odontogram.js/category.js can stay
// plain, cacheable, static files instead of being PHP-templated themselves.
const PRMS_SERVICE_CONFIG = {
    catColor: <?= json_encode($catMeta['color']) ?>,
    catLabel: <?= json_encode($cat) ?>,
    todayDate: <?= json_encode(date('Y-m-d')) ?>,
    serviceNames: {<?php foreach ($subServices as $s) echo (int)$s['id'] . ':' . json_encode($s['service_name']) . ','; ?>},
    // Set when arriving here via a "Record a Visit" link from fp_schedule.php
    // or tb_compliance.php — those pages already know which patient, so the
    // Add Record modal should open pre-filled instead of forcing a reselect.
    preselectPatientId: <?= json_encode((int)($_GET['patient_id'] ?? 0) ?: null) ?>
};
</script>
<script src="<?= ASSETS_URL ?>/js/services/body-diagram.js"></script>
<script src="<?= ASSETS_URL ?>/js/services/odontogram.js"></script>
<script src="<?= ASSETS_URL ?>/js/services/prenatal-fp-tb.js"></script>
<script src="<?= ASSETS_URL ?>/js/services/category.js"></script>

<?php include __DIR__ . '/../../includes/layout_footer.php'; ?>
