<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();
$conn = getDBConnection();

$patient_id = (int)($_GET['patient_id'] ?? 0);
$patients = [];
$r = $conn->query("
    SELECT DISTINCT p.id, p.patient_no, p.last_name, CONCAT(p.first_name,' ',p.last_name) as name
    FROM patients p
    JOIN patient_services ps ON ps.patient_id = p.id
    JOIN services s ON s.id = ps.service_id
    WHERE s.category = 'Medical' AND (LOWER(s.service_name) LIKE '%dots%' OR LOWER(s.service_name) LIKE '%tuberculosis%')" . doctorScopeSql('p') . "
    ORDER BY p.last_name
");
while ($row = $r->fetch_assoc()) $patients[] = $row;

$history = [];
$patient = null;
if ($patient_id > 0) {
    $r = $conn->query("SELECT id, patient_no, CONCAT(first_name,' ',last_name) as name FROM patients WHERE id=$patient_id" . doctorScopeSql() . " LIMIT 1");
    $patient = $r->fetch_assoc();
    if ($patient) {
        $stmt = $conn->prepare("
            SELECT ps.* FROM patient_services ps
            JOIN services s ON s.id = ps.service_id
            WHERE ps.patient_id = ? AND s.category = 'Medical' AND (LOWER(s.service_name) LIKE '%dots%' OR LOWER(s.service_name) LIKE '%tuberculosis%')
            ORDER BY ps.service_date ASC, ps.id ASC
        ");
        $stmt->bind_param('i', $patient_id);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) $history[] = $row;
        $stmt->close();
    } else {
        $patient_id = 0;
    }
}
$conn->close();

$taken = 0; $missed = 0;
foreach ($history as $h) {
    if ($h['tb_attendance'] === 'taken') $taken++;
    elseif ($h['tb_attendance'] === 'missed') $missed++;
}
$totalMarked = $taken + $missed;
$adherencePct = $totalMarked > 0 ? round(($taken / $totalMarked) * 100) : null;
$latest = !empty($history) ? end($history) : null;

$pageTitle = 'TB-DOTS Compliance';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<div class="page-header"><div class="page-block">
    <h5 class="m-b-10">TB-DOTS Compliance</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Clinical Services</li><li class="breadcrumb-item active">TB-DOTS Compliance</li></ul>
</div></div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET">
            <div class="row g-3">
                <div class="col-md-5">
                    <label class="form-label fw-bold">Select Patient</label>
                    <select class="form-select" name="patient_id" onchange="this.form.submit()">
                        <option value="">— Choose a patient with a TB-DOTS record —</option>
                        <?php foreach ($patients as $p): ?><option value="<?= $p['id'] ?>" <?= $patient_id == $p['id'] ? 'selected' : '' ?>><?= htmlspecialchars($p['patient_no'] . ' - ' . $p['name']) ?></option><?php endforeach; ?>
                    </select>
                </div>
            </div>
        </form>
    </div>
</div>

<?php if ($patient && !empty($history)): ?>
<div class="row g-3">
    <div class="col-md-4">
        <div class="card">
            <div class="card-body text-center py-4">
                <div style="width:70px;height:70px;background:#e3f2fd;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 16px;">
                    <i class="ti ti-report-medical" style="font-size:2rem;color:#1565c0;"></i>
                </div>
                <div class="fw-bold" style="font-size:1.1rem;"><?= htmlspecialchars($patient['name']) ?></div>
                <div class="text-muted mb-3" style="font-size:.85rem;"><?= htmlspecialchars($patient['patient_no']) ?></div>
                <div style="background:#f8f9fa;border-radius:8px;padding:12px;">
                    <div class="text-muted" style="font-size:.78rem;">TREATMENT CATEGORY</div>
                    <div class="fw-bold" style="font-size:1.1rem;"><?= htmlspecialchars($latest['tb_treatment_category'] ?: 'Not Set') ?></div>
                </div>
                <div class="row g-2 mt-2">
                    <div class="col-6"><div class="card" style="background:#f8f9fa;"><div class="card-body py-2 px-2 text-center"><div class="fw-bold" style="font-size:1.2rem;"><?= htmlspecialchars($latest['tb_regimen'] ?: '—') ?></div><div class="text-muted" style="font-size:.72rem;">Regimen</div></div></div></div>
                    <div class="col-6"><div class="card" style="background:#f8f9fa;"><div class="card-body py-2 px-2 text-center"><div class="fw-bold" style="font-size:1.2rem;"><?= htmlspecialchars($latest['tb_sputum_result'] ?: '—') ?></div><div class="text-muted" style="font-size:.72rem;">Latest Sputum</div></div></div></div>
                </div>
                <div class="mt-3 p-2" style="background:<?= $adherencePct !== null && $adherencePct < 80 ? '#fce4ec' : '#e8f5e9' ?>;border-radius:8px;">
                    <div class="fw-bold" style="font-size:1.6rem;color:<?= $adherencePct !== null && $adherencePct < 80 ? '#c62828' : '#2e7d32' ?>;"><?= $adherencePct !== null ? $adherencePct . '%' : '—' ?></div>
                    <div class="text-muted" style="font-size:.78rem;">Adherence (<?= $taken ?> taken / <?= $missed ?> missed)</div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h6 class="section-title mb-0"><i class="ti ti-calendar-stats me-2" style="color:#0d6efd;"></i>DOTS Attendance Calendar</h6>
                <a href="category.php?cat=Medical&patient_id=<?= $patient['id'] ?>" class="btn btn-sm btn-primary"><i class="ti ti-plus me-1"></i>Record a Visit</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0" style="font-size:.85rem;">
                        <thead><tr><th>Date</th><th>Attendance</th><th>Sputum</th><th>Category</th><th>Regimen</th><th>Notes</th></tr></thead>
                        <tbody>
                            <?php foreach (array_reverse($history) as $h): ?>
                            <tr>
                                <td><?= date('M d, Y', strtotime($h['service_date'])) ?></td>
                                <td>
                                    <?php if ($h['tb_attendance'] === 'taken'): ?>
                                    <span class="badge bg-success">Taken</span>
                                    <?php elseif ($h['tb_attendance'] === 'missed'): ?>
                                    <span class="badge bg-danger">Missed</span>
                                    <?php else: ?>
                                    <span class="text-muted">—</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($h['tb_sputum_result'] ?: '—') ?></td>
                                <td><?= htmlspecialchars($h['tb_treatment_category'] ?: '—') ?></td>
                                <td><?= htmlspecialchars($h['tb_regimen'] ?: '—') ?></td>
                                <td style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= htmlspecialchars($h['notes'] ?: '') ?>"><?= htmlspecialchars($h['notes'] ?: '—') ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php elseif ($patient && empty($history)): ?>
<div class="card"><div class="card-body text-center py-5 text-muted"><i class="ti ti-report-medical" style="font-size:3rem;opacity:.3;"></i><div class="mt-2">No TB-DOTS records found for this patient.</div><a href="category.php?cat=Medical&patient_id=<?= $patient['id'] ?>" class="btn btn-primary btn-sm mt-3"><i class="ti ti-plus me-1"></i>Record a Visit</a></div></div>
<?php else: ?>
<div class="card"><div class="card-body text-center py-5 text-muted"><i class="ti ti-search" style="font-size:3rem;opacity:.4;"></i><div class="mt-2">Select a patient to view their DOTS compliance history.</div></div></div>
<?php endif;
include __DIR__ . '/../../includes/layout_footer.php'; ?>
