<?php
// Family Planning structured fields — embedded inside the Record Service
// modal (modules/services/views/record_modal.php). Only shown (via JS)
// when the selected sub-service is Family Planning.
?>
<div class="mb-1" id="fpSection" style="display:none;">
    <hr>
    <label class="form-label mb-2"><i class="ti ti-heart me-1"></i>Family Planning</label>
    <div class="row">
        <div class="col-md-4 mb-3">
            <label class="form-label">Method</label>
            <select class="form-select" name="fp_method" id="fpMethod">
                <option value="">Select…</option>
                <option>Pills (COC)</option>
                <option>Pills (POP)</option>
                <option>Injectable (DMPA)</option>
                <option>IUD</option>
                <option>Implant</option>
                <option>Condom</option>
                <option>Bilateral Tubal Ligation</option>
                <option>Vasectomy</option>
                <option>Natural Family Planning</option>
                <option>LAM</option>
                <option>Other</option>
            </select>
        </div>
        <div class="col-md-4 mb-3">
            <label class="form-label">Acceptor Type</label>
            <select class="form-select" name="fp_acceptor_type" id="fpAcceptor">
                <option value="">Select…</option>
                <option value="new">New Acceptor</option>
                <option value="current">Current User</option>
                <option value="switching">Switching Method</option>
                <option value="dropout">Dropout</option>
            </select>
        </div>
        <div class="col-md-4 mb-3">
            <label class="form-label">Next FP Visit Due</label>
            <input type="date" class="form-control" name="fp_next_visit" id="fpNextVisit">
        </div>
    </div>
</div>
