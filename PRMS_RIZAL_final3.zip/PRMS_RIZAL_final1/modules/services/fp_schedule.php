<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();
$conn = getDBConnection();

$filter = $_GET['filter'] ?? 'upcoming'; // upcoming | overdue | all
$days   = (int)($_GET['days'] ?? 7);

$where = '';
if ($filter === 'upcoming') {
    $where = "AND ps.fp_next_visit BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL $days DAY)";
} elseif ($filter === 'overdue') {
    $where = "AND ps.fp_next_visit < CURDATE()";
} else {
    $where = "AND ps.fp_next_visit IS NOT NULL";
}

// Only each patient's most recent Family Planning visit represents their
// current status — older superseded visits (a prior method, an old due
// date) shouldn't also show up on the schedule.
$records = [];
$r = $conn->query("
    SELECT ps.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no, p.contact_number
    FROM patient_services ps
    JOIN patients p ON p.id = ps.patient_id
    JOIN services s ON s.id = ps.service_id
    WHERE s.category = 'Medical' AND LOWER(s.service_name) LIKE '%family planning%'
    AND ps.id = (
        SELECT ps2.id FROM patient_services ps2
        JOIN services s2 ON s2.id = ps2.service_id
        WHERE ps2.patient_id = ps.patient_id AND s2.category = 'Medical' AND LOWER(s2.service_name) LIKE '%family planning%'
        ORDER BY ps2.service_date DESC, ps2.id DESC LIMIT 1
    )
    $where" . doctorScopeSql('p') . "
    ORDER BY ps.fp_next_visit ASC LIMIT 200
");
while ($row = $r->fetch_assoc()) $records[] = $row;

// Stats
$stats = ['week' => 0, 'overdue' => 0];
$res = $conn->query("
    SELECT COUNT(*) as cnt FROM patient_services ps
    JOIN services s ON s.id = ps.service_id
    WHERE s.category = 'Medical' AND LOWER(s.service_name) LIKE '%family planning%'
    AND ps.id = (SELECT ps2.id FROM patient_services ps2 JOIN services s2 ON s2.id=ps2.service_id WHERE ps2.patient_id=ps.patient_id AND s2.category = 'Medical' AND LOWER(s2.service_name) LIKE '%family planning%' ORDER BY ps2.service_date DESC, ps2.id DESC LIMIT 1)
    AND ps.fp_next_visit BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
    " . doctorScopeSql('p') . "
");
$stats['week'] = (int)$res->fetch_assoc()['cnt'];
$res = $conn->query("
    SELECT COUNT(*) as cnt FROM patient_services ps
    JOIN services s ON s.id = ps.service_id
    WHERE s.category = 'Medical' AND LOWER(s.service_name) LIKE '%family planning%'
    AND ps.id = (SELECT ps2.id FROM patient_services ps2 JOIN services s2 ON s2.id=ps2.service_id WHERE ps2.patient_id=ps.patient_id AND s2.category = 'Medical' AND LOWER(s2.service_name) LIKE '%family planning%' ORDER BY ps2.service_date DESC, ps2.id DESC LIMIT 1)
    AND ps.fp_next_visit < CURDATE()
    " . doctorScopeSql('p') . "
");
$stats['overdue'] = (int)$res->fetch_assoc()['cnt'];
$conn->close();

$pageTitle = 'Family Planning Schedule';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<div class="page-header"><div class="page-block">
    <h5 class="m-b-10">Family Planning Schedule</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Clinical Services</li><li class="breadcrumb-item active">Family Planning Schedule</li></ul>
</div></div>

<!-- Stats -->
<div class="row g-3 mb-3">
    <div class="col-md-4">
        <div class="card stat-card"><div class="card-body d-flex align-items-center gap-3">
            <div class="stat-icon" style="background:#fff3e0;"><i class="ti ti-clock" style="color:#e65100;font-size:1.4rem;"></i></div>
            <div><div class="fw-bold" style="font-size:1.6rem;color:#e65100;"><?= $stats['week'] ?></div><div class="text-muted" style="font-size:.82rem;">Due This Week</div></div>
        </div></div>
    </div>
    <div class="col-md-4">
        <div class="card stat-card"><div class="card-body d-flex align-items-center gap-3">
            <div class="stat-icon" style="background:#ffebee;"><i class="ti ti-alert-circle" style="color:#c62828;font-size:1.4rem;"></i></div>
            <div><div class="fw-bold" style="font-size:1.6rem;color:#c62828;"><?= $stats['overdue'] ?></div><div class="text-muted" style="font-size:.82rem;">Overdue</div></div>
        </div></div>
    </div>
</div>

<!-- Filter -->
<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" class="d-flex gap-3 align-items-end flex-wrap">
            <div>
                <label class="form-label mb-1 fw-bold" style="font-size:.83rem;">Show</label>
                <select class="form-select form-select-sm" name="filter" onchange="this.form.submit()">
                    <option value="upcoming" <?= $filter === 'upcoming' ? 'selected' : '' ?>>Upcoming</option>
                    <option value="overdue" <?= $filter === 'overdue' ? 'selected' : '' ?>>Overdue</option>
                    <option value="all" <?= $filter === 'all' ? 'selected' : '' ?>>All Scheduled</option>
                </select>
            </div>
            <?php if ($filter === 'upcoming'): ?>
            <div>
                <label class="form-label mb-1 fw-bold" style="font-size:.83rem;">Within (days)</label>
                <select class="form-select form-select-sm" name="days" onchange="this.form.submit()">
                    <?php foreach ([7, 14, 30, 60] as $d): ?><option value="<?= $d ?>" <?= $days == $d ? 'selected' : '' ?>><?= $d ?> days</option><?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0"><i class="ti ti-heart me-2" style="color:#0d6efd;"></i>
            <?= $filter === 'upcoming' ? "Upcoming FP Visits (Next $days Days)" : ($filter === 'overdue' ? 'Overdue FP Visits' : 'All Scheduled FP Visits') ?>
            <span class="badge bg-primary bg-opacity-10 text-primary ms-2"><?= count($records) ?></span>
        </h6>
        <a href="category.php?cat=Medical" class="btn btn-primary btn-sm"><i class="ti ti-heart me-1"></i>Record a Visit</a>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0">
                <thead><tr><th>Patient</th><th>Contact</th><th>Method</th><th>Acceptor Type</th><th>Last Visit</th><th>Next Visit Due</th><th>Status</th></tr></thead>
                <tbody>
                    <?php foreach ($records as $rec):
                        $nextDate = new DateTime($rec['fp_next_visit']);
                        $today = new DateTime();
                        $diff = $today->diff($nextDate)->days * ($nextDate >= $today ? 1 : -1);
                        if ($diff < 0) { $statusBadge = '<span class="badge bg-danger">Overdue ' . abs($diff) . ' days</span>'; }
                        elseif ($diff === 0) { $statusBadge = '<span class="badge bg-warning text-dark">Due Today</span>'; }
                        else { $statusBadge = '<span class="badge bg-success">In ' . $diff . ' days</span>'; }
                        $acceptorLabels = ['new' => 'New Acceptor', 'current' => 'Current User', 'switching' => 'Switching Method', 'dropout' => 'Dropout'];
                    ?>
                    <tr>
                        <td><div class="fw-semibold" style="font-size:.88rem;"><?= htmlspecialchars($rec['patient_name']) ?></div><div class="text-muted" style="font-size:.78rem;"><?= htmlspecialchars($rec['patient_no']) ?></div></td>
                        <td><?= htmlspecialchars($rec['contact_number'] ?: '—') ?></td>
                        <td class="fw-semibold"><?= htmlspecialchars($rec['fp_method'] ?: '—') ?></td>
                        <td><?= htmlspecialchars($acceptorLabels[$rec['fp_acceptor_type']] ?? '—') ?></td>
                        <td><?= date('M d, Y', strtotime($rec['service_date'])) ?></td>
                        <td class="fw-semibold <?= $diff < 0 ? 'text-danger' : ($diff === 0 ? 'text-warning' : '') ?>"><?= date('M d, Y', strtotime($rec['fp_next_visit'])) ?></td>
                        <td><?= $statusBadge ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../../includes/layout_footer.php'; ?>
