<?php
// Public "Now Serving" display for a waiting-room TV/monitor. Deliberately
// has NO login requirement — it's meant to run unattended on a screen in
// the lobby — but for that exact reason it must never show anything that
// identifies a patient (no names, no patient numbers, no reasons/notes).
// It only ever SELECTs today's queue; there is no mutation path here.
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
$conn = getDBConnection();
$today = date('Y-m-d');
$categories = ['Dental', 'Physical', 'Mental', 'Medical'];
$catIcons  = ['Dental' => 'ti-mood-smile', 'Physical' => 'ti-stethoscope', 'Mental' => 'ti-heart', 'Medical' => 'ti-medical-cross'];
$catColors = ['Dental' => '#4dabf7', 'Physical' => '#69db7c', 'Mental' => '#da77f2', 'Medical' => '#ffa94d'];

$data = [];
foreach ($categories as $cat) {
    $stmt = $conn->prepare("
        SELECT queue_no, status FROM patient_queue
        WHERE category=? AND queue_date=? AND status IN ('waiting','serving')
        ORDER BY (priority != 'normal') DESC, queue_no ASC
    ");
    $stmt->bind_param('ss', $cat, $today);
    $stmt->execute();
    $res = $stmt->get_result();
    $rows = [];
    while ($row = $res->fetch_assoc()) $rows[] = $row;
    $data[$cat] = $rows;
    $stmt->close();
}
$conn->close();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="refresh" content="12">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Now Serving — RHU Rizal</title>
<link rel="stylesheet" href="<?= ASSETS_URL ?>/fonts/tabler-icons.min.css">
<style>
    * { box-sizing: border-box; }
    html, body {
        margin: 0; padding: 0; height: 100%;
        background: radial-gradient(circle at top, #1a3a5c 0%, #0d1b2a 70%);
        color: #fff;
        font-family: 'Segoe UI', Arial, sans-serif;
        overflow: hidden;
    }
    .kiosk-header {
        display: flex; align-items: center; justify-content: space-between;
        padding: 18px 40px;
        border-bottom: 1px solid rgba(255,255,255,0.12);
    }
    .kiosk-brand { display: flex; align-items: center; gap: 14px; }
    .kiosk-brand img { width: 46px; height: 46px; border-radius: 50%; background: #fff; }
    .kiosk-brand-text { font-size: 1.3rem; font-weight: 700; letter-spacing: .5px; }
    .kiosk-brand-sub { font-size: .85rem; opacity: .6; }
    #kioskClock { font-size: 1.6rem; font-weight: 700; letter-spacing: 1px; }
    #kioskDate { font-size: .85rem; opacity: .6; text-align: right; }

    .kiosk-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 24px;
        padding: 32px 40px;
        height: calc(100vh - 100px);
    }
    .kiosk-tile {
        background: rgba(255,255,255,0.05);
        border: 1px solid rgba(255,255,255,0.1);
        border-radius: 20px;
        padding: 24px;
        display: flex;
        flex-direction: column;
        align-items: center;
    }
    .kiosk-cat { display: flex; align-items: center; gap: 10px; font-size: 1.3rem; font-weight: 700; margin-bottom: 10px; }
    .kiosk-now-label { font-size: .8rem; text-transform: uppercase; letter-spacing: 2px; opacity: .55; margin-top: 10px; }
    .kiosk-now-number { font-size: 5.5rem; font-weight: 800; line-height: 1; margin: 6px 0 18px; }
    .kiosk-upnext-label { font-size: .75rem; text-transform: uppercase; letter-spacing: 1.5px; opacity: .5; margin-bottom: 8px; }
    .kiosk-upnext { display: flex; flex-wrap: wrap; gap: 8px; justify-content: center; }
    .kiosk-chip {
        background: rgba(255,255,255,0.1);
        border-radius: 10px;
        padding: 6px 12px;
        font-size: 1.1rem;
        font-weight: 600;
    }
    .kiosk-empty { opacity: .4; font-size: 1rem; margin-top: 20px; }
</style>
</head>
<body>
    <div class="kiosk-header">
        <div class="kiosk-brand">
            <img src="<?= ASSETS_URL ?>/images/rhu_logo.png" alt="RHU Rizal">
            <div>
                <div class="kiosk-brand-text">Rural Health Unit — Rizal</div>
                <div class="kiosk-brand-sub">Now Serving</div>
            </div>
        </div>
        <div>
            <div id="kioskClock">--:--</div>
            <div id="kioskDate"><?= date('l, F d, Y') ?></div>
        </div>
    </div>

    <div class="kiosk-grid">
        <?php foreach ($categories as $cat):
            $rows = $data[$cat];
            $serving = null;
            $upNext = [];
            foreach ($rows as $row) {
                if ($row['status'] === 'serving' && $serving === null) { $serving = $row['queue_no']; }
                elseif ($row['status'] === 'waiting') { $upNext[] = $row['queue_no']; }
            }
            $upNext = array_slice($upNext, 0, 6);
        ?>
        <div class="kiosk-tile" style="border-top:4px solid <?= $catColors[$cat] ?>;">
            <div class="kiosk-cat" style="color:<?= $catColors[$cat] ?>;"><i class="ti <?= $catIcons[$cat] ?>"></i> <?= $cat ?></div>
            <div class="kiosk-now-label">Now Serving</div>
            <div class="kiosk-now-number" style="color:<?= $serving !== null ? '#fff' : 'rgba(255,255,255,0.25)' ?>;">
                <?= $serving !== null ? str_pad((string)$serving, 2, '0', STR_PAD_LEFT) : '—' ?>
            </div>
            <div class="kiosk-upnext-label">Up Next</div>
            <?php if (empty($upNext)): ?>
            <div class="kiosk-empty">No one waiting</div>
            <?php else: ?>
            <div class="kiosk-upnext">
                <?php foreach ($upNext as $n): ?>
                <div class="kiosk-chip"><?= str_pad((string)$n, 2, '0', STR_PAD_LEFT) ?></div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>

    <script>
    function tickClock() {
        var d = new Date();
        var h = d.getHours(), m = d.getMinutes();
        var ampm = h >= 12 ? 'PM' : 'AM';
        h = h % 12; if (h === 0) h = 12;
        document.getElementById('kioskClock').textContent = h + ':' + String(m).padStart(2, '0') + ' ' + ampm;
    }
    tickClock();
    setInterval(tickClock, 1000);
    </script>
</body>
</html>
