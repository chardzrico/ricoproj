<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/helpers.php';
requireLogin();
requireStaffOnly();

// FHSIS reporting is compiled facility-wide (not per assigned patient), so
// it's limited to the roles that would realistically prepare/review it in
// an actual RHU — the encoder/midwife (nurse) and the officer-in-charge
// (admin). Doctors and general staff are scoped to their own patients
// elsewhere in the system and don't need facility-wide statistics here.
if (!isAdmin() && !hasRole('nurse')) {
    header('Location: ' . BASE_URL . '/dashboard.php');
    exit;
}

$conn = getDBConnection();

// ── Reporting period ─────────────────────────────────────────────────────
$month = isset($_GET['month']) ? max(1, min(12, (int)$_GET['month'])) : (int)date('n');
$year  = isset($_GET['year'])  ? (int)$_GET['year'] : (int)date('Y');
$periodStart = sprintf('%04d-%02d-01', $year, $month);
$periodEnd   = date('Y-m-t', strtotime($periodStart));
$periodLabel = date('F Y', strtotime($periodStart));

// Standard FHSIS-style age brackets — fhsisAgeGroup() lives in includes/helpers.php,
// shared with modules/reports/morbidity.php.
$ageGroupOrder = FHSIS_AGE_GROUP_ORDER;

// ── A. Consultation overview ─────────────────────────────────────────────
$stmt = $conn->prepare("SELECT COUNT(*) c FROM checkups WHERE checkup_date BETWEEN ? AND ? AND status != 'cancelled'");
$stmt->bind_param('ss', $periodStart, $periodEnd);
$stmt->execute();
$totalConsultations = (int)$stmt->get_result()->fetch_assoc()['c'];
$stmt->close();

$stmt = $conn->prepare("SELECT COUNT(DISTINCT patient_id) c FROM checkups WHERE checkup_date BETWEEN ? AND ? AND status != 'cancelled'");
$stmt->bind_param('ss', $periodStart, $periodEnd);
$stmt->execute();
$uniquePatientsServed = (int)$stmt->get_result()->fetch_assoc()['c'];
$stmt->close();

$stmt = $conn->prepare("SELECT COUNT(*) c FROM patients WHERE status='active' AND DATE(created_at) BETWEEN ? AND ?");
$stmt->bind_param('ss', $periodStart, $periodEnd);
$stmt->execute();
$newRegistrations = (int)$stmt->get_result()->fetch_assoc()['c'];
$stmt->close();

$visitTypeCounts = ['New Consultation' => 0, 'New Admission' => 0, 'Follow-up Visit' => 0, 'Unspecified' => 0];
$stmt = $conn->prepare("SELECT nature_of_visit, COUNT(*) c FROM checkups WHERE checkup_date BETWEEN ? AND ? AND status != 'cancelled' GROUP BY nature_of_visit");
$stmt->bind_param('ss', $periodStart, $periodEnd);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $key = $row['nature_of_visit'] ?: 'Unspecified';
    $visitTypeCounts[$key] = (int)$row['c'];
}
$stmt->close();

// ── B. Morbidity — top 10 diagnoses + age/sex breakdown ─────────────────
$topDiagnoses = [];
$stmt = $conn->prepare("
    SELECT MIN(TRIM(diagnosis)) AS dx_label, COUNT(*) AS cnt
    FROM checkups
    WHERE checkup_date BETWEEN ? AND ? AND status != 'cancelled'
      AND diagnosis IS NOT NULL AND TRIM(diagnosis) != ''
    GROUP BY LOWER(TRIM(diagnosis))
    ORDER BY cnt DESC, dx_label ASC
    LIMIT 10
");
$stmt->bind_param('ss', $periodStart, $periodEnd);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $topDiagnoses[] = $row;
$stmt->close();

// Age-group x sex matrix, seeded with zeros so every row/column prints even when empty
$ageSexMatrix = [];
foreach ($ageGroupOrder as $ag) $ageSexMatrix[$ag] = ['Male' => 0, 'Female' => 0];
$stmt = $conn->prepare("SELECT age_at_visit, sex_at_visit FROM checkups WHERE checkup_date BETWEEN ? AND ? AND status != 'cancelled'");
$stmt->bind_param('ss', $periodStart, $periodEnd);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $ag  = fhsisAgeGroup($row['age_at_visit']);
    $sex = ($row['sex_at_visit'] === 'Female') ? 'Female' : 'Male';
    $ageSexMatrix[$ag][$sex]++;
}
$stmt->close();

// ── C. EPI / Immunization summary ────────────────────────────────────────
$immunizationRows = [];
$stmt = $conn->prepare("
    SELECT v.vaccine_name, COUNT(*) AS doses_given, COUNT(DISTINCT ir.patient_id) AS children_reached
    FROM immunization_records ir
    JOIN vaccines v ON ir.vaccine_id = v.id
    WHERE ir.date_given BETWEEN ? AND ?
    GROUP BY v.id, v.vaccine_name
    ORDER BY v.vaccine_name
");
$stmt->bind_param('ss', $periodStart, $periodEnd);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $immunizationRows[] = $row;
$stmt->close();

// ── D. Nutritional status summary ────────────────────────────────────────
$nutritionStatusCounts = [];
$stmt = $conn->prepare("SELECT COALESCE(NULLIF(TRIM(nutritional_status),''),'Not classified') AS label, COUNT(*) c FROM nutritional_records WHERE record_date BETWEEN ? AND ? GROUP BY label ORDER BY c DESC");
$stmt->bind_param('ss', $periodStart, $periodEnd);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $nutritionStatusCounts[] = $row;
$stmt->close();

$weightForAgeCounts = [];
$stmt = $conn->prepare("SELECT COALESCE(NULLIF(TRIM(weight_for_age),''),'Not classified') AS label, COUNT(*) c FROM nutritional_records WHERE record_date BETWEEN ? AND ? GROUP BY label ORDER BY c DESC");
$stmt->bind_param('ss', $periodStart, $periodEnd);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $weightForAgeCounts[] = $row;
$stmt->close();

// ── E. Clinical services rendered, by category ───────────────────────────
$serviceCategoryCounts = ['Medical' => 0, 'Dental' => 0, 'Mental' => 0, 'Physical' => 0];
$stmt = $conn->prepare("
    SELECT s.category, COUNT(*) c
    FROM patient_services ps
    JOIN services s ON ps.service_id = s.id
    WHERE ps.service_date BETWEEN ? AND ? AND ps.status != 'cancelled'
    GROUP BY s.category
");
$stmt->bind_param('ss', $periodStart, $periodEnd);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    if (isset($serviceCategoryCounts[$row['category']])) $serviceCategoryCounts[$row['category']] = (int)$row['c'];
}
$stmt->close();

$topSubServices = [];
$stmt = $conn->prepare("
    SELECT s.service_name, s.category, COUNT(*) c
    FROM patient_services ps
    JOIN services s ON ps.service_id = s.id
    WHERE ps.service_date BETWEEN ? AND ? AND ps.status != 'cancelled'
    GROUP BY s.id, s.service_name, s.category
    ORDER BY c DESC
    LIMIT 10
");
$stmt->bind_param('ss', $periodStart, $periodEnd);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $topSubServices[] = $row;
$stmt->close();

// ── F. Prescriptions dispensed ───────────────────────────────────────────
$stmt = $conn->prepare("SELECT COUNT(*) c FROM prescriptions WHERE prescription_date BETWEEN ? AND ?");
$stmt->bind_param('ss', $periodStart, $periodEnd);
$stmt->execute();
$totalPrescriptions = (int)$stmt->get_result()->fetch_assoc()['c'];
$stmt->close();

$preparedBy = getCurrentUser()['full_name'] ?? getCurrentUser()['username'] ?? '';
$conn->close();

// ── CSV export — same period, same data, no HTML rendered ──────────────────
if (($_GET['export'] ?? '') === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="fhsis_report_' . $year . '-' . str_pad((string)$month, 2, '0', STR_PAD_LEFT) . '.csv"');
    $out = fopen('php://output', 'w');
    fputs($out, "\xEF\xBB\xBF"); // UTF-8 BOM so Excel doesn't mangle the peso sign / special characters
    fputcsv($out, ['FHSIS-Aligned Monthly Report - Rural Health Unit, Rizal']);
    fputcsv($out, ['Period', $periodLabel]);
    fputcsv($out, ['Generated by', $preparedBy, 'on', date('F d, Y')]);
    fputcsv($out, []);

    fputcsv($out, ['A. Consultation Overview']);
    fputcsv($out, ['Total Consultations', $totalConsultations]);
    fputcsv($out, ['Unique Patients Served', $uniquePatientsServed]);
    fputcsv($out, ['New Patient Registrations', $newRegistrations]);
    fputcsv($out, ['Prescriptions Dispensed', $totalPrescriptions]);
    fputcsv($out, []);
    fputcsv($out, ['Visit Type', 'Count']);
    foreach ($visitTypeCounts as $type => $cnt) fputcsv($out, [$type, $cnt]);
    fputcsv($out, []);

    fputcsv($out, ['B. Morbidity - Top 10 Diagnoses']);
    fputcsv($out, ['#', 'Diagnosis', 'Cases']);
    foreach ($topDiagnoses as $i => $d) fputcsv($out, [$i + 1, $d['dx_label'], $d['cnt']]);
    fputcsv($out, []);

    fputcsv($out, ['Consultations by Age Group & Sex']);
    fputcsv($out, ['Age Group', 'Male', 'Female', 'Total']);
    $csvAgeTotals = ['Male' => 0, 'Female' => 0];
    foreach ($ageGroupOrder as $ag) {
        $m = $ageSexMatrix[$ag]['Male']; $f = $ageSexMatrix[$ag]['Female'];
        $csvAgeTotals['Male'] += $m; $csvAgeTotals['Female'] += $f;
        fputcsv($out, [$ag, $m, $f, $m + $f]);
    }
    fputcsv($out, ['Total', $csvAgeTotals['Male'], $csvAgeTotals['Female'], $csvAgeTotals['Male'] + $csvAgeTotals['Female']]);
    fputcsv($out, []);

    fputcsv($out, ['C. Immunization (EPI) Summary']);
    fputcsv($out, ['Vaccine', 'Doses Given', 'Children Reached']);
    foreach ($immunizationRows as $row) fputcsv($out, [$row['vaccine_name'], $row['doses_given'], $row['children_reached']]);
    fputcsv($out, []);

    fputcsv($out, ['D. Nutritional Status Summary']);
    fputcsv($out, ['Nutritional Status', 'Count']);
    foreach ($nutritionStatusCounts as $row) fputcsv($out, [$row['label'], $row['c']]);
    fputcsv($out, []);
    fputcsv($out, ['Weight-for-Age', 'Count']);
    foreach ($weightForAgeCounts as $row) fputcsv($out, [$row['label'], $row['c']]);
    fputcsv($out, []);

    fputcsv($out, ['E. Clinical Services Rendered']);
    fputcsv($out, ['Category', 'Count']);
    foreach ($serviceCategoryCounts as $cat => $cnt) fputcsv($out, [$cat, $cnt]);
    fputcsv($out, []);
    fputcsv($out, ['#', 'Service', 'Category', 'Count']);
    foreach ($topSubServices as $i => $s) fputcsv($out, [$i + 1, $s['service_name'], $s['category'], $s['c']]);

    fclose($out);
    exit;
}

$pageTitle = 'FHSIS Report';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<link rel="stylesheet" href="<?= ASSETS_URL ?>/css/reports.css"/>

<div class="page-header no-print"><div class="page-block">
    <h5 class="m-b-10">FHSIS-Aligned Monthly Report</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Reports</li><li class="breadcrumb-item active">FHSIS Report</li></ul>
</div></div>

<div class="report-card no-print">
    <form method="GET" class="d-flex flex-wrap align-items-end gap-3">
        <div>
            <label class="form-label mb-1">Month</label>
            <select name="month" class="form-select form-select-sm">
                <?php for ($m = 1; $m <= 12; $m++): ?>
                <option value="<?= $m ?>" <?= $m === $month ? 'selected' : '' ?>><?= date('F', mktime(0,0,0,$m,1)) ?></option>
                <?php endfor; ?>
            </select>
        </div>
        <div>
            <label class="form-label mb-1">Year</label>
            <select name="year" class="form-select form-select-sm">
                <?php for ($y = (int)date('Y'); $y >= (int)date('Y') - 5; $y--): ?>
                <option value="<?= $y ?>" <?= $y === $year ? 'selected' : '' ?>><?= $y ?></option>
                <?php endfor; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary btn-sm"><i class="ti ti-filter me-1"></i>Generate</button>
        <a href="?month=<?= $month ?>&year=<?= $year ?>&export=csv" class="btn btn-outline-success btn-sm ms-auto"><i class="ti ti-table-export me-1"></i>Export CSV</a>
        <button type="button" class="btn btn-outline-secondary btn-sm" onclick="window.print()"><i class="ti ti-printer me-1"></i>Print / Save PDF</button>
    </form>
</div>

<?php renderReportLetterhead('FHSIS-Aligned Monthly Health Report &bull; ' . htmlspecialchars($periodLabel), $preparedBy); ?>

<!-- A. Overview -->
<div class="report-card">
    <h6>A. Consultation Overview</h6>
    <div class="row g-3">
        <div class="col-6 col-md-3"><div class="stat-box"><div class="val"><?= $totalConsultations ?></div><div class="lbl">Total Consultations</div></div></div>
        <div class="col-6 col-md-3"><div class="stat-box"><div class="val"><?= $uniquePatientsServed ?></div><div class="lbl">Unique Patients Served</div></div></div>
        <div class="col-6 col-md-3"><div class="stat-box"><div class="val"><?= $newRegistrations ?></div><div class="lbl">New Patient Registrations</div></div></div>
        <div class="col-6 col-md-3"><div class="stat-box"><div class="val"><?= $totalPrescriptions ?></div><div class="lbl">Prescriptions Dispensed</div></div></div>
    </div>
    <table class="fhsis-table mt-3">
        <thead><tr><th>Visit Type</th><th class="num">Count</th></tr></thead>
        <tbody>
            <?php foreach ($visitTypeCounts as $type => $cnt): ?>
            <tr><td><?= htmlspecialchars($type) ?></td><td class="num"><?= $cnt ?></td></tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- B. Morbidity -->
<div class="report-card">
    <h6>B. Morbidity — Top 10 Diagnoses</h6>
    <table class="fhsis-table">
        <thead><tr><th>#</th><th>Diagnosis</th><th class="num">Cases</th></tr></thead>
        <tbody>
            <?php if (empty($topDiagnoses)): ?>
            <tr><td colspan="3" class="text-center text-muted">No diagnoses recorded for this period.</td></tr>
            <?php else: foreach ($topDiagnoses as $i => $d): ?>
            <tr><td><?= $i + 1 ?></td><td><?= htmlspecialchars($d['dx_label']) ?></td><td class="num"><?= $d['cnt'] ?></td></tr>
            <?php endforeach; endif; ?>
        </tbody>
    </table>

    <h6 class="mt-4">Consultations by Age Group &amp; Sex</h6>
    <table class="fhsis-table">
        <thead><tr><th>Age Group</th><th class="num">Male</th><th class="num">Female</th><th class="num">Total</th></tr></thead>
        <tbody>
            <?php $ageTotals = ['Male'=>0,'Female'=>0]; foreach ($ageGroupOrder as $ag):
                $m = $ageSexMatrix[$ag]['Male']; $f = $ageSexMatrix[$ag]['Female'];
                if ($m === 0 && $f === 0) continue;
                $ageTotals['Male'] += $m; $ageTotals['Female'] += $f;
            ?>
            <tr><td><?= $ag ?></td><td class="num"><?= $m ?></td><td class="num"><?= $f ?></td><td class="num"><?= $m + $f ?></td></tr>
            <?php endforeach; ?>
            <tr style="font-weight:700;background:#f4f6f8;"><td>Total</td><td class="num"><?= $ageTotals['Male'] ?></td><td class="num"><?= $ageTotals['Female'] ?></td><td class="num"><?= $ageTotals['Male'] + $ageTotals['Female'] ?></td></tr>
        </tbody>
    </table>
</div>

<!-- C. EPI -->
<div class="report-card">
    <h6>C. Immunization (EPI) Summary</h6>
    <table class="fhsis-table">
        <thead><tr><th>Vaccine</th><th class="num">Doses Given</th><th class="num">Children Reached</th></tr></thead>
        <tbody>
            <?php if (empty($immunizationRows)): ?>
            <tr><td colspan="3" class="text-center text-muted">No immunizations recorded for this period.</td></tr>
            <?php else: foreach ($immunizationRows as $row): ?>
            <tr><td><?= htmlspecialchars($row['vaccine_name']) ?></td><td class="num"><?= $row['doses_given'] ?></td><td class="num"><?= $row['children_reached'] ?></td></tr>
            <?php endforeach; endif; ?>
        </tbody>
    </table>
</div>

<!-- D. Nutrition -->
<div class="report-card">
    <h6>D. Nutritional Status Summary</h6>
    <div class="row">
        <div class="col-md-6">
            <table class="fhsis-table">
                <thead><tr><th>Nutritional Status</th><th class="num">Count</th></tr></thead>
                <tbody>
                    <?php if (empty($nutritionStatusCounts)): ?>
                    <tr><td colspan="2" class="text-center text-muted">No records for this period.</td></tr>
                    <?php else: foreach ($nutritionStatusCounts as $row): ?>
                    <tr><td><?= htmlspecialchars($row['label']) ?></td><td class="num"><?= $row['c'] ?></td></tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        <div class="col-md-6">
            <table class="fhsis-table">
                <thead><tr><th>Weight-for-Age</th><th class="num">Count</th></tr></thead>
                <tbody>
                    <?php if (empty($weightForAgeCounts)): ?>
                    <tr><td colspan="2" class="text-center text-muted">No records for this period.</td></tr>
                    <?php else: foreach ($weightForAgeCounts as $row): ?>
                    <tr><td><?= htmlspecialchars($row['label']) ?></td><td class="num"><?= $row['c'] ?></td></tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- E. Clinical services -->
<div class="report-card">
    <h6>E. Clinical Services Rendered</h6>
    <div class="row g-3 mb-3">
        <?php foreach ($serviceCategoryCounts as $cat => $cnt): ?>
        <div class="col-6 col-md-3"><div class="stat-box"><div class="val"><?= $cnt ?></div><div class="lbl"><?= htmlspecialchars($cat) ?></div></div></div>
        <?php endforeach; ?>
    </div>
    <table class="fhsis-table">
        <thead><tr><th>#</th><th>Service</th><th>Category</th><th class="num">Count</th></tr></thead>
        <tbody>
            <?php if (empty($topSubServices)): ?>
            <tr><td colspan="4" class="text-center text-muted">No services recorded for this period.</td></tr>
            <?php else: foreach ($topSubServices as $i => $s): ?>
            <tr><td><?= $i + 1 ?></td><td><?= htmlspecialchars($s['service_name']) ?></td><td><?= htmlspecialchars($s['category']) ?></td><td class="num"><?= $s['c'] ?></td></tr>
            <?php endforeach; endif; ?>
        </tbody>
    </table>
</div>

<p class="text-muted no-print" style="font-size:.8rem;">
    <i class="ti ti-info-circle me-1"></i>
    Diagnoses and nutritional-status labels are grouped from free-text fields entered during consultations, so near-duplicate phrasing may appear as separate rows. Age-group brackets follow the standard FHSIS scheme.
</p>

<?php include __DIR__ . '/../../includes/layout_footer.php'; ?>
