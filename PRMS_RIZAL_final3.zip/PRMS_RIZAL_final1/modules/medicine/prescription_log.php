<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();
$conn = getDBConnection();
$msg = '';
$uid = getCurrentUser()['id'];

if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    verifyCsrf();
    $conn->query("UPDATE prescriptions SET status='cancelled' WHERE id=".(int)$_GET['delete']);
    header('Location: prescription_log.php?msg=cancelled'); exit;
}

// Handle new prescription POST (moved from create_prescription.php)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $patient_id = (int)$_POST['patient_id'];
    $date       = $_POST['prescription_date'] ?? date('Y-m-d');
    $diagnosis  = trim($_POST['diagnosis'] ?? '');
    $notes      = trim($_POST['notes'] ?? '');
    $uid        = getCurrentUser()['id'];

    $medicine_ids = $_POST['medicine_id'] ?? [];
    $dosages      = $_POST['dosage'] ?? [];
    $frequencies  = $_POST['frequency'] ?? [];
    $durations    = $_POST['duration'] ?? [];
    $quantities   = $_POST['quantity'] ?? [];
    $instructions = $_POST['instructions'] ?? [];

    // rx_number is generated from a plain COUNT(*)+1, so two prescriptions
    // saved in the same instant could compute the same number — rx_number
    // has a UNIQUE constraint, so that collision is caught here and retried
    // with the next number rather than silently failing (mysqli_report is
    // OFF app-wide, so a failed execute() would otherwise pass silently and
    // leave prescription_items pointing at a non-existent prescription_id).
    // The whole header+items save is one transaction so a failure partway
    // through (e.g. after some items but not all) can't leave a half-saved
    // prescription behind.
    $conn->begin_transaction();
    $rx_id = null;
    $rx_number = null;
    try {
        for ($attempt = 0; $attempt < 5; $attempt++) {
            $r = $conn->query("SELECT COUNT(*) as cnt FROM prescriptions");
            $cnt = (int)$r->fetch_assoc()['cnt'] + 1 + $attempt;
            $candidate = 'RX-' . date('Y') . '-' . str_pad($cnt, 5, '0', STR_PAD_LEFT);

            $stmt = $conn->prepare("INSERT INTO prescriptions (rx_number,patient_id,prescribed_by,prescription_date,diagnosis,notes) VALUES (?,?,?,?,?,?)");
            $stmt->bind_param('siisss', $candidate, $patient_id, $uid, $date, $diagnosis, $notes);
            if ($stmt->execute()) {
                $rx_number = $candidate;
                $rx_id = $conn->insert_id;
                break;
            }
            if ($conn->errno !== 1062) { // not a duplicate-rx_number error — some other real problem
                throw new Exception('prescription insert failed: ' . $conn->error);
            }
        }
        if (!$rx_id) {
            throw new Exception('could not generate a unique RX number after 5 attempts');
        }

        foreach ($medicine_ids as $i => $mid) {
            if (!$mid) continue;
            $mid  = (int)$mid;
            $dos  = trim($dosages[$i] ?? '');
            $freq = trim($frequencies[$i] ?? '');
            $dur  = trim($durations[$i] ?? '');
            $qty  = (int)($quantities[$i] ?? 0);
            $inst = trim($instructions[$i] ?? '');
            $stmt2 = $conn->prepare("INSERT INTO prescription_items (prescription_id,medicine_id,dosage,frequency,duration,quantity,instructions) VALUES (?,?,?,?,?,?,?)");
            $stmt2->bind_param('iisssis', $rx_id, $mid, $dos, $freq, $dur, $qty, $inst);
            if (!$stmt2->execute()) {
                throw new Exception('prescription item insert failed: ' . $conn->error);
            }
        }

        $conn->commit();
        header("Location: prescription_log.php?msg=created&rx=$rx_number"); exit;
    } catch (Exception $e) {
        $conn->rollback();
        error_log('prescription save failed: ' . $e->getMessage());
        header("Location: prescription_log.php?msg=save_failed"); exit;
    }
}

if (isset($_GET['msg'])) { $msg = ['created'=>'Prescription created: '.($_GET['rx'] ?? '').'.','cancelled'=>'Prescription cancelled.'][$_GET['msg']] ?? ''; }
$errMsg = ($_GET['msg'] ?? '') === 'save_failed' ? 'Could not save the prescription — please try again. If this keeps happening, contact your administrator.' : null;

$prescriptions = [];
$r = $conn->query("SELECT pr.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no, u.full_name as prescribed_by_name, up.full_name as printed_by_name, (SELECT COUNT(*) FROM prescription_items pi WHERE pi.prescription_id=pr.id) as item_count FROM prescriptions pr LEFT JOIN patients p ON pr.patient_id=p.id LEFT JOIN users u ON pr.prescribed_by=u.id LEFT JOIN users up ON pr.printed_by=up.id WHERE 1=1" . doctorScopeSql('p') . " ORDER BY pr.prescription_date DESC, pr.id DESC LIMIT 200");
while ($row = $r->fetch_assoc()) $prescriptions[] = $row;

$patients = [];
$r = $conn->query("SELECT id, patient_no, CONCAT(first_name,' ',last_name) as name FROM patients WHERE status='active'" . doctorScopeSql() . " ORDER BY last_name");
while ($row = $r->fetch_assoc()) $patients[] = $row;

$medicines = [];
$r = $conn->query("SELECT id, medicine_name, generic_name, strength, dosage_form FROM medicines WHERE status='active' ORDER BY medicine_name");
while ($row = $r->fetch_assoc()) $medicines[] = $row;

// For print preview — this is also the admin hand-off point: the first time
// a prescription is opened for printing, stamp who printed it and when.
$printData = null;
if (isset($_GET['print']) && is_numeric($_GET['print'])) {
    verifyCsrf();
    $rxid = (int)$_GET['print'];
    $stmt = $conn->prepare("UPDATE prescriptions SET printed_at=NOW(), printed_by=? WHERE id=? AND printed_at IS NULL");
    $stmt->bind_param('ii', $uid, $rxid);
    $stmt->execute();
    $stmt->close();
    $r = $conn->query("SELECT pr.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no, p.date_of_birth, p.gender, p.address, u.full_name as prescribed_by_name, u.role, u.license_number FROM prescriptions pr LEFT JOIN patients p ON pr.patient_id=p.id LEFT JOIN users u ON pr.prescribed_by=u.id WHERE pr.id=$rxid LIMIT 1");
    $printData = $r->fetch_assoc();
    if ($printData) {
        $printData['items'] = [];
        $r = $conn->query("SELECT pi.*, m.medicine_name, m.generic_name, m.strength, m.dosage_form FROM prescription_items pi LEFT JOIN medicines m ON pi.medicine_id=m.id WHERE pi.prescription_id=$rxid");
        while ($row = $r->fetch_assoc()) $printData['items'][] = $row;
    }
}
$conn->close();

$pageTitle = 'Prescription Log';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<div class="page-header"><div class="page-block">
    <h5 class="m-b-10">Prescription Log</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Medicine</li><li class="breadcrumb-item active">Prescription Log</li></ul>
</div></div>

<?php if ($msg): ?><div class="alert alert-success alert-dismissible fade show"><i class="ti ti-circle-check me-2"></i><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
<?php if ($errMsg): ?><div class="alert alert-danger alert-dismissible fade show"><i class="ti ti-alert-circle me-2"></i><?= htmlspecialchars($errMsg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0"><i class="ti ti-file-text me-2" style="color:#0d6efd;"></i>Prescription Log</h6>
        <button class="btn btn-primary btn-sm" onclick="openAddRxModal()">
            <i class="ti ti-plus me-1"></i>New Prescription
        </button>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0">
                <thead><tr><th>RX Number</th><th>Patient</th><th>Date</th><th>Diagnosis</th><th>Medicines</th><th>Prescribed By</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php foreach ($prescriptions as $rx): ?>
                    <tr>
                        <td class="fw-semibold"><?= htmlspecialchars($rx['rx_number']) ?></td>
                        <td>
                            <div class="fw-semibold" style="font-size:.88rem;"><?= htmlspecialchars($rx['patient_name']) ?></div>
                            <div class="text-muted" style="font-size:.78rem;"><?= htmlspecialchars($rx['patient_no']) ?></div>
                        </td>
                        <td><?= date('M d, Y', strtotime($rx['prescription_date'])) ?></td>
                        <td style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= htmlspecialchars($rx['diagnosis'] ?: '—') ?></td>
                        <td class="text-dark"><?= $rx['item_count'] ?> item<?= $rx['item_count']!=1?'s':'' ?></td>
                        <td><?= htmlspecialchars($rx['prescribed_by_name'] ?: '—') ?></td>
                        <td class="text-dark">
                            <?= ucfirst($rx['status']) ?>
                            <?php if ($rx['status'] !== 'cancelled'): ?>
                                <?php if ($rx['printed_at']): ?>
                                <div><span style="font-size:.7rem;" title="Printed by <?= htmlspecialchars($rx['printed_by_name'] ?: '') ?>"><i class="ti ti-printer me-1"></i>Printed</span></div>
                                <?php else: ?>
                                <div><span style="font-size:.7rem;" title="Sent to admin — not yet printed"><i class="ti ti-clock me-1"></i>Needs Printing</span></div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?= csrfUrl('?print=' . $rx['id']) ?>" class="btn-view btn btn-sm me-1" title="Print/View RX"><i class="ti ti-printer"></i></a>
                            <button class="btn-delete btn btn-sm" onclick="confirmDelete('<?= csrfUrl('prescription_log.php?delete=' . $rx['id']) ?>','RX <?= htmlspecialchars($rx['rx_number']) ?>')"><i class="ti ti-x"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ══ NEW PRESCRIPTION MODAL ══ -->
<div class="modal fade" id="rxModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="ti ti-pill me-2"></i>New Prescription</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="" onsubmit="finalizeRxForm()"><?= csrfField() ?>
                <div class="modal-body">
                    <div class="row g-3">
                        <!-- Left: Prescription Header -->
                        <div class="col-md-4">
                            <div class="mb-3">
                                <div class="d-flex align-items-center mb-3">
                                    <div style="width:28px;height:28px;border-radius:50%;background:#e3f2fd;display:flex;align-items:center;justify-content:center;margin-right:10px;">
                                        <i class="ti ti-user" style="color:#0d6efd;font-size:.9rem;"></i>
                                    </div>
                                    <h6 class="mb-0 fw-bold" style="color:#1e3a5f;">Prescription Header</h6>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Patient <span class="text-danger">*</span></label>
                                    <select class="form-select" name="patient_id" required>
                                        <option value="">Select Patient</option>
                                        <?php foreach ($patients as $p): ?><option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['patient_no'].' - '.$p['name']) ?></option><?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Date <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control" name="prescription_date" value="<?= date('Y-m-d') ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Diagnosis / Indication</label>
                                    <textarea class="form-control" name="diagnosis" rows="3" placeholder="Diagnosis or reason for prescription"></textarea>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Notes / Instructions</label>
                                    <textarea class="form-control" name="notes" rows="2" placeholder="General patient instructions"></textarea>
                                </div>
                            </div>
                        </div>

                        <!-- Right: Medicine Items -->
                        <div class="col-md-8">
                            <div class="d-flex align-items-center mb-3">
                                <div style="width:28px;height:28px;border-radius:50%;background:#e8f5e9;display:flex;align-items:center;justify-content:center;margin-right:10px;">
                                    <i class="ti ti-pill" style="color:#2e7d32;font-size:.9rem;"></i>
                                </div>
                                <h6 class="mb-0 fw-bold" style="color:#1e3a5f;">Prescribed Medicines</h6>
                                <button type="button" class="btn btn-sm btn-outline-primary ms-auto" onclick="addMedicineRow()"><i class="ti ti-plus me-1"></i>Add Medicine</button>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-sm mb-0" id="rxTable">
                                    <thead><tr><th style="min-width:150px;">Medicine</th><th style="min-width:150px;">Dosage</th><th style="min-width:120px;">Frequency</th><th style="min-width:140px;">Duration</th><th style="min-width:65px;">Qty</th><th style="min-width:130px;">Instructions</th><th></th></tr></thead>
                                    <tbody id="rxItems">
                                        <tr id="row_0">
                                            <td><select class="form-select form-select-sm" name="medicine_id[]" required><option value="">Select</option><?php foreach ($medicines as $m): ?><option value="<?= $m['id'] ?>"><?= htmlspecialchars($m['medicine_name'].($m['strength']?' '.$m['strength']:'')) ?></option><?php endforeach; ?></select></td>
                                            <td>
                                                <div class="d-flex gap-1">
                                                    <input type="number" step="0.25" min="0" class="form-control form-control-sm dose-qty" placeholder="1" style="width:58px;" oninput="calcRowQty(this.closest('tr'))">
                                                    <select class="form-select form-select-sm dose-unit" onchange="calcRowQty(this.closest('tr'))">
                                                        <option>tablet(s)</option><option>capsule(s)</option><option>mL</option><option>mg</option><option>drop(s)</option><option>puff(s)</option><option>sachet(s)</option><option>ampule(s)</option>
                                                    </select>
                                                </div>
                                                <input type="hidden" name="dosage[]" class="dosage-hidden">
                                            </td>
                                            <td><select class="form-select form-select-sm freq-select" name="frequency[]" onchange="calcRowQty(this.closest('tr'))"><option value="">Select</option><option>Once daily</option><option>Twice daily</option><option>3x a day</option><option>4x a day</option><option>Every 6 hours</option><option>Every 8 hours</option><option>Every 12 hours</option><option>As needed (PRN)</option><option>Once</option></select></td>
                                            <td>
                                                <div class="d-flex gap-1">
                                                    <input type="number" min="0" class="form-control form-control-sm dur-num" placeholder="7" style="width:54px;" oninput="calcRowQty(this.closest('tr'))">
                                                    <select class="form-select form-select-sm dur-unit" onchange="calcRowQty(this.closest('tr'))">
                                                        <option>day(s)</option><option>week(s)</option><option>month(s)</option>
                                                    </select>
                                                </div>
                                                <input type="hidden" name="duration[]" class="duration-hidden">
                                            </td>
                                            <td><input type="number" class="form-control form-control-sm qty-input" name="quantity[]" min="0" placeholder="0" title="Auto-suggested from dosage × frequency × duration — edit freely, your value is kept once you type here." oninput="markQtyManual(this)"></td>
                                            <td><input type="text" class="form-control form-control-sm" name="instructions[]" placeholder="Special instructions"></td>
                                            <td><button type="button" class="btn btn-sm btn-link text-danger" onclick="this.closest('tr').remove()" disabled><i class="ti ti-trash"></i></button></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <p class="text-muted mb-0 mt-1" style="font-size:.76rem;">Qty auto-fills from dosage × frequency × duration once all three are set — you can still type your own.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="ti ti-x me-1"></i>Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save Prescription</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($printData): ?>
<!-- Print Preview Modal (auto-opened) -->
<div class="modal fade" id="printModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="ti ti-pill me-2"></i>Digital Prescription — <?= htmlspecialchars($printData['rx_number']) ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="rxPrintArea" style="background:#e9edf1;padding:24px;">
                <!-- Everything below is inline-styled on purpose: printRX() lifts this
                     element's raw HTML into a bare popup window with no stylesheet. -->
                <div style="font-family:'Open Sans',sans-serif;max-width:680px;margin:0 auto;background:#fff;border:1px solid #d5dbe2;box-shadow:0 2px 10px rgba(0,0,0,.06);" id="rxPrintContent">
                    <!-- Letterhead -->
                    <div style="display:flex;align-items:center;gap:14px;padding:20px 28px 16px;border-bottom:3px solid #1e3a5f;">
                        <img src="<?= ASSETS_URL ?>/images/rhu_logo.png" alt="RHU Rizal" style="width:54px;height:54px;min-width:54px;border-radius:50%;object-fit:cover;border:2px solid #1e3a5f;">
                        <div style="flex:1;">
                            <div style="font-size:1.2rem;font-weight:700;color:#1e3a5f;line-height:1.25;">Rural Health Unit &ndash; Rizal</div>
                            <div style="font-size:.78rem;color:#666;">Patient Record Management System</div>
                        </div>
                        <div style="text-align:right;">
                            <div style="font-size:.68rem;color:#888;text-transform:uppercase;letter-spacing:.5px;">RX Number</div>
                            <div style="font-size:1.1rem;font-weight:700;color:#0d6efd;"><?= htmlspecialchars($printData['rx_number']) ?></div>
                            <div style="font-size:.75rem;color:#666;"><?= date('F d, Y', strtotime($printData['prescription_date'])) ?></div>
                        </div>
                    </div>

                    <div style="padding:18px 28px;">
                        <!-- Patient info -->
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px 16px;margin-bottom:16px;font-size:.85rem;padding:12px 14px;background:#f8f9fa;border-radius:8px;border:1px solid #eef0f2;">
                            <div><span style="color:#888;font-size:.72rem;">PATIENT</span><br><strong><?= htmlspecialchars($printData['patient_name']) ?></strong></div>
                            <div><span style="color:#888;font-size:.72rem;">PATIENT NO.</span><br><strong><?= htmlspecialchars($printData['patient_no']) ?></strong></div>
                            <div><span style="color:#888;font-size:.72rem;">DATE OF BIRTH</span><br><?= date('M d, Y', strtotime($printData['date_of_birth'])) ?></div>
                            <div><span style="color:#888;font-size:.72rem;">GENDER</span><br><?= htmlspecialchars($printData['gender']) ?></div>
                            <?php if ($printData['diagnosis']): ?><div style="grid-column:1/-1;"><span style="color:#888;font-size:.72rem;">DIAGNOSIS</span><br><?= htmlspecialchars($printData['diagnosis']) ?></div><?php endif; ?>
                        </div>

                        <!-- Rx mark -->
                        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
                            <div style="font-size:1.8rem;font-weight:900;color:#1e3a5f;font-style:italic;line-height:1;">℞</div>
                            <div style="flex:1;height:1px;background:#e0e0e0;"></div>
                        </div>

                        <?php foreach ($printData['items'] as $idx => $item): ?>
                        <div style="margin-bottom:10px;padding:10px 12px;background:#f8f9fa;border-left:3px solid #0d6efd;border-radius:0 6px 6px 0;">
                            <div style="font-weight:700;font-size:.92rem;color:#1e3a5f;"><?= ($idx+1) ?>. <?= htmlspecialchars($item['medicine_name']) ?> <?= htmlspecialchars($item['strength'] ?? '') ?></div>
                            <?php if ($item['generic_name']): ?><div style="font-size:.78rem;color:#888;font-style:italic;">(<?= htmlspecialchars($item['generic_name']) ?>)</div><?php endif; ?>
                            <div style="font-size:.86rem;margin-top:4px;color:#333;">
                                <?php if ($item['dosage']): ?>Sig: <?= htmlspecialchars($item['dosage']) ?><?php endif; ?>
                                <?php if ($item['frequency']): ?> &mdash; <?= htmlspecialchars($item['frequency']) ?><?php endif; ?>
                                <?php if ($item['duration']): ?> for <?= htmlspecialchars($item['duration']) ?><?php endif; ?>
                                <?php if ($item['quantity']): ?> &mdash; Qty: <?= $item['quantity'] ?><?php endif; ?>
                            </div>
                            <?php if ($item['instructions']): ?><div style="font-size:.8rem;color:#666;margin-top:3px;"><em><?= htmlspecialchars($item['instructions']) ?></em></div><?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                        <?php if ($printData['notes']): ?><div style="margin-top:10px;padding:10px 12px;background:#fff3e0;border-radius:6px;font-size:.83rem;"><strong>Notes:</strong> <?= htmlspecialchars($printData['notes']) ?></div><?php endif; ?>

                        <!-- Signature -->
                        <div style="margin-top:28px;display:flex;justify-content:flex-end;">
                            <div style="text-align:center;">
                                <div style="border-top:1px solid #333;padding-top:6px;min-width:200px;">
                                    <div style="font-weight:600;font-size:.9rem;"><?= htmlspecialchars($printData['prescribed_by_name']) ?></div>
                                    <div style="font-size:.75rem;color:#666;"><?= ucfirst($printData['role']) ?>, RHU Rizal</div>
                                    <?php if (!empty($printData['license_number'])): ?>
                                    <div style="font-size:.72rem;color:#888;">License No. <?= htmlspecialchars($printData['license_number']) ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Footer strip -->
                    <div style="border-top:1px solid #e5e8eb;padding:10px 28px;display:flex;justify-content:space-between;font-size:.68rem;color:#999;">
                        <span>Generated by PRMS &bull; Rural Health Unit, Rizal</span>
                        <?php if (!empty($printData['printed_at'])): ?><span>Printed <?= date('M d, Y g:i A', strtotime($printData['printed_at'])) ?></span><?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="printRX()"><i class="ti ti-printer me-1"></i>Print / Save PDF</button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php
$extraJS='<script>
function openAddRxModal(){
    // Reset back to a single blank row each time the modal is (re)opened.
    const items = document.getElementById("rxItems");
    items.innerHTML = "";
    items.appendChild(rxRowTemplate.cloneNode(true));
    new bootstrap.Modal(document.getElementById("rxModal")).show();
}

// The first row in the PHP-rendered table (with the full medicine <select>
// options already in it) doubles as the template for every row after it —
// cloned rather than rebuilt from a second, separately-maintained HTML
// string, so the two can never drift out of sync with each other.
const rxRowTemplate = document.getElementById("row_0").cloneNode(true);

function addMedicineRow(){
    const row = rxRowTemplate.cloneNode(true);
    row.removeAttribute("id");
    row.querySelectorAll("input").forEach(el => { el.value = ""; delete el.dataset.manual; });
    row.querySelector("select[name=\'medicine_id[]\']").value = "";
    row.querySelector(".dose-unit").selectedIndex = 0;
    row.querySelector(".freq-select").value = "";
    row.querySelector(".dur-unit").selectedIndex = 0;
    row.querySelector("button.text-danger").disabled = false;
    document.getElementById("rxItems").appendChild(row);
}

// Roughly how many doses/day each frequency option implies — used only to
// suggest a quantity, never to block manual entry (PRN/"Once" are
// intentionally left out: there is no sane auto-multiplier for either).
const FREQUENCY_PER_DAY = {"Once daily":1,"Twice daily":2,"3x a day":3,"4x a day":4,"Every 6 hours":4,"Every 8 hours":3,"Every 12 hours":2};
const DURATION_DAYS = {"day(s)":1,"week(s)":7,"month(s)":30};

function calcRowQty(row){
    const qtyInput = row.querySelector(".qty-input");
    if (qtyInput.dataset.manual === "1") return; // user already typed their own — don\'t clobber it
    const doseQty  = parseFloat(row.querySelector(".dose-qty").value) || 0;
    const perDay   = FREQUENCY_PER_DAY[row.querySelector(".freq-select").value];
    const durNum   = parseFloat(row.querySelector(".dur-num").value) || 0;
    const durDays  = DURATION_DAYS[row.querySelector(".dur-unit").value];
    if (!doseQty || !perDay || !durNum || !durDays) return; // not enough info yet
    qtyInput.value = Math.ceil(doseQty * perDay * durNum * durDays);
}
function markQtyManual(input){ input.dataset.manual = "1"; }

// Combine each row\'s "1" + "tablet(s)" (etc.) into the single dosage/duration
// text string the server expects, right before the form actually submits.
function finalizeRxForm(){
    document.querySelectorAll("#rxItems tr").forEach(row => {
        const doseQty  = row.querySelector(".dose-qty").value.trim();
        const doseUnit = row.querySelector(".dose-unit").value;
        row.querySelector(".dosage-hidden").value = doseQty ? (doseQty + " " + doseUnit) : "";

        const durNum  = row.querySelector(".dur-num").value.trim();
        const durUnit = row.querySelector(".dur-unit").value;
        row.querySelector(".duration-hidden").value = durNum ? (durNum + " " + durUnit) : "";
    });
}
' . ($printData ? 'window.addEventListener("load",function(){ new bootstrap.Modal(document.getElementById("printModal")).show(); });' : '') . '
function printRX(){
    const content=document.getElementById("rxPrintContent").innerHTML;
    const w=window.open("","_blank","width=800,height=700");
    w.document.write(`<!DOCTYPE html><html><head><title>Prescription</title><style>body{font-family:Open Sans,sans-serif;margin:32px;}@media print{body{margin:0;}}</style></head><body>${content}</body></html>`);
    w.document.close();
    w.focus();
    setTimeout(()=>w.print(),500);
}
</script>';
include __DIR__ . '/../../includes/layout_footer.php';
?>
