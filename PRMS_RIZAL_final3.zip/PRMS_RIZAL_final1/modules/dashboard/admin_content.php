<?php
// ── Admin Dashboard: system-wide stats + user management shortcuts ────────
// Expects: $conn (open mysqli connection) from dashboard.php

if (!isset($conn) || !is_object($conn) || !method_exists($conn, 'query')) {
    require_once __DIR__ . '/../../config/database.php';
    $conn = getDBConnection();
}
require_once __DIR__ . '/../../includes/helpers.php';

$stats = [];
$queries = [
    'patients'       => "SELECT COUNT(*) as cnt FROM patients WHERE status='active'",
    'checkups_today' => "SELECT COUNT(*) as cnt FROM checkups WHERE checkup_date = CURDATE()",
    'prescriptions'  => "SELECT COUNT(*) as cnt FROM prescriptions WHERE prescription_date = CURDATE()",
    'vaccinations'   => "SELECT COUNT(*) as cnt FROM immunization_records WHERE date_given = CURDATE()",
    'total_checkups' => "SELECT COUNT(*) as cnt FROM checkups WHERE MONTH(checkup_date)=MONTH(CURDATE()) AND YEAR(checkup_date)=YEAR(CURDATE())",
    'upcoming_doses' => "SELECT COUNT(*) as cnt FROM immunization_records WHERE next_dose_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)",
];
foreach ($queries as $key => $sql) {
    $r = $conn->query($sql);
    $stats[$key] = (is_object($r) && method_exists($r, 'fetch_assoc')) ? (int) $r->fetch_assoc()['cnt'] : 0;
}

// ── Users by role ───────────────────────────────────────────────────────
$roleCounts = ['admin' => 0, 'doctor' => 0, 'nurse' => 0, 'staff' => 0];
$r = $conn->query("SELECT role, COUNT(*) as cnt FROM users WHERE status='active' GROUP BY role");
if (is_object($r) && method_exists($r, 'fetch_assoc')) {
    while ($row = $r->fetch_assoc()) {
        if (isset($roleCounts[$row['role']])) $roleCounts[$row['role']] = (int)$row['cnt'];
    }
}

// ── Monthly checkups (last 6 months) ──────────────────────────────────────
$monthlyData = [];
for ($i = 5; $i >= 0; $i--) {
    $r = $conn->query("SELECT COUNT(*) as cnt, DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL $i MONTH), '%b %Y') as label FROM checkups WHERE MONTH(checkup_date)=MONTH(DATE_SUB(CURDATE(), INTERVAL $i MONTH)) AND YEAR(checkup_date)=YEAR(DATE_SUB(CURDATE(), INTERVAL $i MONTH))");
    if (is_object($r) && method_exists($r, 'fetch_assoc')) {
        $row = $r->fetch_assoc();
        $monthlyData[] = ['label' => $row['label'] ?? '—', 'cnt' => (int)($row['cnt'] ?? 0)];
    }
}

// ── Gender distribution ────────────────────────────────────────────────────
$genderData = [];
$r = $conn->query("SELECT gender, COUNT(*) as cnt FROM patients GROUP BY gender");
if (is_object($r) && method_exists($r, 'fetch_assoc')) {
    while ($row = $r->fetch_assoc()) $genderData[] = $row;
}

// ── Recent patients ────────────────────────────────────────────────────────
$recentPatients = [];
$r = $conn->query("SELECT id, patient_no, CONCAT(first_name,' ',last_name) as name, date_of_birth, gender, created_at FROM patients ORDER BY created_at DESC LIMIT 8");
if (is_object($r) && method_exists($r, 'fetch_assoc')) {
    while ($row = $r->fetch_assoc()) $recentPatients[] = $row;
}
?>

<!-- ══ Stat Cards ══ -->
<div class="row g-3 mb-4">
    <?php
    $cards = [
        ['icon'=>'ti-users',        'color'=>'#1565c0','bg'=>'#e3f2fd','value'=>$stats['patients'],       'label'=>'Active Patients'],
        ['icon'=>'ti-stethoscope',  'color'=>'#2e7d32','bg'=>'#e8f5e9','value'=>$stats['checkups_today'], 'label'=>'Checkups Today'],
        ['icon'=>'ti-vaccine',      'color'=>'#e65100','bg'=>'#fff3e0','value'=>$stats['vaccinations'],   'label'=>'Vaccinations Today'],
        ['icon'=>'ti-pill', 'color'=>'#c62828','bg'=>'#fce4ec','value'=>$stats['prescriptions'],  'label'=>'Prescriptions Today'],
    ];
    renderStatCards($cards);
    ?>
</div>

<!-- ══ Charts Row ══ -->
<div class="row g-3 mb-4">
    <div class="col-xl-8 col-md-12">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h6 class="section-title mb-0">
                    <i class="ti ti-chart-bar me-2" style="color:#0d6efd;"></i>Monthly Checkups
                    <small class="text-muted fw-normal ms-1" style="font-size:.78rem;">(Last 6 Months)</small>
                </h6>
            </div>
            <div class="card-body" style="padding:16px 18px;">
                <canvas id="monthlyChart" style="max-height:220px;width:100%;"></canvas>
            </div>
        </div>
    </div>
    <div class="col-xl-4 col-md-6">
        <div class="card h-100">
            <div class="card-header">
                <h6 class="section-title mb-0">
                    <i class="ti ti-chart-pie me-2" style="color:#0d6efd;"></i>Patient Gender
                </h6>
            </div>
            <div class="card-body d-flex flex-column align-items-center justify-content-center" style="padding:14px 18px;">
                <canvas id="genderChart" style="max-height:200px;max-width:200px;"></canvas>
                <div class="d-flex gap-4 mt-3">
                    <?php foreach ($genderData as $g): ?>
                    <div class="text-center">
                        <div class="fw-bold" style="font-size:1.3rem;"><?= $g['cnt'] ?></div>
                        <div class="text-muted" style="font-size:.8rem;"><?= htmlspecialchars($g['gender']) ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ══ User Management + Recent Patients ══ -->
<div class="row g-3">
    <!-- User Management Shortcuts -->
    <div class="col-xl-4 col-md-12">
        <div class="card h-100">
            <div class="card-header">
                <h6 class="section-title mb-0">
                    <i class="ti ti-settings me-2" style="color:#0d6efd;"></i>User Management
                </h6>
            </div>
            <div class="card-body">
                <ul class="list-group list-group-flush mb-3">
                    <?php
                    $roleLabels = ['admin'=>'Admins','doctor'=>'Doctors','nurse'=>'Nurses / Midwives','staff'=>'Staff'];
                    $roleBadges = ['admin'=>'bg-danger','doctor'=>'bg-primary','nurse'=>'bg-success','staff'=>'bg-secondary'];
                    foreach ($roleCounts as $roleKey => $cnt):
                    ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center px-0 py-2">
                        <span class="text-muted" style="font-size:.9rem;"><?= $roleLabels[$roleKey] ?></span>
                        <span class="badge <?= $roleBadges[$roleKey] ?> rounded-pill fs-6"><?= $cnt ?></span>
                    </li>
                    <?php endforeach; ?>
                </ul>
                <div class="d-flex flex-column gap-2">
                    <a href="<?= BASE_URL ?>/modules/admin/users.php" class="btn btn-primary btn-sm">
                        <i class="ti ti-user-plus me-1"></i>Manage Users
                    </a>
                    <a href="<?= BASE_URL ?>/patients.php" class="btn btn-outline-primary btn-sm">
                        <i class="ti ti-user-plus me-1"></i>Register Patient
                    </a>
                    <a href="<?= BASE_URL ?>/modules/reports/fhsis.php" class="btn btn-outline-primary btn-sm">
                        <i class="ti ti-report-analytics me-1"></i>FHSIS Report
                    </a>
                    <a href="<?= BASE_URL ?>/modules/reports/morbidity.php" class="btn btn-outline-primary btn-sm">
                        <i class="ti ti-activity me-1"></i>Morbidity Report
                    </a>
                    <a href="<?= BASE_URL ?>/modules/community/households.php" class="btn btn-outline-primary btn-sm">
                        <i class="ti ti-home me-1"></i>Households
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Patients Table -->
    <div class="col-xl-8 col-md-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h6 class="section-title mb-0">
                    <i class="ti ti-users me-2" style="color:#0d6efd;"></i>Recently Registered Patients
                </h6>
                <a href="<?= BASE_URL ?>/patients.php" class="btn btn-sm btn-outline-primary">View All</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0" style="font-size:.88rem;">
                        <thead>
                            <tr>
                                <th>Patient No.</th>
                                <th>Name</th>
                                <th>Gender</th>
                                <th>Date of Birth</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recentPatients)): ?>
                            <tr><td colspan="5" class="text-center text-muted py-4">No patients registered yet.</td></tr>
                            <?php else: foreach ($recentPatients as $p): ?>
                            <tr>
                                <td><span class="badge bg-primary bg-opacity-10 text-primary fw-semibold"><?= htmlspecialchars($p['patient_no']) ?></span></td>
                                <td class="fw-semibold"><?= htmlspecialchars($p['name']) ?></td>
                                <td><?= htmlspecialchars($p['gender']) ?></td>
                                <td><?= date('M d, Y', strtotime($p['date_of_birth'])) ?></td>
                                <td>
                                    <a href="<?= BASE_URL ?>/patients.php?view=<?= $p['id'] ?>" class="btn-view btn">
                                        <i class="ti ti-eye me-1"></i>View
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$extraJS = '
<script>
const mCtx = document.getElementById("monthlyChart");
if (mCtx) {
    new Chart(mCtx.getContext("2d"), {
        type: "bar",
        data: {
            labels: ' . json_encode(array_column($monthlyData, 'label')) . ',
            datasets: [{
                label: "Checkups",
                data: ' . json_encode(array_column($monthlyData, 'cnt')) . ',
                backgroundColor: "rgba(13,110,253,0.15)",
                borderColor: "#0d6efd",
                borderWidth: 2,
                borderRadius: 6,
                hoverBackgroundColor: "rgba(13,110,253,0.3)"
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, ticks: { stepSize: 1 }, grid: { color: "#f0f0f0" } } }
        }
    });
}

const gCtx = document.getElementById("genderChart");
if (gCtx) {
    new Chart(gCtx.getContext("2d"), {
        type: "doughnut",
        data: {
            labels: ' . json_encode(array_column($genderData, 'gender')) . ',
            datasets: [{
                data: ' . json_encode(array_column($genderData, 'cnt')) . ',
                backgroundColor: ["#0d6efd","#e91e63","#ff9800","#4caf50"],
                borderWidth: 3,
                borderColor: "#fff"
            }]
        },
        options: { responsive: true, cutout: "68%", plugins: { legend: { position: "bottom" } } }
    });
}
</script>';
