<?php
require_once __DIR__ . '/config/session.php';
require_once __DIR__ . '/config/database.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . '/dashboard.php');
    exit;
}

$error = '';
$success = '';
// Public self-registration may only ever create a patient or a base "staff"
// account. Nurse/doctor/admin accounts carry clinical/administrative access
// and must be provisioned by an administrator via modules/admin/users.php —
// never chosen by the person submitting this form.
$validRoles = ['patient', 'staff'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role      = $_POST['role'] ?? 'patient';
    if (!in_array($role, $validRoles, true)) $role = 'patient';

    $username  = trim($_POST['username'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $password  = $_POST['password'] ?? '';
    $confirm   = $_POST['confirm_password'] ?? '';

    if ($role === 'patient') {
        // ── Patient self-registration fields ────────────────────────────
        $first_name  = trim($_POST['first_name'] ?? '');
        $last_name   = trim($_POST['last_name'] ?? '');
        $middle_name = trim($_POST['middle_name'] ?? '');
        $dob         = $_POST['date_of_birth'] ?? '';
        $gender      = $_POST['gender'] ?? '';
        $address     = trim($_POST['address'] ?? '');
        $contact     = trim($_POST['contact_number'] ?? '');
        $guardian    = trim($_POST['guardian_name'] ?? '');
        $gcontact    = trim($_POST['guardian_contact'] ?? '');
        $full_name   = trim($first_name . ' ' . $middle_name . ' ' . $last_name);
        $full_name   = preg_replace('/\s+/', ' ', $full_name);
    } else {
        $full_name = trim($_POST['full_name'] ?? '');
    }

    if (empty($username) || empty($email) || empty($password)) {
        $error = 'All fields are required.';
    } elseif (empty($_POST['terms_agree'])) {
        $error = 'You must agree to the Terms and Conditions and Privacy Notice to create an account.';
    } elseif ($role === 'patient' && (empty($first_name) || empty($last_name) || empty($dob) || empty($gender))) {
        $error = 'Please fill in your first name, last name, date of birth, and gender.';
    } elseif ($role !== 'patient' && empty($full_name)) {
        $error = 'All fields are required.';
    } elseif (($_POST['csrf_token'] ?? '') === '' || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $error = 'Security check failed (invalid or expired form token). Please refresh the page and try again.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $conn = getDBConnection();
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1");
        $stmt->bind_param('ss', $username, $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $error = 'Username or email already exists.';
            $stmt->close();
            $conn->close();
        } else {
            $stmt->close();
            $hashed = password_hash($password, PASSWORD_DEFAULT);

            $conn->begin_transaction();
            try {
                $stmt = $conn->prepare("INSERT INTO users (full_name, username, email, password, role) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param('sssss', $full_name, $username, $email, $hashed, $role);
                if (!$stmt->execute()) throw new Exception('user insert failed');
                $newUserId = $conn->insert_id;
                $stmt->close();

                if ($role === 'patient') {
                    $r   = $conn->query("SELECT COUNT(*) as cnt FROM patients");
                    $cnt = (int)$r->fetch_assoc()['cnt'] + 1;
                    $patient_no = 'RHU-' . date('Y') . '-' . str_pad($cnt, 5, '0', STR_PAD_LEFT);

                    $stmt = $conn->prepare("INSERT INTO patients (user_id, patient_no, first_name, last_name, middle_name, date_of_birth, gender, address, contact_number, guardian_name, guardian_contact) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
                    $stmt->bind_param('issssssssss', $newUserId, $patient_no, $first_name, $last_name, $middle_name, $dob, $gender, $address, $contact, $guardian, $gcontact);
                    if (!$stmt->execute()) throw new Exception('patient insert failed');
                    $stmt->close();
                }

                $conn->commit();
                $success = 'Account created successfully! You can now <a href="' . BASE_URL . '/login.php" class="fw-semibold">sign in</a>.';
            } catch (Exception $e) {
                $conn->rollback();
                $error = 'Registration failed. Please try again.';
            }
            $conn->close();
        }
    }
}
?>
<!doctype html>
<html lang="en" data-pc-preset="preset-1" data-pc-direction="ltr" dir="ltr" data-pc-theme="light">
<head>
    <title>Register | PRMS - Patient Record Management System</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui"/>
    <link rel="icon" href="<?= ASSETS_URL ?>/images/favicon.svg" type="image/x-icon"/>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/fonts/tabler-icons.min.css"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/fonts/feather.css"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/fonts/fontawesome.css"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/css/style.css" id="main-style-link"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/css/auth.css"/>
    <style>
        html, body { margin: 0; padding: 0; height: 100%; overflow: hidden; }

        .auth-main {
            background: linear-gradient(135deg, #005fdb 0%, #88a7d8 50%, #ffffff 100%);
            height: 100vh;
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 18px;
            box-sizing: border-box;
        }


        /* ── Landscape split card ── */
        .auth-wrapper { width: 100%; max-width: 1220px; position: relative; z-index: 10; }
        .auth-card {
            border-radius: 18px;
            box-shadow: 0 24px 64px rgba(0,0,0,.35);
            border: none;
            overflow: hidden;
            display: flex;
            flex-direction: row;
            height: min(95vh, 900px);
            background: #fff;
        }

        /* ── Left branding panel ── */
        .auth-brand {
            flex: 0 0 29%;
            background: linear-gradient(135deg, #1e3a5f, #0d6efd);
            color: #fff;
            padding: 30px 26px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        .rhu-logo-circle {
            width: 96px; height: 96px;
            border-radius: 50%;
            background: #fff;
            border: 3px solid rgba(255,255,255,.85);
            box-shadow: 0 4px 14px rgba(0,0,0,.25);
            margin: 0 auto 20px;
            display: flex; align-items: center; justify-content: center;
            overflow: hidden;
            flex-shrink: 0;
        }
        .rhu-logo-circle img { width: 100%; height: 100%; object-fit: cover; border-radius: 50%; display: block; }
        .prms-badge {
            background: rgba(255,255,255,.2);
            border-radius: 50px; padding: 6px 22px;
            display: inline-block; font-size: .84rem;
            font-weight: 600; letter-spacing: 2px; margin-bottom: 16px;
        }
        .auth-brand h2 { font-weight: 700; font-size: 1.75rem; margin: 0 0 6px; color: #e0e0e0; }
        .auth-brand p.tagline { opacity: .85; font-size: .95rem; margin: 0 0 26px; }
        .brand-divider { width: 50px; height: 3px; background: rgba(255,255,255,.35); border-radius: 3px; margin: 4px auto 26px; }
        .brand-note { font-size: .87rem; opacity: .8; line-height: 1.65; max-width: 280px; margin: 0 auto; }
        .brand-signin { margin-top: 30px; font-size: .9rem; }
        .brand-signin a {
            display: inline-block; margin-top: 12px;
            color: #fff; border: 1.5px solid rgba(255,255,255,.6);
            padding: 9px 28px; border-radius: 8px; font-weight: 600;
            text-decoration: none; transition: all .2s;
        }
        .brand-signin a:hover { background: rgba(255,255,255,.15); border-color: #fff; }

        /* ── Right form panel ── */
        .auth-body {
            flex: 1;
            padding: 26px 48px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .auth-body::-webkit-scrollbar { width: 6px; }
        .auth-body::-webkit-scrollbar-thumb { background: #d9e2ef; border-radius: 6px; }

        .form-control, .form-select {
            border-radius: 8px; padding: 9px 14px;
            border: 1.5px solid #e0e0e0; font-size: .88rem; transition: all .2s;
        }
        .form-control:focus, .form-select:focus { border-color: #0d6efd; box-shadow: 0 0 0 3px rgba(13,110,253,.1); }
        .input-group-text { border: 1.5px solid #e0e0e0; background: #f8f9fa; padding: 9px 13px; }
        .input-group { display: flex; }
        .input-group .form-control { border-left: none; border-radius: 0 8px 8px 0 !important; min-width: 0; flex: 1; }
        .input-group .input-group-text:first-child { border-right: none; border-radius: 8px 0 0 8px !important; }
        .input-group .input-group-text:last-child  { border-left: none;  border-radius: 0 8px 8px 0 !important; cursor: pointer; }

        .btn-register {
            background: linear-gradient(135deg, #1e3a5f, #0d6efd);
            border: none; padding: 12px; font-size: .96rem; font-weight: 600;
            border-radius: 10px; transition: all .3s; width: 100%; color: #fff;
        }
        .btn-register:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(13,110,253,.4); color: #fff; }

        .label-text { font-weight: 600; font-size: .8rem; color: #444; margin-bottom: 5px; display: block; }
        .error-alert   { border-radius: 8px; padding: 9px 15px; background: #fff3f3; border: 1px solid #ffcdd2; color: #c62828; font-size: .85rem; }
        .success-alert { border-radius: 8px; padding: 9px 15px; background: #f0fff4; border: 1px solid #a5d6a7; color: #2e7d32; font-size: .85rem; }
        .password-strength { height: 4px; border-radius: 4px; margin-top: 5px; transition: all .3s; background: #e0e0e0; }

        .field-grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px 18px; }
        .two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 12px 18px; }
        .span-all { grid-column: 1 / -1; }

        .section-title { font-weight: 700; font-size: 1.3rem; color: #1e3a5f; margin: 0 0 3px; }
        .section-sub { color: #777; font-size: .85rem; margin: 0 0 14px; }

        /* ── Register-as toggle ── */
        .type-toggle { display: flex; gap: 10px; }
        .type-toggle input[type="radio"] { display: none; }
        .type-toggle label {
            flex: 1; text-align: center; padding: 9px 10px; border-radius: 8px;
            border: 1.5px solid #e0e0e0; font-size: .85rem; font-weight: 600; color: #555;
            cursor: pointer; transition: all .2s;
        }
        .type-toggle input[type="radio"]:checked + label {
            background: linear-gradient(135deg, #1e3a5f, #0d6efd); border-color: transparent; color: #fff;
        }
        .type-helper { font-size: .74rem; color: #888; margin-top: 5px; display: block; }

        /* ── Terms & Privacy ── */
        .terms-check-row { display: flex; align-items: flex-start; gap: 10px; margin: 16px 0; text-align: left; }
        .terms-check-row input[type="checkbox"] { margin-top: 3px; width: 16px; height: 16px; flex-shrink: 0; cursor: pointer; }
        .terms-check-row label { font-size: .83rem; color: #555; line-height: 1.5; cursor: pointer; }
        .terms-check-row a { color: #0d6efd; font-weight: 600; text-decoration: none; }
        .terms-check-row a:hover { text-decoration: underline; }
        .terms-overlay {
            display: none; position: fixed; inset: 0; background: rgba(15,25,40,.6);
            z-index: 2000; align-items: center; justify-content: center; padding: 20px;
        }
        .terms-overlay.show { display: flex; }
        .terms-box {
            background: #fff; border-radius: 14px; max-width: 600px; width: 100%;
            max-height: 82vh; display: flex; flex-direction: column; overflow: hidden;
            box-shadow: 0 24px 64px rgba(0,0,0,.4);
        }
        .terms-box-header {
            background: linear-gradient(135deg, #1e3a5f, #0d6efd); color: #fff;
            padding: 18px 24px; display: flex; align-items: center; justify-content: space-between;
        }
        .terms-box-header h5 { margin: 0; font-size: 1.05rem; font-weight: 700; }
        .terms-box-header button { background: none; border: none; color: #fff; font-size: 1.3rem; cursor: pointer; line-height: 1; opacity: .85; }
        .terms-box-header button:hover { opacity: 1; }
        .terms-box-body { padding: 22px 26px; overflow-y: auto; font-size: .87rem; color: #444; line-height: 1.65; text-align: left; }
        .terms-box-body h6 { color: #1e3a5f; font-weight: 700; margin: 16px 0 6px; font-size: .92rem; }
        .terms-box-body h6:first-child { margin-top: 0; }
        .terms-box-body p, .terms-box-body ul { margin: 0 0 8px; }
        .terms-box-body ul { padding-left: 20px; }
        .terms-box-footer { padding: 14px 24px; border-top: 1px solid #eee; text-align: right; }
        .terms-box-footer button {
            background: linear-gradient(135deg, #1e3a5f, #0d6efd); color: #fff; border: none;
            padding: 9px 22px; border-radius: 8px; font-weight: 600; font-size: .88rem; cursor: pointer;
        }

        /* ── Small-screen fallback: stack panels, allow page scroll ── */
        @media (max-width: 860px) {
            html, body { overflow: auto; }
            .auth-main { height: auto; min-height: 100vh; padding: 20px 14px; }
            .auth-card { flex-direction: column; height: auto; }
            .auth-brand { flex: none; padding: 24px 20px; }
            .auth-body { overflow-y: visible; padding: 22px 22px 26px; }
            .field-grid-3 { grid-template-columns: 1fr 1fr; }
            .two-col { grid-template-columns: 1fr; }
        }
        @media (max-width: 480px) {
            .field-grid-3 { grid-template-columns: 1fr; }
        }
    </style>
    <style>
        /* Compact adjustments for register page: reduce whitespace and input sizes */
        .auth-main { padding: 12px; }
        .auth-wrapper { max-width: 950px; }
        .auth-card { height: min(88vh, 720px); border-radius: 14px; }
        .auth-brand { padding: 18px 16px; flex: 0 0 28%; }
        .auth-body { padding: 18px 28px; }
        .rhu-logo-circle { width: 80px; height: 80px; }
        .form-control, .form-select { padding: 8px 10px; font-size: .84rem; }
        .input-group-text { padding: 8px 10px; }
        .field-grid-3, .two-col { gap: 8px 12px; }
        .label-text { font-size: .8rem; margin-bottom: 4px; }
        .btn-register { padding: 10px; font-size: .92rem; }
    </style>
</head>
<body>
<noscript><style>html body{opacity:1 !important;}</style></noscript>
<div class="loader-bg fixed inset-0 bg-white z-[1034]">
    <div class="loader-track h-[5px] w-full inline-block absolute overflow-hidden top-0">
        <div class="loader-fill w-[300px] h-[5px] bg-primary-500 absolute top-0 left-0"></div>
    </div>
</div>

<div class="auth-main">
    <div class="floating-shapes" aria-hidden="true" style="position:fixed;inset:0;overflow:hidden;pointer-events:none;z-index:0;">
        <span style="width:300px;height:300px;background:rgba(255,255,255,.05);top:-50px;left:-100px;animation-delay:0s"></span>
        <span style="width:200px;height:200px;background:rgba(255,255,255,.07);bottom:50px;right:-50px;animation-delay:3s"></span>
        <span style="width:100px;height:100px;background:rgba(255,255,255,.05);top:40%;left:10%;animation-delay:1.5s"></span>
    </div>

    <div class="auth-wrapper">
        <div class="auth-card card">

            <!-- ══ Left branding panel ══ -->
            <div class="auth-brand">
                <div class="rhu-logo-circle" title="RHU Rizal Logo">
                    <img src="<?= ASSETS_URL ?>/images/rhu_logo.png" alt="Rural Health Unit of Rizal logo">
                </div>
                <div class="prms-badge"><i class="ti ti-activity me-1"></i> PRMS</div>
                <h2>Create Your Account</h2>
                <p class="tagline">Rural Health Unit &bull; Rizal</p>
                <div class="brand-divider"></div>
                <p class="brand-note">Join the Patient Record Management System to manage appointments and access your health records online.</p>
                <div class="brand-signin">
                    <span style="opacity:.85;">Already have an account?</span><br>
                    <a href="<?= BASE_URL ?>/login.php"><i class="ti ti-login me-1"></i>Sign In</a>
                </div>
            </div>

            <!-- ══ Right form panel ══ -->
            <div class="auth-body">
                <div class="section-title">Register</div>
                <div class="section-sub">Fill in your details to request system access</div>

                <?php if ($error): ?>
                    <div class="error-alert mb-2 d-flex align-items-center gap-2">
                        <i class="ti ti-alert-circle"></i> <?= htmlspecialchars($error) ?>
                    </div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="success-alert mb-2 d-flex align-items-center gap-2">
                        <i class="ti ti-circle-check"></i> <?= $success ?>
                    </div>
                <?php endif; ?>

                <?php if (!$success):
                    $postRole = $_POST['role'] ?? 'patient';
                    $isPatientTab = $postRole === 'patient';
                ?>
                <form method="POST" action="" id="registerForm">
                    <?= csrfField() ?>
                    <!-- Register-as toggle -->
                    <div class="mb-2">
                        <label class="label-text">I am registering as</label>
                        <div class="type-toggle">
                            <input type="radio" name="accountType" id="tabPatient" autocomplete="off" <?= $isPatientTab ? 'checked' : '' ?> onchange="toggleAccountType('patient')">
                            <label for="tabPatient"><i class="ti ti-user me-1"></i>Patient</label>

                            <input type="radio" name="accountType" id="tabStaff" autocomplete="off" <?= !$isPatientTab ? 'checked' : '' ?> onchange="toggleAccountType('staff')">
                            <label for="tabStaff"><i class="ti ti-stethoscope me-1"></i>Staff Member</label>
                        </div>
                        <small class="type-helper">Patients get their own portal to request appointments. Staff accounts are for RHU personnel.</small>
                    </div>

                    <!-- ══ Patient-only fields ══ -->
                    <div id="patientFields" class="field-grid-3 mb-2" style="<?= $isPatientTab ? '' : 'display:none;' ?>">
                        <div>
                            <label class="label-text">First Name</label>
                            <input type="text" class="form-control" name="first_name" placeholder="First name"
                                   value="<?= htmlspecialchars($_POST['first_name'] ?? '') ?>" <?= $isPatientTab ? 'required' : '' ?>>
                        </div>
                        <div>
                            <label class="label-text">Last Name</label>
                            <input type="text" class="form-control" name="last_name" placeholder="Last name"
                                   value="<?= htmlspecialchars($_POST['last_name'] ?? '') ?>" <?= $isPatientTab ? 'required' : '' ?>>
                        </div>
                        <div>
                            <label class="label-text">Middle Name</label>
                            <input type="text" class="form-control" name="middle_name" placeholder="Optional"
                                   value="<?= htmlspecialchars($_POST['middle_name'] ?? '') ?>">
                        </div>
                        <div>
                            <label class="label-text">Date of Birth</label>
                            <input type="date" class="form-control" name="date_of_birth"
                                   value="<?= htmlspecialchars($_POST['date_of_birth'] ?? '') ?>" <?= $isPatientTab ? 'required' : '' ?>>
                        </div>
                        <div>
                            <label class="label-text">Gender</label>
                            <select class="form-select" name="gender">
                                <option value="">Select</option>
                                <option value="Male"   <?= ($_POST['gender'] ?? '') === 'Male'   ? 'selected' : '' ?>>Male</option>
                                <option value="Female" <?= ($_POST['gender'] ?? '') === 'Female' ? 'selected' : '' ?>>Female</option>
                            </select>
                        </div>
                        <div>
                            <label class="label-text">Contact Number</label>
                            <input type="text" class="form-control" name="contact_number" placeholder="09XX-XXX-XXXX"
                                   value="<?= htmlspecialchars($_POST['contact_number'] ?? '') ?>">
                        </div>
                        <div class="span-all">
                            <label class="label-text">Address</label>
                            <input type="text" class="form-control" name="address" placeholder="Barangay, Municipality, Province"
                                   value="<?= htmlspecialchars($_POST['address'] ?? '') ?>">
                        </div>
                        <div>
                            <label class="label-text">Guardian Name <small class="text-muted">(if minor)</small></label>
                            <input type="text" class="form-control" name="guardian_name" placeholder="Parent / Guardian"
                                   value="<?= htmlspecialchars($_POST['guardian_name'] ?? '') ?>">
                        </div>
                        <div>
                            <label class="label-text">Guardian Contact</label>
                            <input type="text" class="form-control" name="guardian_contact" placeholder="Contact number"
                                   value="<?= htmlspecialchars($_POST['guardian_contact'] ?? '') ?>">
                        </div>
                    </div>

                    <!-- ══ Staff-only fields ══ -->
                    <div id="staffFields" class="two-col mb-2" style="<?= $isPatientTab ? 'display:none;' : '' ?>">
                        <div>
                            <label class="label-text">Full Name</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="ti ti-id" style="color:#0d6efd;"></i></span>
                                <input type="text" class="form-control" name="full_name" placeholder="e.g. Juan Dela Cruz"
                                       value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>" <?= $isPatientTab ? '' : 'required' ?>>
                            </div>
                        </div>
                        <div>
                            <label class="label-text">Staff Role</label>
                            <input type="text" class="form-control" value="Staff" disabled>
                            <small class="type-helper">Need a Nurse, Doctor, or Administrator account? Ask your RHU administrator to create one from the Staff Management panel — those roles aren't self-service.</small>
                        </div>
                    </div>

                    <!-- Hidden field actually submitted as the account role -->
                    <input type="hidden" name="role" id="roleField" value="<?= htmlspecialchars($postRole) ?>">

                    <div class="two-col mb-2">
                        <div>
                            <label class="label-text">Username</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="ti ti-user" style="color:#0d6efd;"></i></span>
                                <input type="text" class="form-control" name="username" placeholder="Username"
                                       value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
                            </div>
                        </div>
                        <div>
                            <label class="label-text">Email Address</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="ti ti-mail" style="color:#0d6efd;"></i></span>
                                <input type="email" class="form-control" name="email" placeholder="your@email.com"
                                       value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="two-col mb-2">
                        <div>
                            <label class="label-text">Password</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="ti ti-lock" style="color:#0d6efd;"></i></span>
                                <input type="password" class="form-control" name="password" id="pw1"
                                       placeholder="Min. 8 characters" required oninput="checkStrength(this.value)"
                                       style="border-radius:0!important;">
                                <span class="input-group-text" onclick="togglePw('pw1', this)" title="Show/Hide">
                                    <i class="ti ti-eye"></i>
                                </span>
                            </div>
                            <div class="password-strength" id="strengthBar" style="width:0%"></div>
                            <small id="strengthText" class="text-muted" style="font-size:.7rem;"></small>
                        </div>
                        <div>
                            <label class="label-text">Confirm Password</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="ti ti-shield-check" style="color:#0d6efd;"></i></span>
                                <input type="password" class="form-control" name="confirm_password" id="pw2"
                                       placeholder="Repeat password" required
                                       style="border-radius:0!important;">
                                <span class="input-group-text" onclick="togglePw('pw2', this)" title="Show/Hide">
                                    <i class="ti ti-eye"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="terms-check-row">
                        <input type="checkbox" name="terms_agree" id="termsCheck" value="1" required
                               <?= !empty($_POST['terms_agree']) ? 'checked' : '' ?>>
                        <label for="termsCheck">
                            I have read and agree to the <a href="#" onclick="openTerms(); return false;">Terms and Conditions and Privacy Notice</a> of the RHU Rizal Patient Record Management System.
                        </label>
                    </div>
                    <button type="submit" class="btn-register">
                        <i class="ti ti-user-plus me-2"></i>Create Account
                    </button>
                </form>
                <?php endif; ?>

                <?php if ($success): ?>
                <div class="text-center mt-3">
                    <a href="<?= BASE_URL ?>/login.php" class="btn btn-outline-primary" style="border-radius:8px;padding:10px 40px;font-weight:600;">
                        <i class="ti ti-login me-2"></i>Go to Sign In
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- ══ Terms & Conditions / Privacy Notice ══ -->
<div class="terms-overlay" id="termsOverlay" onclick="if(event.target===this) closeTerms()">
    <div class="terms-box">
        <div class="terms-box-header">
            <h5 style="color: #d9e2ef;"><i class="ti ti-file-text me-2"></i>Terms and Conditions &amp; Privacy Notice</h5>
            <button type="button" onclick="closeTerms()" aria-label="Close">&times;</button>
        </div>
        <div class="terms-box-body">
            <h6>1. Acceptance of Terms</h6>
            <p>By creating an account on the Rural Health Unit (RHU) Rizal Patient Record Management System (PRMS), you agree to be bound by these Terms and Conditions and this Privacy Notice. If you do not agree, please do not create an account.</p>

            <h6>2. Purpose of the System</h6>
            <p>PRMS is used by RHU Rizal to record, manage, and monitor patient health information, consultations, immunizations, dental and other clinical services, prescriptions, and related appointments, in support of the health unit's delivery of care to the community.</p>

            <h6>3. Information We Collect</h6>
            <ul>
                <li>Personal information: name, date of birth, sex/gender, address, and contact details.</li>
                <li>Health information: vital signs, chief complaints, diagnoses, treatment plans, prescriptions, immunization and dental records, and related clinical notes.</li>
                <li>Account information: username, email address, and password (stored in encrypted form).</li>
            </ul>

            <h6>4. How Your Information Is Used</h6>
            <ul>
                <li>To provide and coordinate your medical, dental, and other health services at RHU Rizal.</li>
                <li>To maintain accurate medical records for continuity of care and follow-up.</li>
                <li>To schedule appointments and send you relevant health notices.</li>
                <li>To generate anonymized statistics and reports required for public health reporting.</li>
            </ul>

            <h6>5. Confidentiality and Data Privacy</h6>
            <p>Your health and personal information is confidential and is accessed only by authorized RHU Rizal personnel (doctors, nurses, and administrative staff) for the purposes described above. RHU Rizal processes personal data in line with the principles of the Data Privacy Act of 2012 (Republic Act No. 10173), including transparency, legitimate purpose, and proportionality.</p>

            <h6>6. Your Rights</h6>
            <p>You have the right to be informed of, access, and request correction of your personal and health records held in this system. To exercise these rights, please coordinate directly with RHU Rizal staff.</p>

            <h6>7. Account Responsibility</h6>
            <p>You are responsible for the accuracy of the information you provide and for keeping your login credentials confidential. Notify RHU Rizal staff immediately if you suspect unauthorized use of your account.</p>

            <h6>8. Changes to This Notice</h6>
            <p>RHU Rizal may update these Terms and this Privacy Notice from time to time. Continued use of the system after changes take effect constitutes acceptance of the revised terms.</p>
        </div>
        <div class="terms-box-footer">
            <button type="button" onclick="acceptTerms()">I Understand, Close</button>
        </div>
    </div>
</div>

<script src="<?= ASSETS_URL ?>/js/plugins/popper.min.js"></script>
<script src="<?= ASSETS_URL ?>/js/component.js"></script>
<script src="<?= ASSETS_URL ?>/js/theme.js"></script>
<script src="<?= ASSETS_URL ?>/js/script.js"></script>
<script src="<?= ASSETS_URL ?>/js/page-transitions.js"></script>
<script>
function checkStrength(val) {
    const bar = document.getElementById('strengthBar');
    const txt = document.getElementById('strengthText');
    let score = 0;
    if (val.length >= 8) score++;
    if (/[A-Z]/.test(val)) score++;
    if (/[0-9]/.test(val)) score++;
    if (/[^A-Za-z0-9]/.test(val)) score++;
    const colors = ['#ef5350','#ff9800','#66bb6a','#2e7d32'];
    const labels = ['Weak','Fair','Good','Strong'];
    const widths = ['25%','50%','75%','100%'];
    if (!val.length) { bar.style.width = '0'; txt.textContent = ''; return; }
    const idx = Math.max(0, score - 1);
    bar.style.background = colors[idx]; bar.style.width = widths[idx];
    txt.textContent = labels[idx]; txt.style.color = colors[idx];
}
function togglePw(id, iconWrap) {
    const field = document.getElementById(id);
    const icon  = iconWrap.querySelector('i');
    if (field.type === 'password') { field.type = 'text';     icon.className = 'ti ti-eye-off'; }
    else                           { field.type = 'password'; icon.className = 'ti ti-eye'; }
}
function toggleAccountType(type) {
    const patientBox = document.getElementById('patientFields');
    const staffBox    = document.getElementById('staffFields');
    const roleField   = document.getElementById('roleField');
    const patientRequired = ['input[name="first_name"]', 'input[name="last_name"]', 'input[name="date_of_birth"]'];
    const staffRequired   = 'input[name="full_name"]';

    if (type === 'patient') {
        patientBox.style.display = '';
        staffBox.style.display   = 'none';
        roleField.value = 'patient';
        patientRequired.forEach(sel => document.querySelector(sel).required = true);
        document.querySelector(staffRequired).required = false;
    } else {
        patientBox.style.display = 'none';
        staffBox.style.display   = '';
        roleField.value = 'staff';
        patientRequired.forEach(sel => document.querySelector(sel).required = false);
        document.querySelector(staffRequired).required = true;
    }
}
function openTerms() {
    document.getElementById('termsOverlay').classList.add('show');
}
function closeTerms() {
    document.getElementById('termsOverlay').classList.remove('show');
}
function acceptTerms() {
    document.getElementById('termsCheck').checked = true;
    closeTerms();
}
document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeTerms();
});

// Fail-safe: make sure the loading overlay never gets stuck on this page.
window.addEventListener('load', function () {
    const loader = document.querySelector('.loader-bg');
    if (loader) loader.style.display = 'none';
});
if (typeof preset_change === 'function') preset_change('preset-1');
if (typeof main_layout_change === 'function') main_layout_change('vertical');
</script>
</body>
</html>