<?php
require_once __DIR__ . '/config/session.php';
require_once __DIR__ . '/config/database.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . (isPatient() ? '/patient/portal.php' : '/dashboard.php'));
    exit;
}

$error   = '';
$success = false;
$token   = trim($_GET['token'] ?? $_POST['token'] ?? '');

$conn = getDBConnection();

// A token is valid only if it matches a user AND hasn't expired yet.
$stmt = $conn->prepare("SELECT id, full_name FROM users WHERE reset_token = ? AND reset_token_expires > NOW() LIMIT 1");
$stmt->bind_param('s', $token);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

$tokenValid = $token !== '' && $user;

if ($tokenValid && $_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $upd = $conn->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_token_expires = NULL WHERE id = ?");
        $upd->bind_param('si', $hashed, $user['id']);
        $upd->execute();
        $upd->close();
        $success = true;
    }
}
$conn->close();
?>
<!doctype html>
<html lang="en" data-pc-preset="preset-1" data-pc-direction="ltr" dir="ltr" data-pc-theme="light">
<head>
    <title>Reset Password | PRMS - Patient Record Management System</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <link rel="icon" href="<?= ASSETS_URL ?>/images/favicon.svg" type="image/x-icon"/>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/fonts/tabler-icons.min.css"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/fonts/feather.css"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/fonts/fontawesome.css"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/css/style.css" id="main-style-link"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/css/auth.css"/>
    <style>
        body { margin: 0; padding: 0; }
        .auth-main {
            background: linear-gradient(135deg, #005fdb 0%, #88a7d8 50%, #ffffff 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .auth-wrapper { width: 100%; max-width: 440px; }
        .auth-card { border-radius: 18px; box-shadow: 0 24px 64px rgba(0,0,0,.35); border: none; overflow: hidden; }
        .auth-logo-area {
            background: linear-gradient(135deg, #1e3a5f, #0d6efd);
            padding: 36px 30px 28px;
            text-align: center;
            color: white;
        }
        .rhu-logo-circle {
            width: 88px; height: 88px;
            border-radius: 50%;
            background: #fff;
            border: 3px solid rgba(255,255,255,.85);
            box-shadow: 0 4px 14px rgba(0,0,0,.25);
            margin: 0 auto 18px;
            display: flex; align-items: center; justify-content: center;
            overflow: hidden;
        }
        .rhu-logo-circle img { width: 100%; height: 100%; object-fit: cover; border-radius: 50%; display: block; }
        .prms-badge {
            background: rgba(255,255,255,.2);
            border-radius: 50px; padding: 5px 20px;
            display: inline-block; font-size: .78rem;
            font-weight: 600; letter-spacing: 2px; margin-bottom: 12px;
        }
        .auth-logo-area h2 { font-weight: 700; font-size: 1.7rem; margin-bottom: 4px; }
        .auth-logo-area p  { opacity: .85; font-size: .88rem; margin: 0; }
        .auth-body { padding: 32px 36px 36px; text-align: center; }
        .auth-body .form-group-wrap { text-align: left; }
        .form-control { border-radius: 8px; padding: 12px 16px; border: 1.5px solid #e0e0e0; font-size: .95rem; transition: all .2s; }
        .form-control:focus { border-color: #0d6efd; box-shadow: 0 0 0 3px rgba(13,110,253,.1); }
        .input-group-text { border: 1.5px solid #e0e0e0; background: #f8f9fa; }
        .icon-prefix { border-right: none !important; border-radius: 8px 0 0 8px !important; }
        .btn-login {
            background: linear-gradient(135deg, #1e3a5f, #0d6efd);
            border: none; padding: 13px; font-size: 1rem; font-weight: 600;
            border-radius: 10px; letter-spacing: .5px; transition: all .3s;
            width: 100%; color: #fff; margin: 0 auto; display: block;
        }
        .btn-login:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(13,110,253,.4); color: #fff; }
        .error-alert { border-radius: 8px; padding: 12px 16px; background: #fff3f3; border: 1px solid #ffcdd2; color: #c62828; font-size: .9rem; text-align: left; }
        .success-alert { border-radius: 8px; padding: 12px 16px; background: #f0fff4; border: 1px solid #a5d6a7; color: #2e7d32; font-size: .9rem; text-align: left; }
        .label-text { font-weight: 600; font-size: .87rem; color: #444; margin-bottom: 6px; display: block; }
        .password-strength { height: 4px; border-radius: 4px; margin-top: 5px; transition: all .3s; background: #e0e0e0; }
    </style>
</head>
<body>
<noscript><style>html body{opacity:1 !important;}</style></noscript>
<div class="loader-bg fixed inset-0 bg-white z-[1034]">
    <div class="loader-track h-[5px] w-full inline-block absolute overflow-hidden top-0">
        <div class="loader-fill w-[300px] h-[5px] bg-primary-500 absolute top-0 left-0 animate-[hitZak_0.6s_ease-in-out_infinite_alternate]"></div>
    </div>
</div>

<div class="auth-main">
    <div class="floating-shapes" aria-hidden="true" style="position:fixed;inset:0;overflow:hidden;pointer-events:none;z-index:0;">
        <span style="width:300px;height:300px;background:rgba(255,255,255,.05);top:-50px;left:-100px;animation-delay:0s"></span>
        <span style="width:200px;height:200px;background:rgba(255,255,255,.07);bottom:50px;right:-50px;animation-delay:3s"></span>
        <span style="width:100px;height:100px;background:rgba(255,255,255,.05);top:40%;left:10%;animation-delay:1.5s"></span>
    </div>

    <div class="auth-wrapper" style="position:relative;z-index:10;">
        <div class="auth-card card">
            <div class="auth-logo-area">
                <div class="rhu-logo-circle" title="RHU Rizal Logo">
                    <img src="<?= ASSETS_URL ?>/images/rhu_logo.png" alt="Rural Health Unit of Rizal logo">
                </div>
                <div class="prms-badge">
                    <i class="ti ti-activity me-1"></i> PRMS
                </div>
                <h2 style="color: #e0e0e0;">Set a New Password</h2>
                <p>Rural Health Unit &bull; Rizal</p>
            </div>

            <div class="auth-body">
                <div class="form-group-wrap">
                    <?php if (!$tokenValid): ?>
                        <h5 class="fw-bold mb-1" style="color:#1e3a5f;">Link Invalid or Expired</h5>
                        <p class="text-muted mb-4" style="font-size:.9rem;">This password reset link is no longer valid. Reset links expire 1 hour after they're sent.</p>
                        <div class="d-flex justify-content-center">
                            <a href="<?= BASE_URL ?>/forgot_password.php" class="btn-login" style="max-width:260px;">
                                <i class="ti ti-refresh me-2"></i>Request a New Link
                            </a>
                        </div>
                    <?php elseif ($success): ?>
                        <h5 class="fw-bold mb-1" style="color:#1e3a5f;">Password Updated</h5>
                        <p class="text-muted mb-4" style="font-size:.9rem;">Your password has been reset. You can now sign in with your new password.</p>
                        <div class="d-flex justify-content-center">
                            <a href="<?= BASE_URL ?>/login.php" class="btn-login" style="max-width:260px;">
                                <i class="ti ti-login me-2"></i>Go to Sign In
                            </a>
                        </div>
                    <?php else: ?>
                        <h5 class="fw-bold mb-1" style="color:#1e3a5f;">Hi <?= htmlspecialchars(explode(' ', $user['full_name'])[0] ?? '') ?>,</h5>
                        <p class="text-muted mb-4" style="font-size:.9rem;">Choose a new password for your account.</p>

                        <?php if ($error): ?>
                            <div class="error-alert mb-3 d-flex align-items-center gap-2">
                                <i class="ti ti-alert-circle"></i> <?= htmlspecialchars($error) ?>
                            </div>
                        <?php endif; ?>

                        <form method="POST" action="">
                            <?= csrfField() ?>
                            <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
                            <div class="mb-3">
                                <label class="label-text">New Password</label>
                                <div class="input-group">
                                    <span class="input-group-text icon-prefix"><i class="ti ti-lock" style="color:#0d6efd;"></i></span>
                                    <input type="password" class="form-control" name="password" id="pw1"
                                           placeholder="Min. 8 characters" required oninput="checkStrength(this.value)"
                                           style="border-left:none;border-radius:0!important;">
                                </div>
                                <div class="password-strength" id="strengthBar" style="width:0%"></div>
                                <small id="strengthText" class="text-muted" style="font-size:.7rem;"></small>
                            </div>
                            <div class="mb-4">
                                <label class="label-text">Confirm New Password</label>
                                <div class="input-group">
                                    <span class="input-group-text icon-prefix"><i class="ti ti-shield-check" style="color:#0d6efd;"></i></span>
                                    <input type="password" class="form-control" name="confirm_password"
                                           placeholder="Repeat new password" required
                                           style="border-left:none;border-radius:0!important;">
                                </div>
                            </div>
                            <div class="d-flex justify-content-center">
                                <button type="submit" class="btn-login">
                                    <i class="ti ti-device-floppy me-2"></i>Update Password
                                </button>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <p class="text-center text-white mt-3" style="font-size:.8rem;opacity:.7;">
            &copy; <?= date('Y') ?> PRMS &bull; Rural Health Unit, Rizal &bull; All rights reserved
        </p>
    </div>
</div>

<script src="<?= ASSETS_URL ?>/js/plugins/popper.min.js"></script>
<script src="<?= ASSETS_URL ?>/js/plugins/feather.min.js"></script>
<script src="<?= ASSETS_URL ?>/js/component.js"></script>
<script src="<?= ASSETS_URL ?>/js/theme.js"></script>
<script src="<?= ASSETS_URL ?>/js/script.js"></script>
<script src="<?= ASSETS_URL ?>/js/page-transitions.js"></script>
<script>
function checkStrength(val) {
    const bar = document.getElementById('strengthBar');
    const txt = document.getElementById('strengthText');
    let score = 0;
    if (val.length >= 8) score++;
    if (/[A-Z]/.test(val)) score++;
    if (/[0-9]/.test(val)) score++;
    if (/[^A-Za-z0-9]/.test(val)) score++;
    const colors = ['#ef5350','#ff9800','#66bb6a','#2e7d32'];
    const labels = ['Weak','Fair','Good','Strong'];
    const widths = ['25%','50%','75%','100%'];
    if (!val.length) { bar.style.width = '0'; txt.textContent = ''; return; }
    const idx = Math.max(0, score - 1);
    bar.style.background = colors[idx]; bar.style.width = widths[idx];
    txt.textContent = labels[idx]; txt.style.color = colors[idx];
}
preset_change('preset-1');
main_layout_change('vertical');
</script>
</body>
</html>
