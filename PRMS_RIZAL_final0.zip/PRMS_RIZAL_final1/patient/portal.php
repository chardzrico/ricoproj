<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/auth.php';
requirePatientOnly();

$conn = getDBConnection();
$currentUser = getCurrentUser();

// ── Load this patient's record ──────────────────────────────────────────────
$stmt = $conn->prepare("SELECT * FROM patients WHERE user_id = ? LIMIT 1");
$stmt->bind_param('i', $currentUser['id']);
$stmt->execute();
$patient = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$patient) {
    // Safety net: a patient-role account somehow has no linked patient record.
    $conn->close();
    $pageTitle = 'My Dashboard';
    include __DIR__ . '/includes/patient_header.php';
    include __DIR__ . '/../includes/topbar.php';
    echo '<div class="alert alert-danger">We could not find a patient record linked to your account. Please contact RHU staff for assistance.</div>';
    include __DIR__ . '/../includes/layout_footer.php';
    exit;
}

$patientId = (int)$patient['id'];

// ── Stats (drafts are staff-side works-in-progress, never shown to patients) ─
$totalConsultations = 0;
$visitsThisYear      = 0;
$lastVisitDate        = null;

$r = $conn->prepare("SELECT COUNT(*) as cnt FROM checkups WHERE patient_id = ? AND status != 'draft'");
$r->bind_param('i', $patientId);
$r->execute();
$totalConsultations = (int)($r->get_result()->fetch_assoc()['cnt'] ?? 0);
$r->close();

$r = $conn->prepare("SELECT COUNT(*) as cnt FROM checkups WHERE patient_id = ? AND status != 'draft' AND YEAR(checkup_date) = YEAR(CURDATE())");
$r->bind_param('i', $patientId);
$r->execute();
$visitsThisYear = (int)($r->get_result()->fetch_assoc()['cnt'] ?? 0);
$r->close();

$r = $conn->prepare("SELECT checkup_date FROM checkups WHERE patient_id = ? AND status != 'draft' ORDER BY checkup_date DESC, id DESC LIMIT 1");
$r->bind_param('i', $patientId);
$r->execute();
$row = $r->get_result()->fetch_assoc();
$lastVisitDate = $row['checkup_date'] ?? null;
$r->close();

// ── Recent consultations (ITR history) ───────────────────────────────────────
$consultations = [];
$stmt = $conn->prepare("
    SELECT id, checkup_date, checkup_time, nature_of_visit, chief_complaint, diagnosis, follow_up_date, status
    FROM checkups
    WHERE patient_id = ? AND status != 'draft'
    ORDER BY checkup_date DESC, id DESC
    LIMIT 10
");
$stmt->bind_param('i', $patientId);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $consultations[] = $row;
$stmt->close();
$conn->close();

$pageTitle = 'My Dashboard';
include __DIR__ . '/includes/patient_header.php';
include __DIR__ . '/../includes/topbar.php';

$statusBadge = [
    'pending'   => 'bg-warning text-dark',
    'completed' => 'bg-success',
    'cancelled' => 'bg-secondary',
];
?>

<!-- ══ Breadcrumb ══ -->
<div class="page-header">
    <div class="page-block">
        <div class="row align-items-center">
            <div class="col-md-12">
                <h5 class="m-b-10">My Dashboard</h5>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/patient/portal.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- ══ Welcome / Patient Info ══ -->
<div class="card mb-4">
    <div class="card-body d-flex flex-wrap align-items-center justify-content-between gap-3">
        <div>
            <h5 class="fw-bold mb-1" style="color:#1e3a5f;">
                Welcome, <?= htmlspecialchars($patient['first_name']) ?>!
            </h5>
            <p class="text-muted mb-0" style="font-size:.88rem;">
                Patient No: <span class="fw-semibold"><?= htmlspecialchars($patient['patient_no']) ?></span>
            </p>
        </div>
    </div>
</div>

<!-- ══ Stat Cards ══ -->
<div class="row g-3 mb-4">
    <?php
    $cards = [
        ['icon'=>'ti-file-text','color'=>'#1565c0','bg'=>'#e3f2fd','value'=>$totalConsultations,'label'=>'Total Consultations'],
        ['icon'=>'ti-calendar-stats',  'color'=>'#2e7d32','bg'=>'#e8f5e9','value'=>$visitsThisYear,     'label'=>'Visits This Year'],
        ['icon'=>'ti-clock',           'color'=>'#e65100','bg'=>'#fff3e0','value'=>$lastVisitDate ? date('M d, Y', strtotime($lastVisitDate)) : '—','label'=>'Last Visit'],
    ];
    foreach ($cards as $c):
    ?>
    <div class="col-xl-4 col-md-6">
        <div class="card stat-card h-100">
            <div class="card-body d-flex align-items-center gap-3 py-3">
                <div class="stat-icon" style="background:<?= $c['bg'] ?>;flex-shrink:0;">
                    <i class="ti <?= $c['icon'] ?>" style="color:<?= $c['color'] ?>;font-size:1.45rem;"></i>
                </div>
                <div>
                    <div class="fw-bold" style="font-size:1.5rem;color:<?= $c['color'] ?>;line-height:1.1;"><?= htmlspecialchars((string)$c['value']) ?></div>
                    <div class="text-muted" style="font-size:.82rem;"><?= $c['label'] ?></div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- ══ Recent Consultations ══ -->
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0">
            <i class="ti ti-file-text me-2" style="color:#0d6efd;"></i>Recent Consultations
        </h6>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0" style="font-size:.88rem;">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Nature of Visit</th>
                        <th>Chief Complaint</th>
                        <th>Diagnosis</th>
                        <th>Follow-up</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($consultations)): ?>
                    <tr><td colspan="6" class="text-center text-muted py-4">You have no consultation records yet.</td></tr>
                    <?php else: foreach ($consultations as $c): ?>
                    <tr>
                        <td>
                            <div><?= date('M d, Y', strtotime($c['checkup_date'])) ?></div>
                            <div class="text-muted" style="font-size:.78rem;"><?= $c['checkup_time'] ? date('h:i A', strtotime($c['checkup_time'])) : '' ?></div>
                        </td>
                        <td><?= htmlspecialchars($c['nature_of_visit'] ?: '—') ?></td>
                        <td style="max-width:180px;"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= htmlspecialchars($c['chief_complaint'] ?? '') ?>"><?= htmlspecialchars($c['chief_complaint'] ?: '—') ?></div></td>
                        <td style="max-width:180px;"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= htmlspecialchars($c['diagnosis'] ?? '') ?>"><?= htmlspecialchars($c['diagnosis'] ?: '—') ?></div></td>
                        <td><?= $c['follow_up_date'] ? date('M d, Y', strtotime($c['follow_up_date'])) : '—' ?></td>
                        <td><span class="badge <?= $statusBadge[$c['status']] ?? 'bg-secondary' ?>"><?= ucfirst($c['status']) ?></span></td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../includes/layout_footer.php'; ?>
