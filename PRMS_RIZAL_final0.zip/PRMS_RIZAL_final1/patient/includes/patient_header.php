<?php
// patient/includes/patient_header.php — sidebar for logged-in patients
if (!function_exists('getCurrentUser')) {
    require_once __DIR__ . '/../../config/session.php';
}
$currentUser = getCurrentUser();
$pageTitle   = $pageTitle ?? 'PRMS';
$baseUrl     = defined('BASE_URL') ? BASE_URL : '';
$assetsUrl   = defined('ASSETS_URL') ? ASSETS_URL : ($baseUrl ? $baseUrl . '/assets' : '/assets');
?>
<!doctype html>
<html lang="en" data-pc-preset="preset-1" data-pc-sidebar-caption="true" data-pc-direction="ltr" dir="ltr" data-pc-theme="light">
<head>
    <title><?= htmlspecialchars($pageTitle) ?> | PRMS</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <link rel="icon" href="<?= $assetsUrl ?>/images/favicon.svg" type="image/x-icon"/>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
    <link rel="stylesheet" href="<?= $assetsUrl ?>/fonts/phosphor/duotone/style.css"/>
    <link rel="stylesheet" href="<?= $assetsUrl ?>/fonts/tabler-icons.min.css"/>
    <link rel="stylesheet" href="<?= $assetsUrl ?>/fonts/feather.css"/>
    <link rel="stylesheet" href="<?= $assetsUrl ?>/fonts/fontawesome.css"/>
    <link rel="stylesheet" href="<?= $assetsUrl ?>/fonts/material.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="<?= $assetsUrl ?>/css/style.css" id="main-style-link"/>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css"/>
    <style>
        :root {
            --primary-color: #0d6efd;
            --sidebar-bg: #1e3a5f;
            --sidebar-hover: rgba(255, 255, 255, 0.1);
            --sidebar-active: rgba(255, 255, 255, 0.15);
            --text-main: #212529;
            --text-muted: #6c757d;
            --card-shadow: 0 2px 12px rgba(0, 0, 0, 0.05);
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: #f4f7fa;
            color: var(--text-main);
        }

        /* ── Sidebar Styling ── */
        .pc-sidebar {
            background: var(--sidebar-bg);
            border-right: none;
            box-shadow: 2px 0 10px rgba(0,0,0,0.05);
        }
        .sidebar-brand-text { font-weight: 700; font-size: 1.2rem; color: #fff; letter-spacing: 0.5px; }
        .sidebar-brand-sub { font-size: 0.7rem; opacity: 0.7; color: #fff; text-transform: uppercase; letter-spacing: 1px; }
        
        .pc-navbar > .pc-item > .pc-link {
            padding: 12px 20px;
            font-size: 0.875rem;
            font-weight: 500;
            color: rgba(255, 255, 255, 0.75);
            border-left: 3px solid transparent;
            transition: all 0.2s ease;
        }
        .pc-navbar > .pc-item > .pc-link:hover {
            background: var(--sidebar-hover);
            color: #fff;
        }
        .pc-navbar > .pc-item.active > .pc-link {
            background: var(--sidebar-active);
            color: #fff;
            border-left-color: #fff;
            font-weight: 600;
        }
        .pc-micon { font-size: 1.1rem; margin-right: 12px; width: 20px; text-align: center; }
        .pc-caption { 
            padding: 20px 20px 8px; 
            font-size: 0.65rem; 
            font-weight: 700; 
            text-transform: uppercase; 
            color: rgba(255, 255, 255, 0.4); 
            letter-spacing: 1.2px;
        }

        /* ── Header Styling ── */
        .pc-header {
            top: 0 !important;
            height: 44px !important;
            min-height: 44px !important;
            background: #fff !important;
            border-bottom: 1px solid #e9ecef;
            box-shadow: 0 1px 4px rgba(0,0,0,0.06);
        }
        .header-wrapper {
            height: 44px !important;
        }
        /* Push content up to match the new smaller header */
        .pc-container {
            top: 44px !important;
            min-height: calc(100vh - 105px) !important;
        }
        .pc-footer {
            margin-top: 44px !important;
        }
        .pc-head-link {
            color: var(--text-main);
            padding: 0.25rem 0.5rem;
            border-radius: 8px;
            transition: background 0.2s;
        }
        .pc-head-link:hover { background: #f8f9fa; }

        /* ── Card & Content Styling ── */
        .card {
            border: none;
            border-radius: 12px;
            box-shadow: var(--card-shadow);
            margin-bottom: 24px;
        }
        .card-header {
            background: #fff;
            border-bottom: 1px solid #f0f0f0;
            padding: 18px 24px;
            border-radius: 12px 12px 0 0 !important;
        }
        .card-body { padding: 24px; }
        .section-title { font-weight: 700; font-size: 1.1rem; color: var(--sidebar-bg); margin: 0; }

        /* ── Table Styling ── */
        .table thead th {
            background: #f8f9fa;
            font-weight: 600;
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            color: var(--text-muted);
            border-bottom: 2px solid #e9ecef;
            padding: 12px 16px;
        }
        .table td {
            padding: 14px 16px;
            vertical-align: middle;
            font-size: 0.875rem;
            border-bottom: 1px solid #f0f0f0;
        }

        /* ── Stat Cards ── */
        .stat-card {
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 16px;
        }
        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
        }
        .stat-label { font-size: 0.8rem; color: var(--text-muted); font-weight: 500; margin-bottom: 2px; }
        .stat-value { font-size: 1.5rem; font-weight: 700; color: var(--text-main); line-height: 1; }

        /* ── Buttons ── */
        .btn { border-radius: 8px; font-weight: 500; padding: 8px 16px; font-size: 0.875rem; }
        .btn-sm { padding: 5px 12px; font-size: 0.8rem; }
        .btn-primary { background: var(--primary-color); border: none; box-shadow: 0 2px 6px rgba(13, 110, 253, 0.2); }
        .btn-primary:hover { background: #0b5ed7; transform: translateY(-1px); }

        /* ── Alignment Utilities ── */
        .text-align-center { text-align: center; }
        .text-align-right { text-align: right; }
        .flex-center { display: flex; align-items: center; justify-content: center; }
        .flex-between { display: flex; align-items: center; justify-content: space-between; }

        /* ── MODAL GLOBAL STYLES ── */
        .modal-header {
            background: linear-gradient(135deg, #1e3a5f 0%, #2563a8 100%);
            color: #fff;
            border-bottom: none;
            border-radius: 12px 12px 0 0;
            padding: 1rem 1.4rem;
        }
        .modal-header .modal-title { font-weight: 600; font-size: 1rem; }
        .modal-header .btn-close-white { filter: brightness(0) invert(1); opacity: .8; }
        .modal-content {
            border: none;
            border-radius: 14px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.18);
        }
        .modal-body { padding: 1.4rem 1.5rem 0.5rem; }
        .modal-footer {
            border-top: 1px solid #e9ecef;
            padding: 1rem 1.5rem;
            border-radius: 0 0 14px 14px;
            background: #f8f9fa;
        }
        /* Section headers inside modal body */
        .modal-section-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid #e9ecef;
        }
        .modal-section-icon {
            width: 30px; height: 30px;
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            flex-shrink: 0;
        }
        .modal-section-header h6 {
            margin: 0;
            font-weight: 700;
            color: #1e3a5f;
            font-size: .9rem;
        }
        /* Ensure backdrop is always on top of content */
        .modal-backdrop { z-index: 1040; }
        .modal          { z-index: 1050; }
        /* Smooth open animation */
        .modal.fade .modal-dialog { transform: translateY(-20px) scale(0.98); transition: transform .2s ease-out, opacity .2s ease-out; }
        .modal.show .modal-dialog { transform: translateY(0) scale(1); }
    </style>
</head>
<body>
<noscript><style>html body{opacity:1 !important;}</style></noscript>
<div class="loader-bg fixed inset-0 bg-white dark:bg-themedark-cardbg z-[1034]">
    <div class="loader-track h-[5px] w-full inline-block absolute overflow-hidden top-0">
        <div class="loader-fill w-[300px] h-[5px] bg-primary-500 absolute top-0 left-0 animate-[hitZak_0.6s_ease-in-out_infinite_alternate]"></div>
    </div>
</div>

<!-- ══════════ SIDEBAR ══════════ -->
<nav class="pc-sidebar">
    <div class="navbar-wrapper">
        <div class="m-header flex items-center py-4 px-4 h-header-height">
            <a href="<?= $baseUrl ?>/patient/portal.php" class="b-brand flex items-center gap-3">
                <div style="width:42px;height:42px;border-radius:10px;background:rgba(255,255,255,0.15);display:flex;align-items:center;justify-content:center;">
                    <i class="ti ti-building-hospital" style="font-size:1.4rem;color:#fff;"></i>
                </div>
                <div class="logo logo-lg">
                    <div class="sidebar-brand-text">PRMS</div>
                    <div class="sidebar-brand-sub">Patient Portal</div>
                </div>
            </a>
        </div>

        <ul class="pc-navbar">
                <li class="pc-item pc-caption"><label>Patient Portal</label></li>
                <li class="pc-item">
                    <a href="<?= $baseUrl ?>/patient/portal.php" class="pc-link">
                        <span class="pc-micon"><i data-feather="home"></i></span>
                        <span class="pc-mtext">My Dashboard</span>
                    </a>
                </li>
                <li class="pc-item">
                    <a href="<?= $baseUrl ?>/patient/profile.php" class="pc-link">
                        <span class="pc-micon"><i data-feather="user"></i></span>
                        <span class="pc-mtext">My Profile</span>
                    </a>
                </li>
            </ul>
<!-- ══════════ END SIDEBAR ══════════ -->