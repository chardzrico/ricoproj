<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';
requirePatientOnly();

$conn = getDBConnection();
$currentUser = getCurrentUser();
$msg = '';

$stmt = $conn->prepare("SELECT * FROM patients WHERE user_id = ? LIMIT 1");
$stmt->bind_param('i', $currentUser['id']);
$stmt->execute();
$patient = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$patient) {
    $conn->close();
    header('Location: ' . BASE_URL . '/patient/portal.php');
    exit;
}

// ── Update contact-type info only (identity fields stay staff-managed) ──────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $address    = trim($_POST['address'] ?? '');
    $contact    = trim($_POST['contact_number'] ?? '');
    $guardian   = trim($_POST['guardian_name'] ?? '');
    $gcontact   = trim($_POST['guardian_contact'] ?? '');

    $stmt = $conn->prepare("UPDATE patients SET address=?, contact_number=?, guardian_name=?, guardian_contact=? WHERE id=?");
    $stmt->bind_param('ssssi', $address, $contact, $guardian, $gcontact, $patient['id']);
    if ($stmt->execute()) {
        $msg = 'success';
        $patient['address'] = $address;
        $patient['contact_number'] = $contact;
        $patient['guardian_name'] = $guardian;
        $patient['guardian_contact'] = $gcontact;
    } else {
        $msg = 'error';
    }
    $stmt->close();
}

$conn->close();

$pageTitle = 'My Profile';
include __DIR__ . '/includes/patient_header.php';
include __DIR__ . '/../includes/topbar.php';
?>

<!-- ══ Breadcrumb ══ -->
<div class="page-header">
    <div class="page-block">
        <div class="row align-items-center">
            <div class="col-md-12">
                <h5 class="m-b-10">My Profile</h5>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/patient/portal.php">Home</a></li>
                    <li class="breadcrumb-item active">My Profile</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php if ($msg === 'success'): ?>
<div class="alert alert-success alert-dismissible fade show d-flex align-items-center gap-2" role="alert">
    <i class="ti ti-circle-check fs-5"></i><span>Your profile has been updated.</span>
    <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
</div>
<?php elseif ($msg === 'error'): ?>
<div class="alert alert-danger alert-dismissible fade show d-flex align-items-center gap-2" role="alert">
    <i class="ti ti-alert-circle fs-5"></i><span>Could not update your profile. Please try again.</span>
    <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="row g-3">
    <!-- Read-only identity info -->
    <div class="col-lg-5">
        <div class="card h-100">
            <div class="card-header">
                <h6 class="section-title mb-0"><i class="ti ti-id-badge me-2" style="color:#0d6efd;"></i>Identity Information</h6>
            </div>
            <div class="card-body">
                <p class="text-muted" style="font-size:.82rem;">These details are managed by RHU staff. Contact the clinic if any of this needs correction.</p>
                <table class="table table-borderless mb-0" style="font-size:.9rem;">
                    <tr><td class="text-muted" style="width:40%;">Patient No.</td><td class="fw-semibold"><?= htmlspecialchars($patient['patient_no']) ?></td></tr>
                    <tr><td class="text-muted">Full Name</td><td class="fw-semibold"><?= htmlspecialchars(trim($patient['first_name'] . ' ' . $patient['middle_name'] . ' ' . $patient['last_name'])) ?></td></tr>
                    <tr><td class="text-muted">Date of Birth</td><td><?= date('M d, Y', strtotime($patient['date_of_birth'])) ?></td></tr>
                    <tr><td class="text-muted">Gender</td><td><?= htmlspecialchars($patient['gender']) ?></td></tr>
                    <tr><td class="text-muted">Blood Type</td><td><?= htmlspecialchars($patient['blood_type'] ?: '—') ?></td></tr>
                    <tr><td class="text-muted">Civil Status</td><td><?= htmlspecialchars($patient['civil_status'] ?: '—') ?></td></tr>
                    <tr><td class="text-muted">Occupation</td><td><?= htmlspecialchars($patient['occupation'] ?: '—') ?></td></tr>
                </table>
            </div>
        </div>
    </div>

    <!-- Editable contact info -->
    <div class="col-lg-7">
        <div class="card h-100">
            <div class="card-header">
                <h6 class="section-title mb-0"><i class="ti ti-phone me-2" style="color:#2e7d32;"></i>Contact & Guardian Information</h6>
            </div>
            <div class="card-body">
                <form method="POST" action="">
                    <div class="mb-3">
                        <label class="form-label">Contact Number</label>
                        <input type="text" class="form-control" name="contact_number" value="<?= htmlspecialchars($patient['contact_number'] ?? '') ?>" placeholder="09XX-XXX-XXXX">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Address</label>
                        <input type="text" class="form-control" name="address" value="<?= htmlspecialchars($patient['address'] ?? '') ?>" placeholder="Barangay, Municipality, Province">
                    </div>
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Guardian Name</label>
                            <input type="text" class="form-control" name="guardian_name" value="<?= htmlspecialchars($patient['guardian_name'] ?? '') ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Guardian Contact</label>
                            <input type="text" class="form-control" name="guardian_contact" value="<?= htmlspecialchars($patient['guardian_contact'] ?? '') ?>">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save Changes</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../includes/layout_footer.php'; ?>
