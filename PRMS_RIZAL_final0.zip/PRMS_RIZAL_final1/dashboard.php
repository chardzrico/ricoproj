<?php
require_once __DIR__ . '/config/session.php';
require_once __DIR__ . '/config/database.php';
requireLogin();

if (isPatient()) {
    header('Location: ' . BASE_URL . '/patient/portal.php');
    exit;
}

$conn = getDBConnection();
$currentUser = getCurrentUser();
$role = $currentUser['role'];

$roleLabels = ['admin' => 'Admin', 'doctor' => 'Doctor', 'nurse' => 'Nurse', 'staff' => 'Staff'];
$pageTitle = 'Dashboard';

include __DIR__ . '/includes/layout_header.php';
include __DIR__ . '/includes/topbar.php';
?>

<!-- ══ Breadcrumb ══ -->
<div class="page-header">
    <div class="page-block">
        <div class="row align-items-center">
            <div class="col-md-12">
                <h5 class="m-b-10">
                    Dashboard
                    <span class="badge bg-primary bg-opacity-10 text-primary fw-semibold ms-2" style="font-size:.7rem;vertical-align:middle;">
                        <?= htmlspecialchars($roleLabels[$role] ?? ucfirst($role)) ?> View
                    </span>
                </h5>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php
// ── Route to the appropriate role-specific dashboard content ───────────────
switch ($role) {
    case 'admin':
        include __DIR__ . '/modules/dashboard/admin_content.php';
        break;
    case 'doctor':
        include __DIR__ . '/modules/dashboard/doctor_content.php';
        break;
    case 'nurse':
        include __DIR__ . '/modules/dashboard/nurse_content.php';
        break;
    case 'staff':
    default:
        include __DIR__ . '/modules/dashboard/staff_content.php';
        break;
}

$conn->close();
include __DIR__ . '/includes/layout_footer.php';
?>
