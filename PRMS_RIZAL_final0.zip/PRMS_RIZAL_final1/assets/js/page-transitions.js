/**
=========================================================================
File: page-transitions.js
Purpose: Site-wide fade-in / fade-out page transitions for PRMS.
         Fades the page content in on load (in sync with the existing
         loader-bg) and fades it out before any real navigation
         (link clicks, form submits, confirmDelete, sidebar links),
         so moving between pages feels like one continuous app
         instead of a hard reload.
=========================================================================
*/
(function () {
  'use strict';

  var FADE_MS = 260; // must match the CSS transition duration below

  function fadeIn() {
    // Double rAF so the browser paints the opacity:0 state first,
    // guaranteeing the transition actually runs.
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        document.documentElement.classList.add('pt-loaded');
      });
    });
  }

  // Fade the content in as soon as the DOM is ready (don't wait for
  // every image/font — the loader-bg overlay already covers the page
  // until window 'load', so this crossfades nicely with it).
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', fadeIn);
  } else {
    fadeIn();
  }

  // If the page is restored from the back/forward cache (bfcache),
  // make sure it's visible immediately instead of stuck mid-fade.
  window.addEventListener('pageshow', function (e) {
    document.documentElement.classList.remove('pt-leaving');
    document.documentElement.classList.add('pt-loaded');
  });

  function isTransitionable(el) {
    if (!el || !el.getAttribute) return false;
    var href = el.getAttribute('href');
    if (!href) return false;
    if (href.charAt(0) === '#') return false;
    if (href.indexOf('javascript:') === 0) return false;
    if (href.indexOf('mailto:') === 0 || href.indexOf('tel:') === 0) return false;
    if (el.hasAttribute('download')) return false;
    if (el.target && el.target !== '' && el.target !== '_self') return false;
    if (el.dataset && el.dataset.noTransition !== undefined) return false;
    if (el.hasAttribute('data-bs-toggle') || el.hasAttribute('data-bs-dismiss')) return false;
    // Only intercept same-origin navigations.
    try {
      var url = new URL(el.href, window.location.href);
      if (url.origin !== window.location.origin) return false;
      // Same page, different hash only -> let the browser handle it.
      if (url.pathname === window.location.pathname && url.search === window.location.search && url.hash) {
        return false;
      }
    } catch (err) {
      return false;
    }
    return true;
  }

  function leaveThenGo(navigate) {
    document.documentElement.classList.add('pt-leaving');
    document.documentElement.classList.remove('pt-loaded');
    window.setTimeout(navigate, FADE_MS);
  }

  // Intercept normal link clicks site-wide.
  document.addEventListener('click', function (e) {
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    var el = e.target.closest ? e.target.closest('a[href]') : null;
    if (!isTransitionable(el)) return;

    e.preventDefault();
    var destination = el.href;
    leaveThenGo(function () {
      window.location.href = destination;
    });
  });

  // Intercept normal (non-AJAX) form submissions, e.g. login, filters,
  // "Save Changes" forms that do a full-page redirect back.
  document.addEventListener('submit', function (e) {
    var form = e.target;
    if (e.defaultPrevented || !form || form.tagName !== 'FORM') return;
    if (form.dataset && form.dataset.noTransition !== undefined) return;
    // Skip forms explicitly handled elsewhere via AJAX/JS (they call
    // preventDefault themselves before this listener would matter).
    if (form.target && form.target !== '' && form.target !== '_self') return;

    e.preventDefault();
    leaveThenGo(function () {
      form.submit();
    });
  });

  // Wrap confirmDelete() (defined in script.js) so its
  // window.location.href redirect also gets a fade-out instead of
  // jumping instantly.
  function wrapConfirmDelete() {
    if (typeof window.confirmDelete !== 'function' || window.confirmDelete.__ptWrapped) return;
    var original = window.confirmDelete;
    var wrapped = function (url, name) {
      if (typeof Swal === 'undefined') {
        leaveThenGo(function () { window.location.href = url; });
        return;
      }
      Swal.fire({
        title: 'Confirm Deletion',
        text: 'Are you sure you want to permanently delete "' + name + '"? This action cannot be undone.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#dc3545',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Yes, Delete Record',
        cancelButtonText: 'Cancel',
        reverseButtons: true,
        customClass: { confirmButton: 'btn btn-danger px-4', cancelButton: 'btn btn-light px-4' },
        buttonsStyling: false
      }).then(function (result) {
        if (result.isConfirmed) {
          leaveThenGo(function () { window.location.href = url; });
        }
      });
    };
    wrapped.__ptWrapped = true;
    window.confirmDelete = wrapped;
  }
  wrapConfirmDelete();
  // script.js may define confirmDelete after this file runs if load
  // order ever changes, so also try again once everything has loaded.
  window.addEventListener('load', wrapConfirmDelete);
})();
