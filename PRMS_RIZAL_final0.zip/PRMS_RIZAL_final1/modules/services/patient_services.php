<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();
$conn = getDBConnection();
$msg = '';

if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $conn->query("DELETE FROM patient_services WHERE id=".(int)$_GET['delete']);
    header('Location: patient_services.php?msg=deleted'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id         = (int)($_POST['id'] ?? 0);
    $patient_id = (int)$_POST['patient_id'];
    $service_id = (int)$_POST['service_id'];
    $date       = $_POST['service_date'] ?? date('Y-m-d');
    $notes      = trim($_POST['notes'] ?? '');
    $status     = $_POST['status'] ?? 'done';
    $uid        = getCurrentUser()['id'];

    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE patient_services SET patient_id=?,service_id=?,service_date=?,notes=?,status=?,administered_by=? WHERE id=?");
        $stmt->bind_param('iisssii',$patient_id,$service_id,$date,$notes,$status,$uid,$id);
    } else {
        $stmt = $conn->prepare("INSERT INTO patient_services (patient_id,service_id,service_date,notes,status,administered_by) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param('iisssi',$patient_id,$service_id,$date,$notes,$status,$uid);
    }
    $stmt->execute();
    header('Location: patient_services.php?msg=' . ($id>0?'updated':'added')); exit;
}

$patients = [];
$r = $conn->query("SELECT id, patient_no, CONCAT(first_name,' ',last_name) as name FROM patients WHERE status='active'" . doctorScopeSql() . " ORDER BY last_name");
while ($row = $r->fetch_assoc()) $patients[] = $row;

$services = [];
$r = $conn->query("SELECT id, service_name, category FROM services WHERE status='active' ORDER BY service_name");
while ($row = $r->fetch_assoc()) $services[] = $row;

$records = [];
$r = $conn->query("SELECT ps.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no, s.service_name, s.category, u.full_name as staff_name FROM patient_services ps LEFT JOIN patients p ON ps.patient_id=p.id LEFT JOIN services s ON ps.service_id=s.id LEFT JOIN users u ON ps.administered_by=u.id WHERE 1=1" . doctorScopeSql('p') . " ORDER BY ps.service_date DESC LIMIT 100");
while ($row = $r->fetch_assoc()) $records[] = $row;
$conn->close();

if (isset($_GET['msg'])) { $msg = ['added'=>'Service recorded.','updated'=>'Updated.','deleted'=>'Record removed.'][$_GET['msg']] ?? ''; }
$pageTitle = 'Patient Services';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<div class="page-header"><div class="page-block">
    <h5 class="m-b-10">Patient Services</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Services</li><li class="breadcrumb-item active">Patient Services</li></ul>
</div></div>
<?php if ($msg): ?><div class="alert alert-success alert-dismissible fade show"><i class="ti ti-circle-check me-2"></i><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0"><i class="ti ti-clipboard-check me-2" style="color:#0d6efd;"></i>Patient Services</h6>
        <button class="btn btn-primary btn-sm" onclick="openAddModal()"><i class="ti ti-plus me-1"></i>Record Service</button>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0">
                <thead><tr><th>Patient</th><th>Service</th><th>Category</th><th>Date</th><th>Notes</th><th>Status</th><th>Staff</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php foreach ($records as $rec):
                        $sc = $rec['status']==='done' ? 'bg-success' : ($rec['status']==='pending' ? 'bg-warning text-dark' : 'bg-secondary');
                    ?>
                    <tr>
                        <td><div class="fw-semibold" style="font-size:.88rem;"><?= htmlspecialchars($rec['patient_name']) ?></div><div class="text-muted" style="font-size:.78rem;"><?= htmlspecialchars($rec['patient_no']) ?></div></td>
                        <td class="fw-semibold"><?= htmlspecialchars($rec['service_name']) ?></td>
                        <td><span class="badge bg-info bg-opacity-15 text-info"><?= htmlspecialchars($rec['category'] ?: '—') ?></span></td>
                        <td><?= date('M d, Y', strtotime($rec['service_date'])) ?></td>
                        <td style="max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= htmlspecialchars($rec['notes'] ?: '—') ?></td>
                        <td><span class="badge <?= $sc ?>"><?= ucfirst($rec['status']) ?></span></td>
                        <td><?= htmlspecialchars($rec['staff_name'] ?: '—') ?></td>
                        <td>
                            <button class="btn-edit btn btn-sm me-1" onclick="openEditModal(<?= htmlspecialchars(json_encode($rec)) ?>)"><i class="ti ti-edit"></i></button>
                            <button class="btn-delete btn btn-sm" onclick="confirmDelete('patient_services.php?delete=<?= $rec['id'] ?>','this record')"><i class="ti ti-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="psModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="psModalTitle"><i class="ti ti-clipboard-check me-2"></i>Record Service</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="id" id="psId" value="0">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-12"><label class="form-label">Patient *</label><select class="form-select" name="patient_id" id="psPatient" required><option value="">Select Patient</option><?php foreach ($patients as $p): ?><option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['patient_no'].' - '.$p['name']) ?></option><?php endforeach; ?></select></div>
                        <div class="col-12"><label class="form-label">Service *</label><select class="form-select" name="service_id" id="psService" required><option value="">Select Service</option><?php foreach ($services as $s): ?><option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['service_name'].($s['category']?' ('.$s['category'].')':'')) ?></option><?php endforeach; ?></select></div>
                        <div class="col-md-6"><label class="form-label">Date *</label><input type="date" class="form-control" name="service_date" id="psDate" value="<?= date('Y-m-d') ?>" required></div>
                        <div class="col-md-6"><label class="form-label">Status</label><select class="form-select" name="status" id="psStatus"><option value="done">Done</option><option value="pending">Pending</option><option value="cancelled">Cancelled</option></select></div>
                        <div class="col-12"><label class="form-label">Notes</label><textarea class="form-control" name="notes" id="psNotes" rows="2" placeholder="Additional notes"></textarea></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php
$extraJS='<script>
function openAddModal(){
    document.getElementById("psModalTitle").innerHTML=\'<i class="ti ti-clipboard-check me-2"></i>Record Service\';
    document.getElementById("psId").value="0";
    document.getElementById("psPatient").value="";
    document.getElementById("psService").value="";
    document.getElementById("psNotes").value="";
    document.getElementById("psDate").value="'.date('Y-m-d').'";
    document.getElementById("psStatus").value="done";

    new bootstrap.Modal(document.getElementById("psModal")).show();
}
function openEditModal(r){
    document.getElementById("psModalTitle").innerHTML=\'<i class="ti ti-edit me-2"></i>Edit Service Record\';
    document.getElementById("psId").value=r.id;
    document.getElementById("psPatient").value=r.patient_id;
    document.getElementById("psService").value=r.service_id;
    document.getElementById("psDate").value=r.service_date||"";
    document.getElementById("psNotes").value=r.notes||"";
    document.getElementById("psStatus").value=r.status||"done";
    new bootstrap.Modal(document.getElementById("psModal")).show();
}
</script>';
include __DIR__ . '/../../includes/layout_footer.php';
?>
