<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();

$conn = getDBConnection();
$msg  = '';

// ── Category (Medical / Dental / Mental / Physical only) ───────────────────
$validCategories = ['Medical', 'Dental', 'Mental', 'Physical'];
$cat = $_GET['cat'] ?? 'Medical';
if (!in_array($cat, $validCategories, true)) $cat = 'Medical';

$catMeta = [
    'Medical'  => ['icon' => 'ti-activity',        'color' => '#1565c0'],
    'Dental'   => ['icon' => 'ti-mood-smile',       'color' => '#00897b'],
    'Mental'   => ['icon' => 'ti-heart',            'color' => '#8e24aa'],
    'Physical' => ['icon' => 'ti-stethoscope',      'color' => '#e65100'],
][$cat];

// ── Deactivate / Reactivate a sub-service (never hard-delete — patient ─────
//    service history rows reference it, and a real DELETE would cascade
//    and wipe that history out from under a patient's record).
if (isset($_GET['toggle_service']) && is_numeric($_GET['toggle_service'])) {
    $sid = (int)$_GET['toggle_service'];
    $conn->query("UPDATE services SET status = IF(status='active','inactive','active') WHERE id = $sid AND category = '" . $conn->real_escape_string($cat) . "'");
    header("Location: category.php?cat=" . urlencode($cat) . "&msg=service_updated"); exit;
}

// ── Delete a sub-service (only when no patient history references it — ────
//    patient_services.service_id is ON DELETE CASCADE, so deleting a
//    sub-service that's already been used would silently wipe those
//    patients' service records. Use the Deactivate toggle for that case.
if (isset($_GET['delete_service']) && is_numeric($_GET['delete_service'])) {
    $sid = (int)$_GET['delete_service'];
    $check = $conn->prepare("SELECT COUNT(*) AS c FROM patient_services WHERE service_id = ?");
    $check->bind_param('i', $sid);
    $check->execute();
    $inUse = (int)$check->get_result()->fetch_assoc()['c'];
    $check->close();

    if ($inUse > 0) {
        header("Location: category.php?cat=" . urlencode($cat) . "&msg=service_in_use"); exit;
    }
    $del = $conn->prepare("DELETE FROM services WHERE id = ? AND category = ?");
    $del->bind_param('is', $sid, $cat);
    $del->execute();
    $del->close();
    header("Location: category.php?cat=" . urlencode($cat) . "&msg=service_deleted"); exit;
}

// ── Add / Edit a sub-service ────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_service'])) {
    $sid  = (int)($_POST['service_id'] ?? 0);
    $name = trim($_POST['service_name'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $fee  = $_POST['fee'] !== '' ? (float)$_POST['fee'] : 0.00;

    if ($name === '') {
        header("Location: category.php?cat=" . urlencode($cat) . "&msg=noname"); exit;
    }

    if ($sid > 0) {
        $stmt = $conn->prepare("UPDATE services SET service_name=?, description=?, fee=? WHERE id=? AND category=?");
        $stmt->bind_param('ssdis', $name, $desc, $fee, $sid, $cat);
    } else {
        $stmt = $conn->prepare("INSERT INTO services (service_name, description, category, fee, status) VALUES (?,?,?,?,'active')");
        $stmt->bind_param('sssd', $name, $desc, $cat, $fee);
    }
    $stmt->execute();
    header("Location: category.php?cat=" . urlencode($cat) . "&msg=" . ($sid > 0 ? 'service_updated' : 'service_added')); exit;
}

// ── Delete a single patient-service encounter record ───────────────────────
if (isset($_GET['delete_record']) && is_numeric($_GET['delete_record'])) {
    $rid = (int)$_GET['delete_record'];
    $conn->query("DELETE FROM patient_services WHERE id = $rid");
    header("Location: category.php?cat=" . urlencode($cat) . "&msg=record_deleted"); exit;
}

// ── Record (or edit) a patient's service encounter ──────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_record'])) {
    $rid        = (int)($_POST['record_id'] ?? 0);
    $patient_id = (int)($_POST['patient_id'] ?? 0);
    $service_id = (int)($_POST['service_id'] ?? 0);
    $date       = $_POST['service_date'] ?: date('Y-m-d');
    $notes      = trim($_POST['notes'] ?? '');
    $status     = $_POST['status'] ?? 'done';
    $uid        = getCurrentUser()['id'];

    // Medico-Legal Examination body-diagram findings, submitted as JSON
    // from the injury map widget below (empty for every other service).
    // Each finding is a group of 1-2 marks sharing one description — a
    // simple single-point injury has 1 mark; a through-and-through injury
    // (e.g. "rod pierced through the arm") links a front entry mark with a
    // back exit mark under the same finding.
    $injuryMap = null;
    $rawMap = trim($_POST['injury_map'] ?? '');
    if ($rawMap !== '') {
        $decoded = json_decode($rawMap, true);
        if (is_array($decoded)) {
            $clean = [];
            foreach ($decoded as $f) {
                $rawMarks = is_array($f['marks'] ?? null) ? $f['marks'] : [$f]; // back-compat: flat old-format item
                $marks = [];
                foreach ($rawMarks as $m) {
                    $marks[] = [
                        'view' => ($m['view'] ?? 'front') === 'back' ? 'back' : 'front',
                        'x'    => round((float)($m['x'] ?? 0), 2),
                        'y'    => round((float)($m['y'] ?? 0), 2),
                        'zone' => trim((string)($m['zone'] ?? '')),
                        'role' => in_array($m['role'] ?? '', ['entry', 'exit'], true) ? $m['role'] : null,
                    ];
                }
                if (empty($marks)) continue;
                // Cap at 2 marks per finding (entry + exit) — anything beyond
                // that isn't a supported "linked injury" shape.
                $marks = array_slice($marks, 0, 2);
                $clean[] = [
                    'marks' => $marks,
                    'note'  => trim((string)($f['note'] ?? '')),
                ];
            }
            if (!empty($clean)) $injuryMap = json_encode($clean);
        }
    }

    // Dental odontogram — one entry per marked tooth (FDI two-digit
    // notation), each with a procedure and an optional note.
    $validTeeth = [];
    foreach (['1','2','3','4'] as $q) foreach (range(1,8) as $n) $validTeeth[] = $q . $n;
    $validProcedures = ['Caries','Filling','Extraction','Root Canal','Crown','Sealant','Missing','Other'];
    $odontogram = null;
    $rawOdo = trim($_POST['odontogram'] ?? '');
    if ($rawOdo !== '') {
        $decodedOdo = json_decode($rawOdo, true);
        if (is_array($decodedOdo)) {
            $cleanOdo = [];
            foreach ($decodedOdo as $t) {
                $tooth = trim((string)($t['tooth'] ?? ''));
                if (!in_array($tooth, $validTeeth, true)) continue;
                $proc = in_array($t['procedure'] ?? '', $validProcedures, true) ? $t['procedure'] : 'Other';
                $cleanOdo[] = [
                    'tooth'     => $tooth,
                    'procedure' => $proc,
                    'note'      => trim((string)($t['note'] ?? '')),
                ];
            }
            if (!empty($cleanOdo)) $odontogram = json_encode($cleanOdo);
        }
    }

    if ($patient_id <= 0 || $service_id <= 0) {
        header("Location: category.php?cat=" . urlencode($cat) . "&msg=norecord"); exit;
    }

    if ($rid > 0) {
        $stmt = $conn->prepare("UPDATE patient_services SET patient_id=?, service_id=?, service_date=?, notes=?, status=?, administered_by=?, injury_map=?, odontogram=? WHERE id=?");
        if ($stmt) $stmt->bind_param('iisssissi', $patient_id, $service_id, $date, $notes, $status, $uid, $injuryMap, $odontogram, $rid);
    } else {
        $stmt = $conn->prepare("INSERT INTO patient_services (patient_id, service_id, service_date, notes, status, administered_by, injury_map, odontogram) VALUES (?,?,?,?,?,?,?,?)");
        if ($stmt) $stmt->bind_param('iisssiss', $patient_id, $service_id, $date, $notes, $status, $uid, $injuryMap, $odontogram);
    }
    // A false $stmt here means the query referenced a column that doesn't
    // exist yet (schema drift) — fail loudly with a redirect message
    // instead of a raw fatal error, which used to render as a blank page.
    if (!$stmt || !$stmt->execute()) {
        header("Location: category.php?cat=" . urlencode($cat) . "&msg=save_failed"); exit;
    }
    header("Location: category.php?cat=" . urlencode($cat) . "&msg=" . ($rid > 0 ? 'record_updated' : 'record_added')); exit;
}

// ── Data for this category ──────────────────────────────────────────────────
$patients = [];
$r = $conn->query("SELECT id, patient_no, CONCAT(first_name,' ',last_name) as name FROM patients WHERE status='active'" . doctorScopeSql() . " ORDER BY last_name");
while ($row = $r->fetch_assoc()) $patients[] = $row;

$subServices = [];
$stmt = $conn->prepare("SELECT * FROM services WHERE category = ? ORDER BY status DESC, service_name");
$stmt->bind_param('s', $cat);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $subServices[] = $row;
$stmt->close();

// How many patient records reference each sub-service (blocks hard delete).
$serviceUsage = [];
$r = $conn->query("SELECT service_id, COUNT(*) AS c FROM patient_services GROUP BY service_id");
while ($row = $r->fetch_assoc()) $serviceUsage[$row['service_id']] = (int)$row['c'];

$records = [];
$stmt = $conn->prepare("
    SELECT ps.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no,
           s.service_name, u.full_name as staff_name
    FROM patient_services ps
    LEFT JOIN patients p ON ps.patient_id = p.id
    LEFT JOIN services s ON ps.service_id = s.id
    LEFT JOIN users u ON ps.administered_by = u.id
    WHERE s.category = ?" . doctorScopeSql('p') . "
    ORDER BY ps.service_date DESC, ps.id DESC
    LIMIT 100
");
$stmt->bind_param('s', $cat);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $records[] = $row;
$stmt->close();
$conn->close();

if (isset($_GET['msg'])) {
    $msg = [
        'service_added'   => 'Sub-service added.',
        'service_updated' => 'Sub-service updated.',
        'service_deleted' => 'Sub-service deleted.',
        'record_added'    => 'Service recorded to patient history.',
        'record_updated'  => 'Record updated.',
        'record_deleted'  => 'Record removed.',
        'noname'          => null,
        'norecord'        => null,
        'service_in_use'  => null,
        'save_failed'     => null,
    ][$_GET['msg']] ?? '';
}
$errMsg = null;
if (($_GET['msg'] ?? '') === 'noname')   $errMsg = 'Sub-service name is required.';
if (($_GET['msg'] ?? '') === 'norecord') $errMsg = 'Please select both a patient and a sub-service.';
if (($_GET['msg'] ?? '') === 'service_in_use') $errMsg = 'This sub-service already has patient records attached to it, so it can\'t be permanently deleted — use Deactivate instead to hide it from new records while keeping history intact.';
if (($_GET['msg'] ?? '') === 'save_failed') $errMsg = 'Could not save the record — please try again. If this keeps happening, contact your administrator.';

$pageTitle = "$cat Services";
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';

$statusBadge = ['done' => 'bg-success', 'pending' => 'bg-warning text-dark', 'cancelled' => 'bg-secondary'];

// Simple humanoid outline reused for the Medico-Legal Examination body
// diagram (front + back, and the add-form + view-only modal each need
// their own copy so both can exist in the DOM at once).
function bodySilhouetteSvg(string $svgId): string {
    ob_start(); ?>
<svg id="<?= $svgId ?>" viewBox="0 0 200 400" class="body-diagram-svg" preserveAspectRatio="xMidYMid meet">
  <ellipse cx="100" cy="34" rx="26" ry="28" class="body-part"/>
  <rect x="90" y="58" width="20" height="16" rx="4" class="body-part"/>
  <path d="M64,74 Q100,64 136,74 L142,188 Q100,204 58,188 Z" class="body-part"/>
  <path d="M64,76 Q30,86 26,148 Q23,190 30,232 L48,229 Q42,190 45,148 Q49,108 71,96 Z" class="body-part"/>
  <path d="M136,76 Q170,86 174,148 Q177,190 170,232 L152,229 Q158,190 155,148 Q151,108 129,96 Z" class="body-part"/>
  <ellipse cx="37" cy="244" rx="13" ry="17" class="body-part"/>
  <ellipse cx="163" cy="244" rx="13" ry="17" class="body-part"/>
  <path d="M58,188 Q100,204 142,188 L136,220 Q100,231 64,220 Z" class="body-part"/>
  <path d="M64,218 Q61,290 59,320 L57,376 L83,376 L87,320 Q91,290 93,218 Z" class="body-part"/>
  <path d="M136,218 Q139,290 141,320 L143,376 L117,376 L113,320 Q109,290 107,218 Z" class="body-part"/>
  <ellipse cx="72" cy="386" rx="19" ry="8" class="body-part"/>
  <ellipse cx="128" cy="386" rx="19" ry="8" class="body-part"/>
</svg>
    <?php
    return ob_get_clean();
}
?>
<style>
.body-diagram-wrap{ position:relative; width:100%; max-width:220px; margin:0 auto; aspect-ratio:1/2; cursor:crosshair; background:#f5f7fa; border:1px solid #e0e0e0; border-radius:8px; }
.body-diagram-svg{ position:absolute; inset:0; width:100%; height:100%; }
.body-part{ fill:#dbe3ea; stroke:#7c93a8; stroke-width:2; }
.injury-marker{ position:absolute; width:20px; height:20px; margin-left:-10px; margin-top:-10px; background:<?= $catMeta['color'] ?>; color:#fff; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:.7rem; font-weight:700; box-shadow:0 0 0 2px #fff, 0 1px 4px rgba(0,0,0,.4); }
.injury-marker.linked-entry{ background:#2e7d32; box-shadow:0 0 0 2px #fff, 0 0 0 4px #2e7d32, 0 1px 4px rgba(0,0,0,.4); }
.injury-marker.linked-exit{ background:#c62828; box-shadow:0 0 0 2px #fff, 0 0 0 4px #c62828, 0 1px 4px rgba(0,0,0,.4); }
.injury-marker.pending-entry{ background:#fff; color:#2e7d32; border:2px dashed #2e7d32; animation:pulse-pending 1s infinite; }
@keyframes pulse-pending{ 0%,100%{opacity:1;} 50%{opacity:.4;} }
.injury-finding-card{ border:1px solid #e5e9ed; border-radius:8px; }
.injury-finding-card.linked{ border-color:#8e24aa; background:#faf5fc; }
#linkModeBanner{ font-size:.78rem; border-radius:6px; padding:6px 10px; }
.odontogram-chart{ display:flex; flex-direction:column; gap:6px; align-items:center; background:#f8f9fa; border-radius:8px; padding:14px 8px; }
.odontogram-row{ display:flex; gap:4px; }
.odontogram-row.lower{ border-top:2px solid #cfd8dc; padding-top:10px; margin-top:4px; }
.tooth-cell{ width:30px; height:34px; border:1px solid #cfd8dc; border-radius:6px; background:#fff; display:flex; align-items:center; justify-content:center; font-size:.68rem; font-weight:600; cursor:pointer; color:#555; user-select:none; }
.tooth-cell:hover{ border-color:#0d6efd; }
.tooth-cell.marked{ color:#fff; border-color:transparent; }
.tooth-quadrant-gap{ width:8px; }
.odontogram-legend-chip{ display:inline-flex; align-items:center; gap:4px; padding:2px 8px; border-radius:10px; color:#fff; }
</style>

<div class="page-header">
    <div class="page-block">
        <h5 class="m-b-10"><i class="ti <?= $catMeta['icon'] ?> me-2" style="color:<?= $catMeta['color'] ?>;"></i><?= htmlspecialchars($cat) ?> Services</h5>
        <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li>
            <li class="breadcrumb-item">Clinical Services</li>
            <li class="breadcrumb-item active"><?= htmlspecialchars($cat) ?></li>
        </ul>
    </div>
</div>

<!-- Category switcher -->
<div class="mb-3 d-flex gap-2 flex-wrap">
    <?php foreach ($validCategories as $c): ?>
    <a href="category.php?cat=<?= urlencode($c) ?>" class="btn btn-sm <?= $c === $cat ? 'btn-primary' : 'btn-outline-secondary' ?>"><?= $c ?></a>
    <?php endforeach; ?>
</div>

<?php if ($msg): ?><div class="alert alert-success alert-dismissible fade show"><i class="ti ti-circle-check me-2"></i><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
<?php if ($errMsg): ?><div class="alert alert-danger alert-dismissible fade show"><i class="ti ti-alert-circle me-2"></i><?= htmlspecialchars($errMsg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

<div class="row g-3">
    <!-- Sub-services list -->
    <div class="col-lg-4">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h6 class="section-title mb-0">Sub-Services</h6>
                <button class="btn btn-primary btn-sm" onclick="openServiceModal()"><i class="ti ti-plus me-1"></i>Add</button>
            </div>
            <div class="card-body p-0">
                <?php if (empty($subServices)): ?>
                <p class="text-muted text-center py-4 mb-0">No <?= htmlspecialchars($cat) ?> sub-services yet — add the first one.</p>
                <?php else: ?>
                <ul class="list-group list-group-flush">
                    <?php foreach ($subServices as $s): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center <?= $s['status'] === 'inactive' ? 'opacity-50' : '' ?>">
                        <div>
                            <div class="fw-semibold"><?= htmlspecialchars($s['service_name']) ?></div>
                            <?php if ($s['description']): ?><div class="text-muted" style="font-size:.78rem;"><?= htmlspecialchars($s['description']) ?></div><?php endif; ?>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <?php if ($s['status'] === 'inactive'): ?><span class="badge bg-secondary">Inactive</span><?php endif; ?>
                            <button class="btn-edit btn btn-sm" title="Edit" onclick='openServiceModal(<?= htmlspecialchars(json_encode($s), ENT_QUOTES) ?>)'><i class="ti ti-edit"></i></button>
                            <button class="btn btn-sm btn-outline-secondary" title="<?= $s['status'] === 'active' ? 'Deactivate' : 'Reactivate' ?>" onclick="location.href='category.php?cat=<?= urlencode($cat) ?>&toggle_service=<?= $s['id'] ?>'">
                                <i class="ti <?= $s['status'] === 'active' ? 'ti-eye-off' : 'ti-eye' ?>"></i>
                            </button>
                            <?php if (!empty($serviceUsage[$s['id']])): ?>
                            <button class="btn btn-sm btn-outline-secondary" disabled title="Has <?= $serviceUsage[$s['id']] ?> patient record<?= $serviceUsage[$s['id']] === 1 ? '' : 's' ?> — deactivate instead of deleting">
                                <i class="ti ti-trash"></i>
                            </button>
                            <?php else: ?>
                            <button class="btn-delete btn btn-sm" title="Delete" onclick="confirmDelete('category.php?cat=<?= urlencode($cat) ?>&delete_service=<?= $s['id'] ?>','<?= htmlspecialchars($s['service_name'], ENT_QUOTES) ?>')">
                                <i class="ti ti-trash"></i>
                            </button>
                            <?php endif; ?>
                        </div>
                    </li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Patient service history for this category -->
    <div class="col-lg-8">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h6 class="section-title mb-0">Patient Records — <?= htmlspecialchars($cat) ?></h6>
                <button class="btn btn-primary btn-sm" onclick="openRecordModal()" <?= empty($subServices) ? 'disabled title="Add a sub-service first"' : '' ?>>
                    <i class="ti ti-plus me-1"></i>Record Service
                </button>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table prms-datatable mb-0" style="font-size:.88rem;">
                        <thead>
                            <tr><th>Patient</th><th>Sub-Service</th><th>Date</th><th>Notes</th><th>Status</th><th>Staff</th><th>Actions</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($records as $rec): ?>
                            <tr>
                                <td>
                                    <div class="fw-semibold"><?= htmlspecialchars($rec['patient_name'] ?? '') ?></div>
                                    <div class="text-muted" style="font-size:.78rem;"><?= htmlspecialchars($rec['patient_no'] ?? '') ?></div>
                                </td>
                                <td><?= htmlspecialchars($rec['service_name'] ?? '—') ?></td>
                                <td><?= date('M d, Y', strtotime($rec['service_date'])) ?></td>
                                <td style="max-width:150px;"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= htmlspecialchars($rec['notes'] ?? '') ?>"><?= htmlspecialchars($rec['notes'] ?: '—') ?></div></td>
                                <td><span class="badge <?= $statusBadge[$rec['status']] ?? 'bg-secondary' ?>"><?= ucfirst($rec['status']) ?></span></td>
                                <td><?= htmlspecialchars($rec['staff_name'] ?: '—') ?></td>
                                <td>
                                    <?php if (!empty($rec['injury_map']) && stripos($rec['service_name'] ?? '', 'medico-legal') !== false): ?>
                                    <button class="btn btn-sm btn-outline-primary me-1" title="View Exam Diagram" onclick='openExamView(<?= htmlspecialchars(json_encode($rec), ENT_QUOTES) ?>)'><i class="ti ti-scan"></i></button>
                                    <?php endif; ?>
                                    <?php if ($cat === 'Dental' && !empty($rec['odontogram'])): ?>
                                    <button class="btn btn-sm btn-outline-primary me-1" title="View Dental Chart" onclick='openOdontogramView(<?= htmlspecialchars(json_encode($rec), ENT_QUOTES) ?>)'><i class="ti ti-mood-smile"></i></button>
                                    <?php endif; ?>
                                    <button class="btn-edit btn btn-sm me-1" onclick='openRecordModal(<?= htmlspecialchars(json_encode($rec), ENT_QUOTES) ?>)'><i class="ti ti-edit"></i></button>
                                    <button class="btn-delete btn btn-sm" onclick="confirmDelete('category.php?cat=<?= urlencode($cat) ?>&delete_record=<?= $rec['id'] ?>','this record')"><i class="ti ti-trash"></i></button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ══ Sub-Service Modal ══ -->
<div class="modal fade" id="serviceModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" action="category.php?cat=<?= urlencode($cat) ?>">
                <input type="hidden" name="save_service" value="1">
                <input type="hidden" name="service_id" id="svcId">
                <div class="modal-header" style="background:<?= $catMeta['color'] ?>;">
                    <h5 class="modal-title" id="svcModalTitle" style="color:#fff;"><i class="ti ti-plus me-2" style="color:#fff;"></i>Add Sub-Service</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Sub-Service Name *</label>
                        <input type="text" class="form-control" name="service_name" id="svcName" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea class="form-control" name="description" id="svcDesc" rows="2"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Fee (optional)</label>
                        <input type="number" step="0.01" min="0" class="form-control" name="fee" id="svcFee" placeholder="0.00">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Sub-Service</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ══ Record Service Modal ══ -->
<div class="modal fade" id="recordModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="post" action="category.php?cat=<?= urlencode($cat) ?>" id="recordForm" onsubmit="finalizeInjuryMap()">
                <input type="hidden" name="save_record" value="1">
                <input type="hidden" name="record_id" id="recId">
                <div class="modal-header" style="background:<?= $catMeta['color'] ?>;">
                    <h5 class="modal-title" id="recModalTitle" style="color:#fff;"><i class="ti ti-file-plus me-2" style="color:#fff;"></i>Record <?= htmlspecialchars($cat) ?> Service</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Patient *</label>
                        <select class="form-select" name="patient_id" id="recPatient" required>
                            <option value="">Select patient…</option>
                            <?php foreach ($patients as $p): ?>
                            <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['patient_no'] . ' - ' . $p['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Sub-Service *</label>
                        <select class="form-select" name="service_id" id="recService" onchange="toggleInjurySection()" required>
                            <option value="">Select sub-service…</option>
                            <?php foreach ($subServices as $s): if ($s['status'] !== 'active') continue; ?>
                            <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['service_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row">
                        <div class="col-6 mb-3">
                            <label class="form-label">Date *</label>
                            <input type="date" class="form-control" name="service_date" id="recDate" value="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="col-6 mb-3">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="status" id="recStatus">
                                <option value="done">Done</option>
                                <option value="pending">Pending</option>
                                <option value="cancelled">Cancelled</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Notes</label>
                        <textarea class="form-control" name="notes" id="recNotes" rows="3"></textarea>
                    </div>

                    <!-- Medico-Legal Examination body diagram — only shown when the
                         selected sub-service is a Medico-Legal Examination. -->
                    <div class="mb-1" id="injuryMapSection" style="display:none;">
                        <hr>
                        <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
                            <label class="form-label mb-0"><i class="ti ti-scan me-1"></i>Body Diagram — Findings</label>
                            <div class="btn-group btn-group-sm" role="group">
                                <button type="button" class="btn btn-outline-secondary active" id="viewFrontBtn" onclick="switchBodyView('front')">Front</button>
                                <button type="button" class="btn btn-outline-secondary" id="viewBackBtn" onclick="switchBodyView('back')">Back</button>
                            </div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
                            <button type="button" class="btn btn-sm btn-outline-purple" id="linkModeBtn" style="border-color:#8e24aa;color:#8e24aa;" onclick="toggleLinkMode()">
                                <i class="ti ti-line" id="linkModeIcon"></i> <span id="linkModeLabel">Link Entry ⇄ Exit (one injury, two marks)</span>
                            </button>
                        </div>
                        <div id="linkModeBanner" class="alert alert-purple mb-2" style="display:none;background:#faf5fc;color:#6a1b7a;border:1px solid #e0c3ec;">
                            <span id="linkModeStatusText"></span>
                            <button type="button" class="btn btn-sm btn-link text-danger p-0 ms-2" onclick="cancelLinkMode()">Cancel</button>
                        </div>
                        <div class="row g-3">
                            <div class="col-12 col-sm-5">
                                <div class="body-diagram-wrap" id="bodyDiagramWrap" onclick="onBodyClick(event)">
                                    <?= bodySilhouetteSvg('frontSvg') ?>
                                    <?php $backSvg = bodySilhouetteSvg('backSvg'); ?>
                                    <?= str_replace('<svg id="backSvg"', '<svg id="backSvg" style="display:none;"', $backSvg) ?>
                                    <div id="markerLayer" style="position:absolute; inset:0; pointer-events:none;"></div>
                                </div>
                                <p class="text-muted text-center mb-0 mt-1" style="font-size:.72rem;">Click the diagram to drop a pin where the finding is.</p>
                            </div>
                            <div class="col-12 col-sm-7">
                                <div id="findingsList" class="d-flex flex-column gap-2" style="max-height:280px; overflow-y:auto;"></div>
                                <p class="text-muted mb-0" id="noFindingsMsg" style="font-size:.8rem;">No findings marked yet.</p>
                            </div>
                        </div>
                        <input type="hidden" name="injury_map" id="injuryMapInput">
                    </div>

                    <?php if ($cat === 'Dental'): ?>
                    <!-- Dental Chart (odontogram) — one procedure/finding per tooth, FDI notation -->
                    <div class="mb-1">
                        <hr>
                        <label class="form-label mb-2"><i class="ti ti-mood-smile me-1"></i>Dental Chart</label>
                        <p class="text-muted mb-2" style="font-size:.76rem;">Click a tooth to mark it, then choose what was done. Numbers use the FDI two-digit system.</p>
                        <div id="odontogramChart" class="odontogram-chart"></div>
                        <div id="odontogramLegend" class="d-flex flex-wrap gap-2 mt-2 mb-3" style="font-size:.72rem;"></div>
                        <div id="odontogramList" class="d-flex flex-column gap-2" style="max-height:220px; overflow-y:auto;"></div>
                        <p class="text-muted mb-0" id="noTeethMsg" style="font-size:.8rem;">No teeth marked yet.</p>
                        <input type="hidden" name="odontogram" id="odontogramInput">
                    </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save Record</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ══ Medico-Legal Exam — read-only diagram viewer ══ -->
<div class="modal fade" id="examViewModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header" style="background:<?= $catMeta['color'] ?>;">
                <h5 class="modal-title" style="color:#fff;"><i class="ti ti-scan me-2" style="color:#fff;"></i>Medico-Legal Exam — <span id="examPatientName"></span></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="text-muted" id="examMeta" style="font-size:.85rem;"></div>
                    <div class="btn-group btn-group-sm" role="group">
                        <button type="button" class="btn btn-outline-secondary active" id="examFrontBtn" onclick="switchExamView('front')">Front</button>
                        <button type="button" class="btn btn-outline-secondary" id="examBackBtn" onclick="switchExamView('back')">Back</button>
                    </div>
                </div>
                <div class="row g-3">
                    <div class="col-12 col-sm-5">
                        <div class="body-diagram-wrap" id="examDiagramWrap">
                            <?= bodySilhouetteSvg('examFrontSvg') ?>
                            <?php $examBackSvg = bodySilhouetteSvg('examBackSvg'); ?>
                            <?= str_replace('<svg id="examBackSvg"', '<svg id="examBackSvg" style="display:none;"', $examBackSvg) ?>
                            <div id="examMarkerLayer" style="position:absolute; inset:0; pointer-events:none;"></div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-7">
                        <div id="examFindingsList" class="d-flex flex-column gap-2" style="max-height:320px; overflow-y:auto;"></div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php if ($cat === 'Dental'): ?>
<!-- ══ Dental Chart — read-only odontogram viewer ══ -->
<div class="modal fade" id="odontogramViewModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header" style="background:<?= $catMeta['color'] ?>;">
                <h5 class="modal-title" style="color:#fff;"><i class="ti ti-mood-smile me-2" style="color:#fff;"></i>Dental Chart — <span id="examOdontoPatientName"></span></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="text-muted mb-2" id="examOdontoMeta" style="font-size:.85rem;"></div>
                <div id="examOdontogramChart" class="odontogram-chart"></div>
                <div id="examOdontogramLegend" class="d-flex flex-wrap gap-2 mt-2 mb-3" style="font-size:.72rem;"></div>
                <div id="examOdontogramList" class="d-flex flex-column gap-2" style="max-height:260px; overflow-y:auto;"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
function openServiceModal(s) {
    document.getElementById('svcId').value = s ? s.id : '';
    document.getElementById('svcName').value = s ? s.service_name : '';
    document.getElementById('svcDesc').value = s ? (s.description || '') : '';
    document.getElementById('svcFee').value = s ? s.fee : '';
    document.getElementById('svcModalTitle').innerHTML = (s ? '<i class="ti ti-edit me-2" style="color:#fff;"></i>Edit' : '<i class="ti ti-plus me-2" style="color:#fff;"></i>Add') + ' Sub-Service';
    new bootstrap.Modal(document.getElementById('serviceModal')).show();
}

// ── Medico-Legal Examination body diagram ───────────────────────────────
const SERVICE_NAMES = {<?php foreach ($subServices as $s) echo (int)$s['id'] . ':' . json_encode($s['service_name']) . ','; ?>};
function isMedicolegal(serviceId) {
    const name = (SERVICE_NAMES[serviceId] || '').toLowerCase();
    return name.indexOf('medico-legal') !== -1 || name.indexOf('medico legal') !== -1;
}

const BODY_ZONES = [
    { label: 'Head',            x1: 37.5, y1: 2,     x2: 62.5, y2: 16.25 },
    { label: 'Neck',             x1: 42.5, y1: 16.25, x2: 57.5, y2: 20 },
    { label: 'Right Shoulder',   x1: 17.5, y1: 20,    x2: 32.5, y2: 27.5 },
    { label: 'Left Shoulder',    x1: 67.5, y1: 20,    x2: 82.5, y2: 27.5 },
    { label: 'Chest',            x1: 32.5, y1: 20,    x2: 67.5, y2: 35 },
    { label: 'Abdomen',          x1: 32.5, y1: 35,    x2: 67.5, y2: 47.5 },
    { label: 'Right Upper Arm',  x1: 12.5, y1: 27.5,  x2: 30,   y2: 45 },
    { label: 'Left Upper Arm',   x1: 70,   y1: 27.5,  x2: 87.5, y2: 45 },
    { label: 'Right Forearm',    x1: 10,   y1: 45,    x2: 27.5, y2: 60 },
    { label: 'Left Forearm',     x1: 72.5, y1: 45,    x2: 90,   y2: 60 },
    { label: 'Right Hand',       x1: 7.5,  y1: 60,    x2: 25,   y2: 66.25 },
    { label: 'Left Hand',        x1: 75,   y1: 60,    x2: 92.5, y2: 66.25 },
    { label: 'Pelvis / Groin',   x1: 37.5, y1: 47.5,  x2: 62.5, y2: 53.75 },
    { label: 'Right Thigh',      x1: 32.5, y1: 53.75, x2: 50,   y2: 72.5 },
    { label: 'Left Thigh',       x1: 50,   y1: 53.75, x2: 67.5, y2: 72.5 },
    { label: 'Right Knee',       x1: 32.5, y1: 72.5,  x2: 50,   y2: 77.5 },
    { label: 'Left Knee',        x1: 50,   y1: 72.5,  x2: 67.5, y2: 77.5 },
    { label: 'Right Lower Leg',  x1: 32.5, y1: 77.5,  x2: 50,   y2: 93.75 },
    { label: 'Left Lower Leg',   x1: 50,   y1: 77.5,  x2: 67.5, y2: 93.75 },
    { label: 'Right Foot',       x1: 30,   y1: 93.75, x2: 50,   y2: 98.75 },
    { label: 'Left Foot',        x1: 50,   y1: 93.75, x2: 70,   y2: 98.75 }
];
function zoneLabel(x, y) {
    for (const z of BODY_ZONES) { if (x >= z.x1 && x <= z.x2 && y >= z.y1 && y <= z.y2) return z.label; }
    return 'Body';
}

let bodyFindings = []; // each: { marks: [{view,x,y,zone,role}], note } — 1 mark = single point, 2 = linked entry/exit
let currentBodyView = 'front';
let linkMode = false;
let pendingEntry = null; // first mark clicked while linking an entry/exit pair

function toggleInjurySection() {
    const sid = parseInt(document.getElementById('recService').value) || 0;
    document.getElementById('injuryMapSection').style.display = isMedicolegal(sid) ? '' : 'none';
}

function switchBodyView(view) {
    currentBodyView = view;
    document.getElementById('frontSvg').style.display = view === 'front' ? '' : 'none';
    document.getElementById('backSvg').style.display = view === 'back' ? '' : 'none';
    document.getElementById('viewFrontBtn').classList.toggle('active', view === 'front');
    document.getElementById('viewBackBtn').classList.toggle('active', view === 'back');
    renderMarkers();
}

// ── Linked injury mode: click an entry point, then an exit point (any view) ─
function toggleLinkMode() {
    if (linkMode) { cancelLinkMode(); return; }
    linkMode = true;
    pendingEntry = null;
    document.getElementById('linkModeBtn').classList.add('active');
    document.getElementById('linkModeBtn').style.background = '#8e24aa';
    document.getElementById('linkModeBtn').style.color = '#fff';
    document.getElementById('linkModeLabel').textContent = 'Linking… click the diagram (Cancel to stop)';
    document.getElementById('linkModeBanner').style.display = '';
    document.getElementById('linkModeStatusText').textContent = 'Click the entry point on the diagram.';
    renderMarkers();
}
function cancelLinkMode() {
    linkMode = false;
    pendingEntry = null;
    document.getElementById('linkModeBtn').classList.remove('active');
    document.getElementById('linkModeBtn').style.background = '';
    document.getElementById('linkModeBtn').style.color = '#8e24aa';
    document.getElementById('linkModeLabel').textContent = 'Link Entry ⇄ Exit (one injury, two marks)';
    document.getElementById('linkModeBanner').style.display = 'none';
    renderMarkers();
}

function onBodyClick(e) {
    try {
        if (!e || typeof e.clientX === 'undefined') return;
        const wrap = document.getElementById('bodyDiagramWrap');
        if (!wrap) return;
        const rect = wrap.getBoundingClientRect();
        const x = Math.round(((e.clientX - rect.left) / rect.width) * 10000) / 100;
        const y = Math.round(((e.clientY - rect.top) / rect.height) * 10000) / 100;
        const mark = { view: currentBodyView, x: x, y: y, zone: zoneLabel(x, y) };

        if (linkMode) {
            if (!pendingEntry) {
                pendingEntry = Object.assign({ role: 'entry' }, mark);
                const statusEl = document.getElementById('linkModeStatusText');
                if (statusEl) statusEl.textContent = 'Entry point set on ' + (currentBodyView === 'front' ? 'Front' : 'Back') + '. Switch view if needed, then click the exit point.';
                renderMarkers();
            } else {
                const exitMark = Object.assign({ role: 'exit' }, mark);
                bodyFindings.push({ marks: [pendingEntry, exitMark], note: '' });
                cancelLinkMode();
                renderFindingsList();
                syncInjuryMapInput();
            }
            return;
        }

        bodyFindings.push({ marks: [mark], note: '' });
        renderMarkers();
        renderFindingsList();
        syncInjuryMapInput();
    } catch (err) {
        console.error('onBodyClick error', err);
    }
}

function renderMarkers() {
    const layer = document.getElementById('markerLayer');
    layer.innerHTML = '';
    bodyFindings.forEach((f, i) => {
        f.marks.forEach(m => {
            if (m.view !== currentBodyView) return;
            const dot = document.createElement('div');
            dot.className = 'injury-marker' + (m.role === 'entry' ? ' linked-entry' : (m.role === 'exit' ? ' linked-exit' : ''));
            dot.style.left = m.x + '%';
            dot.style.top = m.y + '%';
            dot.title = m.role ? (m.role === 'entry' ? 'Entry point' : 'Exit point') : '';
            dot.textContent = (i + 1) + (m.role === 'entry' ? 'a' : (m.role === 'exit' ? 'b' : ''));
            layer.appendChild(dot);
        });
    });
    if (linkMode && pendingEntry && pendingEntry.view === currentBodyView) {
        const dot = document.createElement('div');
        dot.className = 'injury-marker pending-entry';
        dot.style.left = pendingEntry.x + '%';
        dot.style.top = pendingEntry.y + '%';
        dot.textContent = '?';
        layer.appendChild(dot);
    }
}

function renderFindingsList() {
    const list = document.getElementById('findingsList');
    const noMsg = document.getElementById('noFindingsMsg');
    list.innerHTML = '';
    noMsg.style.display = bodyFindings.length ? 'none' : '';
    bodyFindings.forEach((f, i) => {
        const isLinked = f.marks.length > 1;
        const card = document.createElement('div');
        card.className = 'injury-finding-card p-2' + (isLinked ? ' linked' : '');

        const head = document.createElement('div');
        head.className = 'd-flex justify-content-between align-items-center mb-1';
        const badge = document.createElement('span');
        badge.className = 'badge';
        const rmBtn = document.createElement('button');
        rmBtn.type = 'button';
        rmBtn.className = 'btn btn-sm btn-outline-danger py-0 px-1';
        rmBtn.innerHTML = '<i class="ti ti-x"></i>';
        rmBtn.addEventListener('click', function (ev) { ev.preventDefault(); ev.stopPropagation(); try { removeFinding(i); } catch (err) { console.error('removeFinding click error', err); } });

        if (isLinked) {
            badge.style.background = '#8e24aa';
            badge.textContent = '#' + (i + 1) + ' · Linked ⇄ (entry/exit)';
            head.appendChild(badge); head.appendChild(rmBtn);
            card.appendChild(head);

            const locLine = document.createElement('div');
            locLine.className = 'text-muted mb-1';
            locLine.style.fontSize = '.76rem';
            locLine.textContent = f.marks.map(m =>
                (m.role === 'entry' ? 'Entry' : 'Exit') + ': ' + (m.view === 'front' ? 'Front' : 'Back') + ' — ' + (m.zone || 'Body')
            ).join('  /  ');
            card.appendChild(locLine);
        } else {
            const m = f.marks[0];
            badge.style.background = '<?= $catMeta['color'] ?>';
            badge.textContent = '#' + (i + 1) + ' · ' + (m.view === 'front' ? 'Front' : 'Back');
            head.appendChild(badge); head.appendChild(rmBtn);
            card.appendChild(head);

            const zoneInput = document.createElement('input');
            zoneInput.type = 'text';
            zoneInput.className = 'form-control form-control-sm mb-1';
            zoneInput.placeholder = 'Location';
            zoneInput.value = m.zone;
            zoneInput.oninput = function () { m.zone = zoneInput.value; syncInjuryMapInput(); };
            card.appendChild(zoneInput);
        }

        const noteArea = document.createElement('textarea');
        noteArea.className = 'form-control form-control-sm';
        noteArea.rows = 2;
        noteArea.placeholder = isLinked
            ? 'Describe this injury (shared by both points), e.g. "Rod pierced through the left forearm — entry anterior, exit posterior"'
            : 'Describe the finding, e.g. "3.5cm x 4.5cm red bruise with tenderness"';
        noteArea.value = f.note;
        noteArea.oninput = function () { f.note = noteArea.value; syncInjuryMapInput(); };
        card.appendChild(noteArea);

        list.appendChild(card);
    });
}

function finalizeInjuryMap() {
    // If the sub-service was switched away from Medico-Legal after
    // findings were marked, don't submit stale diagram data with it.
    if (document.getElementById('injuryMapSection').style.display === 'none') {
        document.getElementById('injuryMapInput').value = '';
    }
}
function removeFinding(i) { try { bodyFindings.splice(i, 1); renderMarkers(); renderFindingsList(); syncInjuryMapInput(); } catch (err) { console.error('removeFinding error', err); } }
function syncInjuryMapInput() { document.getElementById('injuryMapInput').value = bodyFindings.length ? JSON.stringify(bodyFindings) : ''; }

// Back-compat: older records stored one mark per finding, flat on the object
// itself ({view,x,y,zone,note}) instead of nested under "marks".
function normalizeFindings(raw) {
    if (!Array.isArray(raw)) return [];
    return raw.map(f => {
        if (Array.isArray(f.marks)) return { marks: f.marks, note: f.note || '' };
        return { marks: [{ view: f.view || 'front', x: f.x || 0, y: f.y || 0, zone: f.zone || '' }], note: f.note || '' };
    });
}

function openRecordModal(r) {
    document.getElementById('recId').value = r ? r.id : '';
    document.getElementById('recPatient').value = r ? r.patient_id : '';
    document.getElementById('recService').value = r ? r.service_id : '';
    document.getElementById('recDate').value = r ? r.service_date : '<?= date('Y-m-d') ?>';
    document.getElementById('recStatus').value = r ? r.status : 'done';
    document.getElementById('recNotes').value = r ? (r.notes || '') : '';
    document.getElementById('recModalTitle').innerHTML = '<i class="ti ti-file-plus me-2" style="color:#fff;"></i>' + (r ? 'Edit' : 'Record') + ' <?= htmlspecialchars($cat) ?> Service';

    bodyFindings = (r && r.injury_map) ? normalizeFindings(JSON.parse(r.injury_map)) : [];
    cancelLinkMode();
    switchBodyView('front');
    renderFindingsList();
    syncInjuryMapInput();
    toggleInjurySection();

    if (document.getElementById('odontogramChart')) {
        odontogram = (r && r.odontogram) ? JSON.parse(r.odontogram) : [];
        renderOdontogramChart();
        renderOdontogramList();
        syncOdontogramInput();
    }

    new bootstrap.Modal(document.getElementById('recordModal')).show();
}

// ── Dental Chart (odontogram) — FDI two-digit tooth notation ───────────────
let odontogram = []; // [{ tooth, procedure, note }]
const PROCEDURE_COLORS = {
    'Caries': '#e65100', 'Filling': '#1565c0', 'Extraction': '#c62828',
    'Root Canal': '#6a1b7a', 'Crown': '#00897b', 'Sealant': '#2e7d32',
    'Missing': '#757575', 'Other': '#455a64'
};
const UPPER_TEETH = [18,17,16,15,14,13,12,11,21,22,23,24,25,26,27,28].map(String);
const LOWER_TEETH = [48,47,46,45,44,43,42,41,31,32,33,34,35,36,37,38].map(String);

function buildToothRow(teeth, rowClass, editable) {
    const row = document.createElement('div');
    row.className = 'odontogram-row' + (rowClass ? ' ' + rowClass : '');
    teeth.forEach((t, idx) => {
        if (idx === 8) { const gap = document.createElement('div'); gap.className = 'tooth-quadrant-gap'; row.appendChild(gap); }
        const cell = document.createElement('div');
        cell.className = 'tooth-cell';
        cell.textContent = t;
        cell.title = 'Tooth ' + t;
        const entry = odontogram.find(o => o.tooth === t);
        if (entry) {
            cell.classList.add('marked');
            cell.style.background = PROCEDURE_COLORS[entry.procedure] || PROCEDURE_COLORS['Other'];
        }
        if (editable) cell.addEventListener('click', function (ev) { ev.preventDefault(); ev.stopPropagation(); try { toggleTooth(t); } catch (err) { console.error('toggleTooth click error', err); } });
        row.appendChild(cell);
    });
    return row;
}

function renderOdontogramChart(editable = true) {
    const chart = document.getElementById(editable ? 'odontogramChart' : 'examOdontogramChart');
    if (!chart) return;
    chart.innerHTML = '';
    chart.appendChild(buildToothRow(UPPER_TEETH, 'upper', editable));
    chart.appendChild(buildToothRow(LOWER_TEETH, 'lower', editable));

    const legendId = editable ? 'odontogramLegend' : 'examOdontogramLegend';
    const legend = document.getElementById(legendId);
    if (legend) {
        legend.innerHTML = '';
        Object.keys(PROCEDURE_COLORS).forEach(proc => {
            const chip = document.createElement('span');
            chip.className = 'odontogram-legend-chip';
            chip.style.background = PROCEDURE_COLORS[proc];
            chip.textContent = proc;
            legend.appendChild(chip);
        });
    }
}

function toggleTooth(tooth) {
    const idx = odontogram.findIndex(o => o.tooth === tooth);
    if (idx >= 0) {
        odontogram.splice(idx, 1);
    } else {
        odontogram.push({ tooth: tooth, procedure: 'Caries', note: '' });
    }
    renderOdontogramChart();
    renderOdontogramList();
    syncOdontogramInput();
}

function renderOdontogramList() {
    const list = document.getElementById('odontogramList');
    const noMsg = document.getElementById('noTeethMsg');
    if (!list) return;
    list.innerHTML = '';
    noMsg.style.display = odontogram.length ? 'none' : '';
    // Keep the list in tooth-number order so it reads left-to-right like the chart.
    const ordered = [...odontogram].sort((a, b) => UPPER_TEETH.concat(LOWER_TEETH).indexOf(a.tooth) - UPPER_TEETH.concat(LOWER_TEETH).indexOf(b.tooth));
    ordered.forEach(entry => {
        const card = document.createElement('div');
        card.className = 'injury-finding-card p-2';

        const head = document.createElement('div');
        head.className = 'd-flex justify-content-between align-items-center mb-1 gap-2';
        const badge = document.createElement('span');
        badge.className = 'badge';
        badge.style.background = PROCEDURE_COLORS[entry.procedure] || PROCEDURE_COLORS['Other'];
        badge.textContent = 'Tooth ' + entry.tooth;

        const procSelect = document.createElement('select');
        procSelect.className = 'form-select form-select-sm';
        procSelect.style.maxWidth = '150px';
        Object.keys(PROCEDURE_COLORS).forEach(proc => {
            const opt = document.createElement('option');
            opt.value = proc; opt.textContent = proc;
            if (proc === entry.procedure) opt.selected = true;
            procSelect.appendChild(opt);
        });
        procSelect.onchange = function () { entry.procedure = procSelect.value; renderOdontogramChart(); renderOdontogramList(); syncOdontogramInput(); };

        const rmBtn = document.createElement('button');
        rmBtn.type = 'button';
        rmBtn.className = 'btn btn-sm btn-outline-danger py-0 px-1';
        rmBtn.innerHTML = '<i class="ti ti-x"></i>';
        rmBtn.addEventListener('click', function (ev) { ev.preventDefault(); ev.stopPropagation(); try { toggleTooth(entry.tooth); } catch (err) { console.error('odontogram rm click error', err); } });

        head.appendChild(badge); head.appendChild(procSelect); head.appendChild(rmBtn);
        card.appendChild(head);

        const noteInput = document.createElement('input');
        noteInput.type = 'text';
        noteInput.className = 'form-control form-control-sm';
        noteInput.placeholder = 'Note (optional)';
        noteInput.value = entry.note;
        noteInput.oninput = function () { entry.note = noteInput.value; syncOdontogramInput(); };
        card.appendChild(noteInput);

        list.appendChild(card);
    });
}

function syncOdontogramInput() {
    const input = document.getElementById('odontogramInput');
    if (input) input.value = odontogram.length ? JSON.stringify(odontogram) : '';
}

// ── Dental Chart — read-only viewer (mirrors the Medico-Legal exam viewer) ─
function openOdontogramView(rec) {
    odontogram = rec.odontogram ? JSON.parse(rec.odontogram) : [];
    document.getElementById('examOdontoPatientName').textContent = rec.patient_name || '';
    const dateTxt = rec.service_date ? new Date(rec.service_date).toLocaleDateString() : '';
    document.getElementById('examOdontoMeta').textContent = (rec.patient_no ? rec.patient_no + ' · ' : '') + dateTxt;
    renderOdontogramChart(false);

    const list = document.getElementById('examOdontogramList');
    list.innerHTML = '';
    const ordered = [...odontogram].sort((a, b) => UPPER_TEETH.concat(LOWER_TEETH).indexOf(a.tooth) - UPPER_TEETH.concat(LOWER_TEETH).indexOf(b.tooth));
    ordered.forEach(entry => {
        const item = document.createElement('div');
        item.className = 'injury-finding-card p-2';
        const head = document.createElement('div');
        head.className = 'd-flex align-items-center gap-2 mb-1';
        const badge = document.createElement('span');
        badge.className = 'badge';
        badge.style.background = PROCEDURE_COLORS[entry.procedure] || PROCEDURE_COLORS['Other'];
        badge.textContent = 'Tooth ' + entry.tooth + ' · ' + entry.procedure;
        head.appendChild(badge);
        const noteP = document.createElement('div');
        noteP.className = 'text-muted';
        noteP.style.fontSize = '.85rem';
        noteP.textContent = entry.note || '(no note)';
        item.appendChild(head);
        item.appendChild(noteP);
        list.appendChild(item);
    });

    new bootstrap.Modal(document.getElementById('odontogramViewModal')).show();
}

// ── Medico-Legal Examination — read-only diagram viewer ─────────────────
let examFindings = [];
function openExamView(rec) {
    examFindings = rec.injury_map ? normalizeFindings(JSON.parse(rec.injury_map)) : [];
    document.getElementById('examPatientName').textContent = rec.patient_name || '';
    const dateTxt = rec.service_date ? new Date(rec.service_date).toLocaleDateString() : '';
    document.getElementById('examMeta').textContent = (rec.patient_no ? rec.patient_no + ' · ' : '') + dateTxt;

    const hasFront = examFindings.some(f => f.marks.some(m => m.view === 'front'));
    const hasBack = examFindings.some(f => f.marks.some(m => m.view === 'back'));
    document.getElementById('examFrontBtn').style.display = hasFront ? '' : 'none';
    document.getElementById('examBackBtn').style.display = hasBack ? '' : 'none';
    switchExamView(hasFront ? 'front' : 'back');

    new bootstrap.Modal(document.getElementById('examViewModal')).show();
}

let currentExamView = 'front';
function switchExamView(view) {
    currentExamView = view;
    document.getElementById('examFrontSvg').style.display = view === 'front' ? '' : 'none';
    document.getElementById('examBackSvg').style.display = view === 'back' ? '' : 'none';
    document.getElementById('examFrontBtn').classList.toggle('active', view === 'front');
    document.getElementById('examBackBtn').classList.toggle('active', view === 'back');

    const layer = document.getElementById('examMarkerLayer');
    layer.innerHTML = '';
    examFindings.forEach((f, i) => {
        f.marks.forEach(m => {
            if (m.view !== currentExamView) return;
            const dot = document.createElement('div');
            dot.className = 'injury-marker' + (m.role === 'entry' ? ' linked-entry' : (m.role === 'exit' ? ' linked-exit' : ''));
            dot.style.left = m.x + '%';
            dot.style.top = m.y + '%';
            dot.title = m.role ? (m.role === 'entry' ? 'Entry point' : 'Exit point') : '';
            dot.textContent = (i + 1) + (m.role === 'entry' ? 'a' : (m.role === 'exit' ? 'b' : ''));
            layer.appendChild(dot);
        });
    });

    const list = document.getElementById('examFindingsList');
    list.innerHTML = '';
    examFindings.forEach((f, i) => {
        const isLinked = f.marks.length > 1;
        const item = document.createElement('div');
        item.className = 'injury-finding-card p-2' + (isLinked ? ' linked' : '');
        const head = document.createElement('div');
        head.className = 'd-flex align-items-center gap-2 mb-1 flex-wrap';
        const badge = document.createElement('span');
        badge.className = 'badge';
        badge.style.background = isLinked ? '#8e24aa' : '<?= $catMeta['color'] ?>';
        badge.textContent = isLinked ? ('#' + (i + 1) + ' · Linked ⇄') : ('#' + (i + 1) + ' · ' + (f.marks[0].view === 'front' ? 'Front' : 'Back'));
        head.appendChild(badge);

        if (isLinked) {
            const locSpan = document.createElement('span');
            locSpan.className = 'text-muted';
            locSpan.style.fontSize = '.8rem';
            locSpan.textContent = f.marks.map(m =>
                (m.role === 'entry' ? 'Entry' : 'Exit') + ': ' + (m.view === 'front' ? 'Front' : 'Back') + ' — ' + (m.zone || 'Body')
            ).join('  /  ');
            head.appendChild(locSpan);
        } else {
            const zoneText = document.createElement('strong');
            zoneText.textContent = f.marks[0].zone || 'Body';
            head.appendChild(zoneText);
        }

        const noteP = document.createElement('div');
        noteP.className = 'text-muted';
        noteP.style.fontSize = '.85rem';
        noteP.textContent = f.note || '(no description)';
        item.appendChild(head);
        item.appendChild(noteP);
        list.appendChild(item);
    });
}
</script>

<?php include __DIR__ . '/../../includes/layout_footer.php'; ?>
