<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();
$conn = getDBConnection();
$msg = '';
$today = date('Y-m-d');

// ── Add patient to queue ─────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'enqueue') {
    $patient_id = (int)($_POST['patient_id'] ?? 0);
    $category   = $_POST['category'] ?? '';
    $valid_cats = ['Dental','Physical','Mental','Medical'];

    if ($patient_id > 0 && in_array($category, $valid_cats, true)) {
        $r = $conn->prepare("SELECT COALESCE(MAX(queue_no),0)+1 as next_no FROM patient_queue WHERE category=? AND queue_date=?");
        $r->bind_param('ss', $category, $today);
        $r->execute();
        $next_no = $r->get_result()->fetch_assoc()['next_no'];

        $stmt = $conn->prepare("INSERT INTO patient_queue (queue_no, patient_id, category, queue_date) VALUES (?,?,?,?)");
        $stmt->bind_param('iiss', $next_no, $patient_id, $category, $today);
        $stmt->execute();
    }
    header('Location: queueing.php?msg=added'); exit;
}

// ── Update queue status ──────────────────────────────────────────────
if (isset($_GET['action']) && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = (int)$_GET['id'];
    $map = ['serve' => 'serving', 'done' => 'done', 'cancel' => 'cancelled'];
    if (isset($map[$_GET['action']])) {
        $status = $map[$_GET['action']];
        if ($status === 'serving') {
            $conn->query("UPDATE patient_queue SET status='serving', time_served=NOW() WHERE id=$id");
        } else {
            $stmt = $conn->prepare("UPDATE patient_queue SET status=? WHERE id=?");
            $stmt->bind_param('si', $status, $id);
            $stmt->execute();
        }
    }
    header('Location: queueing.php?msg=updated'); exit;
}

// ── Fetch data ────────────────────────────────────────────────────────
$patients = [];
$r = $conn->query("SELECT id, patient_no, CONCAT(first_name,' ',last_name) as name FROM patients WHERE status='active'" . doctorScopeSql() . " ORDER BY last_name");
while ($row = $r->fetch_assoc()) $patients[] = $row;

$categories = ['Dental','Physical','Mental','Medical'];
$queues = [];
foreach ($categories as $cat) {
    $stmt = $conn->prepare("SELECT q.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no
                             FROM patient_queue q LEFT JOIN patients p ON q.patient_id=p.id
                             WHERE q.category=? AND q.queue_date=? AND q.status IN ('waiting','serving')
                             ORDER BY q.queue_no ASC");
    $stmt->bind_param('ss', $cat, $today);
    $stmt->execute();
    $res = $stmt->get_result();
    $rows = [];
    while ($row = $res->fetch_assoc()) $rows[] = $row;
    $queues[$cat] = $rows;
}
$conn->close();

if (isset($_GET['msg'])) { $msg = ['added'=>'Patient added to queue.','updated'=>'Queue status updated.'][$_GET['msg']] ?? ''; }
$catIcons = ['Dental'=>'ti-dental','Physical'=>'ti-stethoscope','Mental'=>'ti-brain','Medical'=>'ti-first-aid-kit'];
$catColors = ['Dental'=>'#0d6efd','Physical'=>'#2e7d32','Mental'=>'#8e24aa','Medical'=>'#e65100'];

$pageTitle = 'Queueing';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<div class="page-header"><div class="page-block">
    <h5 class="m-b-10">Queueing</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Services</li><li class="breadcrumb-item active">Queueing</li></ul>
</div></div>

<?php if ($msg): ?><div class="alert alert-success alert-dismissible fade show"><i class="ti ti-circle-check me-2"></i><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0"><i class="ti ti-users-group me-2" style="color:#0d6efd;"></i>Today's Queue &mdash; <?= date('F d, Y') ?></h6>
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#queueModal">
            <i class="ti ti-plus me-1"></i>Add to Queue
        </button>
    </div>
</div>

<div class="row g-3 mt-1">
    <?php foreach ($categories as $cat): ?>
    <div class="col-md-6 col-xl-3">
        <div class="card h-100">
            <div class="card-header d-flex align-items-center justify-content-between" style="border-left:4px solid <?= $catColors[$cat] ?>;">
                <h6 class="mb-0 fw-bold"><i class="ti <?= $catIcons[$cat] ?> me-2" style="color:<?= $catColors[$cat] ?>;"></i><?= $cat ?></h6>
                <span class="badge" style="background:<?= $catColors[$cat] ?>;"><?= count($queues[$cat]) ?> waiting</span>
            </div>
            <div class="card-body p-2" style="max-height:420px;overflow-y:auto;">
                <?php if (empty($queues[$cat])): ?>
                    <p class="text-muted text-center py-4 mb-0" style="font-size:.85rem;">No patients in queue.</p>
                <?php else: foreach ($queues[$cat] as $q): ?>
                    <div class="d-flex align-items-center justify-content-between p-2 mb-2 rounded" style="background:<?= $q['status']==='serving' ? '#fff8e1' : '#f8f9fa' ?>;border:1px solid #eee;">
                        <div class="d-flex align-items-center gap-2">
                            <div class="fw-bold text-center" style="width:38px;height:38px;line-height:38px;border-radius:50%;background:<?= $catColors[$cat] ?>;color:#fff;font-size:.9rem;">
                                <?= str_pad($q['queue_no'], 2, '0', STR_PAD_LEFT) ?>
                            </div>
                            <div>
                                <div class="fw-semibold" style="font-size:.85rem;"><?= htmlspecialchars($q['patient_name']) ?></div>
                                <div class="text-muted" style="font-size:.75rem;"><?= htmlspecialchars($q['patient_no']) ?></div>
                                <?php if ($q['status']==='serving'): ?><span class="badge bg-warning text-dark" style="font-size:.65rem;">Serving</span><?php else: ?><span class="badge bg-secondary bg-opacity-25 text-secondary" style="font-size:.65rem;">Waiting</span><?php endif; ?>
                            </div>
                        </div>
                        <div class="d-flex flex-column gap-1">
                            <?php if ($q['status']==='waiting'): ?>
                                <a href="queueing.php?action=serve&id=<?= $q['id'] ?>" class="btn btn-sm btn-outline-primary py-0 px-2" style="font-size:.7rem;" title="Call / Start Serving"><i class="ti ti-bell"></i></a>
                            <?php else: ?>
                                <a href="queueing.php?action=done&id=<?= $q['id'] ?>" class="btn btn-sm btn-outline-success py-0 px-2" style="font-size:.7rem;" title="Mark Done"><i class="ti ti-check"></i></a>
                            <?php endif; ?>
                            <a href="queueing.php?action=cancel&id=<?= $q['id'] ?>" class="btn btn-sm btn-outline-danger py-0 px-2" style="font-size:.7rem;" title="Cancel" onclick="return confirm('Remove this patient from the queue?')"><i class="ti ti-x"></i></a>
                        </div>
                    </div>
                <?php endforeach; endif; ?>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Add to Queue Modal -->
<div class="modal fade" id="queueModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="ti ti-users-group me-2"></i>Add Patient to Queue</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="enqueue">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Patient *</label>
                        <select class="form-select" name="patient_id" required>
                            <option value="">Select Patient</option>
                            <?php foreach ($patients as $p): ?><option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['patient_no'].' - '.$p['name']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Category *</label>
                        <select class="form-select" name="category" required>
                            <option value="">Select Category</option>
                            <?php foreach ($categories as $cat): ?><option value="<?= $cat ?>"><?= $cat ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <p class="text-muted mb-0" style="font-size:.8rem;"><i class="ti ti-info-circle me-1"></i>The patient will be assigned the next queue number for the selected category, for today.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-plus me-1"></i>Add to Queue</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php
include __DIR__ . '/../../includes/layout_footer.php';
?>
