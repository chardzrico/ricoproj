<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();
$conn = getDBConnection();
$msg = '';

if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $conn->query("UPDATE services SET status='inactive' WHERE id=".(int)$_GET['delete']);
    header('Location: list.php?msg=deleted'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id   = (int)($_POST['id'] ?? 0);
    $name = trim($_POST['service_name'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $cat  = trim($_POST['category'] ?? '');
    $fee  = floatval($_POST['fee'] ?? 0);

    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE services SET service_name=?,description=?,category=?,fee=? WHERE id=?");
        $stmt->bind_param('sssdi',$name,$desc,$cat,$fee,$id);
    } else {
        $stmt = $conn->prepare("INSERT INTO services (service_name,description,category,fee) VALUES (?,?,?,?)");
        $stmt->bind_param('sssd',$name,$desc,$cat,$fee);
    }
    $stmt->execute();
    header('Location: list.php?msg=' . ($id>0?'updated':'added')); exit;
}

$services = [];
$r = $conn->query("SELECT s.*, (SELECT COUNT(*) FROM patient_services ps WHERE ps.service_id=s.id) as total_given FROM services s WHERE s.status='active' ORDER BY s.category, s.service_name");
while ($row = $r->fetch_assoc()) $services[] = $row;
$conn->close();

if (isset($_GET['msg'])) { $msg = ['added'=>'Service added.','updated'=>'Updated.','deleted'=>'Service deactivated.'][$_GET['msg']] ?? ''; }
$pageTitle = 'Services';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<div class="page-header"><div class="page-block">
    <h5 class="m-b-10">Services</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Services</li><li class="breadcrumb-item active">Service List</li></ul>
</div></div>
<?php if ($msg): ?><div class="alert alert-success alert-dismissible fade show"><i class="ti ti-circle-check me-2"></i><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0"><i class="ti ti-clipboard me-2" style="color:#0d6efd;"></i>Service List</h6>
        <div class="d-flex gap-2">
            <a href="patient_services.php" class="btn btn-outline-primary btn-sm"><i class="ti ti-clipboard-check me-1"></i>Patient Services</a>
            <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#svcModal" onclick="openAddModal()"><i class="ti ti-plus me-1"></i>Add Service</button>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0">
                <thead><tr><th>Service Name</th><th>Category</th><th>Description</th><th>Fee (₱)</th><th>Total Availed</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php foreach ($services as $s): ?>
                    <tr>
                        <td class="fw-semibold"><?= htmlspecialchars($s['service_name']) ?></td>
                        <td class="text-dark"><?= htmlspecialchars($s['category'] ?: '—') ?></td>
                        <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= htmlspecialchars($s['description'] ?: '—') ?></td>
                        <td><?= number_format($s['fee'], 2) == '0.00' ? '<span class="text-success fw-semibold">Free</span>' : '₱'.number_format($s['fee'],2) ?></td>
                        <td class="text-dark"><?= $s['total_given'] ?></td>
                        <td>
                            <button class="btn-edit btn btn-sm me-1" onclick="openEditModal(<?= htmlspecialchars(json_encode($s)) ?>)"><i class="ti ti-edit"></i></button>
                            <button class="btn-delete btn btn-sm" onclick="confirmDelete('list.php?delete=<?= $s['id'] ?>','<?= htmlspecialchars($s['service_name']) ?>')"><i class="ti ti-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($services)): ?><tr><td colspan="6" class="text-center text-muted py-4">No services added yet.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="svcModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="svcModalTitle"><i class="ti ti-clipboard me-2"></i>Add Service</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="id" id="svcId" value="0">
                <div class="modal-body">
                    <div class="mb-3"><label class="form-label">Service Name *</label><input type="text" class="form-control" name="service_name" id="sName" required placeholder="e.g. General Consultation"></div>
                    <div class="mb-3"><label class="form-label">Category</label>
                        <select class="form-select" name="category" id="sCat" required>
                            <option value="">Select Category</option>
                            <option value="Dental">Dental</option>
                            <option value="Physical">Physical</option>
                            <option value="Mental">Mental</option>
                            <option value="Medical">Medical</option>
                        </select>
                    </div>
                    <div class="mb-3"><label class="form-label">Fee (₱)</label><input type="number" step="0.01" class="form-control" name="fee" id="sFee" value="0" min="0"></div>
                    <div class="mb-3"><label class="form-label">Description</label><textarea class="form-control" name="description" id="sDesc" rows="2" placeholder="Short description"></textarea></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php
$extraJS='<script>
function openAddModal(){
    document.getElementById("svcModalTitle").innerHTML=\'<i class="ti ti-clipboard me-2"></i>Add Service\';
    document.getElementById("svcId").value="0";
    ["sName","sCat","sDesc"].forEach(id=>document.getElementById(id).value="");
    document.getElementById("sFee").value="0";
}
function openEditModal(s){
    document.getElementById("svcModalTitle").innerHTML=\'<i class="ti ti-edit me-2"></i>Edit Service\';
    document.getElementById("svcId").value=s.id;
    document.getElementById("sName").value=s.service_name||"";
    document.getElementById("sCat").value=s.category||"";
    document.getElementById("sFee").value=s.fee||"0";
    document.getElementById("sDesc").value=s.description||"";
    new bootstrap.Modal(document.getElementById("svcModal")).show();
}
</script>';
include __DIR__ . '/../../includes/layout_footer.php';
?>
