<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();

$conn = getDBConnection();
$msg = '';

if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $conn->query("DELETE FROM immunization_records WHERE id=".(int)$_GET['delete']);
    header('Location: immunization_record.php?msg=deleted');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id          = (int)($_POST['id'] ?? 0);
    $patient_id  = (int)$_POST['patient_id'];
    $vaccine_id  = (int)$_POST['vaccine_id'];
    $dose_no     = (int)($_POST['dose_number'] ?? 1);
    $date_given  = $_POST['date_given'] ?? '';
    $next_date   = $_POST['next_dose_date'] ?: null;
    $batch       = trim($_POST['batch_number'] ?? '');
    $site        = trim($_POST['site'] ?? '');
    $remarks     = trim($_POST['remarks'] ?? '');
    $staff_id    = getCurrentUser()['id'];

    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE immunization_records SET patient_id=?,vaccine_id=?,dose_number=?,date_given=?,next_dose_date=?,batch_number=?,site=?,remarks=?,administered_by=? WHERE id=?");
        $stmt->bind_param('iiissssiii',$patient_id,$vaccine_id,$dose_no,$date_given,$next_date,$batch,$site,$remarks,$staff_id,$id);
    } else {
        $stmt = $conn->prepare("INSERT INTO immunization_records (patient_id,vaccine_id,dose_number,date_given,next_dose_date,batch_number,site,remarks,administered_by) VALUES (?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param('iiisssssi',$patient_id,$vaccine_id,$dose_no,$date_given,$next_date,$batch,$site,$remarks,$staff_id);
    }
    $stmt->execute();
    header('Location: immunization_record.php?msg=' . ($id > 0 ? 'updated' : 'added'));
    exit;
}

$patients = [];
$r = $conn->query("SELECT id, patient_no, CONCAT(first_name,' ',last_name) as name FROM patients WHERE status='active'" . doctorScopeSql() . " ORDER BY last_name");
while ($row = $r->fetch_assoc()) $patients[] = $row;

$vaccines = [];
$r = $conn->query("SELECT id, vaccine_name FROM vaccines WHERE status='active' ORDER BY vaccine_name");
while ($row = $r->fetch_assoc()) $vaccines[] = $row;

$records = [];
$r = $conn->query("SELECT ir.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no, v.vaccine_name, u.full_name as staff_name FROM immunization_records ir LEFT JOIN patients p ON ir.patient_id=p.id LEFT JOIN vaccines v ON ir.vaccine_id=v.id LEFT JOIN users u ON ir.administered_by=u.id WHERE 1=1" . doctorScopeSql('p') . " ORDER BY ir.date_given DESC LIMIT 100");
while ($row = $r->fetch_assoc()) $records[] = $row;
$conn->close();

if (isset($_GET['msg'])) { $msg = ['added'=>'Record saved.','updated'=>'Record updated.','deleted'=>'Record deleted.'][$_GET['msg']] ?? ''; }
$pageTitle = 'Immunization Records';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>

<div class="page-header">
    <div class="page-block">
        <h5 class="m-b-10">Immunization Records</h5>
        <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li>
            <li class="breadcrumb-item">Vaccination</li>
            <li class="breadcrumb-item active">Immunization Records</li>
        </ul>
    </div>
</div>

<?php if ($msg): ?>
<div class="alert alert-success alert-dismissible fade show"><i class="ti ti-circle-check me-2"></i><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif; ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0"><i class="ti ti-vaccine me-2" style="color:#0d6efd;"></i>Immunization Records</h6>
        <button class="btn btn-primary btn-sm" onclick="openAddModal()">
            <i class="ti ti-plus me-1"></i>Add Record
        </button>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0">
                <thead>
                    <tr>
                        <th>Patient</th>
                        <th>Vaccine</th>
                        <th>Dose #</th>
                        <th>Date Given</th>
                        <th>Next Dose</th>
                        <th>Batch No.</th>
                        <th>Site</th>
                        <th>Administered By</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($records as $rec): ?>
                    <tr>
                        <td>
                            <div class="fw-semibold" style="font-size:.88rem;"><?= htmlspecialchars($rec['patient_name']) ?></div>
                            <div class="text-muted" style="font-size:.78rem;"><?= htmlspecialchars($rec['patient_no']) ?></div>
                        </td>
                        <td class="fw-semibold"><?= htmlspecialchars($rec['vaccine_name']) ?></td>
                        <td><span class="badge bg-info bg-opacity-15 text-info fw-semibold">Dose <?= $rec['dose_number'] ?></span></td>
                        <td><?= date('M d, Y', strtotime($rec['date_given'])) ?></td>
                        <td><?= $rec['next_dose_date'] ? '<span class="text-warning fw-semibold">'.date('M d, Y', strtotime($rec['next_dose_date'])).'</span>' : '<span class="text-muted">—</span>' ?></td>
                        <td><?= htmlspecialchars($rec['batch_number'] ?: '—') ?></td>
                        <td><?= htmlspecialchars($rec['site'] ?: '—') ?></td>
                        <td><?= htmlspecialchars($rec['staff_name'] ?: '—') ?></td>
                        <td>
                            <button class="btn-edit btn btn-sm me-1" onclick="openEditModal(<?= htmlspecialchars(json_encode($rec)) ?>)"><i class="ti ti-edit"></i></button>
                            <button class="btn-delete btn btn-sm" onclick="confirmDelete('immunization_record.php?delete=<?= $rec['id'] ?>', 'this record')"><i class="ti ti-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="immunModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="immunModalTitle"><i class="ti ti-vaccine me-2"></i>Add Immunization Record</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="id" id="immunId" value="0">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Patient *</label>
                            <select class="form-select" name="patient_id" id="iPatient" required>
                                <option value="">Select Patient</option>
                                <?php foreach ($patients as $p): ?><option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['patient_no'].' - '.$p['name']) ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Vaccine *</label>
                            <select class="form-select" name="vaccine_id" id="iVaccine" required>
                                <option value="">Select Vaccine</option>
                                <?php foreach ($vaccines as $v): ?><option value="<?= $v['id'] ?>"><?= htmlspecialchars($v['vaccine_name']) ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Dose Number</label>
                            <select class="form-select" name="dose_number" id="iDose">
                                <?php for ($d=1;$d<=5;$d++): ?><option value="<?= $d ?>"><?= $d ?></option><?php endfor; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Date Given *</label>
                            <input type="date" class="form-control" name="date_given" id="iDateGiven" value="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Next Dose Date</label>
                            <input type="date" class="form-control" name="next_dose_date" id="iNextDate">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Batch Number</label>
                            <input type="text" class="form-control" name="batch_number" id="iBatch" placeholder="Batch #">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Administration Site</label>
                            <input type="text" class="form-control" name="site" id="iSite" placeholder="e.g. Left arm, Right thigh">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Remarks</label>
                            <textarea class="form-control" name="remarks" id="iRemarks" rows="2" placeholder="Any remarks or observations"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$extraJS = '<script>
function openAddModal(){
    document.getElementById("immunModalTitle").innerHTML=\'<i class="ti ti-vaccine me-2"></i>Add Immunization Record\';
    document.getElementById("immunId").value="0";
    ["iPatient","iVaccine"].forEach(id=>document.getElementById(id).value="");
    ["iBatch","iSite","iRemarks","iNextDate"].forEach(id=>document.getElementById(id).value="");
    document.getElementById("iDose").value="1";
    document.getElementById("iDateGiven").value="'.date('Y-m-d').'";

    new bootstrap.Modal(document.getElementById("immunModal")).show();
}
function openEditModal(r){
    document.getElementById("immunModalTitle").innerHTML=\'<i class="ti ti-edit me-2"></i>Edit Immunization Record\';
    document.getElementById("immunId").value=r.id;
    document.getElementById("iPatient").value=r.patient_id;
    document.getElementById("iVaccine").value=r.vaccine_id;
    document.getElementById("iDose").value=r.dose_number||"1";
    document.getElementById("iDateGiven").value=r.date_given||"";
    document.getElementById("iNextDate").value=r.next_dose_date||"";
    document.getElementById("iBatch").value=r.batch_number||"";
    document.getElementById("iSite").value=r.site||"";
    document.getElementById("iRemarks").value=r.remarks||"";
    new bootstrap.Modal(document.getElementById("immunModal")).show();
}
</script>';
include __DIR__ . '/../../includes/layout_footer.php';
?>
