<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();
if (!isAdmin()) { header('Location: ../../dashboard.php'); exit; }
$conn = getDBConnection();
$msg = '';

if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $conn->query("UPDATE users SET status='inactive' WHERE id=".(int)$_GET['delete']." AND id != ".getCurrentUser()['id']);
    header('Location: users.php?msg=deactivated'); exit;
}
if (isset($_GET['activate']) && is_numeric($_GET['activate'])) {
    $conn->query("UPDATE users SET status='active' WHERE id=".(int)$_GET['activate']);
    header('Location: users.php?msg=activated'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id       = (int)($_POST['id'] ?? 0);
    $full     = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $role     = $_POST['role'] ?? 'staff';
    $status   = $_POST['status'] ?? 'active';
    $pw       = $_POST['password'] ?? '';

    // This page only manages staff accounts; never let it create/reassign a 'patient' role.
    if (!in_array($role, ['staff', 'nurse', 'doctor', 'admin'], true)) $role = 'staff';

    if ($id > 0) {
        if ($pw) {
            $hashed = password_hash($pw, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET full_name=?,username=?,email=?,role=?,status=?,password=? WHERE id=? AND role != 'patient'");
            $stmt->bind_param('ssssssi',$full,$username,$email,$role,$status,$hashed,$id);
        } else {
            $stmt = $conn->prepare("UPDATE users SET full_name=?,username=?,email=?,role=?,status=? WHERE id=? AND role != 'patient'");
            $stmt->bind_param('sssssi',$full,$username,$email,$role,$status,$id);
        }
    } else {
        $hashed = password_hash($pw ?: 'PRMS@1234', PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (full_name,username,email,password,role,status) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param('ssssss',$full,$username,$email,$hashed,$role,$status);
    }
    $stmt->execute();
    header('Location: users.php?msg=' . ($id>0?'updated':'added')); exit;
}

$users = [];
$r = $conn->query("SELECT * FROM users WHERE role != 'patient' ORDER BY role, full_name");
while ($row = $r->fetch_assoc()) { unset($row['password']); $users[] = $row; }
$conn->close();

if (isset($_GET['msg'])) { $msg = ['added'=>'User created.','updated'=>'Updated.','deactivated'=>'User deactivated.','activated'=>'User activated.'][$_GET['msg']] ?? ''; }
$pageTitle = 'User Management';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<div class="page-header"><div class="page-block">
    <h5 class="m-b-10">User Management</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Administration</li><li class="breadcrumb-item active">Users</li></ul>
</div></div>
<?php if ($msg): ?><div class="alert alert-success alert-dismissible fade show"><i class="ti ti-circle-check me-2"></i><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0"><i class="ti ti-users me-2" style="color:#0d6efd;"></i>System Users</h6>
        <button class="btn btn-primary btn-sm" onclick="openAddModal()"><i class="ti ti-user-plus me-1"></i>Add User</button>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0">
                <thead><tr><th>Full Name</th><th>Username</th><th>Email</th><th>Role</th><th>Status</th><th>Created</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php foreach ($users as $u):
                        $roleBadge = ['admin'=>'bg-danger','doctor'=>'bg-primary','nurse'=>'bg-success','staff'=>'bg-secondary'][$u['role']] ?? 'bg-secondary';
                    ?>
                    <tr>
                        <td class="fw-semibold"><?= htmlspecialchars($u['full_name']) ?></td>
                        <td><code><?= htmlspecialchars($u['username']) ?></code></td>
                        <td><?= htmlspecialchars($u['email']) ?></td>
                        <td><span class="badge <?= $roleBadge ?>"><?= ucfirst($u['role']) ?></span></td>
                        <td><span class="badge <?= $u['status']==='active'?'bg-success':'bg-secondary' ?>"><?= ucfirst($u['status']) ?></span></td>
                        <td><?= date('M d, Y', strtotime($u['created_at'])) ?></td>
                        <td>
                            <button class="btn-edit btn btn-sm me-1" onclick="openEditModal(<?= htmlspecialchars(json_encode($u)) ?>)"><i class="ti ti-edit"></i></button>
                            <?php if ($u['status']==='active' && $u['id'] != getCurrentUser()['id']): ?>
                            <button class="btn-delete btn btn-sm" onclick="confirmDelete('users.php?delete=<?= $u['id'] ?>','<?= htmlspecialchars($u['full_name']) ?>')"><i class="ti ti-user-off"></i></button>
                            <?php elseif ($u['status']==='inactive'): ?>
                            <a href="users.php?activate=<?= $u['id'] ?>" class="btn-view btn btn-sm"><i class="ti ti-user-check"></i></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="userModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="userModalTitle"><i class="ti ti-user-plus me-2"></i>Add User</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="id" id="userId" value="0">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-12"><label class="form-label">Full Name *</label><input type="text" class="form-control" name="full_name" id="uName" required placeholder="Full name"></div>
                        <div class="col-md-6"><label class="form-label">Username *</label><input type="text" class="form-control" name="username" id="uUsername" required placeholder="Username"></div>
                        <div class="col-md-6"><label class="form-label">Email *</label><input type="email" class="form-control" name="email" id="uEmail" required placeholder="Email"></div>
                        <div class="col-md-6"><label class="form-label">Role</label><select class="form-select" name="role" id="uRole"><option value="staff">Staff</option><option value="nurse">Nurse / Midwife</option><option value="doctor">Doctor</option><option value="admin">Admin</option></select></div>
                        <div class="col-md-6"><label class="form-label">Status</label><select class="form-select" name="status" id="uStatus"><option value="active">Active</option><option value="inactive">Inactive</option></select></div>
                        <div class="col-12"><label class="form-label">Password <small class="text-muted" id="pwHint">(leave blank for default: PRMS@1234)</small></label><input type="password" class="form-control" name="password" id="uPw" placeholder="Password"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php
$extraJS='<script>
function openAddModal(){
    document.getElementById("userModalTitle").innerHTML=\'<i class="ti ti-user-plus me-2"></i>Add User\';
    document.getElementById("userId").value="0";
    ["uName","uUsername","uEmail","uPw"].forEach(id=>document.getElementById(id).value="");
    document.getElementById("uRole").value="staff";
    document.getElementById("uStatus").value="active";
    document.getElementById("pwHint").textContent="(leave blank for default: PRMS@1234)";

    new bootstrap.Modal(document.getElementById("userModal")).show();
}
function openEditModal(u){
    document.getElementById("userModalTitle").innerHTML=\'<i class="ti ti-edit me-2"></i>Edit User\';
    document.getElementById("userId").value=u.id;
    document.getElementById("uName").value=u.full_name||"";
    document.getElementById("uUsername").value=u.username||"";
    document.getElementById("uEmail").value=u.email||"";
    document.getElementById("uRole").value=u.role||"staff";
    document.getElementById("uStatus").value=u.status||"active";
    document.getElementById("uPw").value="";
    document.getElementById("pwHint").textContent="(leave blank to keep current password)";
    new bootstrap.Modal(document.getElementById("userModal")).show();
}
</script>';
include __DIR__ . '/../../includes/layout_footer.php';
?>
