<?php
require_once __DIR__ . '/../../config/session.php';
requireLogin();
requireStaffOnly();
// Redirect to prescription_log.php where the modal now lives
header('Location: prescription_log.php');
exit;
