<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();
$conn = getDBConnection();
$msg = '';
$uid = getCurrentUser()['id'];

if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $conn->query("UPDATE prescriptions SET status='cancelled' WHERE id=".(int)$_GET['delete']);
    header('Location: prescription_log.php?msg=cancelled'); exit;
}

// Handle new prescription POST (moved from create_prescription.php)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patient_id = (int)$_POST['patient_id'];
    $date       = $_POST['prescription_date'] ?? date('Y-m-d');
    $diagnosis  = trim($_POST['diagnosis'] ?? '');
    $notes      = trim($_POST['notes'] ?? '');
    $uid        = getCurrentUser()['id'];

    $r = $conn->query("SELECT COUNT(*) as cnt FROM prescriptions");
    $cnt = (int)$r->fetch_assoc()['cnt'] + 1;
    $rx_number = 'RX-' . date('Y') . '-' . str_pad($cnt, 5, '0', STR_PAD_LEFT);

    $stmt = $conn->prepare("INSERT INTO prescriptions (rx_number,patient_id,prescribed_by,prescription_date,diagnosis,notes) VALUES (?,?,?,?,?,?)");
    $stmt->bind_param('siisss',$rx_number,$patient_id,$uid,$date,$diagnosis,$notes);
    $stmt->execute();
    $rx_id = $conn->insert_id;

    $medicine_ids = $_POST['medicine_id'] ?? [];
    $dosages      = $_POST['dosage'] ?? [];
    $frequencies  = $_POST['frequency'] ?? [];
    $durations    = $_POST['duration'] ?? [];
    $quantities   = $_POST['quantity'] ?? [];
    $instructions = $_POST['instructions'] ?? [];

    foreach ($medicine_ids as $i => $mid) {
        if (!$mid) continue;
        $mid  = (int)$mid;
        $dos  = trim($dosages[$i] ?? '');
        $freq = trim($frequencies[$i] ?? '');
        $dur  = trim($durations[$i] ?? '');
        $qty  = (int)($quantities[$i] ?? 0);
        $inst = trim($instructions[$i] ?? '');
        $stmt2 = $conn->prepare("INSERT INTO prescription_items (prescription_id,medicine_id,dosage,frequency,duration,quantity,instructions) VALUES (?,?,?,?,?,?,?)");
        $stmt2->bind_param('iisssis',$rx_id,$mid,$dos,$freq,$dur,$qty,$inst);
        $stmt2->execute();
    }

    header("Location: prescription_log.php?msg=created&rx=$rx_number"); exit;
}

if (isset($_GET['msg'])) { $msg = ['created'=>'Prescription created: '.$_GET['rx'].'.','cancelled'=>'Prescription cancelled.'][$_GET['msg']] ?? ''; }

$prescriptions = [];
$r = $conn->query("SELECT pr.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no, u.full_name as prescribed_by_name, up.full_name as printed_by_name, (SELECT COUNT(*) FROM prescription_items pi WHERE pi.prescription_id=pr.id) as item_count FROM prescriptions pr LEFT JOIN patients p ON pr.patient_id=p.id LEFT JOIN users u ON pr.prescribed_by=u.id LEFT JOIN users up ON pr.printed_by=up.id WHERE 1=1" . doctorScopeSql('p') . " ORDER BY pr.prescription_date DESC, pr.id DESC LIMIT 200");
while ($row = $r->fetch_assoc()) $prescriptions[] = $row;

$patients = [];
$r = $conn->query("SELECT id, patient_no, CONCAT(first_name,' ',last_name) as name FROM patients WHERE status='active'" . doctorScopeSql() . " ORDER BY last_name");
while ($row = $r->fetch_assoc()) $patients[] = $row;

$medicines = [];
$r = $conn->query("SELECT id, medicine_name, generic_name, strength, dosage_form FROM medicines WHERE status='active' ORDER BY medicine_name");
while ($row = $r->fetch_assoc()) $medicines[] = $row;

// For print preview — this is also the admin hand-off point: the first time
// a prescription is opened for printing, stamp who printed it and when.
$printData = null;
if (isset($_GET['print']) && is_numeric($_GET['print'])) {
    $rxid = (int)$_GET['print'];
    $stmt = $conn->prepare("UPDATE prescriptions SET printed_at=NOW(), printed_by=? WHERE id=? AND printed_at IS NULL");
    $stmt->bind_param('ii', $uid, $rxid);
    $stmt->execute();
    $stmt->close();
    $r = $conn->query("SELECT pr.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no, p.date_of_birth, p.gender, p.address, u.full_name as prescribed_by_name, u.role FROM prescriptions pr LEFT JOIN patients p ON pr.patient_id=p.id LEFT JOIN users u ON pr.prescribed_by=u.id WHERE pr.id=$rxid LIMIT 1");
    $printData = $r->fetch_assoc();
    if ($printData) {
        $printData['items'] = [];
        $r = $conn->query("SELECT pi.*, m.medicine_name, m.generic_name, m.strength, m.dosage_form FROM prescription_items pi LEFT JOIN medicines m ON pi.medicine_id=m.id WHERE pi.prescription_id=$rxid");
        while ($row = $r->fetch_assoc()) $printData['items'][] = $row;
    }
}
$conn->close();

$pageTitle = 'Prescription Log';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<div class="page-header"><div class="page-block">
    <h5 class="m-b-10">Prescription Log</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Medicine</li><li class="breadcrumb-item active">Prescription Log</li></ul>
</div></div>

<?php if ($msg): ?><div class="alert alert-success alert-dismissible fade show"><i class="ti ti-circle-check me-2"></i><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0"><i class="ti ti-file-text me-2" style="color:#0d6efd;"></i>Prescription Log</h6>
        <button class="btn btn-primary btn-sm" onclick="openAddRxModal()">
            <i class="ti ti-plus me-1"></i>New Prescription
        </button>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0">
                <thead><tr><th>RX Number</th><th>Patient</th><th>Date</th><th>Diagnosis</th><th>Medicines</th><th>Prescribed By</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php foreach ($prescriptions as $rx):
                        $sc = $rx['status']==='active' ? 'bg-success' : ($rx['status']==='dispensed' ? 'bg-info' : 'bg-danger');
                    ?>
                    <tr>
                        <td class="fw-semibold"><?= htmlspecialchars($rx['rx_number']) ?></td>
                        <td>
                            <div class="fw-semibold" style="font-size:.88rem;"><?= htmlspecialchars($rx['patient_name']) ?></div>
                            <div class="text-muted" style="font-size:.78rem;"><?= htmlspecialchars($rx['patient_no']) ?></div>
                        </td>
                        <td><?= date('M d, Y', strtotime($rx['prescription_date'])) ?></td>
                        <td style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= htmlspecialchars($rx['diagnosis'] ?: '—') ?></td>
                        <td class="text-dark"><?= $rx['item_count'] ?> item<?= $rx['item_count']!=1?'s':'' ?></td>
                        <td><?= htmlspecialchars($rx['prescribed_by_name'] ?: '—') ?></td>
                        <td class="text-dark">
                            <?= ucfirst($rx['status']) ?>
                            <?php if ($rx['status'] !== 'cancelled'): ?>
                                <?php if ($rx['printed_at']): ?>
                                <div><span class="badge bg-success bg-opacity-15 text-success" style="font-size:.7rem;" title="Printed by <?= htmlspecialchars($rx['printed_by_name'] ?: '') ?>"><i class="ti ti-printer me-1"></i>Printed</span></div>
                                <?php else: ?>
                                <div><span class="badge bg-warning text-dark" style="font-size:.7rem;" title="Sent to admin — not yet printed"><i class="ti ti-clock me-1"></i>Needs Printing</span></div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="?print=<?= $rx['id'] ?>" class="btn-view btn btn-sm me-1" title="Print/View RX"><i class="ti ti-printer"></i></a>
                            <button class="btn-delete btn btn-sm" onclick="confirmDelete('prescription_log.php?delete=<?= $rx['id'] ?>','RX <?= htmlspecialchars($rx['rx_number']) ?>')"><i class="ti ti-x"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ══ NEW PRESCRIPTION MODAL ══ -->
<div class="modal fade" id="rxModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="ti ti-prescription me-2"></i>New Prescription</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <div class="row g-3">
                        <!-- Left: Prescription Header -->
                        <div class="col-md-4">
                            <div class="mb-3">
                                <div class="d-flex align-items-center mb-3">
                                    <div style="width:28px;height:28px;border-radius:50%;background:#e3f2fd;display:flex;align-items:center;justify-content:center;margin-right:10px;">
                                        <i class="ti ti-user" style="color:#0d6efd;font-size:.9rem;"></i>
                                    </div>
                                    <h6 class="mb-0 fw-bold" style="color:#1e3a5f;">Prescription Header</h6>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Patient <span class="text-danger">*</span></label>
                                    <select class="form-select" name="patient_id" required>
                                        <option value="">Select Patient</option>
                                        <?php foreach ($patients as $p): ?><option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['patient_no'].' - '.$p['name']) ?></option><?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Date <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control" name="prescription_date" value="<?= date('Y-m-d') ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Diagnosis / Indication</label>
                                    <textarea class="form-control" name="diagnosis" rows="3" placeholder="Diagnosis or reason for prescription"></textarea>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Notes / Instructions</label>
                                    <textarea class="form-control" name="notes" rows="2" placeholder="General patient instructions"></textarea>
                                </div>
                            </div>
                        </div>

                        <!-- Right: Medicine Items -->
                        <div class="col-md-8">
                            <div class="d-flex align-items-center mb-3">
                                <div style="width:28px;height:28px;border-radius:50%;background:#e8f5e9;display:flex;align-items:center;justify-content:center;margin-right:10px;">
                                    <i class="ti ti-pill" style="color:#2e7d32;font-size:.9rem;"></i>
                                </div>
                                <h6 class="mb-0 fw-bold" style="color:#1e3a5f;">Prescribed Medicines</h6>
                                <button type="button" class="btn btn-sm btn-outline-primary ms-auto" onclick="addMedicineRow()"><i class="ti ti-plus me-1"></i>Add Medicine</button>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-sm mb-0" id="rxTable">
                                    <thead><tr><th style="min-width:160px;">Medicine</th><th style="min-width:85px;">Dosage</th><th style="min-width:120px;">Frequency</th><th style="min-width:85px;">Duration</th><th style="min-width:55px;">Qty</th><th style="min-width:130px;">Instructions</th><th></th></tr></thead>
                                    <tbody id="rxItems">
                                        <tr id="row_0">
                                            <td><select class="form-select form-select-sm" name="medicine_id[]" required><option value="">Select</option><?php foreach ($medicines as $m): ?><option value="<?= $m['id'] ?>"><?= htmlspecialchars($m['medicine_name'].($m['strength']?' '.$m['strength']:'')) ?></option><?php endforeach; ?></select></td>
                                            <td><input type="text" class="form-control form-control-sm" name="dosage[]" placeholder="e.g. 1 tab"></td>
                                            <td><select class="form-select form-select-sm" name="frequency[]"><option value="">Select</option><option>Once daily</option><option>Twice daily</option><option>3x a day</option><option>4x a day</option><option>Every 6 hours</option><option>Every 8 hours</option><option>Every 12 hours</option><option>As needed (PRN)</option><option>Once</option></select></td>
                                            <td><input type="text" class="form-control form-control-sm" name="duration[]" placeholder="e.g. 7 days"></td>
                                            <td><input type="number" class="form-control form-control-sm" name="quantity[]" min="0" placeholder="0"></td>
                                            <td><input type="text" class="form-control form-control-sm" name="instructions[]" placeholder="Special instructions"></td>
                                            <td><button type="button" class="btn btn-sm btn-link text-danger" onclick="removeRow('row_0')" disabled><i class="ti ti-trash"></i></button></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="ti ti-x me-1"></i>Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save Prescription</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($printData): ?>
<!-- Print Preview Modal (auto-opened) -->
<div class="modal fade" id="printModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="ti ti-prescription me-2"></i>Digital Prescription — <?= htmlspecialchars($printData['rx_number']) ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="rxPrintArea">
                <div style="font-family:'Open Sans',sans-serif;padding:24px 32px;border:2px solid #1e3a5f;border-radius:8px;max-width:680px;margin:0 auto;" id="rxPrintContent">
                    <div style="border-bottom:2px solid #1e3a5f;padding-bottom:14px;margin-bottom:14px;">
                        <div style="display:flex;justify-content:space-between;align-items:flex-start;">
                            <div>
                                <div style="font-size:1.3rem;font-weight:700;color:#1e3a5f;">Rural Health Unit – Rizal</div>
                                <div style="font-size:.85rem;color:#555;">Patient Record Management System (PRMS)</div>
                            </div>
                            <div style="text-align:right;">
                                <div style="font-size:.75rem;color:#888;">RX Number</div>
                                <div style="font-size:1.1rem;font-weight:700;color:#0d6efd;"><?= htmlspecialchars($printData['rx_number']) ?></div>
                                <div style="font-size:.78rem;color:#666;"><?= date('F d, Y', strtotime($printData['prescription_date'])) ?></div>
                            </div>
                        </div>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px;font-size:.88rem;">
                        <div><span style="color:#888;">Patient:</span> <strong><?= htmlspecialchars($printData['patient_name']) ?></strong></div>
                        <div><span style="color:#888;">Patient No.:</span> <?= htmlspecialchars($printData['patient_no']) ?></div>
                        <div><span style="color:#888;">Date of Birth:</span> <?= date('M d, Y', strtotime($printData['date_of_birth'])) ?></div>
                        <div><span style="color:#888;">Gender:</span> <?= htmlspecialchars($printData['gender']) ?></div>
                        <?php if ($printData['diagnosis']): ?><div style="grid-column:span 2;"><span style="color:#888;">Diagnosis:</span> <?= htmlspecialchars($printData['diagnosis']) ?></div><?php endif; ?>
                    </div>
                    <div style="font-size:2rem;font-weight:900;color:#1e3a5f;margin-bottom:10px;font-style:italic;">℞</div>
                    <?php foreach ($printData['items'] as $idx => $item): ?>
                    <div style="margin-bottom:12px;padding:10px;background:#f8f9fa;border-radius:6px;">
                        <div style="font-weight:700;font-size:.95rem;color:#1e3a5f;"><?= ($idx+1) ?>. <?= htmlspecialchars($item['medicine_name']) ?> <?= htmlspecialchars($item['strength'] ?? '') ?></div>
                        <?php if ($item['generic_name']): ?><div style="font-size:.8rem;color:#888;font-style:italic;">(<?= htmlspecialchars($item['generic_name']) ?>)</div><?php endif; ?>
                        <div style="font-size:.88rem;margin-top:4px;color:#333;">
                            <?php if ($item['dosage']): ?>Sig: <?= htmlspecialchars($item['dosage']) ?><?php endif; ?>
                            <?php if ($item['frequency']): ?> &mdash; <?= htmlspecialchars($item['frequency']) ?><?php endif; ?>
                            <?php if ($item['duration']): ?> for <?= htmlspecialchars($item['duration']) ?><?php endif; ?>
                            <?php if ($item['quantity']): ?> &mdash; Qty: <?= $item['quantity'] ?><?php endif; ?>
                        </div>
                        <?php if ($item['instructions']): ?><div style="font-size:.82rem;color:#666;margin-top:3px;"><em><?= htmlspecialchars($item['instructions']) ?></em></div><?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                    <?php if ($printData['notes']): ?><div style="margin-top:12px;padding:10px;background:#fff3e0;border-radius:6px;font-size:.85rem;"><strong>Notes:</strong> <?= htmlspecialchars($printData['notes']) ?></div><?php endif; ?>
                    <div style="margin-top:24px;display:flex;justify-content:flex-end;">
                        <div style="text-align:center;">
                            <div style="border-top:1px solid #333;padding-top:6px;min-width:180px;">
                                <div style="font-weight:600;"><?= htmlspecialchars($printData['prescribed_by_name']) ?></div>
                                <div style="font-size:.78rem;color:#666;"><?= ucfirst($printData['role']) ?>, RHU Rizal</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="printRX()"><i class="ti ti-printer me-1"></i>Print / Save PDF</button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php
$medOptionsHTML = '';
foreach ($medicines as $m) {
    $label = htmlspecialchars($m['medicine_name'] . ($m['strength'] ? ' ' . $m['strength'] : ''));
    $medOptionsHTML .= "<option value=\"{$m['id']}\">$label</option>";
}
$extraJS='<script>
let rowCount=1;
const medOptions=`<?= addslashes($medOptionsHTML) ?>`;
function openAddRxModal(){ rowCount=1; new bootstrap.Modal(document.getElementById("rxModal")).show(); }
function addMedicineRow(){
    const id="row_"+rowCount;
    const tr=document.createElement("tr");
    tr.id=id;
    tr.innerHTML=`
    <td><select class="form-select form-select-sm" name="medicine_id[]" required><option value="">Select</option>${medOptions}</select></td>
    <td><input type="text" class="form-control form-control-sm" name="dosage[]" placeholder="e.g. 1 tab"></td>
    <td><select class="form-select form-select-sm" name="frequency[]"><option value="">Select</option><option>Once daily</option><option>Twice daily</option><option>3x a day</option><option>4x a day</option><option>Every 6 hours</option><option>Every 8 hours</option><option>Every 12 hours</option><option>As needed (PRN)</option><option>Once</option></select></td>
    <td><input type="text" class="form-control form-control-sm" name="duration[]" placeholder="e.g. 7 days"></td>
    <td><input type="number" class="form-control form-control-sm" name="quantity[]" min="0" placeholder="0"></td>
    <td><input type="text" class="form-control form-control-sm" name="instructions[]" placeholder="Special instructions"></td>
    <td><button type="button" class="btn btn-sm btn-link text-danger" onclick="removeRow(\'${id}\')"><i class="ti ti-trash"></i></button></td>`;
    document.getElementById("rxItems").appendChild(tr);
    rowCount++;
}
function removeRow(id){
    const el=document.getElementById(id);
    if(el) el.remove();
}
' . ($printData ? 'window.addEventListener("load",function(){ new bootstrap.Modal(document.getElementById("printModal")).show(); });' : '') . '
function printRX(){
    const content=document.getElementById("rxPrintContent").innerHTML;
    const w=window.open("","_blank","width=800,height=700");
    w.document.write(`<!DOCTYPE html><html><head><title>Prescription</title><style>body{font-family:Open Sans,sans-serif;margin:32px;}@media print{body{margin:0;}}</style></head><body>${content}</body></html>`);
    w.document.close();
    w.focus();
    setTimeout(()=>w.print(),500);
}
</script>';
include __DIR__ . '/../../includes/layout_footer.php';
?>
