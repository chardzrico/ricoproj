<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();

$conn = getDBConnection();
$msg = '';

// Handle DELETE
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $conn->query("DELETE FROM checkups WHERE id=".(int)$_GET['delete']);
    header('Location: record_vitals.php?msg=deleted');
    exit;
}

// Handle ADD/EDIT
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id         = (int)($_POST['id'] ?? 0);
    $patient_id = (int)$_POST['patient_id'];
    $date       = $_POST['checkup_date'] ?? date('Y-m-d');
    $time       = $_POST['checkup_time'] ?? '';
    $bp         = trim($_POST['blood_pressure'] ?? '');
    $temp       = $_POST['temperature'] ?? null;
    $pulse      = $_POST['pulse_rate'] ?? null;
    $rr         = $_POST['respiratory_rate'] ?? null;
    $weight     = $_POST['weight'] ?? null;
    $height     = $_POST['height'] ?? null;
    $spo2       = trim($_POST['oxygen_saturation'] ?? '');
    $complaint  = trim($_POST['chief_complaint'] ?? '');
    $staff_id   = getCurrentUser()['id'];

    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE checkups SET patient_id=?,checkup_date=?,checkup_time=?,blood_pressure=?,temperature=?,pulse_rate=?,respiratory_rate=?,weight=?,height=?,oxygen_saturation=?,chief_complaint=?,attending_staff=? WHERE id=?");
        $stmt->bind_param('isssdiidd ssii',$patient_id,$date,$time,$bp,$temp,$pulse,$rr,$weight,$height,$spo2,$complaint,$staff_id,$id);
    } else {
        $stmt = $conn->prepare("INSERT INTO checkups (patient_id,checkup_date,checkup_time,blood_pressure,temperature,pulse_rate,respiratory_rate,weight,height,oxygen_saturation,chief_complaint,attending_staff) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param('isssdiiddssi',$patient_id,$date,$time,$bp,$temp,$pulse,$rr,$weight,$height,$spo2,$complaint,$staff_id);
    }
    $stmt->execute();
    header('Location: record_vitals.php?msg=' . ($id > 0 ? 'updated' : 'added'));
    exit;
}

// Get patients for dropdown
$patients = [];
$r = $conn->query("SELECT id, patient_no, CONCAT(first_name,' ',last_name) as name FROM patients WHERE status='active'" . doctorScopeSql() . " ORDER BY last_name");
while ($row = $r->fetch_assoc()) $patients[] = $row;

// Get checkups
$checkups = [];
$r = $conn->query("SELECT c.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no, CONCAT(u.full_name) as staff_name FROM checkups c LEFT JOIN patients p ON c.patient_id=p.id LEFT JOIN users u ON c.attending_staff=u.id WHERE 1=1" . doctorScopeSql('p') . " ORDER BY c.checkup_date DESC, c.id DESC LIMIT 100");
while ($row = $r->fetch_assoc()) $checkups[] = $row;
$conn->close();

if (isset($_GET['msg'])) {
    $msgs = ['added'=>'Vitals recorded.','updated'=>'Record updated.','deleted'=>'Record deleted.'];
    $msg = $msgs[$_GET['msg']] ?? '';
}
$pageTitle = 'Record Vitals';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>

<div class="page-header">
    <div class="page-block">
        <div class="row align-items-center">
            <div class="col-md-12">
                <h5 class="m-b-10">Record Vitals</h5>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li>
                    <li class="breadcrumb-item">Checkups</li>
                    <li class="breadcrumb-item active">Record Vitals</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php if ($msg): ?>
<div class="alert alert-success alert-dismissible fade show">
    <i class="ti ti-circle-check me-2"></i><?= htmlspecialchars($msg) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0"><i class="ti ti-heart-rate me-2" style="color:#0d6efd;"></i>Vital Signs Records</h6>
        <button class="btn btn-primary btn-sm" onclick="openAddModal()">
            <i class="ti ti-plus me-1"></i>Record Vitals
        </button>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0">
                <thead>
                    <tr>
                        <th>Patient</th>
                        <th>Date & Time</th>
                        <th>BP</th>
                        <th>Temp (°C)</th>
                        <th>Pulse</th>
                        <th>RR</th>
                        <th>Weight</th>
                        <th>Height</th>
                        <th>SpO2</th>
                        <th>Chief Complaint</th>
                        <th>Staff</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($checkups as $c): ?>
                    <tr>
                        <td>
                            <div class="fw-semibold" style="font-size:.88rem;"><?= htmlspecialchars($c['patient_name']) ?></div>
                            <div class="text-muted" style="font-size:.78rem;"><?= htmlspecialchars($c['patient_no']) ?></div>
                        </td>
                        <td>
                            <div><?= date('M d, Y', strtotime($c['checkup_date'])) ?></div>
                            <div class="text-muted" style="font-size:.78rem;"><?= $c['checkup_time'] ? date('h:i A', strtotime($c['checkup_time'])) : '' ?></div>
                        </td>
                        <td><?= htmlspecialchars($c['blood_pressure'] ?: '—') ?></td>
                        <td><?= $c['temperature'] ? $c['temperature'].'°C' : '—' ?></td>
                        <td><?= $c['pulse_rate'] ? $c['pulse_rate'].' bpm' : '—' ?></td>
                        <td><?= $c['respiratory_rate'] ? $c['respiratory_rate'].'/min' : '—' ?></td>
                        <td><?= $c['weight'] ? $c['weight'].' kg' : '—' ?></td>
                        <td><?= $c['height'] ? $c['height'].' cm' : '—' ?></td>
                        <td><?= htmlspecialchars($c['oxygen_saturation'] ?: '—') ?></td>
                        <td style="max-width:150px;"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= htmlspecialchars($c['chief_complaint']) ?>"><?= htmlspecialchars($c['chief_complaint'] ?: '—') ?></div></td>
                        <td><?= htmlspecialchars($c['staff_name'] ?: '—') ?></td>
                        <td>
                            <button class="btn-edit btn btn-sm me-1" onclick="openEditModal(<?= htmlspecialchars(json_encode($c)) ?>)"><i class="ti ti-edit"></i></button>
                            <button class="btn-delete btn btn-sm" onclick="confirmDelete('record_vitals.php?delete=<?= $c['id'] ?>', 'this record')"><i class="ti ti-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Vitals Modal -->
<div class="modal fade" id="vitalsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="vitalsModalTitle"><i class="ti ti-heart-rate me-2"></i>Record Vitals</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <input type="hidden" name="id" id="vitalsId" value="0">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Patient *</label>
                            <select class="form-select" name="patient_id" id="vPatient" required>
                                <option value="">Select Patient</option>
                                <?php foreach ($patients as $p): ?>
                                <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['patient_no'].' - '.$p['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Date *</label>
                            <input type="date" class="form-control" name="checkup_date" id="vDate" value="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Time</label>
                            <input type="time" class="form-control" name="checkup_time" id="vTime" value="<?= date('H:i') ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Blood Pressure</label>
                            <input type="text" class="form-control" name="blood_pressure" id="vBP" placeholder="e.g. 120/80">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Temperature (°C)</label>
                            <input type="number" step="0.1" class="form-control" name="temperature" id="vTemp" placeholder="36.5">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Pulse Rate (bpm)</label>
                            <input type="number" class="form-control" name="pulse_rate" id="vPulse" placeholder="72">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Respiratory Rate</label>
                            <input type="number" class="form-control" name="respiratory_rate" id="vRR" placeholder="18">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Weight (kg)</label>
                            <input type="number" step="0.1" class="form-control" name="weight" id="vWeight" placeholder="60.0">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Height (cm)</label>
                            <input type="number" step="0.1" class="form-control" name="height" id="vHeight" placeholder="160">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">SpO2</label>
                            <input type="text" class="form-control" name="oxygen_saturation" id="vSpo2" placeholder="e.g. 98%">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Chief Complaint</label>
                            <textarea class="form-control" name="chief_complaint" id="vComplaint" rows="2" placeholder="Patient's chief complaint"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$extraJS = '<script>
function openAddModal() {
    document.getElementById("vitalsModalTitle").innerHTML = \'<i class="ti ti-heart-rate me-2"></i>Record Vitals\';
    document.getElementById("vitalsId").value = "0";
    ["vBP","vTemp","vPulse","vRR","vWeight","vHeight","vSpo2","vComplaint"].forEach(id => document.getElementById(id).value="");
    document.getElementById("vPatient").value="";
    document.getElementById("vDate").value = "'.date('Y-m-d').'";
    document.getElementById("vTime").value = "'.date('H:i').'";

    new bootstrap.Modal(document.getElementById("vitalsModal")).show();
}
function openEditModal(c) {
    document.getElementById("vitalsModalTitle").innerHTML = \'<i class="ti ti-edit me-2"></i>Edit Vitals\';
    document.getElementById("vitalsId").value = c.id;
    document.getElementById("vPatient").value = c.patient_id;
    document.getElementById("vDate").value = c.checkup_date;
    document.getElementById("vTime").value = c.checkup_time || "";
    document.getElementById("vBP").value = c.blood_pressure || "";
    document.getElementById("vTemp").value = c.temperature || "";
    document.getElementById("vPulse").value = c.pulse_rate || "";
    document.getElementById("vRR").value = c.respiratory_rate || "";
    document.getElementById("vWeight").value = c.weight || "";
    document.getElementById("vHeight").value = c.height || "";
    document.getElementById("vSpo2").value = c.oxygen_saturation || "";
    document.getElementById("vComplaint").value = c.chief_complaint || "";
    new bootstrap.Modal(document.getElementById("vitalsModal")).show();
}
</script>';
include __DIR__ . '/../../includes/layout_footer.php';
?>
