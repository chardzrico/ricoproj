<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();

$conn = getDBConnection();
$msg = '';
$uid = getCurrentUser()['id'];

// ── Cancel a referral ────────────────────────────────────────────────────
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $conn->query("UPDATE referrals SET status='cancelled' WHERE id=" . (int)$_GET['delete']);
    header('Location: referrals.php?msg=cancelled'); exit;
}

// ── Admin prints the letter — flips draft -> printed ────────────────────────
if (isset($_GET['mark_printed']) && is_numeric($_GET['mark_printed'])) {
    $rid = (int)$_GET['mark_printed'];
    $stmt = $conn->prepare("UPDATE referrals SET status='printed', printed_by=?, printed_at=NOW() WHERE id=? AND status='draft'");
    $stmt->bind_param('ii', $uid, $rid);
    $stmt->execute();
    $stmt->close();
    header("Location: referrals.php?print=$rid"); exit;
}

// ── Doctor logs that results are back / finishes it out ────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_results'])) {
    $rid    = (int)($_POST['referral_id'] ?? 0);
    $notes  = trim($_POST['result_notes'] ?? '');
    $status = in_array($_POST['status'] ?? '', ['results_in', 'completed'], true) ? $_POST['status'] : 'results_in';
    if ($rid > 0) {
        $stmt = $conn->prepare("UPDATE referrals SET result_notes=?, status=? WHERE id=?");
        $stmt->bind_param('ssi', $notes, $status, $rid);
        $stmt->execute();
        $stmt->close();
    }
    header('Location: referrals.php?msg=results_saved'); exit;
}

// ── Draft a new referral / lab-order letter ─────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_referral'])) {
    $patient_id = (int)($_POST['patient_id'] ?? 0);
    $checkup_id = !empty($_POST['checkup_id']) ? (int)$_POST['checkup_id'] : null;
    $referred_to = trim($_POST['referred_to'] ?? '');
    $tests      = trim($_POST['tests_requested'] ?? '');
    $reason     = trim($_POST['reason'] ?? '');
    $date       = $_POST['referral_date'] ?: date('Y-m-d');

    if ($patient_id <= 0 || $tests === '') {
        header('Location: referrals.php?msg=norecord'); exit;
    }

    $stmt = $conn->prepare("INSERT INTO referrals (patient_id, checkup_id, referred_to, tests_requested, reason, referral_date, drafted_by, status) VALUES (?,?,?,?,?,?,?,'draft')");
    $stmt->bind_param('iissssi', $patient_id, $checkup_id, $referred_to, $tests, $reason, $date, $uid);
    // checkup_id can be NULL — bind_param with 'i' on a null variable still works in mysqli (sends SQL NULL).
    $stmt->execute();
    header('Location: referrals.php?msg=created'); exit;
}

// ── Data ─────────────────────────────────────────────────────────────────
$patients = [];
$r = $conn->query("SELECT id, patient_no, CONCAT(first_name,' ',last_name) as name FROM patients WHERE status='active'" . doctorScopeSql() . " ORDER BY last_name");
while ($row = $r->fetch_assoc()) $patients[] = $row;

// Recent checkups per patient, for the optional "drafted from this consultation" link
$checkupsByPatient = [];
$r = $conn->query("SELECT id, patient_id, checkup_date, chief_complaint FROM checkups ORDER BY checkup_date DESC LIMIT 500");
while ($row = $r->fetch_assoc()) $checkupsByPatient[$row['patient_id']][] = $row;

$referrals = [];
$stmt = $conn->prepare("
    SELECT rf.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no, p.date_of_birth, p.gender,
           u.full_name as drafted_by_name, u.role as drafted_by_role, up.full_name as printed_by_name
    FROM referrals rf
    LEFT JOIN patients p ON rf.patient_id = p.id
    LEFT JOIN users u ON rf.drafted_by = u.id
    LEFT JOIN users up ON rf.printed_by = up.id
    ORDER BY FIELD(rf.status,'draft','printed','results_in') , rf.referral_date DESC, rf.id DESC
    LIMIT 200
");
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $referrals[] = $row;
$stmt->close();

$printData = null;
if (isset($_GET['print']) && is_numeric($_GET['print'])) {
    $rid = (int)$_GET['print'];
    $r = $conn->query("SELECT rf.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no, p.date_of_birth, p.gender, p.address, u.full_name as drafted_by_name, u.role as drafted_by_role FROM referrals rf LEFT JOIN patients p ON rf.patient_id=p.id LEFT JOIN users u ON rf.drafted_by=u.id WHERE rf.id=$rid LIMIT 1");
    $printData = $r->fetch_assoc();
}
$conn->close();

if (isset($_GET['msg'])) {
    $msg = [
        'created'       => 'Referral / lab-order letter drafted.',
        'cancelled'     => 'Referral cancelled.',
        'results_saved' => 'Results logged. Reopen the consultation in Consultation Notes to finish the diagnosis.',
        'norecord'      => null,
    ][$_GET['msg']] ?? '';
}
$errMsg = ($_GET['msg'] ?? '') === 'norecord' ? 'Please select a patient and list at least one test to request.' : null;

$statusMeta = [
    'draft'      => ['label' => 'Draft — not yet printed', 'badge' => 'bg-secondary'],
    'printed'    => ['label' => 'Printed — awaiting results', 'badge' => 'bg-info text-dark'],
    'results_in' => ['label' => 'Results in', 'badge' => 'bg-warning text-dark'],
    'completed'  => ['label' => 'Completed', 'badge' => 'bg-success'],
    'cancelled'  => ['label' => 'Cancelled', 'badge' => 'bg-dark'],
];

$pageTitle = 'Referrals / Lab Orders';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<div class="page-header"><div class="page-block">
    <h5 class="m-b-10">Referral &amp; Lab-Order Letters</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Checkups</li><li class="breadcrumb-item active">Referrals</li></ul>
</div></div>

<?php if ($msg): ?><div class="alert alert-success alert-dismissible fade show"><i class="ti ti-circle-check me-2"></i><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
<?php if ($errMsg): ?><div class="alert alert-danger alert-dismissible fade show"><i class="ti ti-alert-circle me-2"></i><?= htmlspecialchars($errMsg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0"><i class="ti ti-file-description me-2" style="color:#0d6efd;"></i>Referral / Lab-Order Letters</h6>
        <button class="btn btn-primary btn-sm" onclick="openReferralModal()"><i class="ti ti-plus me-1"></i>Draft Referral</button>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0">
                <thead><tr><th>Patient</th><th>Referred To</th><th>Tests / Labs Requested</th><th>Date</th><th>Drafted By</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php foreach ($referrals as $rf): $sm = $statusMeta[$rf['status']] ?? ['label' => ucfirst($rf['status']), 'badge' => 'bg-secondary']; ?>
                    <tr>
                        <td>
                            <div class="fw-semibold" style="font-size:.88rem;"><?= htmlspecialchars($rf['patient_name']) ?></div>
                            <div class="text-muted" style="font-size:.78rem;"><?= htmlspecialchars($rf['patient_no']) ?></div>
                        </td>
                        <td><?= htmlspecialchars($rf['referred_to'] ?: '—') ?></td>
                        <td style="max-width:220px;"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= htmlspecialchars($rf['tests_requested']) ?>"><?= htmlspecialchars($rf['tests_requested']) ?></div></td>
                        <td><?= date('M d, Y', strtotime($rf['referral_date'])) ?></td>
                        <td><?= htmlspecialchars($rf['drafted_by_name'] ?: '—') ?></td>
                        <td><span class="badge <?= $sm['badge'] ?>"><?= htmlspecialchars($sm['label']) ?></span></td>
                        <td>
                            <?php if ($rf['status'] === 'draft'): ?>
                            <a href="?mark_printed=<?= $rf['id'] ?>" class="btn-view btn btn-sm me-1" title="Print (admin) — marks this printed"><i class="ti ti-printer"></i></a>
                            <?php else: ?>
                            <a href="?print=<?= $rf['id'] ?>" class="btn-view btn btn-sm me-1" title="View / Reprint"><i class="ti ti-eye"></i></a>
                            <?php endif; ?>
                            <?php if (in_array($rf['status'], ['printed', 'results_in'], true)): ?>
                            <button class="btn-edit btn btn-sm me-1" title="Log results / finish" onclick='openResultsModal(<?= htmlspecialchars(json_encode($rf), ENT_QUOTES) ?>)'><i class="ti ti-flask"></i></button>
                            <?php endif; ?>
                            <?php if (!in_array($rf['status'], ['completed', 'cancelled'], true)): ?>
                            <button class="btn-delete btn btn-sm" title="Cancel" onclick="confirmDelete('referrals.php?delete=<?= $rf['id'] ?>','this referral')"><i class="ti ti-x"></i></button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($referrals)): ?><tr><td colspan="7" class="text-center text-muted py-4">No referral letters yet.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ══ Draft Referral Modal ══ -->
<div class="modal fade" id="referralModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" action="referrals.php">
                <input type="hidden" name="save_referral" value="1">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="ti ti-file-description me-2"></i>Draft Referral / Lab-Order Letter</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p class="text-muted" style="font-size:.85rem;">Optional — not every visit needs one. List the tests to be done elsewhere; once results are back, pull the patient up in Consultation Notes to finish the diagnosis.</p>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Patient *</label>
                            <select class="form-select" name="patient_id" id="rfPatient" required onchange="populateCheckupOptions()">
                                <option value="">Select patient…</option>
                                <?php foreach ($patients as $p): ?>
                                <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['patient_no'] . ' - ' . $p['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">From Consultation (optional)</label>
                            <select class="form-select" name="checkup_id" id="rfCheckup">
                                <option value="">— None —</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Referred To</label>
                            <input type="text" class="form-control" name="referred_to" placeholder="e.g. Rizal Provincial Hospital — Laboratory">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Date *</label>
                            <input type="date" class="form-control" name="referral_date" value="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Tests / Labs Requested *</label>
                            <textarea class="form-control" name="tests_requested" rows="3" placeholder="e.g. CBC, Urinalysis, Chest X-ray" required></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Reason / Clinical Notes</label>
                            <textarea class="form-control" name="reason" rows="2" placeholder="Brief reason for the referral (optional)"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save Draft</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ══ Log Results Modal ══ -->
<div class="modal fade" id="resultsModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="referrals.php">
                <input type="hidden" name="update_results" value="1">
                <input type="hidden" name="referral_id" id="resReferralId">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="ti ti-flask me-2"></i>Log Results — <span id="resPatientName"></span></h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Result Notes</label>
                        <textarea class="form-control" name="result_notes" id="resNotes" rows="4" placeholder="Lab results / findings summary"></textarea>
                    </div>
                    <div class="mb-1">
                        <label class="form-label">Status</label>
                        <select class="form-select" name="status" id="resStatus">
                            <option value="results_in">Results In — awaiting doctor review</option>
                            <option value="completed">Completed — diagnosis finished</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($printData): ?>
<!-- Print Preview Modal (auto-opened) -->
<div class="modal fade" id="printModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="ti ti-file-description me-2"></i>Referral Letter</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div style="font-family:'Open Sans',sans-serif;padding:24px 32px;border:2px solid #1e3a5f;border-radius:8px;max-width:680px;margin:0 auto;" id="rfPrintContent">
                    <div style="border-bottom:2px solid #1e3a5f;padding-bottom:14px;margin-bottom:14px;">
                        <div style="display:flex;justify-content:space-between;align-items:flex-start;">
                            <div>
                                <div style="font-size:1.3rem;font-weight:700;color:#1e3a5f;">Rural Health Unit – Rizal</div>
                                <div style="font-size:.85rem;color:#555;">Referral / Laboratory-Order Letter</div>
                            </div>
                            <div style="text-align:right;">
                                <div style="font-size:.78rem;color:#666;"><?= date('F d, Y', strtotime($printData['referral_date'])) ?></div>
                            </div>
                        </div>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px;font-size:.88rem;">
                        <div><span style="color:#888;">Patient:</span> <strong><?= htmlspecialchars($printData['patient_name']) ?></strong></div>
                        <div><span style="color:#888;">Patient No.:</span> <?= htmlspecialchars($printData['patient_no']) ?></div>
                        <div><span style="color:#888;">Date of Birth:</span> <?= $printData['date_of_birth'] ? date('M d, Y', strtotime($printData['date_of_birth'])) : '—' ?></div>
                        <div><span style="color:#888;">Gender:</span> <?= htmlspecialchars($printData['gender'] ?? '') ?></div>
                        <?php if ($printData['referred_to']): ?><div style="grid-column:span 2;"><span style="color:#888;">Referred To:</span> <?= htmlspecialchars($printData['referred_to']) ?></div><?php endif; ?>
                    </div>
                    <div style="margin-bottom:12px;padding:10px;background:#f8f9fa;border-radius:6px;">
                        <div style="font-weight:700;font-size:.9rem;color:#1e3a5f;margin-bottom:4px;">Tests / Labs Requested</div>
                        <div style="white-space:pre-wrap;font-size:.9rem;"><?= htmlspecialchars($printData['tests_requested']) ?></div>
                    </div>
                    <?php if ($printData['reason']): ?><div style="margin-bottom:12px;font-size:.85rem;"><strong>Reason:</strong> <?= htmlspecialchars($printData['reason']) ?></div><?php endif; ?>
                    <div style="margin-top:24px;display:flex;justify-content:flex-end;">
                        <div style="text-align:center;">
                            <div style="border-top:1px solid #333;padding-top:6px;min-width:180px;">
                                <div style="font-weight:600;"><?= htmlspecialchars($printData['drafted_by_name'] ?? '') ?></div>
                                <div style="font-size:.78rem;color:#666;"><?= ucfirst($printData['drafted_by_role'] ?? '') ?>, RHU Rizal</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="printReferral()"><i class="ti ti-printer me-1"></i>Print / Save PDF</button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php
$checkupsJson = json_encode($checkupsByPatient);
$extraJS = '
<script>
const CHECKUPS_BY_PATIENT = ' . $checkupsJson . ';
function openReferralModal() { new bootstrap.Modal(document.getElementById("referralModal")).show(); }
function populateCheckupOptions() {
    const pid = document.getElementById("rfPatient").value;
    const sel = document.getElementById("rfCheckup");
    sel.innerHTML = \'<option value="">— None —</option>\';
    const list = CHECKUPS_BY_PATIENT[pid] || [];
    list.forEach(c => {
        const opt = document.createElement("option");
        opt.value = c.id;
        opt.textContent = c.checkup_date + (c.chief_complaint ? " — " + c.chief_complaint : "");
        sel.appendChild(opt);
    });
}
function openResultsModal(rf) {
    document.getElementById("resReferralId").value = rf.id;
    document.getElementById("resPatientName").textContent = rf.patient_name || "";
    document.getElementById("resNotes").value = rf.result_notes || "";
    document.getElementById("resStatus").value = rf.status === "results_in" ? "completed" : "results_in";
    new bootstrap.Modal(document.getElementById("resultsModal")).show();
}
' . ($printData ? 'window.addEventListener("load",function(){ new bootstrap.Modal(document.getElementById("printModal")).show(); });' : '') . '
function printReferral() {
    const content = document.getElementById("rfPrintContent").innerHTML;
    const w = window.open("", "_blank", "width=800,height=700");
    w.document.write(`<!DOCTYPE html><html><head><title>Referral Letter</title><style>body{font-family:Open Sans,sans-serif;margin:32px;}@media print{body{margin:0;}}</style></head><body>${content}</body></html>`);
    w.document.close();
    w.focus();
    setTimeout(()=>w.print(),500);
}
</script>';
include __DIR__ . '/../../includes/layout_footer.php';
?>
