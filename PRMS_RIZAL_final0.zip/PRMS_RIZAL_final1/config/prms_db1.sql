-- PRMS Database Setup
-- Patient Record Management System for Rural Health Unit, Rizal

CREATE DATABASE IF NOT EXISTS prms_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE prms_db;

-- Users table (login/register)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'doctor', 'nurse', 'staff', 'patient') DEFAULT 'staff',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Patients table
CREATE TABLE IF NOT EXISTS patients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNIQUE NULL COMMENT 'linked login account for self-registered patients',
    patient_no VARCHAR(20) UNIQUE NOT NULL,
    folder_number VARCHAR(50) NULL COMMENT 'ITR Folder Number',
    tn_number VARCHAR(50) NULL COMMENT 'ITR TN #',
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100),
    date_of_birth DATE NULL,
    estimated_age INT NULL COMMENT 'used when date_of_birth is unknown',
    is_dob_estimated TINYINT(1) NOT NULL DEFAULT 0 COMMENT '1 if date_of_birth is unknown/approximate',
    gender ENUM('Male', 'Female') NOT NULL,
    address TEXT,
    contact_number VARCHAR(20),
    guardian_name VARCHAR(150),
    guardian_contact VARCHAR(20),
    blood_type VARCHAR(5),
    religion VARCHAR(100),
    civil_status VARCHAR(50),
    occupation VARCHAR(100),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Checkups / Consultations
CREATE TABLE IF NOT EXISTS checkups (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    checkup_date DATE NOT NULL,
    checkup_time TIME,
    mode_of_transaction ENUM('Walk-in','Visited','Referral') NULL,
    nature_of_visit ENUM('New Consultation','New Admission','Follow-up Visit') NULL,
    age_at_visit INT NULL COMMENT 'Age at time of visit, per ITR Age/sex field',
    sex_at_visit ENUM('Male','Female') NULL COMMENT 'Sex at time of visit, per ITR Age/sex field',
    attending_staff INT,
    blood_pressure VARCHAR(20),
    temperature DECIMAL(5,2),
    pulse_rate INT,
    respiratory_rate INT,
    weight DECIMAL(5,2),
    height DECIMAL(5,2),
    oxygen_saturation VARCHAR(10),
    chief_complaint TEXT,
    history_of_illness TEXT COMMENT 'History Of Patient Illness',
    past_medical_family_history TEXT,
    pertinent_pe TEXT COMMENT 'Pertinent P.E.',
    consultation_notes TEXT,
    diagnosis TEXT,
    treatment_plan TEXT,
    laboratory_findings TEXT COMMENT 'Laboratory Findings/Impression',
    follow_up_date DATE,
    status ENUM('draft', 'pending', 'completed', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (attending_staff) REFERENCES users(id) ON DELETE SET NULL
);

-- Patient History
CREATE TABLE IF NOT EXISTS patient_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    history_type VARCHAR(100),
    description TEXT,
    recorded_by INT,
    record_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (recorded_by) REFERENCES users(id) ON DELETE SET NULL
);

-- Services
CREATE TABLE IF NOT EXISTS services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    service_name VARCHAR(150) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    fee DECIMAL(10,2) DEFAULT 0.00,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Clinical Services seed data: the 4 main categories with their known
-- sub-services. Mental has none yet — add more from the Clinical
-- Services page in the app.
INSERT INTO services (service_name, category) VALUES
    ('Prenatal Service', 'Medical'),
    ('Checkup', 'Medical'),
    ('Tooth Removal', 'Dental'),
    ('Medico-Legal Examination', 'Physical');

-- Patient Services
CREATE TABLE IF NOT EXISTS patient_services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    service_id INT NOT NULL,
    service_date DATE,
    administered_by INT,
    notes TEXT,
    injury_map LONGTEXT NULL, -- Medico-Legal Examination body-diagram findings (JSON), see migration_medicolegal.sql
    odontogram LONGTEXT NULL, -- Dental odontogram / per-tooth chart (JSON), see migration_capstone_features.sql
    status ENUM('pending', 'done', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE,
    FOREIGN KEY (administered_by) REFERENCES users(id) ON DELETE SET NULL
);

-- Patient Queueing (per service category: Dental, Physical, Mental, Medical)
CREATE TABLE IF NOT EXISTS patient_queue (
    id INT AUTO_INCREMENT PRIMARY KEY,
    queue_no INT NOT NULL,
    patient_id INT NOT NULL,
    category ENUM('Dental','Physical','Mental','Medical') NOT NULL,
    queue_date DATE NOT NULL,
    status ENUM('waiting','serving','done','cancelled') DEFAULT 'waiting',
    time_in TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    time_served TIMESTAMP NULL,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
);

-- Appointment Requests (submitted by patients via the patient portal, actioned by staff)
CREATE TABLE IF NOT EXISTS appointments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    service_id INT NULL,
    category ENUM('Dental','Physical','Mental','Medical') NOT NULL,
    preferred_date DATE NOT NULL,
    preferred_time TIME NULL,
    reason TEXT,
    status ENUM('pending','approved','rejected','completed','cancelled') DEFAULT 'pending',
    scheduled_date DATE NULL,
    scheduled_time TIME NULL,
    staff_notes TEXT,
    handled_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE SET NULL,
    FOREIGN KEY (handled_by) REFERENCES users(id) ON DELETE SET NULL
);

-- Vaccines
CREATE TABLE IF NOT EXISTS vaccines (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vaccine_name VARCHAR(150) NOT NULL,
    manufacturer VARCHAR(150),
    description TEXT,
    doses_required INT DEFAULT 1,
    interval_days INT,
    target_age_min INT COMMENT 'in months',
    target_age_max INT COMMENT 'in months',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Immunization Records
CREATE TABLE IF NOT EXISTS immunization_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    vaccine_id INT NOT NULL,
    dose_number INT DEFAULT 1,
    date_given DATE NOT NULL,
    next_dose_date DATE,
    administered_by INT,
    batch_number VARCHAR(100),
    site VARCHAR(100),
    remarks TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (vaccine_id) REFERENCES vaccines(id) ON DELETE CASCADE,
    FOREIGN KEY (administered_by) REFERENCES users(id) ON DELETE SET NULL
);

-- Nutritional Status (Growth Records)
CREATE TABLE IF NOT EXISTS nutritional_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    record_date DATE NOT NULL,
    age_months INT,
    weight DECIMAL(5,2) COMMENT 'kg',
    height DECIMAL(5,2) COMMENT 'cm',
    bmi DECIMAL(5,2),
    weight_for_age VARCHAR(50) COMMENT 'normal/underweight/overweight',
    height_for_age VARCHAR(50) COMMENT 'normal/stunted/tall',
    weight_for_height VARCHAR(50) COMMENT 'normal/wasted/obese',
    nutritional_status VARCHAR(100),
    remarks TEXT,
    recorded_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (recorded_by) REFERENCES users(id) ON DELETE SET NULL
);

-- Medicines
CREATE TABLE IF NOT EXISTS medicines (
    id INT AUTO_INCREMENT PRIMARY KEY,
    medicine_name VARCHAR(150) NOT NULL,
    generic_name VARCHAR(150),
    category VARCHAR(100),
    dosage_form VARCHAR(100) COMMENT 'tablet, capsule, syrup, etc',
    strength VARCHAR(100),
    stock_quantity INT DEFAULT 0,
    unit VARCHAR(50),
    expiry_date DATE,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Prescriptions
CREATE TABLE IF NOT EXISTS prescriptions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rx_number VARCHAR(50) UNIQUE NOT NULL,
    patient_id INT NOT NULL,
    prescribed_by INT,
    prescription_date DATE NOT NULL,
    diagnosis TEXT,
    notes TEXT,
    status ENUM('active', 'dispensed', 'cancelled') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (prescribed_by) REFERENCES users(id) ON DELETE SET NULL
);

-- Prescription Items
CREATE TABLE IF NOT EXISTS prescription_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    prescription_id INT NOT NULL,
    medicine_id INT NOT NULL,
    dosage VARCHAR(100),
    frequency VARCHAR(100),
    duration VARCHAR(100),
    quantity INT,
    instructions TEXT,
    FOREIGN KEY (prescription_id) REFERENCES prescriptions(id) ON DELETE CASCADE,
    FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE CASCADE
);

-- Maintenance / Follow-ups
CREATE TABLE IF NOT EXISTS maintenance_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    maintenance_type VARCHAR(150) COMMENT 'hypertension, diabetes, etc',
    last_visit DATE,
    next_visit DATE,
    current_medications TEXT,
    lab_results TEXT,
    notes TEXT,
    managed_by INT,
    status ENUM('active', 'closed') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (managed_by) REFERENCES users(id) ON DELETE SET NULL
);

-- Default Admin User (password: Admin@1234)
INSERT IGNORE INTO users (full_name, username, email, password, role)
VALUES (
    'System Administrator',
    'admin',
    'admin@prms.gov.ph',
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- password: password
    'admin'
);

-- Default Vaccines
INSERT IGNORE INTO vaccines (vaccine_name, manufacturer, doses_required, interval_days, target_age_min, target_age_max) VALUES
('BCG', 'WHO', 1, 0, 0, 1),
('Hepatitis B', 'WHO', 3, 28, 0, 24),
('DPT-HepB-Hib', 'WHO', 3, 28, 6, 18),
('OPV (Oral Polio Vaccine)', 'WHO', 4, 28, 6, 18),
('IPV (Inactivated Polio Vaccine)', 'WHO', 2, 28, 14, 18),
('PCV (Pneumococcal Conjugate Vaccine)', 'WHO', 3, 28, 6, 15),
('MMR (Measles-Mumps-Rubella)', 'WHO', 2, 90, 12, 72),
('Varicella', 'WHO', 2, 90, 12, 72),
('HPV', 'WHO', 2, 180, 108, 156),
('Influenza', 'WHO', 1, 365, 6, 999);

-- Default Services (grouped by category: Dental, Physical, Mental, Medical)
INSERT IGNORE INTO services (service_name, description, category, fee) VALUES
-- Dental
('Dental Check-up', 'Routine oral examination and assessment', 'Dental', 0.00),
('Tooth Extraction', 'Removal of decayed or damaged tooth', 'Dental', 0.00),
('Oral Prophylaxis (Teeth Cleaning)', 'Removal of plaque and tartar buildup', 'Dental', 0.00),
('Dental Filling', 'Restoration of decayed tooth structure', 'Dental', 0.00),

-- Physical
('Physical Examination', 'General physical assessment and vital signs check', 'Physical', 0.00),
('Blood Pressure Monitoring', 'Routine blood pressure check-up', 'Physical', 0.00),
('Physical Therapy / Rehabilitation', 'Exercise-based treatment for mobility and recovery', 'Physical', 0.00),
('Wound Care / Dressing', 'Cleaning and dressing of wounds', 'Physical', 0.00),

-- Mental
('Mental Health Consultation', 'Initial assessment of mental and emotional well-being', 'Mental', 0.00),
('Individual Counseling Session', 'One-on-one psychosocial counseling', 'Mental', 0.00),
('Stress Management Session', 'Guidance and coping strategies for stress', 'Mental', 0.00),

-- Medical
('General Consultation', 'General medical consultation with a health worker', 'Medical', 0.00),
('Check-up', 'Routine medical check-up', 'Medical', 0.00),
('Prenatal Check-up', 'Regular check-up for pregnant patients', 'Medical', 0.00),
('Family Planning Counseling', 'Guidance on family planning methods', 'Medical', 0.00),
('Blood Sugar Testing', 'Screening for blood glucose levels', 'Medical', 0.00),
('Urinalysis', 'Laboratory examination of urine sample', 'Medical', 0.00),
('Tuberculosis (TB) DOTS', 'Directly Observed Treatment, Short-course for TB patients', 'Medical', 0.00),
('Deworming', 'Preventive deworming service', 'Medical', 0.00);
