-- ============================================================
-- PRMS Migration: Draft status for Consultation (ITR) entries
-- Lets a doctor save a consultation mid-encounter and resume it
-- later, instead of losing the work or forcing an incomplete
-- record to look "completed".
-- Run this once against an EXISTING prms_db database.
-- (Fresh installs already get this via prms_db1.sql)
-- ============================================================
USE prms_db;

ALTER TABLE checkups
    MODIFY COLUMN status ENUM('draft','pending','completed','cancelled') NOT NULL DEFAULT 'pending';
