-- ============================================================
-- PRMS Migration: Medico-Legal body diagram findings
-- Adds a column on patient_services to store the injury markers
-- (location on a front/back body diagram + description) recorded
-- during a Medico-Legal Examination. Stored as a JSON array, e.g.:
--   [{"view":"front","x":42.5,"y":18.2,"zone":"Head","note":"3.5cm x 4.5cm red bruise with tenderness"}, ...]
-- Safe to re-run: only adds the column if it isn't already there.
-- ============================================================
USE prms_db;

SET @col_exists := (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'patient_services'
      AND COLUMN_NAME = 'injury_map'
);
SET @sql := IF(@col_exists = 0,
    'ALTER TABLE patient_services ADD COLUMN injury_map LONGTEXT NULL AFTER notes',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
