-- ============================================================
-- PRMS Migration: Clinical Services seed data
-- Populates the existing `services` table with the 4 main
-- service categories (Medical, Dental, Mental, Physical) and
-- their known sub-services. Categories match the ENUM already
-- used by patient_queue.category / appointments.category.
-- Safe to re-run: skips rows that already exist by name.
-- ============================================================
USE prms_db;

INSERT INTO services (service_name, category, status)
SELECT * FROM (SELECT 'Prenatal Service' AS service_name, 'Medical' AS category, 'active' AS status) t
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Prenatal Service' AND category = 'Medical');

INSERT INTO services (service_name, category, status)
SELECT * FROM (SELECT 'Checkup', 'Medical', 'active') t
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Checkup' AND category = 'Medical');

INSERT INTO services (service_name, category, status)
SELECT * FROM (SELECT 'Tooth Removal', 'Dental', 'active') t
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Tooth Removal' AND category = 'Dental');

INSERT INTO services (service_name, category, status)
SELECT * FROM (SELECT 'Medico-Legal Examination', 'Physical', 'active') t
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Medico-Legal Examination' AND category = 'Physical');

-- Mental has no confirmed sub-services yet — add them from the
-- Clinical Services page (each category page has an "Add Sub-Service"
-- button), or extend this file and re-run it.
