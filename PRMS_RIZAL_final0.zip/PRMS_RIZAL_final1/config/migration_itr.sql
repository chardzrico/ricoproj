-- ============================================================
-- PRMS Migration: Individual Treatment Record (ITR) support
-- Run this once against an EXISTING prms_db database.
-- (Fresh installs already get this via prms_db1.sql)
-- ============================================================
USE prms_db;

-- 1) Patients: Folder Number / TN# from the ITR header, and allow
--    an estimated age when Date of Birth is unknown (common for
--    indigenous/IP patients such as Ita/Aeta where DOB is not recorded).
ALTER TABLE patients
    MODIFY COLUMN date_of_birth DATE NULL,
    ADD COLUMN folder_number VARCHAR(50) NULL COMMENT 'ITR Folder Number' AFTER patient_no,
    ADD COLUMN tn_number VARCHAR(50) NULL COMMENT 'ITR TN #' AFTER folder_number,
    ADD COLUMN estimated_age INT NULL COMMENT 'used when date_of_birth is unknown' AFTER date_of_birth,
    ADD COLUMN is_dob_estimated TINYINT(1) NOT NULL DEFAULT 0 COMMENT '1 if date_of_birth is unknown/approximate' AFTER estimated_age;

-- 2) Checkups: additional fields to match the paper ITR form exactly,
--    so a consultation can be encoded as a single continuous record
--    (Mode of Transaction, Nature of Visit, History of Illness,
--    Past Medical/Family History, Pertinent P.E., Laboratory Findings).
ALTER TABLE checkups
    ADD COLUMN mode_of_transaction ENUM('Walk-in','Visited','Referral') NULL AFTER checkup_time,
    ADD COLUMN nature_of_visit ENUM('New Consultation','New Admission','Follow-up Visit') NULL AFTER mode_of_transaction,
    ADD COLUMN age_at_visit INT NULL COMMENT 'Age at time of visit, per ITR Age/sex field' AFTER nature_of_visit,
    ADD COLUMN sex_at_visit ENUM('Male','Female') NULL COMMENT 'Sex at time of visit, per ITR Age/sex field' AFTER age_at_visit,
    ADD COLUMN history_of_illness TEXT NULL COMMENT 'History Of Patient Illness' AFTER chief_complaint,
    ADD COLUMN past_medical_family_history TEXT NULL AFTER history_of_illness,
    ADD COLUMN pertinent_pe TEXT NULL COMMENT 'Pertinent P.E.' AFTER past_medical_family_history,
    ADD COLUMN laboratory_findings TEXT NULL COMMENT 'Laboratory Findings/Impression' AFTER treatment_plan;
