-- ============================================================
-- PRMS Migration: Capstone feature set (2026)
--   1. Medico-legal linked injuries (entry/exit) — no new columns,
--      injury_map JSON structure gains an optional "marks" array
--      per finding (handled in application code).
--   2. Doctor assignment — patients.assigned_doctor_id
--   3. Patient History "previous consultation" index — no schema change
--   4. Family History rename — no schema change (label only)
--   5. Referral / lab-order letters — new `referrals` table
--   6. Prescription hand-off tracking — prescriptions.printed_at/printed_by
--   7. Follow-up scheduling moved to admin — checkups.needs_follow_up
-- Safe to re-run: every statement checks INFORMATION_SCHEMA first.
-- ============================================================
USE prms_db;

-- ── 2. Doctor assignment ────────────────────────────────────────────────
SET @col_exists := (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'patients' AND COLUMN_NAME = 'assigned_doctor_id'
);
SET @sql := IF(@col_exists = 0,
    'ALTER TABLE patients ADD COLUMN assigned_doctor_id INT NULL AFTER user_id, ADD CONSTRAINT fk_patients_assigned_doctor FOREIGN KEY (assigned_doctor_id) REFERENCES users(id) ON DELETE SET NULL',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ── 7. Follow-up scheduling flag (doctor flags; admin schedules it) ────────
SET @col_exists := (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'checkups' AND COLUMN_NAME = 'needs_follow_up'
);
SET @sql := IF(@col_exists = 0,
    'ALTER TABLE checkups ADD COLUMN needs_follow_up TINYINT(1) NOT NULL DEFAULT 0 AFTER follow_up_date',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ── 6. Prescription hand-off (doctor writes -> admin prints) ──────────────
SET @col_exists := (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'prescriptions' AND COLUMN_NAME = 'printed_at'
);
SET @sql := IF(@col_exists = 0,
    'ALTER TABLE prescriptions ADD COLUMN printed_at TIMESTAMP NULL AFTER status, ADD COLUMN printed_by INT NULL AFTER printed_at, ADD CONSTRAINT fk_prescriptions_printed_by FOREIGN KEY (printed_by) REFERENCES users(id) ON DELETE SET NULL',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ── 5. Referral / lab-order letters ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS referrals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    checkup_id INT NULL COMMENT 'the consultation this referral was drafted from, if any',
    referred_to VARCHAR(200) NULL COMMENT 'facility / specialist the patient is being referred to',
    tests_requested TEXT NOT NULL COMMENT 'tests/labs to be done elsewhere',
    reason TEXT NULL,
    referral_date DATE NOT NULL,
    status ENUM('draft','printed','results_in','completed','cancelled') DEFAULT 'draft',
    result_notes TEXT NULL COMMENT 'filled in once the doctor pulls the patient back up to finish the diagnosis',
    drafted_by INT NULL,
    printed_by INT NULL,
    printed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (checkup_id) REFERENCES checkups(id) ON DELETE SET NULL,
    FOREIGN KEY (drafted_by) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (printed_by) REFERENCES users(id) ON DELETE SET NULL
);

-- ── Dental odontogram (per-tooth chart) ─────────────────────────────────
SET @col_exists := (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'patient_services' AND COLUMN_NAME = 'odontogram'
);
SET @sql := IF(@col_exists = 0,
    'ALTER TABLE patient_services ADD COLUMN odontogram LONGTEXT NULL AFTER injury_map',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
