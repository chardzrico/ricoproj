-- ============================================================
-- PRMS Migration: Patient Self-Registration + Appointments
-- Run this once against an EXISTING prms_db database.
-- (Fresh installs already get this via prms_db1.sql)
-- ============================================================
USE prms_db;

-- 1) Allow a 'patient' role on the users table
ALTER TABLE users
    MODIFY COLUMN role ENUM('admin', 'doctor', 'nurse', 'staff', 'patient') DEFAULT 'staff';

-- 2) Link a patient record to an optional login account
ALTER TABLE patients
    ADD COLUMN user_id INT UNIQUE NULL COMMENT 'linked login account for self-registered patients' AFTER id,
    ADD CONSTRAINT fk_patients_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL;

-- 3) Appointment requests (patient-submitted, staff-actioned)
CREATE TABLE IF NOT EXISTS appointments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    service_id INT NULL,
    category ENUM('Dental','Physical','Mental','Medical') NOT NULL,
    preferred_date DATE NOT NULL,
    preferred_time TIME NULL,
    reason TEXT,
    status ENUM('pending','approved','rejected','completed','cancelled') DEFAULT 'pending',
    scheduled_date DATE NULL,
    scheduled_time TIME NULL,
    staff_notes TEXT,
    handled_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE SET NULL,
    FOREIGN KEY (handled_by) REFERENCES users(id) ON DELETE SET NULL
);
