<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';
requirePatientOnly();

$conn = getDBConnection();
$currentUser = getCurrentUser();

$stmt = $conn->prepare("SELECT * FROM patients WHERE user_id = ? LIMIT 1");
$stmt->bind_param('i', $currentUser['id']);
$stmt->execute();
$patient = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$patient) {
    $conn->close();
    header('Location: ' . BASE_URL . '/patient/portal.php');
    exit;
}
$patientId = (int)$patient['id'];

// ── Fetch this patient's prescriptions ──────────────────────────────────────
$prescriptions = [];
$stmt = $conn->prepare("
    SELECT pr.*, u.full_name as prescribed_by_name
    FROM prescriptions pr
    LEFT JOIN users u ON u.id = pr.prescribed_by
    WHERE pr.patient_id = ?
    ORDER BY pr.prescription_date DESC, pr.id DESC
");
$stmt->bind_param('i', $patientId);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $prescriptions[] = $row;
$stmt->close();

// ── Fetch items for all of them in one go, grouped by prescription_id ───────
$itemsByRx = [];
if (!empty($prescriptions)) {
    $ids = array_column($prescriptions, 'id');
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $types = str_repeat('i', count($ids));
    $stmt = $conn->prepare("
        SELECT pi.*, m.medicine_name, m.generic_name, m.dosage_form, m.strength
        FROM prescription_items pi
        JOIN medicines m ON m.id = pi.medicine_id
        WHERE pi.prescription_id IN ($placeholders)
    ");
    $stmt->bind_param($types, ...$ids);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $itemsByRx[$row['prescription_id']][] = $row;
    }
    $stmt->close();
}

$conn->close();

$pageTitle = 'My Prescriptions';
include __DIR__ . '/includes/patient_header.php';
include __DIR__ . '/../includes/topbar.php';

$statusBadge = [
    'active'    => 'bg-success',
    'dispensed' => 'bg-primary',
    'cancelled' => 'bg-secondary',
];
?>

<!-- ══ Breadcrumb ══ -->
<div class="page-header">
    <div class="page-block">
        <div class="row align-items-center">
            <div class="col-md-12">
                <h5 class="m-b-10">My Prescriptions</h5>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/patient/portal.php">Home</a></li>
                    <li class="breadcrumb-item active">My Prescriptions</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="alert d-flex align-items-center gap-2" style="background:#e3f2fd;border:1px solid #bbdefb;color:#1565c0;border-radius:8px;font-size:.85rem;">
    <i class="ti ti-info-circle fs-5"></i>
    <span>This is a record of medicines prescribed to you by RHU Rizal. Always follow your doctor's instructions on dosage and duration &mdash; contact RHU staff if anything here looks unclear.</span>
</div>

<?php if (empty($prescriptions)): ?>
<div class="card">
    <div class="card-body text-center text-muted py-5">
        <i class="ti ti-prescription mb-2" style="font-size:2.5rem;opacity:.3;"></i>
        <div>You have no prescriptions on record yet.</div>
    </div>
</div>
<?php else: foreach ($prescriptions as $rx): ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
        <div>
            <h6 class="section-title mb-1">
                <i class="ti ti-prescription me-2" style="color:#0d6efd;"></i>Rx #<?= htmlspecialchars($rx['rx_number']) ?>
            </h6>
            <div class="text-muted" style="font-size:.82rem;">
                <?= date('M d, Y', strtotime($rx['prescription_date'])) ?>
                &bull; Prescribed by <?= htmlspecialchars($rx['prescribed_by_name'] ?: 'RHU Staff') ?>
            </div>
        </div>
        <span class="badge <?= $statusBadge[$rx['status']] ?? 'bg-secondary' ?> rounded-pill" style="font-size:.78rem;">
            <?= ucfirst($rx['status']) ?>
        </span>
    </div>
    <div class="card-body">
        <?php if (!empty($rx['diagnosis'])): ?>
        <div class="mb-3">
            <div class="text-muted" style="font-size:.78rem;text-transform:uppercase;letter-spacing:.5px;">Diagnosis</div>
            <div style="font-size:.9rem;"><?= htmlspecialchars($rx['diagnosis']) ?></div>
        </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table mb-0" style="font-size:.87rem;">
                <thead>
                    <tr>
                        <th>Medicine</th>
                        <th>Dosage</th>
                        <th>Frequency</th>
                        <th>Duration</th>
                        <th>Qty</th>
                        <th>Instructions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $items = $itemsByRx[$rx['id']] ?? []; ?>
                    <?php if (empty($items)): ?>
                    <tr><td colspan="6" class="text-center text-muted py-3">No medicine items recorded for this prescription.</td></tr>
                    <?php else: foreach ($items as $it): ?>
                    <tr>
                        <td>
                            <div class="fw-semibold"><?= htmlspecialchars($it['medicine_name']) ?></div>
                            <?php if (!empty($it['generic_name'])): ?>
                            <div class="text-muted" style="font-size:.78rem;"><?= htmlspecialchars($it['generic_name']) ?><?= $it['strength'] ? ' &bull; ' . htmlspecialchars($it['strength']) : '' ?></div>
                            <?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($it['dosage'] ?: '—') ?></td>
                        <td><?= htmlspecialchars($it['frequency'] ?: '—') ?></td>
                        <td><?= htmlspecialchars($it['duration'] ?: '—') ?></td>
                        <td><?= htmlspecialchars((string)($it['quantity'] ?? '—')) ?></td>
                        <td><?= htmlspecialchars($it['instructions'] ?: '—') ?></td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>

        <?php if (!empty($rx['notes'])): ?>
        <div class="mt-3 pt-3" style="border-top:1px solid #f0f0f0;">
            <div class="text-muted" style="font-size:.78rem;text-transform:uppercase;letter-spacing:.5px;">Notes</div>
            <div style="font-size:.87rem;"><?= htmlspecialchars($rx['notes']) ?></div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php endforeach; endif; ?>

<?php include __DIR__ . '/../includes/layout_footer.php'; ?>
