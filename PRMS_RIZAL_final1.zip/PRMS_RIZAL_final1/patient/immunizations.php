<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';
requirePatientOnly();

$conn = getDBConnection();
$currentUser = getCurrentUser();

$stmt = $conn->prepare("SELECT * FROM patients WHERE user_id = ? LIMIT 1");
$stmt->bind_param('i', $currentUser['id']);
$stmt->execute();
$patient = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$patient) {
    $conn->close();
    header('Location: ' . BASE_URL . '/patient/portal.php');
    exit;
}
$patientId = (int)$patient['id'];

// ── Fetch immunization records ───────────────────────────────────────────────
$records = [];
$stmt = $conn->prepare("
    SELECT ir.*, v.vaccine_name, v.manufacturer, v.doses_required, u.full_name as administered_by_name
    FROM immunization_records ir
    JOIN vaccines v ON v.id = ir.vaccine_id
    LEFT JOIN users u ON u.id = ir.administered_by
    WHERE ir.patient_id = ?
    ORDER BY ir.date_given DESC, ir.id DESC
");
$stmt->bind_param('i', $patientId);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $records[] = $row;
$stmt->close();

// ── Upcoming doses (next_dose_date in the future, not yet superseded) ───────
$upcoming = array_filter($records, function ($r) {
    return !empty($r['next_dose_date']) && strtotime($r['next_dose_date']) >= strtotime(date('Y-m-d'));
});
usort($upcoming, function ($a, $b) {
    return strtotime($a['next_dose_date']) <=> strtotime($b['next_dose_date']);
});

$conn->close();

$pageTitle = 'My Immunizations';
include __DIR__ . '/includes/patient_header.php';
include __DIR__ . '/../includes/topbar.php';
?>

<!-- ══ Breadcrumb ══ -->
<div class="page-header">
    <div class="page-block">
        <div class="row align-items-center">
            <div class="col-md-12">
                <h5 class="m-b-10">My Immunizations</h5>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/patient/portal.php">Home</a></li>
                    <li class="breadcrumb-item active">My Immunizations</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- ══ Upcoming Doses ══ -->
<?php if (!empty($upcoming)): ?>
<div class="card mb-4">
    <div class="card-header">
        <h6 class="section-title mb-0">
            <i class="ti ti-calendar-due me-2" style="color:#e65100;"></i>Upcoming Doses
        </h6>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0" style="font-size:.88rem;">
                <thead>
                    <tr>
                        <th>Vaccine</th>
                        <th>Dose #</th>
                        <th>Due Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($upcoming as $u): ?>
                    <tr>
                        <td class="fw-semibold"><?= htmlspecialchars($u['vaccine_name']) ?></td>
                        <td><?= (int)$u['dose_number'] + 1 ?> of <?= (int)$u['doses_required'] ?></td>
                        <td>
                            <?= date('M d, Y', strtotime($u['next_dose_date'])) ?>
                            <?php
                            $daysAway = (int)((strtotime($u['next_dose_date']) - strtotime(date('Y-m-d'))) / 86400);
                            if ($daysAway <= 7):
                            ?>
                            <span class="badge bg-warning text-dark ms-2"><?= $daysAway === 0 ? 'Due today' : "In $daysAway day" . ($daysAway === 1 ? '' : 's') ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ══ Immunization History ══ -->
<div class="card">
    <div class="card-header">
        <h6 class="section-title mb-0">
            <i class="ti ti-vaccine me-2" style="color:#0d6efd;"></i>Immunization History
        </h6>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0" style="font-size:.88rem;">
                <thead>
                    <tr>
                        <th>Vaccine</th>
                        <th>Dose</th>
                        <th>Date Given</th>
                        <th>Administered By</th>
                        <th>Next Dose</th>
                        <th>Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($records)): ?>
                    <tr><td colspan="6" class="text-center text-muted py-4">You have no immunization records yet.</td></tr>
                    <?php else: foreach ($records as $r): ?>
                    <tr>
                        <td>
                            <div class="fw-semibold"><?= htmlspecialchars($r['vaccine_name']) ?></div>
                            <?php if (!empty($r['manufacturer'])): ?>
                            <div class="text-muted" style="font-size:.78rem;"><?= htmlspecialchars($r['manufacturer']) ?></div>
                            <?php endif; ?>
                        </td>
                        <td><?= (int)$r['dose_number'] ?> of <?= (int)$r['doses_required'] ?></td>
                        <td><?= date('M d, Y', strtotime($r['date_given'])) ?></td>
                        <td><?= htmlspecialchars($r['administered_by_name'] ?: 'RHU Staff') ?></td>
                        <td><?= $r['next_dose_date'] ? date('M d, Y', strtotime($r['next_dose_date'])) : '—' ?></td>
                        <td><?= htmlspecialchars($r['remarks'] ?: '—') ?></td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../includes/layout_footer.php'; ?>
