<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';
requirePatientOnly();

$conn = getDBConnection();
$currentUser = getCurrentUser();

$stmt = $conn->prepare("SELECT * FROM patients WHERE user_id = ? LIMIT 1");
$stmt->bind_param('i', $currentUser['id']);
$stmt->execute();
$patient = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$patient) {
    $conn->close();
    header('Location: ' . BASE_URL . '/patient/portal.php');
    exit;
}
$patientId = (int)$patient['id'];
$msg = '';

// ── Cancel a pending request (patient can only cancel their own, while still pending) ──
if (isset($_GET['cancel']) && is_numeric($_GET['cancel'])) {
    verifyCsrf();
    $apptId = (int)$_GET['cancel'];
    $stmt = $conn->prepare("UPDATE appointments SET status='cancelled' WHERE id=? AND patient_id=? AND status='pending'");
    $stmt->bind_param('ii', $apptId, $patientId);
    $stmt->execute();
    $stmt->close();
    header('Location: ' . BASE_URL . '/patient/appointments.php?msg=cancelled');
    exit;
}

// ── Submit a new appointment request ────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $category   = $_POST['category'] ?? '';
    $serviceId  = !empty($_POST['service_id']) ? (int)$_POST['service_id'] : null;
    $prefDate   = $_POST['preferred_date'] ?? '';
    $prefTime   = !empty($_POST['preferred_time']) ? $_POST['preferred_time'] : null;
    $reason     = trim($_POST['reason'] ?? '');

    $validCategories = ['Dental', 'Physical', 'Mental', 'Medical'];

    if (!in_array($category, $validCategories, true) || empty($prefDate)) {
        $msg = 'error:Please select a category and a preferred date.';
    } elseif (strtotime($prefDate) < strtotime(date('Y-m-d'))) {
        $msg = 'error:Preferred date cannot be in the past.';
    } else {
        $stmt = $conn->prepare("INSERT INTO appointments (patient_id, service_id, category, preferred_date, preferred_time, reason) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param('iissss', $patientId, $serviceId, $category, $prefDate, $prefTime, $reason);
        if ($stmt->execute()) {
            $msg = 'success:added';
        } else {
            $msg = 'error:Could not submit your request. Please try again.';
        }
        $stmt->close();
    }
}

// ── Fetch this patient's appointments ────────────────────────────────────────
$appointments = [];
$r = $conn->prepare("
    SELECT a.*, s.service_name
    FROM appointments a
    LEFT JOIN services s ON s.id = a.service_id
    WHERE a.patient_id = ?
    ORDER BY a.created_at DESC
");
$r->bind_param('i', $patientId);
$r->execute();
$res = $r->get_result();
while ($row = $res->fetch_assoc()) $appointments[] = $row;
$r->close();

// ── Active services, for the request form ───────────────────────────────────
$services = [];
$res = $conn->query("SELECT id, service_name, category FROM services WHERE status='active' ORDER BY category, service_name");
while ($row = $res->fetch_assoc()) $services[] = $row;

$conn->close();

if (isset($_GET['msg']) && $_GET['msg'] === 'cancelled') $msg = 'success:cancelled';

$pageTitle = 'My Appointments';
include __DIR__ . '/includes/patient_header.php';
include __DIR__ . '/../includes/topbar.php';

$statusBadge = [
    'pending'   => 'bg-warning text-dark',
    'approved'  => 'bg-success',
    'rejected'  => 'bg-danger',
    'completed' => 'bg-primary',
    'cancelled' => 'bg-secondary',
];
$openModal = (isset($_GET['action']) && $_GET['action'] === 'request');
?>

<!-- ══ Breadcrumb ══ -->
<div class="page-header">
    <div class="page-block">
        <div class="row align-items-center">
            <div class="col-md-12">
                <h5 class="m-b-10">My Appointments</h5>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/patient/portal.php">Home</a></li>
                    <li class="breadcrumb-item active">My Appointments</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php if ($msg): [$type, $text] = array_pad(explode(':', $msg, 2), 2, ''); ?>
    <?php if ($type === 'success'): ?>
        <div class="alert alert-success alert-dismissible fade show d-flex align-items-center gap-2" role="alert">
            <i class="ti ti-circle-check fs-5"></i>
            <span><?= $text === 'cancelled' ? 'Appointment request cancelled.' : 'Your appointment request has been submitted. RHU staff will review it shortly.' ?></span>
            <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
        </div>
    <?php else: ?>
        <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center gap-2" role="alert">
            <i class="ti ti-alert-circle fs-5"></i><span><?= htmlspecialchars($text) ?></span>
            <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; endif; ?>

<!-- ══ Appointments Table ══ -->
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h6 class="section-title mb-0">
            <i class="ti ti-calendar-event me-2" style="color:#0d6efd;"></i>My Appointment Requests
        </h6>
        <button class="btn btn-primary btn-sm" onclick="new bootstrap.Modal(document.getElementById('requestModal')).show()">
            <i class="ti ti-calendar-plus me-1"></i>Request Appointment
        </button>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0" style="font-size:.88rem;">
                <thead>
                    <tr>
                        <th>Category</th>
                        <th>Service</th>
                        <th>Preferred Date</th>
                        <th>Reason</th>
                        <th>Status</th>
                        <th>Scheduled</th>
                        <th>Staff Notes</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($appointments)): ?>
                    <tr><td colspan="8" class="text-center text-muted py-4">You have no appointment requests yet.</td></tr>
                    <?php else: foreach ($appointments as $a): ?>
                    <tr>
                        <td><?= htmlspecialchars($a['category']) ?></td>
                        <td><?= htmlspecialchars($a['service_name'] ?: '—') ?></td>
                        <td>
                            <?= date('M d, Y', strtotime($a['preferred_date'])) ?>
                            <?php if ($a['preferred_time']): ?><br><small class="text-muted"><?= date('h:i A', strtotime($a['preferred_time'])) ?></small><?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($a['reason'] ?: '—') ?></td>
                        <td><span class="badge <?= $statusBadge[$a['status']] ?? 'bg-secondary' ?>"><?= ucfirst($a['status']) ?></span></td>
                        <td>
                            <?= $a['scheduled_date'] ? date('M d, Y', strtotime($a['scheduled_date'])) . ($a['scheduled_time'] ? '<br><small class="text-muted">' . date('h:i A', strtotime($a['scheduled_time'])) . '</small>' : '') : '—' ?>
                        </td>
                        <td><?= htmlspecialchars($a['staff_notes'] ?: '—') ?></td>
                        <td>
                            <?php if ($a['status'] === 'pending'): ?>
                            <button class="btn btn-sm btn-outline-danger" onclick="confirmDelete('<?= csrfUrl(BASE_URL . '/patient/appointments.php?cancel=' . $a['id']) ?>', 'this appointment request')">
                                <i class="ti ti-x"></i> Cancel
                            </button>
                            <?php else: ?>&mdash;<?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ══════════════════════════ REQUEST APPOINTMENT MODAL ══════════════════════════ -->
<div class="modal fade" id="requestModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="ti ti-calendar-plus me-2"></i>Request an Appointment</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <?= csrfField() ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Category <span class="text-danger">*</span></label>
                        <select class="form-select" name="category" id="reqCategory" required onchange="filterServices()">
                            <option value="">Select category</option>
                            <option value="Medical">Medical</option>
                            <option value="Dental">Dental</option>
                            <option value="Physical">Physical</option>
                            <option value="Mental">Mental</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Specific Service <small class="text-muted">(optional)</small></label>
                        <select class="form-select" name="service_id" id="reqService">
                            <option value="">Not sure / any</option>
                            <?php foreach ($services as $s): ?>
                            <option value="<?= $s['id'] ?>" data-category="<?= htmlspecialchars($s['category']) ?>" style="display:none;">
                                <?= htmlspecialchars($s['service_name']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Preferred Date <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" name="preferred_date" min="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Preferred Time <small class="text-muted">(optional)</small></label>
                            <input type="time" class="form-control" name="preferred_time">
                        </div>
                    </div>
                    <div class="mb-1">
                        <label class="form-label">Reason for Visit</label>
                        <textarea class="form-control" name="reason" rows="3" placeholder="Briefly describe your concern or reason for the visit"></textarea>
                    </div>
                    <small class="text-muted">Your request will be reviewed by RHU staff, who will approve, schedule, or reject it.</small>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-send me-1"></i>Submit Request</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$extraJS = '
<script>
function filterServices() {
    const cat = document.getElementById("reqCategory").value;
    const select = document.getElementById("reqService");
    select.value = "";
    Array.from(select.options).forEach(opt => {
        if (!opt.dataset.category) { opt.style.display = ""; return; }
        opt.style.display = (opt.dataset.category === cat) ? "" : "none";
    });
}
' . ($openModal ? 'document.addEventListener("DOMContentLoaded", function(){ new bootstrap.Modal(document.getElementById("requestModal")).show(); });' : '') . '
</script>';
include __DIR__ . '/../includes/layout_footer.php';
?>
