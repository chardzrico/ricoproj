<?php
// Marks a notification (or all of them) read for the current user, then
// redirects back — this is what each bell dropdown item links to, mirroring
// the "stamp a timestamp as a side effect of a GET" pattern used for
// printed_at on prescriptions/certificates.
require_once __DIR__ . '/config/session.php';
require_once __DIR__ . '/config/database.php';
requireLogin();
verifyCsrf();

$conn = getDBConnection();
$currentUser = getCurrentUser();
$uid  = (int)$currentUser['id'];
$role = isPatient() ? 'patient' : 'staff';

if (isset($_GET['all'])) {
    markAllNotificationsRead($conn, $uid, $role);
} elseif (isset($_GET['id']) && is_numeric($_GET['id'])) {
    markNotificationRead($conn, (int)$_GET['id'], $uid);
}

$default = isPatient() ? BASE_URL . '/patient/portal.php' : BASE_URL . '/dashboard.php';
$return = $_GET['return'] ?? $default;
// Only ever redirect back within this app — never trust an arbitrary URL.
if (strpos($return, BASE_URL) !== 0) {
    $return = $default;
}

header('Location: ' . $return);
exit;
