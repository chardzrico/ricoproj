<?php
require_once __DIR__ . '/config/session.php';
require_once __DIR__ . '/config/database.php';
requireLogin();
requireStaffOnly();

$conn = getDBConnection();
$msg  = '';

// ── DELETE ────────────────────────────────────────────────────────────────
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    verifyCsrf();
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("UPDATE patients SET status='inactive' WHERE id=?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    header('Location: ' . BASE_URL . '/patients.php?msg=deleted');
    exit;
}

// ── ASSIGN DOCTOR (admin only) ──────────────────────────────────────────────
// A quick, separate action — kept out of the main Add/Edit form so a staff
// member editing other fields can never accidentally wipe an assignment.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_doctor'])) {
    verifyCsrf();
    if (!isAdmin()) {
        header('Location: ' . BASE_URL . '/patients.php?msg=notallowed'); exit;
    }
    $pid = (int)($_POST['patient_id'] ?? 0);
    $doctorId = $_POST['doctor_id'] !== '' ? (int)$_POST['doctor_id'] : null;
    if ($pid > 0) {
        $stmt = $conn->prepare("UPDATE patients SET assigned_doctor_id=? WHERE id=?");
        $stmt->bind_param('ii', $doctorId, $pid);
        $stmt->execute();
        $stmt->close();
    }
    header('Location: ' . BASE_URL . '/patients.php?msg=doctor_assigned'); exit;
}

// ── ADD / EDIT ─────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['assign_doctor'])) {
    verifyCsrf();
    $id          = (int)($_POST['id'] ?? 0);
    $first_name  = trim($_POST['first_name']  ?? '');
    $last_name   = trim($_POST['last_name']   ?? '');
    $middle_name = trim($_POST['middle_name'] ?? '');
    $folder_no   = trim($_POST['folder_number'] ?? '');
    $tn_no       = trim($_POST['tn_number'] ?? '');

    // DOB is optional — some patients (e.g. Ita/Aeta / IP community members)
    // have no recorded date of birth. When unknown, we store an estimated
    // age instead and flag the record accordingly.
    $dob_unknown = isset($_POST['dob_unknown']) && $_POST['dob_unknown'] === '1';
    $dob         = $dob_unknown ? null : (trim($_POST['date_of_birth'] ?? '') ?: null);
    $est_age     = $dob_unknown ? (int)($_POST['estimated_age'] ?? 0) : null;
    $is_dob_est  = $dob_unknown ? 1 : 0;

    $gender      = $_POST['gender']      ?? '';
    $address     = trim($_POST['address'] ?? '');
    $barangay_id = !empty($_POST['barangay_id']) ? (int)$_POST['barangay_id'] : null;
    $contact     = trim($_POST['contact_number']  ?? '');
    $guardian    = trim($_POST['guardian_name']    ?? '');
    $gcontact    = trim($_POST['guardian_contact'] ?? '');
    $blood_type  = $_POST['blood_type'] ?? '';
    $religion    = trim($_POST['religion']  ?? '');
    $civil_stat  = trim($_POST['civil_status'] ?? '');
    $occupation  = trim($_POST['occupation']   ?? '');

    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE patients SET first_name=?,last_name=?,middle_name=?,folder_number=?,tn_number=?,date_of_birth=?,estimated_age=?,is_dob_estimated=?,gender=?,address=?,barangay_id=?,contact_number=?,guardian_name=?,guardian_contact=?,blood_type=?,religion=?,civil_status=?,occupation=? WHERE id=?");
        $stmt->bind_param('ssssssiississsssssi',
            $first_name,$last_name,$middle_name,$folder_no,$tn_no,$dob,$est_age,$is_dob_est,$gender,
            $address,$barangay_id,$contact,$guardian,$gcontact,$blood_type,
            $religion,$civil_stat,$occupation,$id);
        $stmt->execute();
        header('Location: ' . BASE_URL . '/patients.php?msg=updated');
    } else {
        $r   = $conn->query("SELECT COUNT(*) as cnt FROM patients");
        $cnt = (int)$r->fetch_assoc()['cnt'] + 1;
        $patient_no = 'RHU-' . date('Y') . '-' . str_pad($cnt, 5, '0', STR_PAD_LEFT);
        $stmt = $conn->prepare("INSERT INTO patients (patient_no,folder_number,tn_number,first_name,last_name,middle_name,date_of_birth,estimated_age,is_dob_estimated,gender,address,barangay_id,contact_number,guardian_name,guardian_contact,blood_type,religion,civil_status,occupation) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param('sssssssiississsssss',
            $patient_no,$folder_no,$tn_no,$first_name,$last_name,$middle_name,$dob,$est_age,$is_dob_est,$gender,
            $address,$barangay_id,$contact,$guardian,$gcontact,$blood_type,
            $religion,$civil_stat,$occupation);
        $stmt->execute();
        header('Location: ' . BASE_URL . '/patients.php?msg=added');
    }
    exit;
}

// ── FETCH ─────────────────────────────────────────────────────────────────
$patients = [];
$r = $conn->query("SELECT p.*, u.full_name as assigned_doctor_name, b.name as barangay_name FROM patients p LEFT JOIN users u ON p.assigned_doctor_id = u.id LEFT JOIN barangays b ON p.barangay_id = b.id WHERE p.status='active'" . doctorScopeSql('p') . " ORDER BY p.created_at DESC");
while ($row = $r->fetch_assoc()) $patients[] = $row;

$doctors = [];
$r = $conn->query("SELECT id, full_name FROM users WHERE role='doctor' AND status='active' ORDER BY full_name");
while ($row = $r->fetch_assoc()) $doctors[] = $row;

$barangays = [];
$r = $conn->query("SELECT id, name FROM barangays WHERE status='active' ORDER BY name");
while ($row = $r->fetch_assoc()) $barangays[] = $row;
$conn->close();

if (isset($_GET['msg'])) {
    $msgs = ['added'=>'Patient registered successfully!','updated'=>'Patient updated successfully!','deleted'=>'Patient record deactivated.','doctor_assigned'=>'Doctor assignment updated.','notallowed'=>null];
    $msg  = $msgs[$_GET['msg']] ?? '';
}
$pageTitle = 'Patients';
include __DIR__ . '/includes/layout_header.php';
include __DIR__ . '/includes/topbar.php';
?>

<!-- ══ Breadcrumb ══ -->
<div class="page-header">
    <div class="page-block">
        <div class="row align-items-center">
            <div class="col-md-12">
                <h5 class="m-b-10">Patients</h5>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li>
                    <li class="breadcrumb-item active">Patients</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php if ($msg): ?>
<div class="alert alert-success alert-dismissible fade show d-flex align-items-center gap-2" role="alert">
    <i class="ti ti-circle-check fs-5"></i><span><?= htmlspecialchars($msg) ?></span>
    <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<!-- ══ Patients Table Card ══ -->
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h6 class="section-title mb-0">
            <i class="ti ti-users me-2" style="color:#0d6efd;"></i>Patient List
        </h6>
        <button class="btn btn-primary btn-sm" onclick="openAddModal()">
            <i class="ti ti-user-plus me-1"></i>Register Patient
        </button>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0" id="patientTable" style="width:100%">
                <thead>
                    <tr>
                        <th>Patient No.</th>
                        <th>Folder No.</th>
                        <th>Name</th>
                        <th>Gender</th>
                        <th>Date of Birth</th>
                        <th>Contact</th>
                        <th>Blood Type</th>
                        <th>Barangay</th>
                        <th>Assigned Doctor</th>
                        <th>Registered</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($patients as $p): ?>
                    <tr>
                        <td>
                            <span class="badge bg-primary bg-opacity-10 text-primary fw-semibold">
                                <?= htmlspecialchars($p['patient_no']) ?>
                            </span>
                        </td>
                        <td><?= htmlspecialchars($p['folder_number'] ?: '—') ?></td>
                        <td class="fw-semibold">
                            <?= htmlspecialchars($p['last_name'] . ', ' . $p['first_name'] . ($p['middle_name'] ? ' ' . $p['middle_name'][0] . '.' : '')) ?>
                        </td>
                        <td><?= htmlspecialchars($p['gender']) ?></td>
                        <td>
                            <?php if (!empty($p['date_of_birth'])): ?>
                                <?= date('M d, Y', strtotime($p['date_of_birth'])) ?>
                            <?php elseif (!empty($p['is_dob_estimated'])): ?>
                                <span class="badge bg-warning text-dark" title="Date of birth unknown">~<?= (int)$p['estimated_age'] ?> yrs (est.)</span>
                            <?php else: ?>
                                <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($p['contact_number'] ?: '—') ?></td>
                        <td><?= htmlspecialchars($p['blood_type'] ?: '—') ?></td>
                        <td><?= htmlspecialchars($p['barangay_name'] ?: '—') ?></td>
                        <td>
                            <?php if (isAdmin()): ?>
                            <form method="POST" action="" class="mb-0">
                                <?= csrfField() ?>
                                <input type="hidden" name="assign_doctor" value="1">
                                <input type="hidden" name="patient_id" value="<?= $p['id'] ?>">
                                <select name="doctor_id" class="form-select form-select-sm" style="min-width:150px;" onchange="this.form.submit()" title="Assign doctor">
                                    <option value="">— Unassigned —</option>
                                    <?php foreach ($doctors as $d): ?>
                                    <option value="<?= $d['id'] ?>" <?= (int)$p['assigned_doctor_id'] === (int)$d['id'] ? 'selected' : '' ?>><?= htmlspecialchars($d['full_name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </form>
                            <?php else: ?>
                                <?= $p['assigned_doctor_name'] ? htmlspecialchars($p['assigned_doctor_name']) : '<span class="text-muted">— Unassigned —</span>' ?>
                            <?php endif; ?>
                        </td>
                        <td><?= date('M d, Y', strtotime($p['created_at'])) ?></td>
                        <td>
                            <button class="btn-edit btn btn-sm me-1"
                                    onclick="openEditModal(<?= htmlspecialchars(json_encode($p)) ?>)"
                                    title="Edit">
                                <i class="ti ti-edit"></i>
                            </button>
                            <button class="btn-delete btn btn-sm"
                                    onclick="confirmDelete('<?= csrfUrl(BASE_URL . '/patients.php?delete=' . $p['id']) ?>', '<?= htmlspecialchars(addslashes($p['first_name'] . ' ' . $p['last_name'])) ?>')"
                                    title="Delete">
                                <i class="ti ti-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ══════════════════════════ REGISTER PATIENT MODAL ══════════════════════════ -->
<div class="modal fade" id="patientModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="patientModalTitle" style="color:#fff;">
                    <i class="ti ti-user-plus me-2" style="color:#fff;"></i>Register New Patient
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <?= csrfField() ?>
                <input type="hidden" name="id" id="patientId" value="0">
                <div class="modal-body">

                    <!-- Section: Personal Information -->
                    <div class="mb-3">
                        <div class="d-flex align-items-center mb-3">
                            <div style="width:28px;height:28px;border-radius:50%;background:#e3f2fd;display:flex;align-items:center;justify-content:center;margin-right:10px;">
                                <i class="ti ti-user" style="color:#0d6efd;font-size:.9rem;"></i>
                            </div>
                            <h6 class="mb-0 fw-bold" style="color:#1e3a5f;">Personal Information</h6>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-3">
                                <label class="form-label">Folder Number</label>
                                <input type="text" class="form-control" name="folder_number" id="pFolderNo" placeholder="ITR Folder #">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">TN #</label>
                                <input type="text" class="form-control" name="tn_number" id="pTnNo" placeholder="TN #">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">First Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="first_name" id="pFirstName" required placeholder="First name">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Last Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="last_name" id="pLastName" required placeholder="Last name">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Middle Name</label>
                                <input type="text" class="form-control" name="middle_name" id="pMiddleName" placeholder="Middle name">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Date of Birth</label>
                                <input type="date" class="form-control" name="date_of_birth" id="pDOB" onchange="computeAge()">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Age</label>
                                <input type="text" class="form-control bg-light" id="pAgeDisplay" readonly placeholder="Auto">
                            </div>
                            <div class="col-md-3 d-flex align-items-end">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="dob_unknown" id="pDobUnknown" value="1" onchange="toggleDobUnknown()">
                                    <label class="form-check-label" for="pDobUnknown">
                                        Date of birth unknown <span class="text-muted" style="font-size:.78rem;">(e.g. IP/Aeta patient)</span>
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-3" id="pEstimatedAgeWrap" style="display:none;">
                                <label class="form-label">Estimated Age <span class="text-danger">*</span></label>
                                <input type="number" min="0" max="130" class="form-control" name="estimated_age" id="pEstimatedAge" placeholder="e.g. 45">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Gender <span class="text-danger">*</span></label>
                                <select class="form-select" name="gender" id="pGender" required>
                                    <option value="">Select Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Blood Type</label>
                                <select class="form-select" name="blood_type" id="pBloodType">
                                    <option value="">Unknown</option>
                                    <?php foreach (['A+','A-','B+','B-','AB+','AB-','O+','O-'] as $bt): ?>
                                    <option value="<?= $bt ?>"><?= $bt ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Civil Status</label>
                                <select class="form-select" name="civil_status" id="pCivilStatus">
                                    <option value="">N/A</option>
                                    <option>Single</option><option>Married</option>
                                    <option>Widowed</option><option>Separated</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Religion</label>
                                <input type="text" class="form-control" name="religion" id="pReligion" placeholder="Religion (optional)">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Occupation</label>
                                <input type="text" class="form-control" name="occupation" id="pOccupation" placeholder="Occupation (optional)">
                            </div>
                        </div>
                    </div>

                    <hr class="my-3">

                    <!-- Section: Contact Information -->
                    <div class="mb-3">
                        <div class="d-flex align-items-center mb-3">
                            <div style="width:28px;height:28px;border-radius:50%;background:#e8f5e9;display:flex;align-items:center;justify-content:center;margin-right:10px;">
                                <i class="ti ti-phone" style="color:#2e7d32;font-size:.9rem;"></i>
                            </div>
                            <h6 class="mb-0 fw-bold" style="color:#1e3a5f;">Contact & Address</h6>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">Contact Number</label>
                                <input type="text" class="form-control" name="contact_number" id="pContact" placeholder="09XX-XXX-XXXX">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Barangay</label>
                                <select class="form-select" name="barangay_id" id="pBarangay">
                                    <option value="">Select barangay…</option>
                                    <?php foreach ($barangays as $b): ?>
                                    <option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Sitio / Street / House No.</label>
                                <input type="text" class="form-control" name="address" id="pAddress" placeholder="e.g. Purok 2, Sitio Malaya">
                            </div>
                        </div>
                    </div>

                    <hr class="my-3">

                    <!-- Section: Guardian Information -->
                    <div>
                        <div class="d-flex align-items-center mb-3">
                            <div style="width:28px;height:28px;border-radius:50%;background:#fff3e0;display:flex;align-items:center;justify-content:center;margin-right:10px;">
                                <i class="ti ti-users" style="color:#e65100;font-size:.9rem;"></i>
                            </div>
                            <h6 class="mb-0 fw-bold" style="color:#1e3a5f;">Guardian / Parent</h6>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Guardian Name</label>
                                <input type="text" class="form-control" name="guardian_name" id="pGuardian" placeholder="Parent / Guardian name">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Guardian Contact</label>
                                <input type="text" class="form-control" name="guardian_contact" id="pGContact" placeholder="Guardian contact number">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="ti ti-x me-1"></i>Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="ti ti-device-floppy me-1"></i>Save Patient
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$extraJS = '
<script>
function computeAge() {
    const dob = document.getElementById("pDOB").value;
    if (!dob) return;
    const today = new Date();
    const birth = new Date(dob);
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
    document.getElementById("pAgeDisplay").value = age >= 0 ? age + " yrs" : "";
}
function toggleDobUnknown() {
    const unknown = document.getElementById("pDobUnknown").checked;
    document.getElementById("pDOB").disabled = unknown;
    document.getElementById("pEstimatedAgeWrap").style.display = unknown ? "" : "none";
    if (unknown) {
        document.getElementById("pDOB").value = "";
        document.getElementById("pAgeDisplay").value = "";
    } else {
        document.getElementById("pEstimatedAge").value = "";
    }
}
function openAddModal() {
    document.getElementById("patientModalTitle").innerHTML = \'<i class="ti ti-user-plus me-2"></i>Register New Patient\';
    document.getElementById("patientId").value = "0";
    ["pFirstName","pLastName","pMiddleName","pFolderNo","pTnNo","pContact","pGuardian","pGContact","pAddress","pReligion","pOccupation","pAgeDisplay","pEstimatedAge"].forEach(id => document.getElementById(id).value = "");
    document.getElementById("pDOB").value = "";
    document.getElementById("pDOB").disabled = false;
    document.getElementById("pDobUnknown").checked = false;
    document.getElementById("pEstimatedAgeWrap").style.display = "none";
    document.getElementById("pGender").value = "";
    document.getElementById("pBloodType").value = "";
    document.getElementById("pBarangay").value = "";
    document.getElementById("pCivilStatus") && (document.getElementById("pCivilStatus").value = "");
    new bootstrap.Modal(document.getElementById("patientModal")).show();
}
function openEditModal(p) {
    document.getElementById("patientModalTitle").innerHTML = \'<i class="ti ti-edit me-2"></i>Edit Patient Record\';
    document.getElementById("patientId").value      = p.id;
    document.getElementById("pFolderNo").value      = p.folder_number || "";
    document.getElementById("pTnNo").value          = p.tn_number || "";
    document.getElementById("pFirstName").value     = p.first_name  || "";
    document.getElementById("pLastName").value      = p.last_name   || "";
    document.getElementById("pMiddleName").value    = p.middle_name || "";
    document.getElementById("pGender").value        = p.gender      || "";
    document.getElementById("pBloodType").value     = p.blood_type  || "";
    document.getElementById("pContact").value       = p.contact_number  || "";
    document.getElementById("pGuardian").value      = p.guardian_name   || "";
    document.getElementById("pGContact").value      = p.guardian_contact|| "";
    document.getElementById("pAddress").value       = p.address || "";
    document.getElementById("pBarangay").value      = p.barangay_id || "";
    if (document.getElementById("pReligion"))    document.getElementById("pReligion").value    = p.religion    || "";
    if (document.getElementById("pOccupation"))  document.getElementById("pOccupation").value  = p.occupation  || "";
    if (document.getElementById("pCivilStatus")) document.getElementById("pCivilStatus").value = p.civil_status|| "";

    const dobUnknown = !!parseInt(p.is_dob_estimated || 0);
    document.getElementById("pDobUnknown").checked = dobUnknown;
    document.getElementById("pDOB").disabled = dobUnknown;
    document.getElementById("pEstimatedAgeWrap").style.display = dobUnknown ? "" : "none";
    if (dobUnknown) {
        document.getElementById("pDOB").value = "";
        document.getElementById("pEstimatedAge").value = p.estimated_age || "";
        document.getElementById("pAgeDisplay").value = p.estimated_age ? (p.estimated_age + " yrs (est.)") : "";
    } else {
        document.getElementById("pDOB").value = p.date_of_birth || "";
        computeAge();
    }
    new bootstrap.Modal(document.getElementById("patientModal")).show();
}
</script>';
include __DIR__ . '/includes/layout_footer.php';
?>
