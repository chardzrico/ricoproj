<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();
$conn = getDBConnection();
$msg = '';

if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    verifyCsrf();
    $conn->query("UPDATE vaccines SET status='inactive' WHERE id=".(int)$_GET['delete']);
    header('Location: vaccine_list.php?msg=deleted'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $id    = (int)($_POST['id'] ?? 0);
    $name  = trim($_POST['vaccine_name'] ?? '');
    $mfr   = trim($_POST['manufacturer'] ?? '');
    $desc  = trim($_POST['description'] ?? '');
    $doses = (int)($_POST['doses_required'] ?? 1);
    $intv  = (int)($_POST['interval_days'] ?? 0);
    $amin  = (int)($_POST['target_age_min'] ?? 0);
    $amax  = (int)($_POST['target_age_max'] ?? 999);

    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE vaccines SET vaccine_name=?,manufacturer=?,description=?,doses_required=?,interval_days=?,target_age_min=?,target_age_max=? WHERE id=?");
        $stmt->bind_param('sssiiiii',$name,$mfr,$desc,$doses,$intv,$amin,$amax,$id);
    } else {
        $stmt = $conn->prepare("INSERT INTO vaccines (vaccine_name,manufacturer,description,doses_required,interval_days,target_age_min,target_age_max) VALUES (?,?,?,?,?,?,?)");
        $stmt->bind_param('sssiiii',$name,$mfr,$desc,$doses,$intv,$amin,$amax);
    }
    $stmt->execute();
    header('Location: vaccine_list.php?msg=' . ($id>0?'updated':'added')); exit;
}

$vaccines = [];
$r = $conn->query("SELECT v.*, (SELECT COUNT(*) FROM immunization_records ir WHERE ir.vaccine_id=v.id) as total_given FROM vaccines v WHERE v.status='active' ORDER BY v.vaccine_name");
while ($row = $r->fetch_assoc()) $vaccines[] = $row;
$conn->close();

if (isset($_GET['msg'])) { $msg = ['added'=>'Vaccine added.','updated'=>'Updated.','deleted'=>'Deactivated.'][$_GET['msg']] ?? ''; }
$pageTitle = 'Vaccine List';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<div class="page-header"><div class="page-block">
    <h5 class="m-b-10">Vaccine List</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Vaccination</li><li class="breadcrumb-item active">Vaccine List</li></ul>
</div></div>
<?php if ($msg): ?><div class="alert alert-success alert-dismissible fade show"><i class="ti ti-circle-check me-2"></i><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0"><i class="ti ti-list-details me-2" style="color:#0d6efd;"></i>Vaccine List</h6>
        <button class="btn btn-primary btn-sm" onclick="openAddModal()"><i class="ti ti-plus me-1"></i>Add Vaccine</button>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0">
                <thead><tr><th>Vaccine Name</th><th>Manufacturer</th><th>Doses Required</th><th>Interval (days)</th><th>Target Age (months)</th><th>Total Given</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php foreach ($vaccines as $v): ?>
                    <tr>
                        <td class="fw-semibold"><?= htmlspecialchars($v['vaccine_name']) ?></td>
                        <td><?= htmlspecialchars($v['manufacturer'] ?: '—') ?></td>
                        <td><span class="badge bg-primary bg-opacity-10 text-primary"><?= $v['doses_required'] ?> dose<?= $v['doses_required']>1?'s':'' ?></span></td>
                        <td><?= $v['interval_days'] ? $v['interval_days'].' days' : '—' ?></td>
                        <td><?= $v['target_age_min'] ?>–<?= $v['target_age_max']>=999?'∞':$v['target_age_max'] ?> months</td>
                        <td><span class="badge bg-success bg-opacity-15 text-success fw-semibold"><?= $v['total_given'] ?></span></td>
                        <td>
                            <button class="btn-edit btn btn-sm me-1" onclick="openEditModal(<?= htmlspecialchars(json_encode($v)) ?>)"><i class="ti ti-edit"></i></button>
                            <button class="btn-delete btn btn-sm" onclick="confirmDelete('<?= csrfUrl('vaccine_list.php?delete=' . $v['id']) ?>','<?= htmlspecialchars($v['vaccine_name']) ?>')"><i class="ti ti-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($vaccines)): ?><tr><td colspan="7" class="text-center text-muted py-4">No vaccines in list.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="vaccineModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="vaccineModalTitle"><i class="ti ti-vaccine me-2"></i>Add Vaccine</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <?= csrfField() ?>
                <input type="hidden" name="id" id="vaccineId" value="0">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-12"><label class="form-label">Vaccine Name *</label><input type="text" class="form-control" name="vaccine_name" id="vName" required placeholder="e.g. BCG"></div>
                        <div class="col-12"><label class="form-label">Manufacturer</label><input type="text" class="form-control" name="manufacturer" id="vMfr" placeholder="e.g. WHO"></div>
                        <div class="col-md-4"><label class="form-label">Doses Required</label><input type="number" min="1" class="form-control" name="doses_required" id="vDoses" value="1"></div>
                        <div class="col-md-4"><label class="form-label">Interval (days)</label><input type="number" min="0" class="form-control" name="interval_days" id="vInterval" value="0"></div>
                        <div class="col-md-6"><label class="form-label">Min Age (months)</label><input type="number" min="0" class="form-control" name="target_age_min" id="vAgeMin" value="0"></div>
                        <div class="col-md-6"><label class="form-label">Max Age (months)</label><input type="number" min="0" class="form-control" name="target_age_max" id="vAgeMax" value="999"></div>
                        <div class="col-12"><label class="form-label">Description</label><textarea class="form-control" name="description" id="vDesc" rows="2" placeholder="Optional description"></textarea></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php
$extraJS='<script>
function openAddModal(){
    document.getElementById("vaccineModalTitle").innerHTML=\'<i class="ti ti-vaccine me-2"></i>Add Vaccine\';
    document.getElementById("vaccineId").value="0";
    ["vName","vMfr","vDesc"].forEach(id=>document.getElementById(id).value="");
    document.getElementById("vDoses").value="1";
    document.getElementById("vInterval").value="0";
    document.getElementById("vAgeMin").value="0";
    document.getElementById("vAgeMax").value="999";

    new bootstrap.Modal(document.getElementById("vaccineModal")).show();
}
function openEditModal(v){
    document.getElementById("vaccineModalTitle").innerHTML=\'<i class="ti ti-edit me-2"></i>Edit Vaccine\';
    document.getElementById("vaccineId").value=v.id;
    document.getElementById("vName").value=v.vaccine_name||"";
    document.getElementById("vMfr").value=v.manufacturer||"";
    document.getElementById("vDesc").value=v.description||"";
    document.getElementById("vDoses").value=v.doses_required||"1";
    document.getElementById("vInterval").value=v.interval_days||"0";
    document.getElementById("vAgeMin").value=v.target_age_min||"0";
    document.getElementById("vAgeMax").value=v.target_age_max||"999";
    new bootstrap.Modal(document.getElementById("vaccineModal")).show();
}
</script>';
include __DIR__ . '/../../includes/layout_footer.php';
?>
