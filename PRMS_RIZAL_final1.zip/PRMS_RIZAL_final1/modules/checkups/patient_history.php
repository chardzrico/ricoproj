<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();

$conn = getDBConnection();
$msg = '';
$selectedPatient = null;
$history = [];
$checkups = [];
$immunizations = [];
$clinicalServices = [];

$patient_id = (int)($_GET['patient_id'] ?? 0);

if (isset($_GET['delete_history']) && is_numeric($_GET['delete_history'])) {
    verifyCsrf();
    $conn->query("DELETE FROM patient_history WHERE id=".(int)$_GET['delete_history']);
    header("Location: patient_history.php?patient_id=$patient_id&msg=deleted"); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_history'])) {
    verifyCsrf();
    $pid   = (int)$_POST['patient_id'];
    $type  = trim($_POST['history_type'] ?? '');
    $desc  = trim($_POST['description'] ?? '');
    $date  = $_POST['record_date'] ?? date('Y-m-d');
    $uid   = getCurrentUser()['id'];
    $stmt  = $conn->prepare("INSERT INTO patient_history (patient_id,history_type,description,record_date,recorded_by) VALUES (?,?,?,?,?)");
    $stmt->bind_param('isssi',$pid,$type,$desc,$date,$uid);
    $stmt->execute();
    header("Location: patient_history.php?patient_id=$pid&msg=added"); exit;
}

$patients = [];
$r = $conn->query("SELECT id, patient_no, CONCAT(first_name,' ',last_name) as name, date_of_birth, gender, address, contact_number, blood_type FROM patients WHERE status='active'" . doctorScopeSql() . " ORDER BY last_name");
while ($row = $r->fetch_assoc()) $patients[] = $row;

if ($patient_id > 0) {
    $r = $conn->query("SELECT *, CONCAT(first_name,' ',last_name) as name FROM patients WHERE id=$patient_id" . doctorScopeSql() . " LIMIT 1");
    $selectedPatient = $r->fetch_assoc();
    if (!$selectedPatient) { $patient_id = 0; } else {
    $r = $conn->query("SELECT ph.*, u.full_name as staff FROM patient_history ph LEFT JOIN users u ON ph.recorded_by=u.id WHERE ph.patient_id=$patient_id ORDER BY ph.record_date DESC");
    while ($row = $r->fetch_assoc()) $history[] = $row;

    $r = $conn->query("SELECT c.*, u.full_name as staff FROM checkups c LEFT JOIN users u ON c.attending_staff=u.id WHERE c.patient_id=$patient_id ORDER BY c.checkup_date DESC");
    while ($row = $r->fetch_assoc()) $checkups[] = $row;

    $r = $conn->query("SELECT ir.*, v.vaccine_name FROM immunization_records ir LEFT JOIN vaccines v ON ir.vaccine_id=v.id WHERE ir.patient_id=$patient_id ORDER BY ir.date_given DESC");
    while ($row = $r->fetch_assoc()) $immunizations[] = $row;

    $r = $conn->query("SELECT ps.*, s.service_name, s.category, u.full_name as staff FROM patient_services ps LEFT JOIN services s ON ps.service_id=s.id LEFT JOIN users u ON ps.administered_by=u.id WHERE ps.patient_id=$patient_id ORDER BY ps.service_date DESC");
    while ($row = $r->fetch_assoc()) $clinicalServices[] = $row;
    }
}
$conn->close();

if (isset($_GET['msg'])) { $msg = ['added'=>'History added.','deleted'=>'History deleted.'][$_GET['msg']] ?? ''; }
$pageTitle = 'Patient History';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<div class="page-header"><div class="page-block">
    <h5 class="m-b-10">Patient History</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Checkups</li><li class="breadcrumb-item active">Patient History</li></ul>
</div></div>

<?php if ($msg): ?><div class="alert alert-success alert-dismissible fade show"><i class="ti ti-circle-check me-2"></i><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

<!-- Patient Search -->
<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="" class="d-flex gap-3 align-items-end flex-wrap">
            <div style="flex:1;min-width:250px;">
                <label class="form-label fw-bold">Select Patient</label>
                <select class="form-select" name="patient_id" onchange="this.form.submit()">
                    <option value="">— Choose a patient —</option>
                    <?php foreach ($patients as $p): ?>
                    <option value="<?= $p['id'] ?>" <?= $patient_id == $p['id'] ? 'selected' : '' ?>><?= htmlspecialchars($p['patient_no'].' - '.$p['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </form>
    </div>
</div>

<?php if ($selectedPatient): ?>
<!-- Patient Info Card -->
<div class="card mb-3" style="border-left:4px solid #0d6efd;">
    <div class="card-body">
        <div class="row g-3">
            <div class="col-md-1 d-flex align-items-center justify-content-center">
                <div style="width:60px;height:60px;background:#e3f2fd;border-radius:50%;display:flex;align-items:center;justify-content:center;">
                    <i class="ti ti-user" style="font-size:1.8rem;color:#1565c0;"></i>
                </div>
            </div>
            <div class="col-md-11">
                <div class="d-flex flex-wrap gap-4">
                    <div><div class="text-muted" style="font-size:.78rem;">Patient No.</div><div class="fw-bold text-primary"><?= htmlspecialchars($selectedPatient['patient_no']) ?></div></div>
                    <div><div class="text-muted" style="font-size:.78rem;">Name</div><div class="fw-bold"><?= htmlspecialchars($selectedPatient['name']) ?></div></div>
                    <div><div class="text-muted" style="font-size:.78rem;">Date of Birth</div><div class="fw-semibold"><?= date('M d, Y', strtotime($selectedPatient['date_of_birth'])) ?></div></div>
                    <div><div class="text-muted" style="font-size:.78rem;">Gender</div><div class="fw-semibold"><?= htmlspecialchars($selectedPatient['gender']) ?></div></div>
                    <div><div class="text-muted" style="font-size:.78rem;">Blood Type</div><div class="fw-semibold"><?= htmlspecialchars($selectedPatient['blood_type'] ?: '—') ?></div></div>
                    <div><div class="text-muted" style="font-size:.78rem;">Contact</div><div class="fw-semibold"><?= htmlspecialchars($selectedPatient['contact_number'] ?: '—') ?></div></div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Previous Consultation — quick index of where this patient left off -->
<div class="card mb-3" style="border-left:4px solid #2e7d32;">
    <div class="card-header"><h6 class="section-title mb-0"><i class="ti ti-stethoscope me-2" style="color:#2e7d32;"></i>Previous Consultation</h6></div>
    <div class="card-body">
        <?php if (!empty($checkups)): $prev = $checkups[0]; ?>
        <div class="row g-3">
            <div class="col-md-3">
                <div class="text-muted" style="font-size:.78rem;">Date</div>
                <div class="fw-semibold"><?= date('M d, Y', strtotime($prev['checkup_date'])) ?></div>
            </div>
            <div class="col-md-3">
                <div class="text-muted" style="font-size:.78rem;">Assigned Doctor</div>
                <div class="fw-semibold"><?= htmlspecialchars($prev['staff'] ?: '—') ?></div>
            </div>
            <div class="col-md-6">
                <div class="text-muted" style="font-size:.78rem;">Chief Complaint</div>
                <div class="fw-semibold"><?= htmlspecialchars($prev['chief_complaint'] ?: '—') ?></div>
            </div>
            <div class="col-md-12">
                <div class="text-muted" style="font-size:.78rem;">Findings / Diagnosis</div>
                <div><?= htmlspecialchars($prev['diagnosis'] ?: '—') ?></div>
            </div>
        </div>
        <?php else: ?>
        <div class="text-center text-muted py-3">
            <i class="ti ti-user-plus" style="font-size:1.6rem;opacity:.5;"></i>
            <div class="mt-1">No previous consultation on record — this is a new patient.</div>
        </div>
        <?php endif; ?>
    </div>
</div>

<div class="d-flex justify-content-end mb-3">
    <button class="btn btn-primary btn-sm" onclick="new bootstrap.Modal(document.getElementById('historyModal')).show()">
        <i class="ti ti-plus me-1"></i>Add History Record
    </button>
</div>

<div class="row g-3">
    <div class="col-md-12">
        <!-- History Records -->
        <div class="card mb-3">
            <div class="card-header"><h6 class="section-title mb-0"><i class="ti ti-history me-2" style="color:#0d6efd;"></i>History Records (<?= count($history) ?>)</h6></div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0" style="font-size:.88rem;">
                        <thead><tr><th>Type</th><th>Date</th><th>Description</th><th>Recorded By</th><th>Action</th></tr></thead>
                        <tbody>
                            <?php foreach ($history as $h): ?>
                            <tr>
                                <td><span class="badge bg-info bg-opacity-15 text-info"><?= htmlspecialchars($h['history_type']) ?></span></td>
                                <td><?= date('M d, Y', strtotime($h['record_date'])) ?></td>
                                <td style="max-width:200px;"><div style="white-space:pre-wrap;word-break:break-word;"><?= htmlspecialchars($h['description']) ?></div></td>
                                <td><?= htmlspecialchars($h['staff'] ?: '—') ?></td>
                                <td><button class="btn-delete btn btn-sm" onclick="confirmDelete('<?= csrfUrl('patient_history.php?patient_id=' . $patient_id . '&delete_history=' . $h['id']) ?>','this record')"><i class="ti ti-trash"></i></button></td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($history)): ?><tr><td colspan="5" class="text-center text-muted py-3">No history records.</td></tr><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Past Checkups -->
        <div class="card mb-3">
            <div class="card-header"><h6 class="section-title mb-0"><i class="ti ti-stethoscope me-2" style="color:#2e7d32;"></i>Past Checkups (<?= count($checkups) ?>)</h6></div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0" style="font-size:.85rem;">
                        <thead><tr><th>Date</th><th>BP</th><th>Temp</th><th>Weight</th><th>Diagnosis</th><th>Status</th></tr></thead>
                        <tbody>
                            <?php foreach ($checkups as $c): ?>
                            <tr>
                                <td><?= date('M d, Y', strtotime($c['checkup_date'])) ?></td>
                                <td><?= htmlspecialchars($c['blood_pressure'] ?: '—') ?></td>
                                <td><?= $c['temperature'] ? $c['temperature'].'°C' : '—' ?></td>
                                <td><?= $c['weight'] ? $c['weight'].' kg' : '—' ?></td>
                                <td style="max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= htmlspecialchars($c['diagnosis'] ?: '—') ?></td>
                                <td><span class="badge <?= $c['status']==='completed'?'bg-success':($c['status']==='pending'?'bg-warning text-dark':'bg-secondary') ?>"><?= ucfirst($c['status']) ?></span></td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($checkups)): ?><tr><td colspan="6" class="text-center text-muted py-3">No checkups on record.</td></tr><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Clinical Services Availed (Medical / Dental / Mental / Physical) -->
        <div class="card mb-3">
            <div class="card-header"><h6 class="section-title mb-0"><i class="ti ti-report me-2" style="color:#8e24aa;"></i>Clinical Services Availed (<?= count($clinicalServices) ?>)</h6></div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0" style="font-size:.85rem;">
                        <thead><tr><th>Category</th><th>Sub-Service</th><th>Date</th><th>Notes</th><th>Status</th><th>Staff</th></tr></thead>
                        <tbody>
                            <?php
                            $catColor = ['Medical'=>'#1565c0','Dental'=>'#00897b','Mental'=>'#8e24aa','Physical'=>'#e65100'];
                            foreach ($clinicalServices as $cs):
                                $cc = $catColor[$cs['category']] ?? '#6c757d';
                            ?>
                            <tr>
                                <td><span class="badge" style="background:<?= $cc ?>;"><?= htmlspecialchars($cs['category'] ?: '—') ?></span></td>
                                <td class="fw-semibold"><?= htmlspecialchars($cs['service_name'] ?: '—') ?></td>
                                <td><?= date('M d, Y', strtotime($cs['service_date'])) ?></td>
                                <td style="max-width:180px;"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= htmlspecialchars($cs['notes'] ?? '') ?>"><?= htmlspecialchars($cs['notes'] ?: '—') ?></div></td>
                                <td><span class="badge <?= $cs['status']==='done'?'bg-success':($cs['status']==='pending'?'bg-warning text-dark':'bg-secondary') ?>"><?= ucfirst($cs['status']) ?></span></td>
                                <td><?= htmlspecialchars($cs['staff'] ?: '—') ?></td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($clinicalServices)): ?><tr><td colspan="6" class="text-center text-muted py-3">No clinical services recorded yet.</td></tr><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Vaccination History -->
        <div class="card">
            <div class="card-header"><h6 class="section-title mb-0"><i class="ti ti-vaccine me-2" style="color:#e65100;"></i>Vaccination History (<?= count($immunizations) ?>)</h6></div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0" style="font-size:.85rem;">
                        <thead><tr><th>Vaccine</th><th>Dose</th><th>Date Given</th><th>Next Dose</th><th>Site</th></tr></thead>
                        <tbody>
                            <?php foreach ($immunizations as $im): ?>
                            <tr>
                                <td class="fw-semibold"><?= htmlspecialchars($im['vaccine_name']) ?></td>
                                <td>Dose <?= $im['dose_number'] ?></td>
                                <td><?= date('M d, Y', strtotime($im['date_given'])) ?></td>
                                <td><?= $im['next_dose_date'] ? date('M d, Y', strtotime($im['next_dose_date'])) : '—' ?></td>
                                <td><?= htmlspecialchars($im['site'] ?: '—') ?></td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($immunizations)): ?><tr><td colspan="5" class="text-center text-muted py-3">No vaccination records.</td></tr><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add History Record Modal -->
<div class="modal fade" id="historyModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="ti ti-history me-2"></i>Add History Record</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <?= csrfField() ?>
                <input type="hidden" name="add_history" value="1">
                <input type="hidden" name="patient_id" value="<?= $patient_id ?>">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">History Type</label>
                        <select class="form-select" name="history_type">
                            <option>Medical History</option>
                            <option>Surgical History</option>
                            <option>Family History</option>
                            <option>Allergy</option>
                            <option>Medication History</option>
                            <option>Social History</option>
                            <option>Other</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Date</label>
                        <input type="date" class="form-control" name="record_date" value="<?= date('Y-m-d') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Description <span class="text-danger">*</span></label>
                        <textarea class="form-control" name="description" rows="5" placeholder="Describe the history..." required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-plus me-1"></i>Add History</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php else: ?>
<div class="card"><div class="card-body text-center py-5 text-muted"><i class="ti ti-users" style="font-size:3rem;opacity:.4;"></i><div class="mt-2">Select a patient above to view their history.</div></div></div>
<?php endif; ?>

<?php include __DIR__ . '/../../includes/layout_footer.php'; ?>
