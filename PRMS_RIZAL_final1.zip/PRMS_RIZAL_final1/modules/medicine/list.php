<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();
$conn = getDBConnection();
$msg = '';

if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    verifyCsrf();
    $conn->query("UPDATE medicines SET status='inactive' WHERE id=".(int)$_GET['delete']);
    header('Location: list.php?msg=deleted'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $id      = (int)($_POST['id'] ?? 0);
    $name    = trim($_POST['medicine_name'] ?? '');
    $generic = trim($_POST['generic_name'] ?? '');
    $cat     = trim($_POST['category'] ?? '');
    $form    = trim($_POST['dosage_form'] ?? '');
    $str     = trim($_POST['strength'] ?? '');
    $stock   = (int)($_POST['stock_quantity'] ?? 0);
    $unit    = trim($_POST['unit'] ?? '');
    $expiry  = $_POST['expiry_date'] ?: null;

    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE medicines SET medicine_name=?,generic_name=?,category=?,dosage_form=?,strength=?,stock_quantity=?,unit=?,expiry_date=? WHERE id=?");
        $stmt->bind_param('sssssissi',$name,$generic,$cat,$form,$str,$stock,$unit,$expiry,$id);
    } else {
        $stmt = $conn->prepare("INSERT INTO medicines (medicine_name,generic_name,category,dosage_form,strength,stock_quantity,unit,expiry_date) VALUES (?,?,?,?,?,?,?,?)");
        $stmt->bind_param('sssssiss',$name,$generic,$cat,$form,$str,$stock,$unit,$expiry);
    }
    $stmt->execute();
    header('Location: list.php?msg=' . ($id>0?'updated':'added')); exit;
}

$medicines = [];
$r = $conn->query("SELECT * FROM medicines WHERE status='active' ORDER BY medicine_name");
while ($row = $r->fetch_assoc()) $medicines[] = $row;
$conn->close();

if (isset($_GET['msg'])) { $msg = ['added'=>'Medicine added.','updated'=>'Updated.','deleted'=>'Deactivated.'][$_GET['msg']] ?? ''; }
$pageTitle = 'Medicine List';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<div class="page-header"><div class="page-block">
    <h5 class="m-b-10">Medicine List</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Medicine</li><li class="breadcrumb-item active">Medicine List</li></ul>
</div></div>
<?php if ($msg): ?><div class="alert alert-success alert-dismissible fade show"><i class="ti ti-circle-check me-2"></i><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0"><i class="ti ti-pill me-2" style="color:#0d6efd;"></i>Medicine Inventory</h6>
        <button class="btn btn-primary btn-sm" onclick="openAddModal()"><i class="ti ti-plus me-1"></i>Add Medicine</button>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0">
                <thead><tr><th>Medicine Name</th><th>Generic Name</th><th>Category</th><th>Form</th><th>Strength</th><th>Stock</th><th>Unit</th><th>Expiry</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php foreach ($medicines as $m):
                        $expClass = '';
                        if ($m['expiry_date']) {
                            $days = (new DateTime($m['expiry_date']))->diff(new DateTime())->days * ((new DateTime($m['expiry_date'])) > new DateTime() ? 1 : -1);
                            if ($days < 0) $expClass = 'text-danger fw-bold';
                            elseif ($days <= 30) $expClass = 'text-warning fw-bold';
                        }
                        $stockClass = $m['stock_quantity'] <= 0 ? 'text-danger fw-bold' : ($m['stock_quantity'] <= 10 ? 'text-warning fw-bold' : 'text-success fw-bold');
                    ?>
                    <tr>
                        <td class="fw-semibold"><?= htmlspecialchars($m['medicine_name']) ?></td>
                        <td class="text-muted"><?= htmlspecialchars($m['generic_name'] ?: '—') ?></td>
                        <td><?= htmlspecialchars($m['category'] ?: '—') ?></td>
                        <td><?= htmlspecialchars($m['dosage_form'] ?: '—') ?></td>
                        <td><?= htmlspecialchars($m['strength'] ?: '—') ?></td>
                        <td class="<?= $stockClass ?>"><?= $m['stock_quantity'] ?></td>
                        <td><?= htmlspecialchars($m['unit'] ?: '—') ?></td>
                        <td class="<?= $expClass ?>"><?= $m['expiry_date'] ? date('M d, Y', strtotime($m['expiry_date'])) : '—' ?></td>
                        <td>
                            <button class="btn-edit btn btn-sm me-1" onclick="openEditModal(<?= htmlspecialchars(json_encode($m)) ?>)"><i class="ti ti-edit"></i></button>
                            <button class="btn-delete btn btn-sm" onclick="confirmDelete('<?= csrfUrl('list.php?delete=' . $m['id']) ?>','<?= htmlspecialchars($m['medicine_name']) ?>')"><i class="ti ti-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="medModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="medModalTitle"><i class="ti ti-pill me-2"></i>Add Medicine</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST"><?= csrfField() ?>
                <input type="hidden" name="id" id="medId" value="0">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6"><label class="form-label">Medicine Name *</label><input type="text" class="form-control" name="medicine_name" id="mName" required placeholder="Brand/trade name"></div>
                        <div class="col-md-6"><label class="form-label">Generic Name</label><input type="text" class="form-control" name="generic_name" id="mGeneric" placeholder="Generic name"></div>
                        <div class="col-md-4"><label class="form-label">Category</label><input type="text" class="form-control" name="category" id="mCat" placeholder="e.g. Antibiotic"></div>
                        <div class="col-md-4">
                            <label class="form-label">Dosage Form</label>
                            <select class="form-select" name="dosage_form" id="mForm">
                                <option value="">Select</option>
                                <?php foreach (['Tablet','Capsule','Syrup','Suspension','Injection','Ointment','Drops','Patch','Inhaler','Powder'] as $f): ?><option><?= $f ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4"><label class="form-label">Strength</label><input type="text" class="form-control" name="strength" id="mStr" placeholder="e.g. 500mg"></div>
                        <div class="col-md-4"><label class="form-label">Stock Quantity</label><input type="number" class="form-control" name="stock_quantity" id="mStock" value="0" min="0"></div>
                        <div class="col-md-4"><label class="form-label">Unit</label><input type="text" class="form-control" name="unit" id="mUnit" placeholder="e.g. tablet, bottle"></div>
                        <div class="col-md-4"><label class="form-label">Expiry Date</label><input type="date" class="form-control" name="expiry_date" id="mExpiry"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php
$extraJS='<script>
function openAddModal(){
    document.getElementById("medModalTitle").innerHTML=\'<i class="ti ti-pill me-2"></i>Add Medicine\';
    document.getElementById("medId").value="0";
    ["mName","mGeneric","mCat","mStr","mUnit","mExpiry"].forEach(id=>document.getElementById(id).value="");
    document.getElementById("mForm").value="";
    document.getElementById("mStock").value="0";

    new bootstrap.Modal(document.getElementById("medModal")).show();
}
function openEditModal(m){
    document.getElementById("medModalTitle").innerHTML=\'<i class="ti ti-edit me-2"></i>Edit Medicine\';
    document.getElementById("medId").value=m.id;
    document.getElementById("mName").value=m.medicine_name||"";
    document.getElementById("mGeneric").value=m.generic_name||"";
    document.getElementById("mCat").value=m.category||"";
    document.getElementById("mForm").value=m.dosage_form||"";
    document.getElementById("mStr").value=m.strength||"";
    document.getElementById("mStock").value=m.stock_quantity||"0";
    document.getElementById("mUnit").value=m.unit||"";
    document.getElementById("mExpiry").value=m.expiry_date||"";
    new bootstrap.Modal(document.getElementById("medModal")).show();
}
</script>';
include __DIR__ . '/../../includes/layout_footer.php';
?>
