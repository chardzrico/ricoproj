<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();
$conn = getDBConnection();
$msg = '';
$uid = getCurrentUser()['id'];

$CERT_TYPES = ['Fit to Work', 'Fit to Travel', 'Fit to Return to School', 'Medical Certificate (Illness)', 'Fit for Sports / Exercise Clearance', 'Pre-Employment Medical Certificate', 'Other'];

// ── Void a certificate (never hard-delete — the record stays for ───────────
//    accountability, just marked voided with a reason).
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['void_certificate'])) {
    verifyCsrf();
    $voidId = (int)($_POST['cert_id'] ?? 0);
    $reason = trim($_POST['void_reason'] ?? '');
    $owner = $conn->prepare("SELECT patient_id, cert_number FROM medical_certificates WHERE id = ?");
    $owner->bind_param('i', $voidId);
    $owner->execute();
    $ownerRow = $owner->get_result()->fetch_assoc();
    $owner->close();
    if ($ownerRow) {
        assertPatientInDoctorScope($conn, $ownerRow['patient_id']);
        $stmt = $conn->prepare("UPDATE medical_certificates SET status='voided', void_reason=? WHERE id=?");
        $stmt->bind_param('si', $reason, $voidId);
        $stmt->execute();
        logAudit('void_certificate', 'medical_certificate', $voidId, $ownerRow['cert_number'] . ($reason ? " — $reason" : ''));
    }
    header('Location: certificate_log.php?msg=voided'); exit;
}

// ── Issue a new certificate ──────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_certificate'])) {
    verifyCsrf();
    $patient_id      = (int)($_POST['patient_id'] ?? 0);
    $certTypeSelect  = trim($_POST['cert_type'] ?? '');
    $certTypeOther   = trim($_POST['cert_type_other'] ?? '');
    $cert_type       = ($certTypeSelect === 'Other' && $certTypeOther !== '') ? $certTypeOther : $certTypeSelect;
    $findings        = trim($_POST['findings'] ?? '');
    $recommendation  = trim($_POST['recommendation'] ?? '');
    $valid_from      = $_POST['valid_from'] !== '' ? $_POST['valid_from'] : null;
    $valid_until     = $_POST['valid_until'] !== '' ? $_POST['valid_until'] : null;
    $issued_date     = $_POST['issued_date'] ?: date('Y-m-d');

    if ($patient_id <= 0 || $cert_type === '') {
        header('Location: certificate_log.php?msg=norecord'); exit;
    }
    assertPatientInDoctorScope($conn, $patient_id);

    // Same numbering fix already applied to prescriptions: retry on a
    // cert_number collision (rare, but the column is UNIQUE) instead of
    // silently failing, and wrap header creation in a transaction so a
    // failure can't leave a half-created record behind.
    $conn->begin_transaction();
    $certId = null;
    $certNumber = null;
    try {
        for ($attempt = 0; $attempt < 5; $attempt++) {
            $r = $conn->query("SELECT COUNT(*) as cnt FROM medical_certificates");
            $cnt = (int)$r->fetch_assoc()['cnt'] + 1 + $attempt;
            $candidate = 'MC-' . date('Y') . '-' . str_pad((string)$cnt, 5, '0', STR_PAD_LEFT);

            $stmt = $conn->prepare("INSERT INTO medical_certificates (cert_number, patient_id, cert_type, findings, recommendation, valid_from, valid_until, issued_date, issued_by) VALUES (?,?,?,?,?,?,?,?,?)");
            $stmt->bind_param('sissssssi', $candidate, $patient_id, $cert_type, $findings, $recommendation, $valid_from, $valid_until, $issued_date, $uid);
            if ($stmt->execute()) {
                $certNumber = $candidate;
                $certId = $conn->insert_id;
                break;
            }
            if ($conn->errno !== 1062) {
                throw new Exception('certificate insert failed: ' . $conn->error);
            }
        }
        if (!$certId) {
            throw new Exception('could not generate a unique certificate number after 5 attempts');
        }
        $conn->commit();
        logAudit('create_certificate', 'medical_certificate', $certId, "$certNumber — $cert_type");
        header("Location: certificate_log.php?msg=created&cert=$certNumber"); exit;
    } catch (Exception $e) {
        $conn->rollback();
        error_log('certificate save failed: ' . $e->getMessage());
        header('Location: certificate_log.php?msg=save_failed'); exit;
    }
}

if (isset($_GET['msg'])) {
    $msg = [
        'created' => 'Certificate issued: ' . ($_GET['cert'] ?? '') . '.',
        'voided'  => 'Certificate voided.',
        'norecord' => null,
        'save_failed' => null,
    ][$_GET['msg']] ?? '';
}
$errMsg = null;
if (($_GET['msg'] ?? '') === 'norecord') $errMsg = 'Please select a patient and a certificate type.';
if (($_GET['msg'] ?? '') === 'save_failed') $errMsg = 'Could not issue the certificate — please try again. If this keeps happening, contact your administrator.';

$certificates = [];
$r = $conn->query("SELECT mc.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no, u.full_name as issued_by_name
                    FROM medical_certificates mc
                    LEFT JOIN patients p ON mc.patient_id = p.id
                    LEFT JOIN users u ON mc.issued_by = u.id
                    WHERE 1=1" . doctorScopeSql('p') . "
                    ORDER BY mc.issued_date DESC, mc.id DESC LIMIT 200");
while ($row = $r->fetch_assoc()) $certificates[] = $row;

$patients = [];
$r = $conn->query("SELECT id, patient_no, CONCAT(first_name,' ',last_name) as name FROM patients WHERE status='active'" . doctorScopeSql() . " ORDER BY last_name");
while ($row = $r->fetch_assoc()) $patients[] = $row;

// Print preview — same hand-off pattern as prescriptions: the first time a
// certificate is opened for printing, stamp who printed it and when.
$printData = null;
if (isset($_GET['print']) && is_numeric($_GET['print'])) {
    verifyCsrf();
    $certPrintId = (int)$_GET['print'];
    $stmt = $conn->prepare("UPDATE medical_certificates SET printed_at=NOW(), printed_by=? WHERE id=? AND printed_at IS NULL");
    $stmt->bind_param('ii', $uid, $certPrintId);
    $stmt->execute();
    $stmt->close();
    $stmt = $conn->prepare("SELECT mc.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no, p.date_of_birth, p.gender, p.address,
                                    u.full_name as issued_by_name, u.role, u.license_number
                             FROM medical_certificates mc
                             LEFT JOIN patients p ON mc.patient_id = p.id
                             LEFT JOIN users u ON mc.issued_by = u.id
                             WHERE mc.id = ? LIMIT 1");
    $stmt->bind_param('i', $certPrintId);
    $stmt->execute();
    $printData = $stmt->get_result()->fetch_assoc();
    if ($printData) logAudit('view_certificate', 'medical_certificate', $certPrintId, $printData['cert_number']);
}
$conn->close();

$pageTitle = 'Medical Certificates';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<div class="page-header"><div class="page-block">
    <h5 class="m-b-10">Medical Certificates</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Clinical Services</li><li class="breadcrumb-item active">Medical Certificates</li></ul>
</div></div>

<?php if ($msg): ?><div class="alert alert-success alert-dismissible fade show"><i class="ti ti-circle-check me-2"></i><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
<?php if ($errMsg): ?><div class="alert alert-danger alert-dismissible fade show"><i class="ti ti-alert-circle me-2"></i><?= htmlspecialchars($errMsg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0"><i class="ti ti-certificate me-2" style="color:#0d6efd;"></i>Medical Certificates</h6>
        <button class="btn btn-primary btn-sm" onclick="openAddCertModal()">
            <i class="ti ti-plus me-1"></i>Issue Certificate
        </button>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0">
                <thead><tr><th>Cert Number</th><th>Patient</th><th>Type</th><th>Issued Date</th><th>Validity</th><th>Issued By</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php foreach ($certificates as $c): ?>
                    <tr<?= $c['status'] === 'voided' ? ' style="opacity:.55;"' : '' ?>>
                        <td class="fw-semibold"><?= htmlspecialchars($c['cert_number']) ?></td>
                        <td>
                            <div class="fw-semibold" style="font-size:.88rem;"><?= htmlspecialchars($c['patient_name']) ?></div>
                            <div class="text-muted" style="font-size:.78rem;"><?= htmlspecialchars($c['patient_no']) ?></div>
                        </td>
                        <td><?= htmlspecialchars($c['cert_type']) ?></td>
                        <td><?= date('M d, Y', strtotime($c['issued_date'])) ?></td>
                        <td>
                            <?php if ($c['valid_from'] || $c['valid_until']): ?>
                                <?= $c['valid_from'] ? date('M d, Y', strtotime($c['valid_from'])) : '—' ?> to <?= $c['valid_until'] ? date('M d, Y', strtotime($c['valid_until'])) : '—' ?>
                            <?php else: ?>
                                <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($c['issued_by_name'] ?: '—') ?></td>
                        <td>
                            <?php if ($c['status'] === 'voided'): ?>
                            <span title="<?= htmlspecialchars($c['void_reason'] ?: '') ?>">Voided</span>
                            <?php elseif ($c['printed_at']): ?>
                            <span title="Printed"><i class="ti ti-printer me-1"></i>Printed</span>
                            <?php else: ?>
                            <span>Not yet printed</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?= csrfUrl('?print=' . $c['id']) ?>" class="btn-view btn btn-sm me-1" title="Print / View"><i class="ti ti-printer"></i></a>
                            <?php if ($c['status'] !== 'voided'): ?>
                            <button class="btn-delete btn btn-sm" title="Void" onclick='openVoidModal(<?= (int)$c['id'] ?>, <?= json_encode($c['cert_number']) ?>)'><i class="ti ti-ban"></i></button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <!-- No manual "empty" row here on purpose — DataTables' own
                         emptyTable message (layout_footer.php) handles a zero-row
                         tbody already; a hand-written colspan row as the *only*
                         row in the table can trip its column-count validation
                         (DataTables warning TN 18) instead of just displaying. -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ══ Issue Certificate Modal ══ -->
<div class="modal fade" id="certModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" style="color: #faf8f8;"><i class="ti ti-certificate me-2"></i>Issue Medical Certificate</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <?= csrfField() ?>
                <input type="hidden" name="save_certificate" value="1">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Patient *</label>
                            <select class="form-select" name="patient_id" required>
                                <option value="">Select Patient</option>
                                <?php foreach ($patients as $p): ?>
                                <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['patient_no'] . ' - ' . $p['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Certificate Type *</label>
                            <select class="form-select" name="cert_type" id="certType" onchange="toggleCertOther()" required>
                                <option value="">Select Type</option>
                                <?php foreach ($CERT_TYPES as $t): ?>
                                <option value="<?= htmlspecialchars($t) ?>"><?= htmlspecialchars($t) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6" id="certOtherWrap" style="display:none;">
                            <label class="form-label">Specify Type *</label>
                            <input type="text" class="form-control" name="cert_type_other" id="certOther" placeholder="e.g. Fitness to Drive">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Date Issued *</label>
                            <input type="date" class="form-control" name="issued_date" value="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="col-md-3"></div>
                        <div class="col-md-6">
                            <label class="form-label">Valid From</label>
                            <input type="date" class="form-control" name="valid_from">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Valid Until</label>
                            <input type="date" class="form-control" name="valid_until">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Findings / Diagnosis</label>
                            <textarea class="form-control" name="findings" rows="2" placeholder="Relevant clinical findings, if any"></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Recommendation / Remarks</label>
                            <textarea class="form-control" name="recommendation" rows="2" placeholder="e.g. Advised to rest for 3 days, fit to resume duties effective..."></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Issue Certificate</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ══ Void Certificate Modal ══ -->
<div class="modal fade" id="voidModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="ti ti-ban me-2"></i>Void Certificate <span id="voidCertNumber"></span></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <?= csrfField() ?>
                <input type="hidden" name="void_certificate" value="1">
                <input type="hidden" name="cert_id" id="voidCertId">
                <div class="modal-body">
                    <p class="text-muted" style="font-size:.85rem;">The certificate stays on record for accountability — this only marks it voided and hides it from being treated as valid.</p>
                    <label class="form-label">Reason *</label>
                    <textarea class="form-control" name="void_reason" rows="2" placeholder="e.g. Issued in error, wrong patient selected" required></textarea>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger"><i class="ti ti-ban me-1"></i>Void Certificate</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($printData): ?>
<!-- Print Preview Modal (auto-opened) -->
<div class="modal fade" id="printModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" style="color: #d5dbe2;"><i class="ti ti-certificate me-2"></i>Medical Certificate — <?= htmlspecialchars($printData['cert_number']) ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="certPrintArea" style="background:#e9edf1;padding:24px;">
                <!-- Everything below is inline-styled on purpose: printCert() lifts this
                     element's raw HTML into a bare popup window with no stylesheet. -->
                <div style="font-family:'Open Sans',sans-serif;max-width:680px;margin:0 auto;background:#fff;border:1px solid #d5dbe2;box-shadow:0 2px 10px rgba(0,0,0,.06);" id="certPrintContent">
                    <?php if ($printData['status'] === 'voided'): ?>
                    <div style="background:#c62828;color:#fff;text-align:center;padding:6px;font-weight:700;letter-spacing:1px;">VOIDED<?= $printData['void_reason'] ? ' — ' . htmlspecialchars($printData['void_reason']) : '' ?></div>
                    <?php endif; ?>
                    <!-- Letterhead -->
                    <div style="display:flex;align-items:center;gap:14px;padding:20px 28px 16px;border-bottom:3px solid #1e3a5f;">
                        <img src="<?= ASSETS_URL ?>/images/rhu_logo.png" alt="RHU Rizal" style="width:54px;height:54px;min-width:54px;border-radius:50%;object-fit:cover;border:2px solid #1e3a5f;">
                        <div style="flex:1;">
                            <div style="font-size:1.2rem;font-weight:700;color:#1e3a5f;line-height:1.25;">Rural Health Unit &ndash; Rizal</div>
                            <div style="font-size:.78rem;color:#666;">Patient Record Management System</div>
                        </div>
                        <div style="text-align:right;">
                            <div style="font-size:.68rem;color:#888;text-transform:uppercase;letter-spacing:.5px;">Certificate No.</div>
                            <div style="font-size:1.1rem;font-weight:700;color:#0d6efd;"><?= htmlspecialchars($printData['cert_number']) ?></div>
                            <div style="font-size:.75rem;color:#666;"><?= date('F d, Y', strtotime($printData['issued_date'])) ?></div>
                        </div>
                    </div>

                    <div style="padding:22px 28px;">
                        <div style="text-align:center;font-size:1.05rem;font-weight:700;color:#1e3a5f;text-transform:uppercase;letter-spacing:.5px;margin-bottom:18px;">
                            <?= htmlspecialchars($printData['cert_type']) ?>
                        </div>

                        <div style="font-size:.9rem;line-height:1.8;color:#222;margin-bottom:16px;">
                            This is to certify that <strong><?= htmlspecialchars($printData['patient_name']) ?></strong>
                            (Patient No. <?= htmlspecialchars($printData['patient_no']) ?>),
                            <?= $printData['date_of_birth'] ? (new DateTime($printData['date_of_birth']))->diff(new DateTime())->y . ' years old, ' : '' ?>
                            <?= htmlspecialchars($printData['gender'] ?: '') ?>,
                            was examined at the Rural Health Unit &ndash; Rizal on <?= date('F d, Y', strtotime($printData['issued_date'])) ?>.
                        </div>

                        <?php if ($printData['findings']): ?>
                        <div style="margin-bottom:14px;padding:10px 12px;background:#f8f9fa;border-left:3px solid #0d6efd;border-radius:0 6px 6px 0;">
                            <div style="font-size:.72rem;color:#888;text-transform:uppercase;margin-bottom:3px;">Findings</div>
                            <div style="font-size:.88rem;color:#333;"><?= nl2br(htmlspecialchars($printData['findings'])) ?></div>
                        </div>
                        <?php endif; ?>

                        <?php if ($printData['recommendation']): ?>
                        <div style="margin-bottom:14px;padding:10px 12px;background:#f8f9fa;border-left:3px solid #2e7d32;border-radius:0 6px 6px 0;">
                            <div style="font-size:.72rem;color:#888;text-transform:uppercase;margin-bottom:3px;">Recommendation</div>
                            <div style="font-size:.88rem;color:#333;"><?= nl2br(htmlspecialchars($printData['recommendation'])) ?></div>
                        </div>
                        <?php endif; ?>

                        <?php if ($printData['valid_from'] || $printData['valid_until']): ?>
                        <div style="font-size:.86rem;color:#444;margin-bottom:16px;">
                            <strong>Valid:</strong>
                            <?= $printData['valid_from'] ? date('F d, Y', strtotime($printData['valid_from'])) : '—' ?>
                            to
                            <?= $printData['valid_until'] ? date('F d, Y', strtotime($printData['valid_until'])) : '—' ?>
                        </div>
                        <?php endif; ?>

                        <p style="font-size:.84rem;color:#555;">Issued upon the request of the above-named patient for whatever legal purpose it may serve.</p>

                        <!-- Signature -->
                        <div style="margin-top:32px;display:flex;justify-content:flex-end;">
                            <div style="text-align:center;">
                                <div style="border-top:1px solid #333;padding-top:6px;min-width:220px;">
                                    <div style="font-weight:600;font-size:.9rem;"><?= htmlspecialchars($printData['issued_by_name']) ?></div>
                                    <div style="font-size:.75rem;color:#666;"><?= ucfirst($printData['role']) ?>, RHU Rizal</div>
                                    <?php if (!empty($printData['license_number'])): ?>
                                    <div style="font-size:.72rem;color:#888;">License No. <?= htmlspecialchars($printData['license_number']) ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div style="border-top:1px solid #e5e8eb;padding:10px 28px;display:flex;justify-content:space-between;font-size:.68rem;color:#999;">
                        <span>Generated by PRMS &bull; Rural Health Unit, Rizal</span>
                        <?php if (!empty($printData['printed_at'])): ?><span>Printed <?= date('M d, Y g:i A', strtotime($printData['printed_at'])) ?></span><?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="printCert()"><i class="ti ti-printer me-1"></i>Print / Save PDF</button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php
$extraJS = '<script>
function openAddCertModal(){
    new bootstrap.Modal(document.getElementById("certModal")).show();
}
function toggleCertOther(){
    const isOther = document.getElementById("certType").value === "Other";
    document.getElementById("certOtherWrap").style.display = isOther ? "" : "none";
    document.getElementById("certOther").required = isOther;
}
function openVoidModal(id, certNumber){
    document.getElementById("voidCertId").value = id;
    document.getElementById("voidCertNumber").textContent = certNumber;
    new bootstrap.Modal(document.getElementById("voidModal")).show();
}
' . ($printData ? 'window.addEventListener("load",function(){ new bootstrap.Modal(document.getElementById("printModal")).show(); });' : '') . '
function printCert(){
    const content=document.getElementById("certPrintContent").innerHTML;
    const w=window.open("","_blank","width=800,height=700");
    w.document.write(`<!DOCTYPE html><html><head><title>Medical Certificate</title><style>body{font-family:Open Sans,sans-serif;margin:32px;}@media print{body{margin:0;}}</style></head><body>${content}</body></html>`);
    w.document.close();
    w.focus();
    setTimeout(()=>w.print(),500);
}
</script>';
include __DIR__ . '/../../includes/layout_footer.php';
?>
