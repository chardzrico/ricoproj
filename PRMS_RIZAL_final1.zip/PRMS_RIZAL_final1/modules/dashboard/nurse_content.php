<?php
// ── Nurse Dashboard: vitals + vaccination schedule for today ───────────────
// Expects: $conn (open mysqli connection) from dashboard.php

$stats = [];
$queries = [
    'awaiting_vitals'  => "SELECT COUNT(*) as cnt FROM checkups WHERE checkup_date = CURDATE() AND status = 'pending'",
    'vaccinated_today' => "SELECT COUNT(*) as cnt FROM immunization_records WHERE date_given = CURDATE()",
    'upcoming_doses'   => "SELECT COUNT(*) as cnt FROM immunization_records WHERE next_dose_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)",
    'checkups_today'   => "SELECT COUNT(*) as cnt FROM checkups WHERE checkup_date = CURDATE()",
];
foreach ($queries as $key => $sql) {
    $r = $conn->query($sql);
    $stats[$key] = $r ? (int)$r->fetch_assoc()['cnt'] : 0;
}

// ── Today's checkups awaiting vitals ────────────────────────────────────────
$awaitingVitals = [];
$r = $conn->query("
    SELECT c.id, c.checkup_time, c.chief_complaint, c.blood_pressure,
           CONCAT(p.first_name,' ',p.last_name) as name, p.patient_no
    FROM checkups c
    JOIN patients p ON p.id = c.patient_id
    WHERE c.checkup_date = CURDATE() AND c.status = 'pending'
    ORDER BY c.checkup_time ASC
    LIMIT 10
");
while ($row = $r->fetch_assoc()) $awaitingVitals[] = $row;

// ── Vaccination schedule (next 7 days) ──────────────────────────────────────
$vaccSchedule = [];
$r = $conn->query("
    SELECT ir.id, ir.next_dose_date, ir.dose_number, v.vaccine_name,
           CONCAT(p.first_name,' ',p.last_name) as name, p.patient_no
    FROM immunization_records ir
    JOIN patients p ON p.id = ir.patient_id
    JOIN vaccines v ON v.id = ir.vaccine_id
    WHERE ir.next_dose_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
    ORDER BY ir.next_dose_date ASC
    LIMIT 10
");
while ($row = $r->fetch_assoc()) $vaccSchedule[] = $row;
?>

<!-- ══ Stat Cards ══ -->
<div class="row g-3 mb-4">
    <?php
    $cards = [
        ['icon'=>'ti-stethoscope',  'color'=>'#e65100','bg'=>'#fff3e0','value'=>$stats['awaiting_vitals'], 'label'=>'Awaiting Vitals Today'],
        ['icon'=>'ti-vaccine',      'color'=>'#2e7d32','bg'=>'#e8f5e9','value'=>$stats['vaccinated_today'],'label'=>'Vaccinated Today'],
        ['icon'=>'ti-calendar-event','color'=>'#c62828','bg'=>'#fce4ec','value'=>$stats['upcoming_doses'],  'label'=>'Upcoming Doses (7 days)'],
        ['icon'=>'ti-clipboard-list','color'=>'#1565c0','bg'=>'#e3f2fd','value'=>$stats['checkups_today'],  'label'=>'Checkups Today'],
    ];
    foreach ($cards as $c):
    ?>
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card h-100">
            <div class="card-body d-flex align-items-center gap-3 py-3">
                <div class="stat-icon" style="background:<?= $c['bg'] ?>;flex-shrink:0;">
                    <i class="ti <?= $c['icon'] ?>" style="color:<?= $c['color'] ?>;font-size:1.45rem;"></i>
                </div>
                <div>
                    <div class="fw-bold" style="font-size:1.9rem;color:<?= $c['color'] ?>;line-height:1.1;"><?= $c['value'] ?></div>
                    <div class="text-muted" style="font-size:.82rem;"><?= $c['label'] ?></div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- ══ Quick Actions ══ -->
<div class="row g-3 mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-body d-flex flex-wrap gap-2">
                <a href="<?= BASE_URL ?>/modules/checkups/record_vitals.php" class="btn btn-primary btn-sm">
                    <i class="ti ti-stethoscope me-1"></i>Record Vitals
                </a>
                <a href="<?= BASE_URL ?>/modules/vaccination/immunization_record.php" class="btn btn-outline-success btn-sm">
                    <i class="ti ti-vaccine me-1"></i>Record Vaccination
                </a>
                <a href="<?= BASE_URL ?>/modules/vaccination/schedule.php" class="btn btn-outline-primary btn-sm">
                    <i class="ti ti-calendar me-1"></i>Full Schedule
                </a>
            </div>
        </div>
    </div>
</div>

<!-- ══ Vitals Queue + Vaccination Schedule ══ -->
<div class="row g-3">
    <div class="col-xl-6 col-md-12">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h6 class="section-title mb-0">
                    <i class="ti ti-stethoscope me-2" style="color:#0d6efd;"></i>Today's Vitals Queue
                </h6>
                <a href="<?= BASE_URL ?>/modules/checkups/record_vitals.php" class="btn btn-sm btn-outline-primary">Open</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0" style="font-size:.86rem;">
                        <thead>
                            <tr>
                                <th>Time</th>
                                <th>Patient</th>
                                <th>Chief Complaint</th>
                                <th>BP</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($awaitingVitals)): ?>
                            <tr><td colspan="4" class="text-center text-muted py-4">No patients awaiting vitals today.</td></tr>
                            <?php else: foreach ($awaitingVitals as $a): ?>
                            <tr>
                                <td><?= $a['checkup_time'] ? date('h:i A', strtotime($a['checkup_time'])) : '—' ?></td>
                                <td class="fw-semibold"><?= htmlspecialchars($a['name']) ?> <span class="text-muted" style="font-size:.76rem;">(<?= htmlspecialchars($a['patient_no']) ?>)</span></td>
                                <td><?= htmlspecialchars($a['chief_complaint'] ?: '—') ?></td>
                                <td><?= htmlspecialchars($a['blood_pressure'] ?: '—') ?></td>
                            </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-6 col-md-12">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h6 class="section-title mb-0">
                    <i class="ti ti-vaccine me-2" style="color:#0d6efd;"></i>Vaccination Schedule
                    <small class="text-muted fw-normal ms-1" style="font-size:.78rem;">(Next 7 Days)</small>
                </h6>
                <a href="<?= BASE_URL ?>/modules/vaccination/schedule.php" class="btn btn-sm btn-outline-primary">Open</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0" style="font-size:.86rem;">
                        <thead>
                            <tr>
                                <th>Due Date</th>
                                <th>Patient</th>
                                <th>Vaccine</th>
                                <th>Dose</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($vaccSchedule)): ?>
                            <tr><td colspan="4" class="text-center text-muted py-4">No upcoming doses in the next 7 days.</td></tr>
                            <?php else: foreach ($vaccSchedule as $v): ?>
                            <tr>
                                <td><?= date('M d, Y', strtotime($v['next_dose_date'])) ?></td>
                                <td class="fw-semibold"><?= htmlspecialchars($v['name']) ?> <span class="text-muted" style="font-size:.76rem;">(<?= htmlspecialchars($v['patient_no']) ?>)</span></td>
                                <td><?= htmlspecialchars($v['vaccine_name']) ?></td>
                                <td><span class="badge bg-primary bg-opacity-10 text-primary">Dose <?= $v['dose_number'] ?></span></td>
                            </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
