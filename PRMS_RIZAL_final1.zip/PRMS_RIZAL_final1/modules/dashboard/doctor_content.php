<?php
// ── Doctor Dashboard: "My Patients Today" — scoped to patients this doctor
// has been assigned (patients.assigned_doctor_id), set by an admin. ───────
// Expects: $conn (open mysqli connection) from dashboard.php

if (!isset($conn) || !is_object($conn) || !method_exists($conn, 'query')) {
    require_once __DIR__ . '/../../config/database.php';
    $conn = getDBConnection();
}
require_once __DIR__ . '/../../includes/helpers.php';

$doctorId = (int) getCurrentUser()['id'];

$stats = [];
$queries = [
    'checkups_today'  => "SELECT COUNT(*) as cnt FROM checkups c JOIN patients p ON p.id=c.patient_id WHERE c.checkup_date = CURDATE() AND p.assigned_doctor_id = $doctorId",
    'pending_today'   => "SELECT COUNT(*) as cnt FROM checkups c JOIN patients p ON p.id=c.patient_id WHERE c.checkup_date = CURDATE() AND c.status = 'pending' AND p.assigned_doctor_id = $doctorId",
    'completed_today' => "SELECT COUNT(*) as cnt FROM checkups c JOIN patients p ON p.id=c.patient_id WHERE c.checkup_date = CURDATE() AND c.status = 'completed' AND p.assigned_doctor_id = $doctorId",
    'draft_today'     => "SELECT COUNT(*) as cnt FROM checkups c JOIN patients p ON p.id=c.patient_id WHERE c.checkup_date = CURDATE() AND c.status = 'draft' AND p.assigned_doctor_id = $doctorId",
    'prescriptions'   => "SELECT COUNT(*) as cnt FROM prescriptions WHERE prescription_date = CURDATE() AND prescribed_by = $doctorId",
    'my_patients'     => "SELECT COUNT(*) as cnt FROM patients WHERE status='active' AND assigned_doctor_id = $doctorId",
];
foreach ($queries as $key => $sql) {
    $r = $conn->query($sql);
    $stats[$key] = (is_object($r) && method_exists($r, 'fetch_assoc')) ? (int)$r->fetch_assoc()['cnt'] : 0;
}

// ── "My Patients Today" queue — only this doctor's assigned patients ──────
$consultQueue = [];
$r = $conn->query("
    SELECT c.id, c.checkup_time, c.chief_complaint, c.status,
           CONCAT(p.first_name,' ',p.last_name) as name, p.patient_no
    FROM checkups c
    JOIN patients p ON p.id = c.patient_id
    WHERE c.checkup_date = CURDATE() AND p.assigned_doctor_id = $doctorId
    ORDER BY (c.status = 'draft') DESC, (c.status = 'pending') DESC, c.checkup_time ASC
    LIMIT 12
");
if (is_object($r) && method_exists($r, 'fetch_assoc')) {
    while ($row = $r->fetch_assoc()) $consultQueue[] = $row;
}
?>

<!-- ══ Stat Cards ══ -->
<div class="row g-3 mb-4">
    <?php
    $cards = [
        ['icon'=>'ti-users',         'color'=>'#37474f','bg'=>'#eceff1','value'=>$stats['my_patients'],    'label'=>'My Patients (assigned)'],
        ['icon'=>'ti-clipboard-list','color'=>'#1565c0','bg'=>'#e3f2fd','value'=>$stats['checkups_today'], 'label'=>"Today's Consultations"],
        ['icon'=>'ti-clock',         'color'=>'#e65100','bg'=>'#fff3e0','value'=>$stats['pending_today'],  'label'=>'Pending'],
        ['icon'=>'ti-circle-check',  'color'=>'#2e7d32','bg'=>'#e8f5e9','value'=>$stats['completed_today'],'label'=>'Completed Today'],
        ['icon'=>'ti-pencil',   'color'=>'#b28704','bg'=>'#fff8e1','value'=>$stats['draft_today'],    'label'=>'Drafts to Finish'],
        ['icon'=>'ti-pill',           'color'=>'#c62828','bg'=>'#fce4ec','value'=>$stats['prescriptions'],  'label'=>'Prescriptions Today'],
    ];
    renderStatCards($cards);
    ?>
</div>

<!-- ══ Quick Actions ══ -->
<div class="row g-3 mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-body d-flex flex-wrap gap-2">
                <a href="<?= BASE_URL ?>/modules/checkups/consultation_notes.php" class="btn btn-primary btn-sm">
                    <i class="ti ti-notes me-1"></i>Consultation Notes
                </a>
                <a href="<?= BASE_URL ?>/modules/checkups/patient_history.php" class="btn btn-outline-primary btn-sm">
                    <i class="ti ti-history me-1"></i>Patient History
                </a>
                <a href="<?= BASE_URL ?>/modules/checkups/referrals.php" class="btn btn-outline-primary btn-sm">
                    <i class="ti ti-file-description me-1"></i>Referrals / Lab Orders
                </a>
                <a href="<?= BASE_URL ?>/modules/medicine/prescription_log.php" class="btn btn-outline-secondary btn-sm">
                    <i class="ti ti-pill me-1"></i>Prescription Log
                </a>
            </div>
        </div>
    </div>
</div>

<!-- ══ Today's Consultation Queue ══ -->
<div class="row g-3">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h6 class="section-title mb-0">
                    <i class="ti ti-clipboard-list me-2" style="color:#0d6efd;"></i>My Patients Today
                </h6>
                <a href="<?= BASE_URL ?>/modules/checkups/consultation_notes.php" class="btn btn-sm btn-outline-primary">Open Full List</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0" style="font-size:.88rem;">
                        <thead>
                            <tr>
                                <th>Time</th>
                                <th>Patient</th>
                                <th>Chief Complaint</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($consultQueue)): ?>
                            <tr><td colspan="4" class="text-center text-muted py-4">No consultations scheduled today for your assigned patients.</td></tr>
                            <?php else: foreach ($consultQueue as $c): $isDraft = $c['status'] === 'draft'; ?>
                            <tr<?= $isDraft ? ' style="background:#fffbea;"' : '' ?>>
                                <td><?= $c['checkup_time'] ? date('h:i A', strtotime($c['checkup_time'])) : '—' ?></td>
                                <td class="fw-semibold"><?= htmlspecialchars($c['name']) ?> <span class="text-muted" style="font-size:.78rem;">(<?= htmlspecialchars($c['patient_no']) ?>)</span></td>
                                <td><?= htmlspecialchars($c['chief_complaint'] ?: '—') ?></td>
                                <td>
                                    <?php
                                    $statusBadge = ['pending'=>'bg-warning text-dark','completed'=>'bg-success','cancelled'=>'bg-secondary','draft'=>'bg-warning text-dark'][$c['status']] ?? 'bg-secondary';
                                    ?>
                                    <span class="badge <?= $statusBadge ?>"><?= $isDraft ? '<i class="ti ti-pencil me-1"></i>Draft' : ucfirst($c['status']) ?></span>
                                </td>
                            </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
