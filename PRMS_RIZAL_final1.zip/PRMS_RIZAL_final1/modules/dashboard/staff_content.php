<?php
// ── Staff Dashboard: patient registration + queueing ───────────────────────
// Expects: $conn (open mysqli connection) from dashboard.php

if (!isset($conn) || !is_object($conn) || !method_exists($conn, 'query')) {
    require_once __DIR__ . '/../../config/database.php';
    $conn = getDBConnection();
}
require_once __DIR__ . '/../../includes/helpers.php';

$stats = [];
$queries = [
    'registered_today' => "SELECT COUNT(*) as cnt FROM patients WHERE DATE(created_at) = CURDATE()",
    'active_patients'  => "SELECT COUNT(*) as cnt FROM patients WHERE status='active'",
    'in_queue_today'    => "SELECT COUNT(*) as cnt FROM patient_queue WHERE queue_date = CURDATE() AND status IN ('waiting','serving')",
    'served_today'      => "SELECT COUNT(*) as cnt FROM patient_queue WHERE queue_date = CURDATE() AND status = 'done'",
];
foreach ($queries as $key => $sql) {
    $r = $conn->query($sql);
    $stats[$key] = (is_object($r) && method_exists($r, 'fetch_assoc')) ? (int)$r->fetch_assoc()['cnt'] : 0;
}

// ── Queue counts per category (today) ──────────────────────────────────────
$categories = ['Dental', 'Physical', 'Mental', 'Medical'];
$categoryCounts = [];
foreach ($categories as $cat) {
    $stmt = $conn->prepare("SELECT COUNT(*) as cnt FROM patient_queue WHERE category=? AND queue_date=CURDATE() AND status IN ('waiting','serving')");
    if ($stmt) {
        $stmt->bind_param('s', $cat);
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            $row = $result ? $result->fetch_assoc() : null;
            $categoryCounts[$cat] = (int)($row['cnt'] ?? 0);
        } else {
            $categoryCounts[$cat] = 0;
        }
        $stmt->close();
    } else {
        $categoryCounts[$cat] = 0;
    }
}

// ── Patients currently waiting (today) ──────────────────────────────────────
$waitingList = [];
$r = $conn->query("
    SELECT pq.id, pq.queue_no, pq.category, pq.status, pq.time_in,
           CONCAT(p.first_name,' ',p.last_name) as name, p.patient_no
    FROM patient_queue pq
    JOIN patients p ON p.id = pq.patient_id
    WHERE pq.queue_date = CURDATE() AND pq.status IN ('waiting','serving')
    ORDER BY pq.category, pq.queue_no
    LIMIT 10
");
if (is_object($r) && method_exists($r, 'fetch_assoc')) {
    while ($row = $r->fetch_assoc()) $waitingList[] = $row;
}
?>

<!-- ══ Stat Cards ══ -->
<div class="row g-3 mb-4">
    <?php
    $cards = [
        ['icon'=>'ti-user-plus',  'color'=>'#1565c0','bg'=>'#e3f2fd','value'=>$stats['registered_today'],'label'=>'Registered Today'],
        ['icon'=>'ti-users',      'color'=>'#2e7d32','bg'=>'#e8f5e9','value'=>$stats['active_patients'], 'label'=>'Active Patients'],
        ['icon'=>'ti-clock',      'color'=>'#e65100','bg'=>'#fff3e0','value'=>$stats['in_queue_today'],  'label'=>'In Queue Today'],
        ['icon'=>'ti-circle-check','color'=>'#2e7d32','bg'=>'#e8f5e9','value'=>$stats['served_today'],   'label'=>'Served Today'],
    ];
    renderStatCards($cards);
    ?>
</div>

<!-- ══ Registration + Queue Overview ══ -->
<div class="row g-3 mb-4">
    <div class="col-xl-4 col-md-12">
        <div class="card h-100">
            <div class="card-header">
                <h6 class="section-title mb-0">
                    <i class="ti ti-user-plus me-2" style="color:#0d6efd;"></i>Patient Registration
                </h6>
            </div>
            <div class="card-body d-flex flex-column gap-2">
                <p class="text-muted" style="font-size:.85rem;">Register a new patient or add an existing one to today's queue.</p>
                <a href="<?= BASE_URL ?>/patients.php" class="btn btn-primary btn-sm">
                    <i class="ti ti-user-plus me-1"></i>Register Patient
                </a>
                <a href="<?= BASE_URL ?>/modules/services/queueing.php" class="btn btn-outline-primary btn-sm">
                    <i class="ti ti-clock me-1"></i>Go to Queueing
                </a>
            </div>
        </div>
    </div>

    <div class="col-xl-8 col-md-12">
        <div class="card h-100">
            <div class="card-header">
                <h6 class="section-title mb-0">
                    <i class="ti ti-list-details me-2" style="color:#0d6efd;"></i>Queue by Category
                    <small class="text-muted fw-normal ms-1" style="font-size:.78rem;">(Today, waiting + serving)</small>
                </h6>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <?php
                    $catColors = ['Dental'=>['#0d6efd','#e3f2fd'],'Physical'=>['#2e7d32','#e8f5e9'],'Mental'=>['#7b1fa2','#f3e5f5'],'Medical'=>['#c62828','#fce4ec']];
                    foreach ($categoryCounts as $cat => $cnt):
                        [$color, $bg] = $catColors[$cat];
                    ?>
                    <div class="col-6 col-md-3">
                        <div class="text-center p-3" style="background:<?= $bg ?>;border-radius:10px;">
                            <div class="fw-bold" style="font-size:1.6rem;color:<?= $color ?>;"><?= $cnt ?></div>
                            <div class="text-muted" style="font-size:.82rem;"><?= $cat ?></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ══ Currently Waiting Table ══ -->
<div class="row g-3">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h6 class="section-title mb-0">
                    <i class="ti ti-hourglass me-2" style="color:#0d6efd;"></i>Currently Waiting / Serving
                </h6>
                <a href="<?= BASE_URL ?>/modules/services/queueing.php" class="btn btn-sm btn-outline-primary">View All</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0" style="font-size:.88rem;">
                        <thead>
                            <tr>
                                <th>Queue #</th>
                                <th>Patient</th>
                                <th>Category</th>
                                <th>Status</th>
                                <th>Time In</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($waitingList)): ?>
                            <tr><td colspan="5" class="text-center text-muted py-4">No patients currently in queue.</td></tr>
                            <?php else: foreach ($waitingList as $w): ?>
                            <tr>
                                <td><span class="badge bg-primary bg-opacity-10 text-primary fw-semibold">#<?= $w['queue_no'] ?></span></td>
                                <td class="fw-semibold"><?= htmlspecialchars($w['name']) ?> <span class="text-muted" style="font-size:.78rem;">(<?= htmlspecialchars($w['patient_no']) ?>)</span></td>
                                <td><?= htmlspecialchars($w['category']) ?></td>
                                <td><span class="badge <?= $w['status']==='serving' ? 'bg-success' : 'bg-warning text-dark' ?>"><?= ucfirst($w['status']) ?></span></td>
                                <td><?= date('h:i A', strtotime($w['time_in'])) ?></td>
                            </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
