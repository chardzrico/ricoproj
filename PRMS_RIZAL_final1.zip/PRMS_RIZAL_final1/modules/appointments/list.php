<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();

$conn = getDBConnection();
$msg = '';
$uid = getCurrentUser()['id'];

// ── Update an appointment's status (approve / schedule / reject / complete) ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $id            = (int)($_POST['id'] ?? 0);
    $status        = $_POST['status'] ?? 'pending';
    $scheduledDate = !empty($_POST['scheduled_date']) ? $_POST['scheduled_date'] : null;
    $scheduledTime = !empty($_POST['scheduled_time']) ? $_POST['scheduled_time'] : null;
    $staffNotes    = trim($_POST['staff_notes'] ?? '');
    $validStatuses = ['pending', 'approved', 'rejected', 'completed', 'cancelled'];

    if ($id > 0 && in_array($status, $validStatuses, true)) {
        $stmt = $conn->prepare("UPDATE appointments SET status=?, scheduled_date=?, scheduled_time=?, staff_notes=?, handled_by=? WHERE id=?");
        $stmt->bind_param('ssssii', $status, $scheduledDate, $scheduledTime, $staffNotes, $uid, $id);
        if ($stmt->execute() && in_array($status, ['approved', 'rejected', 'completed'], true)) {
            $r2 = $conn->prepare("SELECT a.category, p.user_id FROM appointments a JOIN patients p ON p.id = a.patient_id WHERE a.id = ?");
            $r2->bind_param('i', $id);
            $r2->execute();
            $apptInfo = $r2->get_result()->fetch_assoc();
            $r2->close();
            if ($apptInfo && $apptInfo['user_id']) {
                $statusText = ['approved' => 'approved', 'rejected' => 'declined', 'completed' => 'marked completed'][$status];
                notifyUser(
                    (int)$apptInfo['user_id'],
                    'appointment_status',
                    'Appointment ' . $statusText,
                    'Your ' . $apptInfo['category'] . ' appointment request was ' . $statusText . ($scheduledDate ? ' — scheduled for ' . date('M d, Y', strtotime($scheduledDate)) : '') . '.',
                    BASE_URL . '/patient/appointments.php',
                    'appointment',
                    $id
                );
            }
        }
        $stmt->close();
    }
    header('Location: ' . BASE_URL . '/modules/appointments/list.php?msg=updated');
    exit;
}

// ── Follow-up scheduling (admin action — doctors only flag it) ─────────────
// A doctor flags a checkup with needs_follow_up during consultation; here
// the admin sets the actual date, keeping scheduling separate from the
// clinical record itself.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['schedule_followup'])) {
    verifyCsrf();
    $checkupId = (int)($_POST['checkup_id'] ?? 0);
    $followUpDate = $_POST['followup_date'] ?: null;
    if ($checkupId > 0 && $followUpDate) {
        $stmt = $conn->prepare("UPDATE checkups SET follow_up_date=? WHERE id=?");
        $stmt->bind_param('si', $followUpDate, $checkupId);
        $stmt->execute();
        $stmt->close();
    }
    header('Location: ' . BASE_URL . '/modules/appointments/list.php?msg=followup_scheduled');
    exit;
}

// Mark a flagged follow-up as handled (removes it from the pending list
// without touching the checkup's other clinical fields).
if (isset($_GET['clear_followup']) && is_numeric($_GET['clear_followup'])) {
    verifyCsrf();
    $conn->query("UPDATE checkups SET needs_follow_up=0 WHERE id=" . (int)$_GET['clear_followup']);
    header('Location: ' . BASE_URL . '/modules/appointments/list.php?msg=followup_cleared');
    exit;
}

// ── Fetch appointments (with patient + service info) ────────────────────────
$validStatuses = ['pending', 'approved', 'rejected', 'completed', 'cancelled'];
$statusFilter  = $_GET['status'] ?? '';
$rangeFilter   = $_GET['range'] ?? 'all';
$today         = date('Y-m-d');

$where  = [];
$params = [];
$types  = '';
if (in_array($statusFilter, $validStatuses, true)) {
    $where[] = 'a.status = ?';
    $params[] = $statusFilter;
    $types .= 's';
}
if ($rangeFilter === 'today') {
    $where[] = '(a.preferred_date = ? OR a.scheduled_date = ?)';
    $params[] = $today; $params[] = $today;
    $types .= 'ss';
} elseif ($rangeFilter === 'upcoming') {
    $where[] = "a.status IN ('pending','approved')";
}
$whereSql = $where ? (' WHERE ' . implode(' AND ', $where)) : '';

$appointments = [];
$stmt = $conn->prepare("
    SELECT a.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no, p.contact_number,
           s.service_name, u.full_name as handled_by_name, pq.id as queue_id
    FROM appointments a
    JOIN patients p ON p.id = a.patient_id
    LEFT JOIN services s ON s.id = a.service_id
    LEFT JOIN users u ON u.id = a.handled_by
    LEFT JOIN patient_queue pq ON pq.appointment_id = a.id AND pq.status IN ('waiting','serving')
    $whereSql
    ORDER BY FIELD(a.status,'pending','approved','completed','rejected','cancelled'), a.preferred_date ASC
");
if ($types !== '') $stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $appointments[] = $row;
$stmt->close();

$pendingCount = 0;
foreach ($appointments as $a) if ($a['status'] === 'pending') $pendingCount++;

// How many of today's approved appointments are ready to check in but
// haven't been yet — surfaced as a quick link to the queueing page.
$readyTodayCount = 0;
$r = $conn->prepare("
    SELECT COUNT(*) c FROM appointments a
    LEFT JOIN patient_queue pq ON pq.appointment_id = a.id AND pq.status IN ('waiting','serving')
    WHERE a.status='approved' AND a.scheduled_date = ? AND pq.id IS NULL
");
$r->bind_param('s', $today);
$r->execute();
$readyTodayCount = (int)$r->get_result()->fetch_assoc()['c'];
$r->close();

// ── Follow-ups flagged by doctors, waiting on the admin to set a date ──────
$followUps = [];
$r = $conn->query("
    SELECT c.id, c.checkup_date, c.chief_complaint, c.diagnosis, c.follow_up_date,
           p.id as patient_id, p.patient_no, CONCAT(p.first_name,' ',p.last_name) as patient_name,
           u.full_name as doctor_name
    FROM checkups c
    JOIN patients p ON p.id = c.patient_id
    LEFT JOIN users u ON u.id = c.attending_staff
    WHERE c.needs_follow_up = 1
    ORDER BY (c.follow_up_date IS NULL) DESC, c.follow_up_date ASC, c.checkup_date DESC
    LIMIT 100
");
while ($row = $r->fetch_assoc()) $followUps[] = $row;
$followUpPendingCount = 0;
foreach ($followUps as $f) if (empty($f['follow_up_date'])) $followUpPendingCount++;

$conn->close();

if (isset($_GET['msg'])) {
    $msg = [
        'updated'            => 'Appointment updated.',
        'followup_scheduled' => 'Follow-up date scheduled.',
        'followup_cleared'   => 'Follow-up flag cleared.',
    ][$_GET['msg']] ?? $msg;
}

$pageTitle = 'Appointments';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';

$statusBadge = [
    'pending'   => 'bg-warning text-dark',
    'approved'  => 'bg-success',
    'rejected'  => 'bg-danger',
    'completed' => 'bg-primary',
    'cancelled' => 'bg-secondary',
];
?>

<!-- ══ Breadcrumb ══ -->
<div class="page-header">
    <div class="page-block">
        <div class="row align-items-center">
            <div class="col-md-12">
                <h5 class="m-b-10">Appointments</h5>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li>
                    <li class="breadcrumb-item active">Appointments</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php if ($msg): ?>
<div class="alert alert-success alert-dismissible fade show d-flex align-items-center gap-2" role="alert">
    <i class="ti ti-circle-check fs-5"></i><span><?= htmlspecialchars($msg) ?></span>
    <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if ($readyTodayCount > 0): ?>
<div class="alert alert-info alert-dismissible fade show d-flex align-items-center gap-2" role="alert">
    <i class="ti ti-calendar-event fs-5"></i>
    <span><?= $readyTodayCount ?> approved appointment<?= $readyTodayCount > 1 ? 's are' : ' is' ?> scheduled for today and ready to check in.</span>
    <a href="<?= BASE_URL ?>/modules/services/queueing.php" class="btn btn-sm btn-info text-white ms-auto">Go to Queueing <i class="ti ti-arrow-right ms-1"></i></a>
</div>
<?php endif; ?>

<!-- ══ Stat Cards ══ -->
<div class="row g-3 mb-4">
    <?php
    $counts = ['pending'=>0,'approved'=>0,'completed'=>0,'rejected'=>0];
    foreach ($appointments as $a) if (isset($counts[$a['status']])) $counts[$a['status']]++;
    $cards = [
        ['icon'=>'ti-clock',        'color'=>'#e65100','bg'=>'#fff3e0','value'=>$counts['pending'],  'label'=>'Pending Review'],
        ['icon'=>'ti-circle-check', 'color'=>'#2e7d32','bg'=>'#e8f5e9','value'=>$counts['approved'], 'label'=>'Approved / Scheduled'],
        ['icon'=>'ti-clipboard-check','color'=>'#1565c0','bg'=>'#e3f2fd','value'=>$counts['completed'],'label'=>'Completed'],
        ['icon'=>'ti-x',            'color'=>'#c62828','bg'=>'#fce4ec','value'=>$counts['rejected'], 'label'=>'Rejected'],
    ];
    foreach ($cards as $c):
    ?>
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card h-100">
            <div class="card-body d-flex align-items-center gap-3 py-3">
                <div class="stat-icon" style="background:<?= $c['bg'] ?>;flex-shrink:0;">
                    <i class="ti <?= $c['icon'] ?>" style="color:<?= $c['color'] ?>;font-size:1.45rem;"></i>
                </div>
                <div>
                    <div class="fw-bold" style="font-size:1.9rem;color:<?= $c['color'] ?>;line-height:1.1;"><?= $c['value'] ?></div>
                    <div class="text-muted" style="font-size:.82rem;"><?= $c['label'] ?></div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- ══ Follow-ups to Schedule (flagged by doctors during consultation) ══ -->
<div class="card mb-4">
    <div class="card-header">
        <h6 class="section-title mb-0">
            <i class="ti ti-calendar-plus me-2" style="color:#8e24aa;"></i>Follow-ups to Schedule
            <?php if ($followUpPendingCount > 0): ?><span class="badge bg-warning text-dark ms-1"><?= $followUpPendingCount ?> awaiting a date</span><?php endif; ?>
        </h6>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0">
                <thead>
                    <tr><th>Patient</th><th>Consultation Date</th><th>Doctor</th><th>Chief Complaint / Findings</th><th>Follow-up Date</th><th>Actions</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($followUps as $f): ?>
                    <tr>
                        <td>
                            <div class="fw-semibold" style="font-size:.88rem;"><?= htmlspecialchars($f['patient_name']) ?></div>
                            <div class="text-muted" style="font-size:.78rem;"><?= htmlspecialchars($f['patient_no']) ?></div>
                        </td>
                        <td><?= date('M d, Y', strtotime($f['checkup_date'])) ?></td>
                        <td><?= htmlspecialchars($f['doctor_name'] ?: '—') ?></td>
                        <td style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= htmlspecialchars(($f['chief_complaint'] ?: '') . ' — ' . ($f['diagnosis'] ?: '')) ?>"><?= htmlspecialchars($f['chief_complaint'] ?: ($f['diagnosis'] ?: '—')) ?></td>
                        <td>
                            <?php if ($f['follow_up_date']): ?>
                                <span class="badge bg-success"><?= date('M d, Y', strtotime($f['follow_up_date'])) ?></span>
                            <?php else: ?>
                                <span class="badge bg-warning text-dark">Not yet scheduled</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-outline-primary me-1" onclick="openFollowupModal(<?= htmlspecialchars(json_encode($f)) ?>)" title="Set follow-up date"><i class="ti ti-calendar-event"></i></button>
                            <button class="btn btn-sm btn-outline-secondary" onclick="confirmDelete('<?= csrfUrl('list.php?clear_followup=' . $f['id']) ?>','this follow-up flag')" title="Clear flag (handled)"><i class="ti ti-check"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <!-- No manual "empty" row on purpose — see the note in
                         modules/certificates/certificate_log.php for why. -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ══ Appointments Table ══ -->
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h6 class="section-title mb-0">
            <i class="ti ti-calendar-event me-2" style="color:#0d6efd;"></i>Appointment Requests
            <?php if ($pendingCount > 0): ?><span class="badge bg-warning text-dark ms-1"><?= $pendingCount ?> pending</span><?php endif; ?>
        </h6>
        <form method="GET" class="d-flex align-items-center gap-2">
            <select name="range" class="form-select form-select-sm" style="width:auto;" onchange="this.form.submit()">
                <option value="all" <?= $rangeFilter === 'all' ? 'selected' : '' ?>>All Dates</option>
                <option value="today" <?= $rangeFilter === 'today' ? 'selected' : '' ?>>Today</option>
                <option value="upcoming" <?= $rangeFilter === 'upcoming' ? 'selected' : '' ?>>Upcoming (Pending/Approved)</option>
            </select>
            <select name="status" class="form-select form-select-sm" style="width:auto;" onchange="this.form.submit()">
                <option value="">All Statuses</option>
                <?php foreach ($validStatuses as $vs): ?>
                <option value="<?= $vs ?>" <?= $statusFilter === $vs ? 'selected' : '' ?>><?= ucfirst($vs) ?></option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0">
                <thead>
                    <tr>
                        <th>Patient</th>
                        <th>Category / Service</th>
                        <th>Preferred</th>
                        <th>Reason</th>
                        <th>Status</th>
                        <th>Scheduled</th>
                        <th>Handled By</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($appointments as $a): ?>
                    <tr>
                        <td>
                            <div class="fw-semibold" style="font-size:.88rem;"><?= htmlspecialchars($a['patient_name']) ?></div>
                            <div class="text-muted" style="font-size:.78rem;"><?= htmlspecialchars($a['patient_no']) ?> <?= $a['contact_number'] ? '&bull; ' . htmlspecialchars($a['contact_number']) : '' ?></div>
                        </td>
                        <td>
                            <span class="badge bg-info bg-opacity-15 text-info"><?= htmlspecialchars($a['category']) ?></span>
                            <?php if ($a['service_name']): ?><div class="text-muted" style="font-size:.78rem;margin-top:2px;"><?= htmlspecialchars($a['service_name']) ?></div><?php endif; ?>
                        </td>
                        <td>
                            <?= date('M d, Y', strtotime($a['preferred_date'])) ?>
                            <?php if ($a['preferred_time']): ?><br><small class="text-muted"><?= date('h:i A', strtotime($a['preferred_time'])) ?></small><?php endif; ?>
                        </td>
                        <td style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= htmlspecialchars($a['reason'] ?: '') ?>"><?= htmlspecialchars($a['reason'] ?: '—') ?></td>
                        <td><span class="badge <?= $statusBadge[$a['status']] ?? 'bg-secondary' ?>"><?= ucfirst($a['status']) ?></span></td>
                        <td>
                            <?= $a['scheduled_date'] ? date('M d, Y', strtotime($a['scheduled_date'])) . ($a['scheduled_time'] ? '<br><small class="text-muted">' . date('h:i A', strtotime($a['scheduled_time'])) . '</small>' : '') : '—' ?>
                        </td>
                        <td><?= htmlspecialchars($a['handled_by_name'] ?: '—') ?></td>
                        <td>
                            <button class="btn btn-sm btn-outline-primary" onclick="openActionModal(<?= htmlspecialchars(json_encode($a)) ?>)">
                                <i class="ti ti-edit"></i> Manage
                            </button>
                            <?php if ($a['status'] === 'approved' && $a['scheduled_date'] === $today && !$a['queue_id']): ?>
                            <a href="<?= csrfUrl(BASE_URL . '/modules/services/queueing.php?checkin_appointment=' . $a['id']) ?>" class="btn btn-sm btn-outline-success" title="Check in to today's queue">
                                <i class="ti ti-login-2"></i>
                            </a>
                            <?php elseif ($a['queue_id']): ?>
                            <span class="badge bg-success bg-opacity-15 text-success" title="Already checked in"><i class="ti ti-check"></i> In Queue</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <!-- No manual "empty" row on purpose — see the note in
                         modules/certificates/certificate_log.php for why. -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ══════════════════════════ MANAGE APPOINTMENT MODAL ══════════════════════════ -->
<div class="modal fade" id="apptModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="apptModalTitle"><i class="ti ti-calendar-event me-2"></i>Manage Appointment</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <?= csrfField() ?>
                <input type="hidden" name="id" id="aId">
                <div class="modal-body">
                    <div class="mb-3 p-2" style="background:#f8f9fa;border-radius:8px;font-size:.85rem;">
                        <div id="aPatientLine" class="fw-semibold"></div>
                        <div id="aRequestLine" class="text-muted"></div>
                        <div id="aReasonLine" class="text-muted mt-1"></div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Status <span class="text-danger">*</span></label>
                        <select class="form-select" name="status" id="aStatus" required onchange="toggleScheduleFields()">
                            <option value="pending">Pending</option>
                            <option value="approved">Approved / Scheduled</option>
                            <option value="rejected">Rejected</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>
                    <div class="row g-3 mb-3" id="aScheduleFields">
                        <div class="col-md-6">
                            <label class="form-label">Scheduled Date</label>
                            <input type="date" class="form-control" name="scheduled_date" id="aSchedDate">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Scheduled Time</label>
                            <input type="time" class="form-control" name="scheduled_time" id="aSchedTime">
                        </div>
                    </div>
                    <div class="mb-1">
                        <label class="form-label">Staff Notes</label>
                        <textarea class="form-control" name="staff_notes" id="aStaffNotes" rows="2" placeholder="Visible to the patient, e.g. instructions or reason for rejection"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ══════════════════════════ SCHEDULE FOLLOW-UP MODAL ══════════════════════════ -->
<div class="modal fade" id="followupModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="ti ti-calendar-plus me-2"></i>Schedule Follow-up</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <?= csrfField() ?>
                <input type="hidden" name="schedule_followup" value="1">
                <input type="hidden" name="checkup_id" id="fuCheckupId">
                <div class="modal-body">
                    <div class="mb-3 p-2" style="background:#f8f9fa;border-radius:8px;font-size:.85rem;">
                        <div id="fuPatientLine" class="fw-semibold"></div>
                        <div id="fuConsultLine" class="text-muted"></div>
                    </div>
                    <div class="mb-1">
                        <label class="form-label">Follow-up Date <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" name="followup_date" id="fuDate" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$extraJS = '
<script>
function openFollowupModal(f) {
    document.getElementById("fuCheckupId").value = f.id;
    document.getElementById("fuPatientLine").textContent = f.patient_name + " (" + f.patient_no + ")";
    document.getElementById("fuConsultLine").textContent = "Consultation: " + f.checkup_date + (f.doctor_name ? " • " + f.doctor_name : "");
    document.getElementById("fuDate").value = f.follow_up_date || "";
    new bootstrap.Modal(document.getElementById("followupModal")).show();
}
function toggleScheduleFields() {
    const status = document.getElementById("aStatus").value;
    document.getElementById("aScheduleFields").style.display = (status === "approved" || status === "completed") ? "" : "none";
}
function openActionModal(a) {
    document.getElementById("aId").value = a.id;
    document.getElementById("aPatientLine").textContent = a.patient_name + " (" + a.patient_no + ")";
    document.getElementById("aRequestLine").textContent = a.category + (a.service_name ? " — " + a.service_name : "") + " • Preferred: " + a.preferred_date + (a.preferred_time ? " " + a.preferred_time : "");
    document.getElementById("aReasonLine").textContent = a.reason ? ("Reason: " + a.reason) : "";
    document.getElementById("aStatus").value = a.status;
    document.getElementById("aSchedDate").value = a.scheduled_date || "";
    document.getElementById("aSchedTime").value = a.scheduled_time || "";
    document.getElementById("aStaffNotes").value = a.staff_notes || "";
    toggleScheduleFields();
    new bootstrap.Modal(document.getElementById("apptModal")).show();
}
</script>';
include __DIR__ . '/../../includes/layout_footer.php';
?>
