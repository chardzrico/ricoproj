<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/helpers.php';
requireLogin();
requireStaffOnly();

// Same reasoning as the FHSIS report — this is a facility-wide compiled
// report, not a per-assigned-patient view, so it's limited to the roles
// that would actually prepare/review it.
if (!isAdmin() && !hasRole('nurse')) {
    header('Location: ' . BASE_URL . '/dashboard.php');
    exit;
}

$conn = getDBConnection();

// ── Reporting window — defaults to the trailing 6 months ────────────────
$dateTo   = $_GET['date_to']   ?? date('Y-m-d');
$dateFrom = $_GET['date_from'] ?? date('Y-m-01', strtotime('-5 months', strtotime($dateTo)));
if (strtotime($dateFrom) > strtotime($dateTo)) { $tmp = $dateFrom; $dateFrom = $dateTo; $dateTo = $tmp; }

// fhsisAgeGroup() lives in includes/helpers.php, shared with modules/reports/fhsis.php.
$ageGroupOrder = FHSIS_AGE_GROUP_ORDER;

// ── Overview ─────────────────────────────────────────────────────────────
$stmt = $conn->prepare("SELECT COUNT(*) c, COUNT(DISTINCT patient_id) p FROM checkups WHERE checkup_date BETWEEN ? AND ? AND status != 'cancelled'");
$stmt->bind_param('ss', $dateFrom, $dateTo);
$stmt->execute();
$ov = $stmt->get_result()->fetch_assoc();
$totalConsultations = (int)$ov['c'];
$uniquePatients = (int)$ov['p'];
$stmt->close();

// ── Top 15 diagnoses across the whole window ─────────────────────────────
$topDiagnoses = [];
$stmt = $conn->prepare("
    SELECT LOWER(TRIM(diagnosis)) AS dx_key, MIN(TRIM(diagnosis)) AS dx_label, COUNT(*) AS cnt
    FROM checkups
    WHERE checkup_date BETWEEN ? AND ? AND status != 'cancelled'
      AND diagnosis IS NOT NULL AND TRIM(diagnosis) != ''
    GROUP BY dx_key
    ORDER BY cnt DESC, dx_label ASC
    LIMIT 15
");
$stmt->bind_param('ss', $dateFrom, $dateTo);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $topDiagnoses[] = $row;
$stmt->close();

// ── Monthly trend for the top 5 diagnoses ────────────────────────────────
$trendDiagnoses = array_slice($topDiagnoses, 0, 5);
$monthsInRange = [];
$cursor = new DateTime(date('Y-m-01', strtotime($dateFrom)));
$end = new DateTime(date('Y-m-01', strtotime($dateTo)));
while ($cursor <= $end) { $monthsInRange[] = $cursor->format('Y-m'); $cursor->modify('+1 month'); }

$trendMatrix = []; // [dx_label][ym] = count
foreach ($trendDiagnoses as $dx) {
    $trendMatrix[$dx['dx_label']] = array_fill_keys($monthsInRange, 0);
    $stmt = $conn->prepare("
        SELECT DATE_FORMAT(checkup_date, '%Y-%m') AS ym, COUNT(*) AS cnt
        FROM checkups
        WHERE checkup_date BETWEEN ? AND ? AND status != 'cancelled' AND LOWER(TRIM(diagnosis)) = ?
        GROUP BY ym
    ");
    $stmt->bind_param('sss', $dateFrom, $dateTo, $dx['dx_key']);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        if (isset($trendMatrix[$dx['dx_label']][$row['ym']])) $trendMatrix[$dx['dx_label']][$row['ym']] = (int)$row['cnt'];
    }
    $stmt->close();
}

// ── Age / sex breakdown ───────────────────────────────────────────────────
$ageSexMatrix = [];
foreach ($ageGroupOrder as $ag) $ageSexMatrix[$ag] = ['Male' => 0, 'Female' => 0];
$stmt = $conn->prepare("SELECT age_at_visit, sex_at_visit FROM checkups WHERE checkup_date BETWEEN ? AND ? AND status != 'cancelled'");
$stmt->bind_param('ss', $dateFrom, $dateTo);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $ag  = fhsisAgeGroup($row['age_at_visit']);
    $sex = ($row['sex_at_visit'] === 'Female') ? 'Female' : 'Male';
    $ageSexMatrix[$ag][$sex]++;
}
$stmt->close();

// ── Barangay breakdown — total cases + leading diagnosis per barangay ────
$barangayDx = []; // [barangay][dx_label] = count
$barangayTotals = [];
$stmt = $conn->prepare("
    SELECT COALESCE(b.name, 'No barangay on record') AS barangay, TRIM(c.diagnosis) AS dx
    FROM checkups c
    JOIN patients p ON c.patient_id = p.id
    LEFT JOIN barangays b ON p.barangay_id = b.id
    WHERE c.checkup_date BETWEEN ? AND ? AND c.status != 'cancelled'
      AND c.diagnosis IS NOT NULL AND TRIM(c.diagnosis) != ''
");
$stmt->bind_param('ss', $dateFrom, $dateTo);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $bgy = $row['barangay'];
    $dxKey = strtolower($row['dx']);
    if (!isset($barangayDx[$bgy])) $barangayDx[$bgy] = [];
    if (!isset($barangayDx[$bgy][$dxKey])) $barangayDx[$bgy][$dxKey] = ['label' => $row['dx'], 'cnt' => 0];
    $barangayDx[$bgy][$dxKey]['cnt']++;
    $barangayTotals[$bgy] = ($barangayTotals[$bgy] ?? 0) + 1;
}
$stmt->close();
arsort($barangayTotals);

$barangaySummary = [];
foreach ($barangayTotals as $bgy => $total) {
    $dxList = $barangayDx[$bgy];
    uasort($dxList, fn($a, $b) => $b['cnt'] <=> $a['cnt']);
    $top = reset($dxList);
    $barangaySummary[] = ['barangay' => $bgy, 'total' => $total, 'top_dx' => $top['label'], 'top_dx_cnt' => $top['cnt']];
}

$preparedBy = getCurrentUser()['full_name'] ?? getCurrentUser()['username'] ?? '';
$conn->close();

// ── CSV export — same window, same data, no HTML rendered ──────────────────
if (($_GET['export'] ?? '') === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="morbidity_report_' . $dateFrom . '_to_' . $dateTo . '.csv"');
    $out = fopen('php://output', 'w');
    fputs($out, "\xEF\xBB\xBF");
    fputcsv($out, ['Morbidity & Summary Report - Rural Health Unit, Rizal']);
    fputcsv($out, ['Period', date('M d, Y', strtotime($dateFrom)) . ' - ' . date('M d, Y', strtotime($dateTo))]);
    fputcsv($out, ['Generated by', $preparedBy, 'on', date('F d, Y')]);
    fputcsv($out, []);

    fputcsv($out, ['Overview']);
    fputcsv($out, ['Total Consultations', $totalConsultations]);
    fputcsv($out, ['Unique Patients', $uniquePatients]);
    fputcsv($out, ['Months Covered', count($monthsInRange)]);
    fputcsv($out, ['Barangays Represented', count($barangaySummary)]);
    fputcsv($out, []);

    fputcsv($out, ['Top 15 Diagnoses (Whole Period)']);
    fputcsv($out, ['#', 'Diagnosis', 'Cases']);
    foreach ($topDiagnoses as $i => $d) fputcsv($out, [$i + 1, $d['dx_label'], $d['cnt']]);
    fputcsv($out, []);

    if ($trendDiagnoses) {
        fputcsv($out, ['Monthly Trend - Top 5 Diagnoses']);
        $trendHeader = ['Diagnosis'];
        foreach ($monthsInRange as $ym) $trendHeader[] = date('M Y', strtotime($ym . '-01'));
        fputcsv($out, $trendHeader);
        foreach ($trendMatrix as $label => $months) fputcsv($out, array_merge([$label], array_values($months)));
        fputcsv($out, []);
    }

    fputcsv($out, ['Consultations by Age Group & Sex']);
    fputcsv($out, ['Age Group', 'Male', 'Female', 'Total']);
    $csvAgeTotals = ['Male' => 0, 'Female' => 0];
    foreach ($ageGroupOrder as $ag) {
        $m = $ageSexMatrix[$ag]['Male']; $f = $ageSexMatrix[$ag]['Female'];
        $csvAgeTotals['Male'] += $m; $csvAgeTotals['Female'] += $f;
        fputcsv($out, [$ag, $m, $f, $m + $f]);
    }
    fputcsv($out, ['Total', $csvAgeTotals['Male'], $csvAgeTotals['Female'], $csvAgeTotals['Male'] + $csvAgeTotals['Female']]);
    fputcsv($out, []);

    fputcsv($out, ['Cases by Barangay']);
    fputcsv($out, ['#', 'Barangay', 'Total Cases', 'Leading Diagnosis', 'Cases']);
    foreach ($barangaySummary as $i => $b) fputcsv($out, [$i + 1, $b['barangay'], $b['total'], $b['top_dx'], $b['top_dx_cnt']]);

    fclose($out);
    exit;
}

$pageTitle = 'Morbidity Report';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<link rel="stylesheet" href="<?= ASSETS_URL ?>/css/reports.css"/>

<div class="page-header no-print"><div class="page-block">
    <h5 class="m-b-10">Morbidity &amp; Summary Report</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Reports</li><li class="breadcrumb-item active">Morbidity Report</li></ul>
</div></div>

<div class="report-card no-print">
    <form method="GET" class="d-flex flex-wrap align-items-end gap-3">
        <div>
            <label class="form-label mb-1">From</label>
            <input type="date" name="date_from" class="form-control form-control-sm" value="<?= htmlspecialchars($dateFrom) ?>">
        </div>
        <div>
            <label class="form-label mb-1">To</label>
            <input type="date" name="date_to" class="form-control form-control-sm" value="<?= htmlspecialchars($dateTo) ?>">
        </div>
        <button type="submit" class="btn btn-primary btn-sm"><i class="ti ti-filter me-1"></i>Generate</button>
        <a href="?date_from=<?= urlencode($dateFrom) ?>&date_to=<?= urlencode($dateTo) ?>&export=csv" class="btn btn-outline-success btn-sm ms-auto"><i class="ti ti-file-spreadsheet me-1"></i>Export CSV</a>
        <button type="button" class="btn btn-outline-secondary btn-sm" onclick="window.print()"><i class="ti ti-printer me-1"></i>Print / Save PDF</button>
    </form>
</div>

<?php renderReportLetterhead('Morbidity &amp; Summary Report &bull; ' . date('M d, Y', strtotime($dateFrom)) . ' – ' . date('M d, Y', strtotime($dateTo)), $preparedBy); ?>

<div class="report-card">
    <h6>Overview</h6>
    <div class="row g-3">
        <div class="col-6 col-md-3"><div class="stat-box"><div class="val"><?= $totalConsultations ?></div><div class="lbl">Total Consultations</div></div></div>
        <div class="col-6 col-md-3"><div class="stat-box"><div class="val"><?= $uniquePatients ?></div><div class="lbl">Unique Patients</div></div></div>
        <div class="col-6 col-md-3"><div class="stat-box"><div class="val"><?= count($monthsInRange) ?></div><div class="lbl">Months Covered</div></div></div>
        <div class="col-6 col-md-3"><div class="stat-box"><div class="val"><?= count($barangaySummary) ?></div><div class="lbl">Barangays Represented</div></div></div>
    </div>
</div>

<div class="report-card">
    <h6>Top 15 Diagnoses (Whole Period)</h6>
    <table class="fhsis-table">
        <thead><tr><th>#</th><th>Diagnosis</th><th class="num">Cases</th></tr></thead>
        <tbody>
            <?php if (empty($topDiagnoses)): ?>
            <tr><td colspan="3" class="text-center text-muted">No diagnoses recorded for this period.</td></tr>
            <?php else: foreach ($topDiagnoses as $i => $d): ?>
            <tr><td><?= $i + 1 ?></td><td><?= htmlspecialchars($d['dx_label']) ?></td><td class="num"><?= $d['cnt'] ?></td></tr>
            <?php endforeach; endif; ?>
        </tbody>
    </table>
</div>

<div class="report-card">
    <h6>Monthly Trend — Top 5 Diagnoses</h6>
    <?php if (empty($trendDiagnoses)): ?>
    <p class="text-muted">No diagnoses recorded for this period.</p>
    <?php else: ?>
    <div class="table-responsive">
        <table class="fhsis-table">
            <thead><tr><th>Diagnosis</th><?php foreach ($monthsInRange as $ym): ?><th class="num"><?= date('M Y', strtotime($ym . '-01')) ?></th><?php endforeach; ?></tr></thead>
            <tbody>
                <?php foreach ($trendMatrix as $label => $months): ?>
                <tr><td><?= htmlspecialchars($label) ?></td><?php foreach ($months as $cnt): ?><td class="num"><?= $cnt ?></td><?php endforeach; ?></tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<div class="report-card">
    <h6>Consultations by Age Group &amp; Sex</h6>
    <table class="fhsis-table">
        <thead><tr><th>Age Group</th><th class="num">Male</th><th class="num">Female</th><th class="num">Total</th></tr></thead>
        <tbody>
            <?php $ageTotals = ['Male'=>0,'Female'=>0]; foreach ($ageGroupOrder as $ag):
                $m = $ageSexMatrix[$ag]['Male']; $f = $ageSexMatrix[$ag]['Female'];
                if ($m === 0 && $f === 0) continue;
                $ageTotals['Male'] += $m; $ageTotals['Female'] += $f;
            ?>
            <tr><td><?= $ag ?></td><td class="num"><?= $m ?></td><td class="num"><?= $f ?></td><td class="num"><?= $m + $f ?></td></tr>
            <?php endforeach; ?>
            <tr style="font-weight:700;background:#f4f6f8;"><td>Total</td><td class="num"><?= $ageTotals['Male'] ?></td><td class="num"><?= $ageTotals['Female'] ?></td><td class="num"><?= $ageTotals['Male'] + $ageTotals['Female'] ?></td></tr>
        </tbody>
    </table>
</div>

<div class="report-card">
    <h6>Cases by Barangay</h6>
    <table class="fhsis-table">
        <thead><tr><th>#</th><th>Barangay</th><th class="num">Total Cases</th><th>Leading Diagnosis</th><th class="num">Cases</th></tr></thead>
        <tbody>
            <?php if (empty($barangaySummary)): ?>
            <tr><td colspan="5" class="text-center text-muted">No records for this period.</td></tr>
            <?php else: foreach ($barangaySummary as $i => $b): ?>
            <tr>
                <td><?= $i + 1 ?></td>
                <td><?= htmlspecialchars($b['barangay']) ?></td>
                <td class="num"><?= $b['total'] ?></td>
                <td><?= htmlspecialchars($b['top_dx']) ?></td>
                <td class="num"><?= $b['top_dx_cnt'] ?></td>
            </tr>
            <?php endforeach; endif; ?>
        </tbody>
    </table>
</div>

<p class="text-muted no-print" style="font-size:.8rem;">
    <i class="ti ti-info-circle me-1"></i>
    Barangay figures depend on each patient's recorded barangay — patients without one appear under "No barangay on record." Diagnoses are grouped from free-text entries, so near-duplicate phrasing may appear as separate rows.
</p>

<?php include __DIR__ . '/../../includes/layout_footer.php'; ?>
