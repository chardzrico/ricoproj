<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/helpers.php';
requireLogin();
requireStaffOnly();
$conn = getDBConnection();
$msg = '';

if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    verifyCsrf();
    $deleteId = (int)$_GET['delete'];
    $owner = $conn->prepare("SELECT patient_id FROM nutritional_records WHERE id = ?");
    $owner->bind_param('i', $deleteId);
    $owner->execute();
    $ownerRow = $owner->get_result()->fetch_assoc();
    $owner->close();
    if ($ownerRow) {
        assertPatientInDoctorScope($conn, $ownerRow['patient_id']);
        $stmt = $conn->prepare("DELETE FROM nutritional_records WHERE id=?");
        $stmt->bind_param('i', $deleteId);
        $stmt->execute();
        logAudit('delete_growth_record', 'patient', (int)$ownerRow['patient_id'], "record #$deleteId");
    }
    header('Location: growth_recording.php?msg=deleted'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $id      = (int)($_POST['id'] ?? 0);
    $pid     = (int)$_POST['patient_id'];
    $date    = $_POST['record_date'] ?? date('Y-m-d');
    $age_m   = (int)($_POST['age_months'] ?? 0);
    $weight  = floatval($_POST['weight'] ?? 0);
    $height  = floatval($_POST['height'] ?? 0);
    $bmi     = ($height > 0) ? round($weight / (($height/100) * ($height/100)), 2) : 0;
    $wfa     = trim($_POST['weight_for_age'] ?? '');
    $hfa     = trim($_POST['height_for_age'] ?? '');
    $wfh     = trim($_POST['weight_for_height'] ?? '');
    $status  = trim($_POST['nutritional_status'] ?? '');
    $remarks = trim($_POST['remarks'] ?? '');
    $uid     = getCurrentUser()['id'];

    assertPatientInDoctorScope($conn, $pid);
    if ($id > 0) {
        $ownerCheck = $conn->prepare("SELECT patient_id FROM nutritional_records WHERE id = ?");
        $ownerCheck->bind_param('i', $id);
        $ownerCheck->execute();
        $existingOwner = $ownerCheck->get_result()->fetch_assoc();
        $ownerCheck->close();
        if ($existingOwner) assertPatientInDoctorScope($conn, $existingOwner['patient_id']);
    }

    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE nutritional_records SET patient_id=?,record_date=?,age_months=?,weight=?,height=?,bmi=?,weight_for_age=?,height_for_age=?,weight_for_height=?,nutritional_status=?,remarks=?,recorded_by=? WHERE id=?");
        $stmt->bind_param('isidddsssssii',$pid,$date,$age_m,$weight,$height,$bmi,$wfa,$hfa,$wfh,$status,$remarks,$uid,$id);
        $stmt->execute();
        logAudit('update_growth_record', 'patient', $pid, "status=$status");
    } else {
        $stmt = $conn->prepare("INSERT INTO nutritional_records (patient_id,record_date,age_months,weight,height,bmi,weight_for_age,height_for_age,weight_for_height,nutritional_status,remarks,recorded_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param('isidddsssssi',$pid,$date,$age_m,$weight,$height,$bmi,$wfa,$hfa,$wfh,$status,$remarks,$uid);
        $stmt->execute();
        logAudit('create_growth_record', 'patient', $pid, "status=$status");
    }
    header('Location: growth_recording.php?msg=' . ($id>0?'updated':'added')); exit;
}

$patients = [];
$r = $conn->query("SELECT id, patient_no, CONCAT(first_name,' ',last_name) as name, date_of_birth FROM patients WHERE status='active'" . doctorScopeSql() . " ORDER BY last_name");
while ($row = $r->fetch_assoc()) $patients[] = $row;

$records = [];
$r = $conn->query("SELECT nr.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no FROM nutritional_records nr LEFT JOIN patients p ON nr.patient_id=p.id WHERE 1=1" . doctorScopeSql('p') . " ORDER BY nr.record_date DESC LIMIT 100");
while ($row = $r->fetch_assoc()) $records[] = $row;
$conn->close();

if (isset($_GET['msg'])) { $msg = ['added'=>'Growth record saved.','updated'=>'Updated.','deleted'=>'Deleted.'][$_GET['msg']] ?? ''; }
$pageTitle = 'Growth Recording';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<div class="page-header"><div class="page-block">
    <h5 class="m-b-10">Growth Recording</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Nutritional Status</li><li class="breadcrumb-item active">Growth Recording</li></ul>
</div></div>
<?php if ($msg): ?><div class="alert alert-success alert-dismissible fade show"><i class="ti ti-circle-check me-2"></i><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0"><i class="ti ti-trending-up me-2" style="color:#0d6efd;"></i>Growth Records</h6>
        <button class="btn btn-primary btn-sm" onclick="openAddModal()"><i class="ti ti-plus me-1"></i>Add Record</button>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0">
                <thead><tr><th>Patient</th><th>Date</th><th>Age (months)</th><th>Weight (kg)</th><th>Height (cm)</th><th>BMI</th><th>WFA</th><th>HFA</th><th>WFH</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php foreach ($records as $rec): ?>
                    <tr>
                        <td><div class="fw-semibold" style="font-size:.88rem;"><?= htmlspecialchars($rec['patient_name']) ?></div><div class="text-muted" style="font-size:.78rem;"><?= htmlspecialchars($rec['patient_no']) ?></div></td>
                        <td><?= date('M d, Y', strtotime($rec['record_date'])) ?></td>
                        <td><?= $rec['age_months'] ? $rec['age_months'].' mos' : '—' ?></td>
                        <td class="fw-semibold"><?= $rec['weight'] ? $rec['weight'].' kg' : '—' ?></td>
                        <td><?= $rec['height'] ? $rec['height'].' cm' : '—' ?></td>
                        <td><?= $rec['bmi'] ?: '—' ?></td>
                        <td><?= htmlspecialchars($rec['weight_for_age'] ?: '—') ?></td>
                        <td><?= htmlspecialchars($rec['height_for_age'] ?: '—') ?></td>
                        <td><?= htmlspecialchars($rec['weight_for_height'] ?: '—') ?></td>
                        <td><?= nutritionStatusBadge($rec['nutritional_status'] ?? '') ?></td>
                        <td>
                            <button class="btn-edit btn btn-sm me-1" onclick="openEditModal(<?= htmlspecialchars(json_encode($rec)) ?>)"><i class="ti ti-edit"></i></button>
                            <button class="btn-delete btn btn-sm" onclick="confirmDelete('<?= csrfUrl('growth_recording.php?delete=' . $rec['id']) ?>','this record')"><i class="ti ti-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="growthModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="growthModalTitle"><i class="ti ti-trending-up me-2"></i>Add Growth Record</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST"><?= csrfField() ?>
                <input type="hidden" name="id" id="growthId" value="0">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Patient *</label>
                            <select class="form-select" name="patient_id" id="gPatient" required>
                                <option value="">Select Patient</option>
                                <?php foreach ($patients as $p): ?><option value="<?= $p['id'] ?>" data-dob="<?= $p['date_of_birth'] ?>"><?= htmlspecialchars($p['patient_no'].' - '.$p['name']) ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3"><label class="form-label">Date *</label><input type="date" class="form-control" name="record_date" id="gDate" value="<?= date('Y-m-d') ?>" required onchange="calcAge()"></div>
                        <div class="col-md-3"><label class="form-label">Age (months)</label><input type="number" class="form-control" name="age_months" id="gAge" min="0" placeholder="Auto-calc"></div>
                        <div class="col-md-3"><label class="form-label">Weight (kg) *</label><input type="number" step="0.1" class="form-control" name="weight" id="gWeight" required placeholder="0.0" oninput="calcBMI()"></div>
                        <div class="col-md-3"><label class="form-label">Height (cm) *</label><input type="number" step="0.1" class="form-control" name="height" id="gHeight" required placeholder="0" oninput="calcBMI()"></div>
                        <div class="col-md-3"><label class="form-label">BMI</label><input type="text" class="form-control bg-light" id="gBMIDisplay" readonly placeholder="Auto-calc"></div>
                        <div class="col-md-4">
                            <label class="form-label">Weight for Age</label>
                            <select class="form-select" name="weight_for_age" id="gWFA">
                                <option value="">Select</option>
                                <option>Normal</option><option>Underweight</option><option>Severely Underweight</option><option>Overweight</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Height for Age</label>
                            <select class="form-select" name="height_for_age" id="gHFA">
                                <option value="">Select</option>
                                <option>Normal</option><option>Stunted</option><option>Severely Stunted</option><option>Tall</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Weight for Height</label>
                            <select class="form-select" name="weight_for_height" id="gWFH">
                                <option value="">Select</option>
                                <option>Normal</option><option>Wasted</option><option>Severely Wasted</option><option>Obese</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Nutritional Status</label>
                            <select class="form-select" name="nutritional_status" id="gStatus">
                                <option value="">Select</option>
                                <option>Normal</option><option>At Risk</option><option>Mild Undernutrition</option>
                                <option>Moderate Undernutrition</option><option>Severe Undernutrition</option><option>Overweight</option><option>Obese</option>
                            </select>
                        </div>
                        <div class="col-12"><label class="form-label">Remarks</label><textarea class="form-control" name="remarks" id="gRemarks" rows="2" placeholder="Additional notes or observations"></textarea></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php
$extraJS='<script>
function calcBMI(){
    const w=parseFloat(document.getElementById("gWeight").value)||0;
    const h=parseFloat(document.getElementById("gHeight").value)||0;
    if(w>0&&h>0){ document.getElementById("gBMIDisplay").value=(w/((h/100)*(h/100))).toFixed(2); }
}
function calcAge(){
    const sel=document.getElementById("gPatient");
    const opt=sel.options[sel.selectedIndex];
    const dob=opt?opt.getAttribute("data-dob"):null;
    const recDate=document.getElementById("gDate").value;
    if(dob&&recDate){
        const d1=new Date(dob),d2=new Date(recDate);
        const months=(d2.getFullYear()-d1.getFullYear())*12+(d2.getMonth()-d1.getMonth());
        document.getElementById("gAge").value=months>0?months:0;
    }
}
function openAddModal(){
    document.getElementById("growthModalTitle").innerHTML=\'<i class="ti ti-trending-up me-2"></i>Add Growth Record\';
    document.getElementById("growthId").value="0";
    document.getElementById("gPatient").value="";
    ["gAge","gWeight","gHeight","gRemarks","gBMIDisplay"].forEach(id=>document.getElementById(id).value="");
    ["gWFA","gHFA","gWFH","gStatus"].forEach(id=>document.getElementById(id).value="");
    document.getElementById("gDate").value="'.date('Y-m-d').'";

    new bootstrap.Modal(document.getElementById("growthModal")).show();
}
function openEditModal(r){
    document.getElementById("growthModalTitle").innerHTML=\'<i class="ti ti-edit me-2"></i>Edit Growth Record\';
    document.getElementById("growthId").value=r.id;
    document.getElementById("gPatient").value=r.patient_id;
    document.getElementById("gDate").value=r.record_date||"";
    document.getElementById("gAge").value=r.age_months||"";
    document.getElementById("gWeight").value=r.weight||"";
    document.getElementById("gHeight").value=r.height||"";
    document.getElementById("gBMIDisplay").value=r.bmi||"";
    document.getElementById("gWFA").value=r.weight_for_age||"";
    document.getElementById("gHFA").value=r.height_for_age||"";
    document.getElementById("gWFH").value=r.weight_for_height||"";
    document.getElementById("gStatus").value=r.nutritional_status||"";
    document.getElementById("gRemarks").value=r.remarks||"";
    new bootstrap.Modal(document.getElementById("growthModal")).show();
}
document.getElementById("gPatient").addEventListener("change",calcAge);
</script>';
include __DIR__ . '/../../includes/layout_footer.php';
?>
