<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();

$conn = getDBConnection();
$msg = '';
$uid = getCurrentUser()['id'];

// ── Save (create/edit) household ────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_household'])) {
    verifyCsrf();
    $id = (int)($_POST['id'] ?? 0);
    $barangay_id = !empty($_POST['barangay_id']) ? (int)$_POST['barangay_id'] : null;
    $address = trim($_POST['address_details'] ?? '');
    $contact = trim($_POST['contact_number'] ?? '');
    $remarks = trim($_POST['remarks'] ?? '');

    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE households SET barangay_id=?, address_details=?, contact_number=?, remarks=? WHERE id=?");
        $stmt->bind_param('isssi', $barangay_id, $address, $contact, $remarks, $id);
        $stmt->execute();
        $stmt->close();
        header('Location: households.php?msg=updated'); exit;
    } else {
        $r = $conn->query("SELECT COUNT(*) c FROM households");
        $cnt = (int)$r->fetch_assoc()['c'] + 1;
        $household_no = 'HH-' . date('Y') . '-' . str_pad($cnt, 5, '0', STR_PAD_LEFT);
        $stmt = $conn->prepare("INSERT INTO households (household_no, barangay_id, address_details, contact_number, remarks, created_by) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param('sisssi', $household_no, $barangay_id, $address, $contact, $remarks, $uid);
        $stmt->execute();
        $stmt->close();
        header('Location: households.php?msg=created'); exit;
    }
}

// ── Deactivate household (detaches members, doesn't delete their records) ──
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    verifyCsrf();
    $hid = (int)$_GET['delete'];
    $conn->query("UPDATE households SET status='inactive' WHERE id=$hid");
    $conn->query("UPDATE patients SET household_id=NULL WHERE household_id=$hid");
    header('Location: households.php?msg=deactivated'); exit;
}

// ── Add a patient to a household ─────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_member'])) {
    verifyCsrf();
    $hid = (int)($_POST['household_id'] ?? 0);
    $pid = (int)($_POST['patient_id'] ?? 0);
    if ($hid > 0 && $pid > 0) {
        $stmt = $conn->prepare("UPDATE patients SET household_id=? WHERE id=?" . doctorScopeSql());
        $stmt->bind_param('ii', $hid, $pid);
        $stmt->execute();
        $stmt->close();
    }
    header('Location: households.php?manage=' . $hid . '&msg=member_added'); exit;
}

// ── Remove a patient from a household ────────────────────────────────────
if (isset($_GET['remove_member']) && is_numeric($_GET['remove_member']) && isset($_GET['from'])) {
    verifyCsrf();
    $pid = (int)$_GET['remove_member'];
    $hid = (int)$_GET['from'];
    $conn->query("UPDATE patients SET household_id=NULL WHERE id=$pid AND household_id=$hid");
    $conn->query("UPDATE households SET household_head_id=NULL WHERE id=$hid AND household_head_id=$pid");
    header('Location: households.php?manage=' . $hid . '&msg=member_removed'); exit;
}

// ── Set household head ───────────────────────────────────────────────────
if (isset($_GET['set_head']) && is_numeric($_GET['set_head']) && isset($_GET['for'])) {
    verifyCsrf();
    $pid = (int)$_GET['set_head'];
    $hid = (int)$_GET['for'];
    $stmt = $conn->prepare("UPDATE households SET household_head_id=? WHERE id=?");
    $stmt->bind_param('ii', $pid, $hid);
    $stmt->execute();
    $stmt->close();
    header('Location: households.php?manage=' . $hid . '&msg=head_set'); exit;
}

// ── Data ─────────────────────────────────────────────────────────────────
$barangays = [];
$r = $conn->query("SELECT id, name FROM barangays WHERE status='active' ORDER BY name");
while ($row = $r->fetch_assoc()) $barangays[] = $row;

$households = [];
$stmt = $conn->prepare("
    SELECT h.*, b.name as barangay_name, hd.first_name as head_first, hd.last_name as head_last,
           (SELECT COUNT(*) FROM patients mp WHERE mp.household_id = h.id AND mp.status='active') as member_count
    FROM households h
    LEFT JOIN barangays b ON h.barangay_id = b.id
    LEFT JOIN patients hd ON h.household_head_id = hd.id
    WHERE h.status='active'
    ORDER BY h.created_at DESC
");
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $households[] = $row;
$stmt->close();

// Patients available to add as members — everyone not already in *this*
// household, scoped the same way a doctor is scoped everywhere else.
$allPatients = [];
$r = $conn->query("SELECT id, patient_no, first_name, last_name, household_id FROM patients WHERE status='active'" . doctorScopeSql() . " ORDER BY last_name");
while ($row = $r->fetch_assoc()) $allPatients[] = $row;

// If managing a specific household, load its members
$managingHousehold = null;
$members = [];
if (isset($_GET['manage']) && is_numeric($_GET['manage'])) {
    $hid = (int)$_GET['manage'];
    $stmt = $conn->prepare("SELECT h.*, b.name as barangay_name FROM households h LEFT JOIN barangays b ON h.barangay_id=b.id WHERE h.id=? LIMIT 1");
    $stmt->bind_param('i', $hid);
    $stmt->execute();
    $managingHousehold = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($managingHousehold) {
        $stmt = $conn->prepare("SELECT id, patient_no, first_name, last_name, date_of_birth, gender FROM patients WHERE household_id=? AND status='active' ORDER BY first_name");
        $stmt->bind_param('i', $hid);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) $members[] = $row;
        $stmt->close();
    }
}
$conn->close();

if (isset($_GET['msg'])) {
    $msg = [
        'created'        => 'Household folder created.',
        'updated'        => 'Household updated.',
        'deactivated'    => 'Household deactivated.',
        'member_added'   => 'Patient added to household.',
        'member_removed' => 'Patient removed from household.',
        'head_set'       => 'Household head updated.',
    ][$_GET['msg']] ?? '';
}

$pageTitle = 'Households';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<div class="page-header"><div class="page-block">
    <h5 class="m-b-10">Household Records (Family Folders)</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Community</li><li class="breadcrumb-item active">Households</li></ul>
</div></div>

<?php if ($msg): ?><div class="alert alert-success alert-dismissible fade show"><i class="ti ti-circle-check me-2"></i><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0"><i class="ti ti-home me-2" style="color:#0d6efd;"></i>Households</h6>
        <button class="btn btn-primary btn-sm" onclick="openHouseholdModal()"><i class="ti ti-plus me-1"></i>New Household</button>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0">
                <thead><tr><th>Household No.</th><th>Barangay</th><th>Household Head</th><th>Members</th><th>Contact</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php foreach ($households as $h): ?>
                    <tr>
                        <td class="fw-semibold"><?= htmlspecialchars($h['household_no']) ?></td>
                        <td><?= htmlspecialchars($h['barangay_name'] ?: '—') ?></td>
                        <td><?= $h['head_first'] ? htmlspecialchars($h['head_first'] . ' ' . $h['head_last']) : '<span class="text-muted">Not set</span>' ?></td>
                        <td><span class="badge bg-light text-secondary border border-secondary-subtle"><?= $h['member_count'] ?> member<?= $h['member_count'] == 1 ? '' : 's' ?></span></td>
                        <td><?= htmlspecialchars($h['contact_number'] ?: '—') ?></td>
                        <td>
                            <a href="?manage=<?= $h['id'] ?>" class="btn-view btn btn-sm me-1" title="Manage Members"><i class="ti ti-users"></i></a>
                            <button class="btn-edit btn btn-sm me-1" title="Edit" onclick='openHouseholdModal(<?= htmlspecialchars(json_encode($h), ENT_QUOTES) ?>)'><i class="ti ti-edit"></i></button>
                            <button class="btn-delete btn btn-sm" title="Deactivate" onclick="confirmDelete('<?= csrfUrl('households.php?delete=' . $h['id']) ?>','this household')"><i class="ti ti-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ══ Add/Edit Household Modal ══ -->
<div class="modal fade" id="householdModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="households.php"><?= csrfField() ?>
                <input type="hidden" name="save_household" value="1">
                <input type="hidden" name="id" id="hId">
                <div class="modal-header">
                    <h5 class="modal-title" id="hModalTitle"><i class="ti ti-home-plus me-2"></i>New Household</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Barangay</label>
                        <select class="form-select" name="barangay_id" id="hBarangay">
                            <option value="">Select barangay…</option>
                            <?php foreach ($barangays as $b): ?>
                            <option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Sitio / Street / House No.</label>
                        <input type="text" class="form-control" name="address_details" id="hAddress" placeholder="e.g. Purok 3, Sitio Malaya">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Contact Number</label>
                        <input type="text" class="form-control" name="contact_number" id="hContact" placeholder="09XX-XXX-XXXX">
                    </div>
                    <div class="mb-1">
                        <label class="form-label">Remarks</label>
                        <textarea class="form-control" name="remarks" id="hRemarks" rows="2" placeholder="e.g. water source, sanitation notes (optional)"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($managingHousehold): ?>
<!-- ══ Manage Members Modal (auto-opened) ══ -->
<div class="modal fade" id="manageModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="ti ti-users me-2"></i>Members — <?= htmlspecialchars($managingHousehold['household_no']) ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" onclick="location.href='households.php'"></button>
            </div>
            <div class="modal-body">
                <p class="text-muted mb-2" style="font-size:.85rem;"><?= htmlspecialchars($managingHousehold['barangay_name'] ?: 'No barangay set') ?> &bull; <?= htmlspecialchars($managingHousehold['address_details'] ?: '') ?></p>

                <table class="table table-sm mb-3">
                    <thead><tr><th>Name</th><th>Patient No.</th><th>Age</th><th>Sex</th><th>Role</th><th>Actions</th></tr></thead>
                    <tbody>
                        <?php foreach ($members as $m):
                            $age = $m['date_of_birth'] ? floor((time() - strtotime($m['date_of_birth'])) / 31557600) : '—';
                            $isHead = (int)$managingHousehold['household_head_id'] === (int)$m['id'];
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($m['first_name'] . ' ' . $m['last_name']) ?></td>
                            <td><?= htmlspecialchars($m['patient_no']) ?></td>
                            <td><?= $age ?></td>
                            <td><?= htmlspecialchars($m['gender']) ?></td>
                            <td><?= $isHead ? '<span class="badge bg-success">Household Head</span>' : '<a href="' . csrfUrl('?manage=' . $managingHousehold['id'] . '&set_head=' . $m['id'] . '&for=' . $managingHousehold['id']) . '" class="btn btn-sm btn-outline-secondary py-0">Make Head</a>' ?></td>
                            <td><a href="<?= csrfUrl('?remove_member=' . $m['id'] . '&from=' . $managingHousehold['id']) ?>" class="btn btn-sm btn-outline-danger py-0" onclick="return confirm('Remove this patient from the household?')"><i class="ti ti-x"></i></a></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($members)): ?><tr><td colspan="6" class="text-center text-muted py-3">No members yet.</td></tr><?php endif; ?>
                    </tbody>
                </table>

                <form method="POST" action="households.php" class="d-flex gap-2"><?= csrfField() ?>
                    <input type="hidden" name="add_member" value="1">
                    <input type="hidden" name="household_id" value="<?= $managingHousehold['id'] ?>">
                    <select name="patient_id" class="form-select form-select-sm" required>
                        <option value="">Add existing patient to this household…</option>
                        <?php foreach ($allPatients as $p): if ((int)$p['household_id'] === (int)$managingHousehold['id']) continue; ?>
                        <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['patient_no'] . ' - ' . $p['first_name'] . ' ' . $p['last_name']) ?><?= $p['household_id'] ? ' (in another household)' : '' ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="btn btn-primary btn-sm text-nowrap"><i class="ti ti-plus me-1"></i>Add</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="location.href='households.php'">Close</button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php
$extraJS = '
<script>
function openHouseholdModal(h) {
    document.getElementById("hId").value = h ? h.id : "";
    document.getElementById("hBarangay").value = h ? (h.barangay_id || "") : "";
    document.getElementById("hAddress").value = h ? (h.address_details || "") : "";
    document.getElementById("hContact").value = h ? (h.contact_number || "") : "";
    document.getElementById("hRemarks").value = h ? (h.remarks || "") : "";
    document.getElementById("hModalTitle").innerHTML = (h ? "<i class=\"ti ti-edit me-2\"></i>Edit Household" : "<i class=\"ti ti-home-plus me-2\"></i>New Household");
    new bootstrap.Modal(document.getElementById("householdModal")).show();
}
' . ($managingHousehold ? 'window.addEventListener("load",function(){ new bootstrap.Modal(document.getElementById("manageModal")).show(); });' : '') . '
</script>';
include __DIR__ . '/../../includes/layout_footer.php';
?>
