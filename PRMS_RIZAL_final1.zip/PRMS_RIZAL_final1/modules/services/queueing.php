<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/helpers.php';
requireLogin();
requireStaffOnly();
$conn = getDBConnection();
$msg = '';
$today = date('Y-m-d');
$categories = ['Dental', 'Physical', 'Mental', 'Medical'];
$priorityLabels = ['senior' => 'Senior Citizen', 'pwd' => 'PWD', 'pregnant' => 'Pregnant', 'normal' => 'Normal'];
$priorityColors = ['senior' => '#7b1fa2', 'pwd' => '#c62828', 'pregnant' => '#ad1457', 'normal' => '#6c757d'];

// Assigns the next queue number for a category/day inside a transaction,
// retrying on a collision instead of trusting a bare COUNT(*)+1 — the same
// bug class (and the same fix) as the RX/certificate numbering.
// See modules/medicine/prescription_log.php for the original write-up.
function enqueuePatient($conn, int $patientId, string $category, string $priority, string $date, ?int $appointmentId = null): bool {
    $conn->begin_transaction();
    for ($attempt = 0; $attempt < 5; $attempt++) {
        $r = $conn->prepare("SELECT COALESCE(MAX(queue_no),0)+1+? AS next_no FROM patient_queue WHERE category=? AND queue_date=?");
        $r->bind_param('iss', $attempt, $category, $date);
        $r->execute();
        $nextNo = (int)$r->get_result()->fetch_assoc()['next_no'];
        $r->close();

        $stmt = $conn->prepare("INSERT INTO patient_queue (queue_no, patient_id, appointment_id, category, priority, queue_date) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param('iiisss', $nextNo, $patientId, $appointmentId, $category, $priority, $date);
        if ($stmt->execute()) {
            $stmt->close();
            $conn->commit();
            return true;
        }
        $isDuplicate = ($conn->errno === 1062);
        $stmt->close();
        if (!$isDuplicate) break;
    }
    $conn->rollback();
    return false;
}

// Senior Citizens Act (RA 9994) priority — auto-suggested from date of birth,
// staff can still override to PWD/Pregnant/Normal in the form.
function suggestPriority(?string $dob): string {
    if (!$dob) return 'normal';
    $age = (new DateTime($dob))->diff(new DateTime())->y;
    return $age >= 60 ? 'senior' : 'normal';
}

// ── Add patient to queue (manual, via the modal) ─────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'enqueue') {
    verifyCsrf();
    $patient_id = (int)($_POST['patient_id'] ?? 0);
    $category   = $_POST['category'] ?? '';
    $priority   = in_array($_POST['priority'] ?? '', ['normal', 'senior', 'pwd', 'pregnant'], true) ? $_POST['priority'] : 'normal';

    if ($patient_id > 0 && in_array($category, $categories, true)) {
        assertPatientInDoctorScope($conn, $patient_id);
        $ok = enqueuePatient($conn, $patient_id, $category, $priority, $today);
        header('Location: queueing.php?msg=' . ($ok ? 'added' : 'error')); exit;
    }
    header('Location: queueing.php?msg=error'); exit;
}

// ── Check a patient in from an approved, today-scheduled appointment ─────
if (isset($_GET['checkin_appointment']) && is_numeric($_GET['checkin_appointment'])) {
    verifyCsrf();
    $apptId = (int)$_GET['checkin_appointment'];
    $stmt = $conn->prepare("
        SELECT a.id, a.patient_id, a.category, p.date_of_birth
        FROM appointments a JOIN patients p ON p.id = a.patient_id
        WHERE a.id = ? AND a.status = 'approved' AND a.scheduled_date = ?
    ");
    $stmt->bind_param('is', $apptId, $today);
    $stmt->execute();
    $appt = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($appt) {
        assertPatientInDoctorScope($conn, $appt['patient_id']);
        // Don't double-check-in if this appointment already has a live queue entry.
        $dupe = $conn->prepare("SELECT id FROM patient_queue WHERE appointment_id=? AND status IN ('waiting','serving')");
        $dupe->bind_param('i', $apptId);
        $dupe->execute();
        $already = $dupe->get_result()->num_rows > 0;
        $dupe->close();

        if (!$already) {
            $priority = suggestPriority($appt['date_of_birth']);
            enqueuePatient($conn, (int)$appt['patient_id'], $appt['category'], $priority, $today, $apptId);
        }
    }
    header('Location: queueing.php?msg=checked_in'); exit;
}

// ── Update queue status (serve / done / cancel) ──────────────────────────
if (isset($_GET['action']) && isset($_GET['id']) && is_numeric($_GET['id']) && in_array($_GET['action'], ['serve', 'done', 'cancel'], true)) {
    verifyCsrf();
    $id = (int)$_GET['id'];
    $map = ['serve' => 'serving', 'done' => 'done', 'cancel' => 'cancelled'];
    $status = $map[$_GET['action']];

    $owner = $conn->prepare("SELECT patient_id FROM patient_queue WHERE id = ?");
    $owner->bind_param('i', $id);
    $owner->execute();
    $ownerRow = $owner->get_result()->fetch_assoc();
    $owner->close();

    if ($ownerRow) {
        assertPatientInDoctorScope($conn, $ownerRow['patient_id']);
        if ($status === 'serving') {
            $conn->query("UPDATE patient_queue SET status='serving', time_served=NOW() WHERE id=$id");
        } elseif ($status === 'done') {
            $conn->query("UPDATE patient_queue SET status='done', time_done=NOW() WHERE id=$id");
        } else {
            $conn->query("UPDATE patient_queue SET status='cancelled', time_done=NOW() WHERE id=$id");
        }
    }
    header('Location: queueing.php?msg=updated'); exit;
}

// ── Reassign priority on an existing waiting/serving entry ───────────────
if (isset($_GET['action']) && $_GET['action'] === 'setpriority' && isset($_GET['id']) && is_numeric($_GET['id'])) {
    verifyCsrf();
    $id = (int)$_GET['id'];
    $priority = in_array($_GET['priority'] ?? '', ['normal', 'senior', 'pwd', 'pregnant'], true) ? $_GET['priority'] : 'normal';
    $owner = $conn->prepare("SELECT patient_id FROM patient_queue WHERE id = ?");
    $owner->bind_param('i', $id);
    $owner->execute();
    $ownerRow = $owner->get_result()->fetch_assoc();
    $owner->close();
    if ($ownerRow) {
        assertPatientInDoctorScope($conn, $ownerRow['patient_id']);
        $stmt = $conn->prepare("UPDATE patient_queue SET priority=? WHERE id=?");
        $stmt->bind_param('si', $priority, $id);
        $stmt->execute();
        $stmt->close();
    }
    header('Location: queueing.php?msg=updated'); exit;
}

// ── Data needed by the (possibly partial) queue render ───────────────────
function fetchQueueData($conn, $today, $categories) {
    $queues = [];
    foreach ($categories as $cat) {
        $stmt = $conn->prepare("
            SELECT q.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no
            FROM patient_queue q LEFT JOIN patients p ON q.patient_id=p.id
            WHERE q.category=? AND q.queue_date=? AND q.status IN ('waiting','serving')
            ORDER BY (q.priority != 'normal') DESC, q.queue_no ASC
        ");
        $stmt->bind_param('ss', $cat, $today);
        $stmt->execute();
        $res = $stmt->get_result();
        $rows = [];
        while ($row = $res->fetch_assoc()) $rows[] = $row;
        $queues[$cat] = $rows;
        $stmt->close();
    }

    $nowServing = [];
    foreach ($categories as $cat) {
        $nowServing[$cat] = null;
        foreach ($queues[$cat] as $row) {
            if ($row['status'] === 'serving') { $nowServing[$cat] = $row; break; }
        }
    }

    $stats = ['waiting' => 0, 'serving' => 0, 'done' => 0, 'avg_wait' => null];
    $r = $conn->prepare("SELECT status, COUNT(*) c FROM patient_queue WHERE queue_date=? GROUP BY status");
    $r->bind_param('s', $today);
    $r->execute();
    $res = $r->get_result();
    while ($row = $res->fetch_assoc()) {
        if (isset($stats[$row['status']])) $stats[$row['status']] = (int)$row['c'];
    }
    $r->close();

    $r = $conn->prepare("SELECT AVG(TIMESTAMPDIFF(MINUTE, time_in, time_served)) AS avg_wait FROM patient_queue WHERE queue_date=? AND time_served IS NOT NULL");
    $r->bind_param('s', $today);
    $r->execute();
    $avgRow = $r->get_result()->fetch_assoc();
    $stats['avg_wait'] = $avgRow['avg_wait'] !== null ? (int)round($avgRow['avg_wait']) : null;
    $r->close();

    return [$queues, $nowServing, $stats];
}

[$queues, $nowServing, $stats] = fetchQueueData($conn, $today, $categories);

$catIcons  = ['Dental' => 'ti-dental', 'Physical' => 'ti-stethoscope', 'Mental' => 'ti-brain', 'Medical' => 'ti-first-aid-kit'];
$catColors = ['Dental' => '#0d6efd', 'Physical' => '#2e7d32', 'Mental' => '#8e24aa', 'Medical' => '#e65100'];

function renderQueueSection($categories, $queues, $nowServing, $stats, $catIcons, $catColors, $priorityLabels, $priorityColors) {
    $cards = [
        ['icon' => 'ti-hourglass',      'color' => '#e65100', 'bg' => '#fff3e0', 'value' => $stats['waiting'], 'label' => 'Waiting'],
        ['icon' => 'ti-user-check',     'color' => '#1565c0', 'bg' => '#e3f2fd', 'value' => $stats['serving'], 'label' => 'Serving Now'],
        ['icon' => 'ti-circle-check',   'color' => '#2e7d32', 'bg' => '#e8f5e9', 'value' => $stats['done'],    'label' => 'Done Today'],
        ['icon' => 'ti-clock-hour-4',   'color' => '#6c757d', 'bg' => '#f1f3f5', 'value' => $stats['avg_wait'] !== null ? $stats['avg_wait'] . 'm' : '—', 'label' => 'Avg. Wait Time'],
    ];
    echo '<div class="row g-3 mb-3">';
    renderStatCards($cards);
    echo '</div>';

    echo '<div class="row g-3">';
    foreach ($categories as $cat) {
        $serving = $nowServing[$cat];
        echo '<div class="col-md-6 col-xl-3">';
        echo '<div class="card h-100">';
        echo '<div class="card-header d-flex align-items-center justify-content-between" style="border-left:4px solid ' . $catColors[$cat] . ';">';
        echo '<h6 class="mb-0 fw-bold"><i class="ti ' . $catIcons[$cat] . ' me-2" style="color:' . $catColors[$cat] . ';"></i>' . $cat . '</h6>';
        echo '<span class="badge" style="background:' . $catColors[$cat] . ';">' . count($queues[$cat]) . ' waiting</span>';
        echo '</div>';

        echo '<div class="p-3 text-center" style="background:#fafbfc;border-bottom:1px solid #eee;">';
        echo '<div class="text-muted" style="font-size:.7rem;text-transform:uppercase;letter-spacing:.5px;">Now Serving</div>';
        if ($serving) {
            echo '<div class="fw-bold" style="font-size:2rem;color:' . $catColors[$cat] . ';line-height:1.1;">#' . str_pad((string)$serving['queue_no'], 2, '0', STR_PAD_LEFT) . '</div>';
        } else {
            echo '<div class="fw-bold text-muted" style="font-size:2rem;line-height:1.1;">—</div>';
        }
        echo '</div>';

        echo '<div class="card-body p-2 queue-entry-list" style="max-height:380px;overflow-y:auto;">';
        if (empty($queues[$cat])) {
            echo '<p class="text-muted text-center py-4 mb-0" style="font-size:.85rem;">No patients in queue.</p>';
        } else {
            foreach ($queues[$cat] as $q) {
                $waitedMin = (int)((time() - strtotime($q['time_in'])) / 60);
                $isPriority = $q['priority'] !== 'normal';
                echo '<div class="queue-entry d-flex align-items-center justify-content-between p-2 mb-2 rounded" data-name="' . htmlspecialchars(strtolower($q['patient_name'] . ' ' . $q['patient_no'])) . '" style="background:' . ($q['status'] === 'serving' ? '#fff8e1' : '#f8f9fa') . ';border:1px solid ' . ($isPriority ? $priorityColors[$q['priority']] : '#eee') . ';' . ($isPriority ? 'border-width:1.5px;' : '') . '">';
                echo '<div class="d-flex align-items-center gap-2">';
                echo '<div class="fw-bold text-center" style="width:38px;height:38px;line-height:38px;border-radius:50%;background:' . $catColors[$cat] . ';color:#fff;font-size:.9rem;flex-shrink:0;">' . str_pad((string)$q['queue_no'], 2, '0', STR_PAD_LEFT) . '</div>';
                echo '<div>';
                echo '<div class="fw-semibold" style="font-size:.85rem;">' . htmlspecialchars($q['patient_name']) . '</div>';
                echo '<div class="text-muted" style="font-size:.75rem;">' . htmlspecialchars($q['patient_no']) . '</div>';
                echo '<div class="d-flex align-items-center gap-1 mt-1 flex-wrap">';
                echo $q['status'] === 'serving'
                    ? '<span class="badge bg-warning text-dark" style="font-size:.62rem;">Serving</span>'
                    : '<span class="badge bg-secondary bg-opacity-25 text-secondary" style="font-size:.62rem;">Waiting ' . $waitedMin . 'm</span>';
                if ($isPriority) {
                    echo '<span class="badge" style="font-size:.62rem;background:' . $priorityColors[$q['priority']] . ';">' . $priorityLabels[$q['priority']] . '</span>';
                }
                if ($q['appointment_id']) {
                    echo '<span class="badge bg-info bg-opacity-15 text-info" style="font-size:.62rem;" title="Checked in from an appointment"><i class="ti ti-calendar-event"></i></span>';
                }
                echo '</div>';
                echo '</div>';
                echo '</div>';

                echo '<div class="d-flex flex-column gap-1 align-items-end">';
                echo '<div class="d-flex gap-1">';
                if ($q['status'] === 'waiting') {
                    echo '<a href="' . csrfUrl('queueing.php?action=serve&id=' . $q['id']) . '" class="btn btn-sm btn-outline-primary py-0 px-2" style="font-size:.7rem;" title="Call / Start Serving"><i class="ti ti-bell"></i></a>';
                } else {
                    echo '<a href="' . csrfUrl('queueing.php?action=done&id=' . $q['id']) . '" class="btn btn-sm btn-outline-success py-0 px-2" style="font-size:.7rem;" title="Mark Done"><i class="ti ti-check"></i></a>';
                }
                echo '<a href="' . csrfUrl('queueing.php?action=cancel&id=' . $q['id']) . '" class="btn btn-sm btn-outline-danger py-0 px-2" style="font-size:.7rem;" title="Cancel" onclick="return confirm(\'Remove this patient from the queue?\')"><i class="ti ti-x"></i></a>';
                echo '</div>';
                echo '<select class="form-select form-select-sm py-0" style="font-size:.65rem;width:auto;" title="Priority lane" onchange="if(this.value) location.href=this.value;">';
                foreach ($priorityLabels as $pKey => $pLabel) {
                    $url = csrfUrl('queueing.php?action=setpriority&id=' . $q['id'] . '&priority=' . $pKey);
                    echo '<option value="' . htmlspecialchars($url) . '"' . ($q['priority'] === $pKey ? ' selected' : '') . '>' . $pLabel . '</option>';
                }
                echo '</select>';
                echo '</div>';
                echo '</div>';
            }
        }
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }
    echo '</div>';
}

// AJAX/polling partial — returns just the auto-refreshing section so the
// page doesn't need a jarring full reload (and doesn't lose modal/scroll
// state) every few seconds.
if (isset($_GET['partial'])) {
    header('Content-Type: text/html; charset=utf-8');
    renderQueueSection($categories, $queues, $nowServing, $stats, $catIcons, $catColors, $priorityLabels, $priorityColors);
    exit;
}

// ── Approved appointments scheduled for today, not yet checked in ────────
$readyToCheckIn = [];
$r = $conn->prepare("
    SELECT a.id, a.category, a.scheduled_time, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no
    FROM appointments a
    JOIN patients p ON p.id = a.patient_id
    LEFT JOIN patient_queue pq ON pq.appointment_id = a.id AND pq.status IN ('waiting','serving')
    WHERE a.status='approved' AND a.scheduled_date = ? AND pq.id IS NULL
    ORDER BY a.scheduled_time ASC
");
$r->bind_param('s', $today);
$r->execute();
$res = $r->get_result();
while ($row = $res->fetch_assoc()) $readyToCheckIn[] = $row;
$r->close();

// ── Patients for the manual Add-to-Queue modal ───────────────────────────
$patients = [];
$r = $conn->query("SELECT id, patient_no, CONCAT(first_name,' ',last_name) as name, date_of_birth FROM patients WHERE status='active'" . doctorScopeSql() . " ORDER BY last_name");
while ($row = $r->fetch_assoc()) $patients[] = $row;
$conn->close();

if (isset($_GET['msg'])) {
    $msg = [
        'added'      => 'Patient added to queue.',
        'updated'    => 'Queue status updated.',
        'checked_in' => 'Patient checked in from their appointment.',
        'error'      => 'Could not update the queue. Please try again.',
    ][$_GET['msg']] ?? '';
}

$pageTitle = 'Queueing';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<div class="page-header"><div class="page-block">
    <h5 class="m-b-10">Queueing</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Services</li><li class="breadcrumb-item active">Queueing</li></ul>
</div></div>

<?php if ($msg): ?><div class="alert alert-success alert-dismissible fade show"><i class="ti ti-circle-check me-2"></i><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

<?php if (!empty($readyToCheckIn)): ?>
<div class="card mb-3">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0"><i class="ti ti-calendar-event me-2" style="color:#8e24aa;"></i>Today's Appointments Ready for Check-In</h6>
        <span class="badge bg-purple" style="background:#8e24aa;"><?= count($readyToCheckIn) ?></span>
    </div>
    <div class="card-body p-2">
        <div class="d-flex flex-wrap gap-2">
            <?php foreach ($readyToCheckIn as $a): ?>
            <div class="d-flex align-items-center gap-2 px-3 py-2 rounded" style="background:#f8f9fa;border:1px solid #eee;">
                <div>
                    <div class="fw-semibold" style="font-size:.85rem;"><?= htmlspecialchars($a['patient_name']) ?> <span class="text-muted" style="font-size:.75rem;">(<?= htmlspecialchars($a['patient_no']) ?>)</span></div>
                    <div class="text-muted" style="font-size:.75rem;"><?= htmlspecialchars($a['category']) ?><?= $a['scheduled_time'] ? ' • ' . date('h:i A', strtotime($a['scheduled_time'])) : '' ?></div>
                </div>
                <a href="<?= csrfUrl('queueing.php?checkin_appointment=' . $a['id']) ?>" class="btn btn-sm btn-primary py-1"><i class="ti ti-login-2 me-1"></i>Check In</a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="card mb-3">
    <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h6 class="section-title mb-0"><i class="ti ti-users-group me-2" style="color:#0d6efd;"></i>Today's Queue &mdash; <?= date('F d, Y') ?></h6>
        <div class="d-flex align-items-center gap-2">
            <input type="text" class="form-control form-control-sm" id="queueSearch" placeholder="Search name or patient no..." style="width:220px;">
            <a href="queue_display.php" target="_blank" class="btn btn-outline-secondary btn-sm" title="Open the waiting-room Now Serving display in a new tab">
                <i class="ti ti-device-tv me-1"></i>Open Display
            </a>
            <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#queueModal">
                <i class="ti ti-plus me-1"></i>Add to Queue
            </button>
        </div>
    </div>
</div>

<div id="queueSection">
<?php renderQueueSection($categories, $queues, $nowServing, $stats, $catIcons, $catColors, $priorityLabels, $priorityColors); ?>
</div>

<!-- Add to Queue Modal -->
<div class="modal fade" id="queueModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="ti ti-users-group me-2"></i>Add Patient to Queue</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="enqueue">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Patient *</label>
                        <select class="form-select" name="patient_id" id="qPatient" required onchange="suggestQueuePriority()">
                            <option value="">Select Patient</option>
                            <?php foreach ($patients as $p): ?><option value="<?= $p['id'] ?>" data-dob="<?= htmlspecialchars($p['date_of_birth'] ?: '') ?>"><?= htmlspecialchars($p['patient_no'].' - '.$p['name']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Category *</label>
                        <select class="form-select" name="category" required>
                            <option value="">Select Category</option>
                            <?php foreach ($categories as $cat): ?><option value="<?= $cat ?>"><?= $cat ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Priority Lane</label>
                        <select class="form-select" name="priority" id="qPriority">
                            <?php foreach ($priorityLabels as $pKey => $pLabel): ?><option value="<?= $pKey ?>"><?= $pLabel ?></option><?php endforeach; ?>
                        </select>
                        <small class="text-muted">Auto-suggested from date of birth (60+) — adjust for PWD/Pregnant as needed, per RA 9994 / RA 10754.</small>
                    </div>
                    <p class="text-muted mb-0" style="font-size:.8rem;"><i class="ti ti-info-circle me-1"></i>The patient will be assigned the next queue number for the selected category, for today.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-plus me-1"></i>Add to Queue</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php
$extraJS = '
<script>
function suggestQueuePriority() {
    var sel = document.getElementById("qPatient");
    var opt = sel.options[sel.selectedIndex];
    var dob = opt.getAttribute("data-dob");
    if (!dob) return;
    var age = Math.floor((new Date() - new Date(dob)) / (365.25 * 24 * 3600 * 1000));
    if (age >= 60) document.getElementById("qPriority").value = "senior";
}

function filterQueueEntries() {
    var q = document.getElementById("queueSearch").value.trim().toLowerCase();
    document.querySelectorAll(".queue-entry").forEach(function(el){
        el.style.display = (!q || el.getAttribute("data-name").indexOf(q) !== -1) ? "" : "none";
    });
}
document.getElementById("queueSearch").addEventListener("input", filterQueueEntries);

// Live refresh: swap in the latest queue HTML every 15s without a full
// page reload, so the search filter, scroll position, and any open modal
// are left alone.
setInterval(function () {
    fetch("queueing.php?partial=1")
        .then(function (r) { return r.text(); })
        .then(function (html) {
            document.getElementById("queueSection").innerHTML = html;
            filterQueueEntries();
        })
        .catch(function () { /* next tick will retry */ });
}, 15000);
</script>';
include __DIR__ . '/../../includes/layout_footer.php';
?>
