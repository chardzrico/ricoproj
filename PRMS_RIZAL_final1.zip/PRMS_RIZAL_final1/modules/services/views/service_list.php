<?php
// Sub-Services card for modules/services/category.php.
// Expects: $cat, $subServices, $serviceUsage (all set by category.php before including this).
/** @var string $cat */
/** @var array $subServices */
/** @var array $serviceUsage */
?>
<div class="col-lg-4">
    <div class="card h-100">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h6 class="section-title mb-0">Sub-Services</h6>
            <button class="btn btn-primary btn-sm" onclick="openServiceModal()"><i class="ti ti-plus me-1"></i>Add</button>
        </div>
        <div class="card-body p-0">
            <?php if (empty($subServices)): ?>
            <p class="text-muted text-center py-4 mb-0">No <?= htmlspecialchars($cat) ?> sub-services yet — add the first one.</p>
            <?php else: ?>
            <ul class="list-group list-group-flush">
                <?php foreach ($subServices as $s): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center <?= $s['status'] === 'inactive' ? 'opacity-50' : '' ?>">
                    <div>
                        <div class="fw-semibold"><?= htmlspecialchars($s['service_name']) ?></div>
                        <?php if ($s['description']): ?><div class="text-muted" style="font-size:.78rem;"><?= htmlspecialchars($s['description']) ?></div><?php endif; ?>
                    </div>
                    <div class="d-flex align-items-center gap-2">
                        <?php if ($s['status'] === 'inactive'): ?><span class="badge bg-secondary">Inactive</span><?php endif; ?>
                        <button class="btn-edit btn btn-sm" title="Edit" onclick='openServiceModal(<?= htmlspecialchars(json_encode($s), ENT_QUOTES) ?>)'><i class="ti ti-edit"></i></button>
                        <button class="btn btn-sm btn-outline-secondary" title="<?= $s['status'] === 'active' ? 'Deactivate' : 'Reactivate' ?>" onclick="location.href='<?= csrfUrl('category.php?cat=' . urlencode($cat) . '&toggle_service=' . $s['id']) ?>'">
                            <i class="ti <?= $s['status'] === 'active' ? 'ti-eye-off' : 'ti-eye' ?>"></i>
                        </button>
                        <?php if (!empty($serviceUsage[$s['id']])): ?>
                        <button class="btn btn-sm btn-outline-secondary" disabled title="Has <?= $serviceUsage[$s['id']] ?> patient record<?= $serviceUsage[$s['id']] === 1 ? '' : 's' ?> — deactivate instead of deleting">
                            <i class="ti ti-trash"></i>
                        </button>
                        <?php else: ?>
                        <button class="btn-delete btn btn-sm" title="Delete" onclick="confirmDelete('<?= csrfUrl('category.php?cat=' . urlencode($cat) . '&delete_service=' . $s['id']) ?>','<?= htmlspecialchars($s['service_name'], ENT_QUOTES) ?>')">
                            <i class="ti ti-trash"></i>
                        </button>
                        <?php endif; ?>
                    </div>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
        </div>
    </div>
</div>
