<?php
// Medico-Legal Examination body diagram — embedded inside the Record
// Service modal (modules/services/views/record_modal.php). Only shown
// (via JS) when the selected sub-service is a Medico-Legal Examination.
// Needs bodySilhouetteSvg() from includes/helpers.php.
?>
<div class="mb-1" id="injuryMapSection" style="display:none;">
    <hr>
    <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
        <label class="form-label mb-0"><i class="ti ti-scan me-1"></i>Body Diagram — Findings</label>
        <div class="btn-group btn-group-sm" role="group">
            <button type="button" class="btn btn-outline-secondary active" id="viewFrontBtn" onclick="switchBodyView('front')">Front</button>
            <button type="button" class="btn btn-outline-secondary" id="viewBackBtn" onclick="switchBodyView('back')">Back</button>
        </div>
    </div>
    <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
        <button type="button" class="btn btn-sm btn-outline-purple" id="linkModeBtn" style="border-color:#8e24aa;color:#8e24aa;" onclick="toggleLinkMode()">
            <i class="ti ti-line" id="linkModeIcon"></i> <span id="linkModeLabel">Link Entry ⇄ Exit (one injury, two marks)</span>
        </button>
    </div>
    <div id="linkModeBanner" class="alert alert-purple mb-2" style="display:none;background:#faf5fc;color:#6a1b7a;border:1px solid #e0c3ec;">
        <span id="linkModeStatusText"></span>
        <button type="button" class="btn btn-sm btn-link text-danger p-0 ms-2" onclick="cancelLinkMode()">Cancel</button>
    </div>
    <div class="row g-3">
        <div class="col-12 col-sm-5">
            <div class="body-diagram-wrap" id="bodyDiagramWrap" onclick="onBodyClick(event)" onmouseover="onBodyHover(event)" onmouseout="onBodyHoverOut(event)">
                <?= bodySilhouetteSvg('frontSvg', 'front') ?>
                <?php $backSvg = bodySilhouetteSvg('backSvg', 'back'); ?>
                <?= str_replace('<svg id="backSvg"', '<svg id="backSvg" style="display:none;"', $backSvg) ?>
                <div id="markerLayer" style="position:absolute; inset:0; pointer-events:none;"></div>
            </div>
            <p class="text-center mb-0 mt-1"><span class="zone-hover-label" id="zoneHoverLabel">Hover the diagram to see each body region</span></p>
            <p class="text-muted text-center mb-0" style="font-size:.72rem;">Click a region to drop a pin where the finding is.</p>
        </div>
        <div class="col-12 col-sm-7">
            <div id="findingsList" class="d-flex flex-column gap-2" style="max-height:280px; overflow-y:auto;"></div>
            <p class="text-muted mb-0" id="noFindingsMsg" style="font-size:.8rem;">No findings marked yet.</p>
        </div>
    </div>
    <input type="hidden" name="injury_map" id="injuryMapInput">
</div>
