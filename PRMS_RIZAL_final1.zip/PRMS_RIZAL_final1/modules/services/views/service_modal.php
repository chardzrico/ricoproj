<?php
// Add/Edit Sub-Service modal for modules/services/category.php.
// Expects: $cat, $catMeta (set by category.php before including this).
/** @var string $cat */
/** @var array $catMeta */
?>
<div class="modal fade" id="serviceModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" action="category.php?cat=<?= urlencode($cat) ?>">
                <?= csrfField() ?>
                <input type="hidden" name="save_service" value="1">
                <input type="hidden" name="service_id" id="svcId">
                <div class="modal-header" style="background:<?= $catMeta['color'] ?>;">
                    <h5 class="modal-title" id="svcModalTitle" style="color:#fff;"><i class="ti ti-plus me-2" style="color:#fff;"></i>Add Sub-Service</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Sub-Service Name *</label>
                        <input type="text" class="form-control" name="service_name" id="svcName" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea class="form-control" name="description" id="svcDesc" rows="2"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Fee (optional)</label>
                        <input type="number" step="0.01" min="0" class="form-control" name="fee" id="svcFee" placeholder="0.00">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Sub-Service</button>
                </div>
            </form>
        </div>
    </div>
</div>
