<?php
// Dental Chart — read-only odontogram viewer, for modules/services/category.php.
// Expects: $catMeta (set by category.php); only included there when $cat === 'Dental'.
/** @var array $catMeta */
?>
<div class="modal fade" id="odontogramViewModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header" style="background:<?= $catMeta['color'] ?>;">
                <h5 class="modal-title" style="color:#fff;"><i class="ti ti-mood-smile me-2" style="color:#fff;"></i>Dental Chart — <span id="examOdontoPatientName"></span></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="text-muted mb-2" id="examOdontoMeta" style="font-size:.85rem;"></div>
                <div id="examOdontogramChart" class="odontogram-chart">
                    <?= odontogramArchSvg(ODONTOGRAM_UPPER_TEETH, false) ?>
                    <?= odontogramArchSvg(ODONTOGRAM_LOWER_TEETH, true) ?>
                </div>
                <div id="examOdontogramLegend" class="d-flex flex-wrap gap-2 mt-2 mb-3" style="font-size:.72rem;"></div>
                <div id="examOdontogramList" class="d-flex flex-column gap-2" style="max-height:260px; overflow-y:auto;"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
