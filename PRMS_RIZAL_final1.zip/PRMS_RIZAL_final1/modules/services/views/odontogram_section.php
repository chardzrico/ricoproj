<?php
// Dental Chart (odontogram) — embedded inside the Record Service modal
// (modules/services/views/record_modal.php), only included there when
// $cat === 'Dental'.
?>
<div class="mb-1">
    <hr>
    <label class="form-label mb-2"><i class="ti ti-mood-smile me-1"></i>Dental Chart</label>
    <p class="text-muted mb-2" style="font-size:.76rem;">Click a tooth to mark it, then choose what was done. Numbers use the FDI two-digit system.</p>
    <div id="odontogramChart" class="odontogram-chart" onclick="onToothClick(event)">
        <?= odontogramArchSvg(ODONTOGRAM_UPPER_TEETH, false) ?>
        <?= odontogramArchSvg(ODONTOGRAM_LOWER_TEETH, true) ?>
    </div>
    <div id="odontogramLegend" class="d-flex flex-wrap gap-2 mt-2 mb-3" style="font-size:.72rem;"></div>
    <div id="odontogramList" class="d-flex flex-column gap-2" style="max-height:220px; overflow-y:auto;"></div>
    <p class="text-muted mb-0" id="noTeethMsg" style="font-size:.8rem;">No teeth marked yet.</p>
    <input type="hidden" name="odontogram" id="odontogramInput">
</div>
