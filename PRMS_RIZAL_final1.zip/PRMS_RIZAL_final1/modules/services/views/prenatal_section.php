<?php
// Prenatal / Maternal Care structured fields — embedded inside the Record
// Service modal (modules/services/views/record_modal.php). Only shown (via
// JS) when the selected sub-service is Prenatal.
$dangerSignOptions = [
    'Vaginal bleeding', 'Severe headache', 'Blurred vision', 'Swelling of face/hands',
    'Decreased fetal movement', 'Severe abdominal pain', 'High fever', 'Convulsions',
];
?>
<div class="mb-1" id="prenatalSection" style="display:none;">
    <hr>
    <label class="form-label mb-2"><i class="ti ti-heartbeat me-1"></i>Prenatal / Maternal Care</label>
    <div class="row">
        <div class="col-md-3 mb-3">
            <label class="form-label">LMP <small class="text-muted">(Last Menstrual Period)</small></label>
            <input type="date" class="form-control" name="prenatal_lmp" id="pnLmp" onchange="calcEDD()">
        </div>
        <div class="col-md-3 mb-3">
            <label class="form-label">EDD <small class="text-muted">(Estimated Delivery)</small></label>
            <input type="date" class="form-control" name="prenatal_edd" id="pnEdd">
        </div>
        <div class="col-md-3 mb-3">
            <label class="form-label">Trimester</label>
            <input type="text" class="form-control bg-light" id="pnTrimester" readonly placeholder="Auto-calc from LMP">
        </div>
        <div class="col-md-3 mb-3">
            <label class="form-label">Blood Pressure</label>
            <input type="text" class="form-control" name="prenatal_bp" id="pnBp" placeholder="e.g. 120/80">
        </div>
    </div>
    <div class="row">
        <div class="col-md-3 mb-3">
            <label class="form-label">Gravida <small class="text-muted">(# pregnancies)</small></label>
            <input type="number" min="0" class="form-control" name="prenatal_gravida" id="pnGravida">
        </div>
        <div class="col-md-3 mb-3">
            <label class="form-label">Para <small class="text-muted">(# live births)</small></label>
            <input type="number" min="0" class="form-control" name="prenatal_para" id="pnPara">
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label">Tetanus Toxoid Status</label>
            <select class="form-select" name="prenatal_tt_status" id="pnTt">
                <option value="">Select…</option>
                <option value="TT1">TT1</option>
                <option value="TT2">TT2</option>
                <option value="TT3">TT3</option>
                <option value="TT4">TT4</option>
                <option value="TT5">TT5</option>
                <option value="Fully Immunized">Fully Immunized</option>
            </select>
        </div>
    </div>
    <div class="mb-1">
        <label class="form-label">Danger Signs <small class="text-muted">(check all present)</small></label>
        <div class="d-flex flex-wrap gap-3">
            <?php foreach ($dangerSignOptions as $sign): ?>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" name="prenatal_danger_signs[]" value="<?= htmlspecialchars($sign) ?>" id="pnDs_<?= md5($sign) ?>">
                <label class="form-check-label" for="pnDs_<?= md5($sign) ?>" style="font-size:.85rem;"><?= htmlspecialchars($sign) ?></label>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
