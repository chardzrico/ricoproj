<?php
// Record (Add/Edit) Service modal for modules/services/category.php.
// Expects: $cat, $catMeta, $patients, $subServices (set by category.php before including this).
/** @var string $cat */
/** @var array $catMeta */
/** @var array $patients */
/** @var array $subServices */
?>
<div class="modal fade" id="recordModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="post" action="category.php?cat=<?= urlencode($cat) ?>" id="recordForm" onsubmit="finalizeInjuryMap()">
                <?= csrfField() ?>
                <input type="hidden" name="save_record" value="1">
                <input type="hidden" name="record_id" id="recId">
                <div class="modal-header" style="background:<?= $catMeta['color'] ?>;">
                    <h5 class="modal-title" id="recModalTitle" style="color:#fff;"><i class="ti ti-file-plus me-2" style="color:#fff;"></i>Record <?= htmlspecialchars($cat) ?> Service</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Patient *</label>
                        <select class="form-select" name="patient_id" id="recPatient" required>
                            <option value="">Select patient…</option>
                            <?php foreach ($patients as $p): ?>
                            <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['patient_no'] . ' - ' . $p['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Sub-Service *</label>
                        <select class="form-select" name="service_id" id="recService" onchange="toggleSpecialSections()" required>
                            <option value="">Select sub-service…</option>
                            <?php foreach ($subServices as $s): if ($s['status'] !== 'active') continue; ?>
                            <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['service_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row">
                        <div class="col-6 mb-3">
                            <label class="form-label">Date *</label>
                            <input type="date" class="form-control" name="service_date" id="recDate" value="<?= date('Y-m-d') ?>" onchange="calcTrimester()" required>
                        </div>
                        <div class="col-6 mb-3">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="status" id="recStatus">
                                <option value="done">Done</option>
                                <option value="pending">Pending</option>
                                <option value="cancelled">Cancelled</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Notes</label>
                        <textarea class="form-control" name="notes" id="recNotes" rows="3"></textarea>
                    </div>

                    <?php include __DIR__ . '/medicolegal_section.php'; ?>

                    <?php if ($cat === 'Dental') include __DIR__ . '/odontogram_section.php'; ?>

                    <?php if ($cat === 'Medical'): ?>
                    <?php include __DIR__ . '/prenatal_section.php'; ?>
                    <?php include __DIR__ . '/family_planning_section.php'; ?>
                    <?php include __DIR__ . '/tbdots_section.php'; ?>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save Record</button>
                </div>
            </form>
        </div>
    </div>
</div>
