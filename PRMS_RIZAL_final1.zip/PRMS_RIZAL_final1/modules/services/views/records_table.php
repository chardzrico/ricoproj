<?php
// Patient service history table for modules/services/category.php.
// Expects: $cat, $records, $statusBadge, $subServices (all set by category.php before including this).
/** @var string $cat */
/** @var array $records */
/** @var array $statusBadge */
/** @var array $subServices */
?>
<div class="col-lg-8">
    <div class="card h-100">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h6 class="section-title mb-0">Patient Records — <?= htmlspecialchars($cat) ?></h6>
            <button class="btn btn-primary btn-sm" onclick="openRecordModal()" <?= empty($subServices) ? 'disabled title="Add a sub-service first"' : '' ?>>
                <i class="ti ti-plus me-1"></i>Record Service
            </button>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table prms-datatable mb-0" style="font-size:.88rem;">
                    <thead>
                        <tr><th>Patient</th><th>Sub-Service</th><th>Date</th><th>Details</th><th>Notes</th><th>Status</th><th>Staff</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($records as $rec): $summary = serviceRecordSummary($rec); ?>
                        <tr>
                            <td>
                                <div class="fw-semibold"><?= htmlspecialchars($rec['patient_name'] ?? '') ?></div>
                                <div class="text-muted" style="font-size:.78rem;"><?= htmlspecialchars($rec['patient_no'] ?? '') ?></div>
                            </td>
                            <td><?= htmlspecialchars($rec['service_name'] ?? '—') ?></td>
                            <td><?= date('M d, Y', strtotime($rec['service_date'])) ?></td>
                            <td style="max-width:170px;"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.8rem;" title="<?= htmlspecialchars($summary ?? '') ?>"><?= htmlspecialchars($summary ?? '—') ?></div></td>
                            <td style="max-width:150px;"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= htmlspecialchars($rec['notes'] ?? '') ?>"><?= htmlspecialchars($rec['notes'] ?: '—') ?></div></td>
                            <td><span class="badge <?= $statusBadge[$rec['status']] ?? 'bg-secondary' ?>"><?= ucfirst($rec['status']) ?></span></td>
                            <td><?= htmlspecialchars($rec['staff_name'] ?: '—') ?></td>
                            <td>
                                <?php if (!empty($rec['injury_map']) && stripos($rec['service_name'] ?? '', 'medico-legal') !== false): ?>
                                <button class="btn btn-sm btn-outline-primary me-1" title="View Exam Diagram" onclick='openExamView(<?= htmlspecialchars(json_encode($rec), ENT_QUOTES) ?>)'><i class="ti ti-scan"></i></button>
                                <?php endif; ?>
                                <?php if ($cat === 'Dental' && !empty($rec['odontogram'])): ?>
                                <button class="btn btn-sm btn-outline-primary me-1" title="View Dental Chart" onclick='openOdontogramView(<?= htmlspecialchars(json_encode($rec), ENT_QUOTES) ?>)'><i class="ti ti-mood-smile"></i></button>
                                <?php endif; ?>
                                <button class="btn-edit btn btn-sm me-1" onclick='openRecordModal(<?= htmlspecialchars(json_encode($rec), ENT_QUOTES) ?>)'><i class="ti ti-edit"></i></button>
                                <button class="btn-delete btn btn-sm" onclick="confirmDelete('<?= csrfUrl('category.php?cat=' . urlencode($cat) . '&delete_record=' . $rec['id']) ?>','this record')"><i class="ti ti-trash"></i></button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
