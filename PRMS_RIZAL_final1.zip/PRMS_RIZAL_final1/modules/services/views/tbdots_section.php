<?php
// TB-DOTS structured fields — embedded inside the Record Service modal
// (modules/services/views/record_modal.php). Only shown (via JS) when the
// selected sub-service is TB-DOTS. Each visit's tb_attendance value is one
// entry in that patient's DOTS attendance/compliance calendar — see
// modules/services/tb_compliance.php.
?>
<div class="mb-1" id="tbSection" style="display:none;">
    <hr>
    <label class="form-label mb-2"><i class="ti ti-lungs me-1"></i>TB-DOTS</label>
    <div class="row">
        <div class="col-md-3 mb-3">
            <label class="form-label">Sputum Result</label>
            <select class="form-select" name="tb_sputum_result" id="tbSputum">
                <option value="">Select…</option>
                <option>Positive</option>
                <option>Negative</option>
                <option>Not Done</option>
            </select>
        </div>
        <div class="col-md-3 mb-3">
            <label class="form-label">Treatment Category</label>
            <select class="form-select" name="tb_treatment_category" id="tbCategory">
                <option value="">Select…</option>
                <option value="Category I">Category I (New)</option>
                <option value="Category II">Category II (Retreatment)</option>
                <option value="Category III">Category III</option>
            </select>
        </div>
        <div class="col-md-3 mb-3">
            <label class="form-label">Regimen</label>
            <input type="text" class="form-control" name="tb_regimen" id="tbRegimen" placeholder="e.g. 2HRZE/4HR">
        </div>
        <div class="col-md-3 mb-3">
            <label class="form-label">This Visit's Attendance</label>
            <select class="form-select" name="tb_attendance" id="tbAttendance">
                <option value="">Select…</option>
                <option value="taken">Taken</option>
                <option value="missed">Missed</option>
            </select>
        </div>
    </div>
</div>
