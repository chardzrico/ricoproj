<?php
// Medico-Legal Exam — read-only body diagram viewer, for modules/services/category.php.
// Expects: $catMeta (set by category.php before including this).
/** @var array $catMeta */
?>
<div class="modal fade" id="examViewModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header" style="background:<?= $catMeta['color'] ?>;">
                <h5 class="modal-title" style="color:#fff;"><i class="ti ti-scan me-2" style="color:#fff;"></i>Medico-Legal Exam — <span id="examPatientName"></span></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="text-muted" id="examMeta" style="font-size:.85rem;"></div>
                    <div class="btn-group btn-group-sm" role="group">
                        <button type="button" class="btn btn-outline-secondary active" id="examFrontBtn" onclick="switchExamView('front')">Front</button>
                        <button type="button" class="btn btn-outline-secondary" id="examBackBtn" onclick="switchExamView('back')">Back</button>
                    </div>
                </div>
                <div class="row g-3">
                    <div class="col-12 col-sm-5">
                        <div class="body-diagram-wrap" id="examDiagramWrap">
                            <?= bodySilhouetteSvg('examFrontSvg', 'front') ?>
                            <?php $examBackSvg = bodySilhouetteSvg('examBackSvg', 'back'); ?>
                            <?= str_replace('<svg id="examBackSvg"', '<svg id="examBackSvg" style="display:none;"', $examBackSvg) ?>
                            <div id="examMarkerLayer" style="position:absolute; inset:0; pointer-events:none;"></div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-7">
                        <div id="examFindingsList" class="d-flex flex-column gap-2" style="max-height:320px; overflow-y:auto;"></div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
