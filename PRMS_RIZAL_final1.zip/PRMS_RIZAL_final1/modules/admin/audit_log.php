<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();
if (!isAdmin()) { header('Location: ' . BASE_URL . '/dashboard.php'); exit; }

$conn = getDBConnection();

// ── Filters ──────────────────────────────────────────────────────────────
$filterUser   = isset($_GET['user_id']) && $_GET['user_id'] !== '' ? (int)$_GET['user_id'] : null;
$filterAction = trim($_GET['action'] ?? '');
$filterFrom   = trim($_GET['date_from'] ?? '');
$filterTo     = trim($_GET['date_to'] ?? '');

$where  = ['1=1'];
$types  = '';
$params = [];

if ($filterUser !== null) { $where[] = 'al.user_id = ?'; $types .= 'i'; $params[] = $filterUser; }
if ($filterAction !== '') { $where[] = 'al.action = ?';  $types .= 's'; $params[] = $filterAction; }
if ($filterFrom !== '')   { $where[] = 'al.created_at >= ?'; $types .= 's'; $params[] = $filterFrom . ' 00:00:00'; }
if ($filterTo !== '')     { $where[] = 'al.created_at <= ?'; $types .= 's'; $params[] = $filterTo . ' 23:59:59'; }

$sql = "SELECT al.*, u.full_name AS user_full_name, u.username AS user_username
        FROM audit_logs al
        LEFT JOIN users u ON al.user_id = u.id
        WHERE " . implode(' AND ', $where) . "
        ORDER BY al.created_at DESC
        LIMIT 300";
$stmt = $conn->prepare($sql);
if ($types !== '') $stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();
$logs = [];
while ($row = $res->fetch_assoc()) $logs[] = $row;
$stmt->close();

// For the filter dropdowns — every user who has at least one log entry,
// and every distinct action type ever recorded, so the filters stay
// accurate as new event types get added later.
$logUsers = [];
$r = $conn->query("SELECT DISTINCT u.id, u.full_name, u.username FROM audit_logs al JOIN users u ON al.user_id = u.id ORDER BY u.full_name");
while ($row = $r->fetch_assoc()) $logUsers[] = $row;

$logActions = [];
$r = $conn->query("SELECT DISTINCT action FROM audit_logs ORDER BY action");
while ($row = $r->fetch_assoc()) $logActions[] = $row['action'];

$totalLogged = $conn->query("SELECT COUNT(*) c FROM audit_logs")->fetch_assoc()['c'];
$conn->close();

// Severity-style coloring so the table can be scanned at a glance —
// failed logins and deletions should visually stand out from routine
// creates/views.
function auditActionBadge(string $action): string {
    if (str_contains($action, 'failed'))                                   $cls = 'bg-danger';
    elseif (str_contains($action, 'delete') || str_contains($action, 'deactivate')) $cls = 'bg-danger';
    elseif (str_contains($action, 'view'))                                  $cls = 'bg-info text-dark';
    elseif (str_contains($action, 'create') || str_contains($action, 'activate') || str_contains($action, 'success')) $cls = 'bg-success';
    elseif (str_contains($action, 'update') || str_contains($action, 'assign'))     $cls = 'bg-warning text-dark';
    else                                                                    $cls = 'bg-secondary';
    return '<span class="badge ' . $cls . '">' . htmlspecialchars(str_replace('_', ' ', $action)) . '</span>';
}

$pageTitle = 'Audit Log';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<div class="page-header"><div class="page-block">
    <h5 class="m-b-10">Audit Log</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Administration</li><li class="breadcrumb-item active">Audit Log</li></ul>
</div></div>

<p class="text-muted" style="font-size:.85rem;">
    <i class="ti ti-info-circle me-1"></i>
    Records logins (including failed attempts), who viewed or changed a patient's record, and user-account changes — showing the most recent <?= min(300, (int)$totalLogged) ?> of <?= (int)$totalLogged ?> total entries. Use the filters below to narrow down to a specific person, action, or date range.
</p>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-3">
                <label class="form-label mb-1">User</label>
                <select name="user_id" class="form-select form-select-sm">
                    <option value="">All users</option>
                    <?php foreach ($logUsers as $u): ?>
                    <option value="<?= $u['id'] ?>" <?= $filterUser === (int)$u['id'] ? 'selected' : '' ?>><?= htmlspecialchars($u['full_name'] . ' (' . $u['username'] . ')') ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label mb-1">Action</label>
                <select name="action" class="form-select form-select-sm">
                    <option value="">All actions</option>
                    <?php foreach ($logActions as $a): ?>
                    <option value="<?= htmlspecialchars($a) ?>" <?= $filterAction === $a ? 'selected' : '' ?>><?= htmlspecialchars(str_replace('_', ' ', $a)) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label mb-1">From</label>
                <input type="date" name="date_from" class="form-control form-control-sm" value="<?= htmlspecialchars($filterFrom) ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label mb-1">To</label>
                <input type="date" name="date_to" class="form-control form-control-sm" value="<?= htmlspecialchars($filterTo) ?>">
            </div>
            <div class="col-md-2 d-flex gap-2">
                <button type="submit" class="btn btn-primary btn-sm"><i class="ti ti-filter me-1"></i>Filter</button>
                <a href="audit_log.php" class="btn btn-outline-secondary btn-sm">Reset</a>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0"><i class="ti ti-history me-2" style="color:#0d6efd;"></i>Activity</h6>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0" style="font-size:.86rem;">
                <thead>
                    <tr><th>Time</th><th>User</th><th>Action</th><th>Target</th><th>Details</th><th>IP Address</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                    <tr>
                        <td><?= date('M d, Y h:i A', strtotime($log['created_at'])) ?></td>
                        <td>
                            <?php if ($log['user_full_name']): ?>
                                <?= htmlspecialchars($log['user_full_name']) ?>
                            <?php elseif ($log['username_attempted']): ?>
                                <span class="text-muted">"<?= htmlspecialchars($log['username_attempted']) ?>" <span class="badge bg-secondary" style="font-size:.65rem;">not a real account</span></span>
                            <?php else: ?>
                                <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                        <td><?= auditActionBadge($log['action']) ?></td>
                        <td><?= $log['target_type'] ? htmlspecialchars($log['target_type']) . ' #' . (int)$log['target_id'] : '—' ?></td>
                        <td><?= htmlspecialchars($log['details'] ?: '—') ?></td>
                        <td class="text-muted"><?= htmlspecialchars($log['ip_address'] ?: '—') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <!-- No manual "empty" row on purpose — see the note in
                         modules/certificates/certificate_log.php for why. -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../includes/layout_footer.php'; ?>
