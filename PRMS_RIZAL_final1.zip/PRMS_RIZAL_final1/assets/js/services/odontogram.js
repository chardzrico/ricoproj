// Dental odontogram widget (FDI two-digit tooth notation) — used by the
// Record Service modal and the read-only dental chart viewer, both in
// modules/services/category.php. The 32 tooth shapes themselves (sized and
// outlined per real tooth type — incisor/canine/premolar/molar) are
// server-rendered once by odontogramArchSvg() in includes/helpers.php; this
// file only paints existing shapes and drives the click/edit interaction.

let odontogram = []; // [{ tooth, procedure, note }]
const PROCEDURE_COLORS = {
    'Caries': '#e65100', 'Filling': '#1565c0', 'Extraction': '#c62828',
    'Root Canal': '#6a1b7a', 'Crown': '#00897b', 'Sealant': '#2e7d32',
    'Missing': '#757575', 'Other': '#455a64'
};
// Must stay in sync with ODONTOGRAM_UPPER_TEETH/LOWER_TEETH in includes/helpers.php.
const UPPER_TEETH = [18,17,16,15,14,13,12,11,21,22,23,24,25,26,27,28].map(String);
const LOWER_TEETH = [48,47,46,45,44,43,42,41,31,32,33,34,35,36,37,38].map(String);

// Click anywhere in the (server-rendered) chart; find which tooth shape
// was actually hit and toggle it. Bound via onclick="onToothClick(event)"
// on #odontogramChart only — the read-only viewer isn't clickable.
function onToothClick(e) {
    const shape = e.target.closest ? e.target.closest('.tooth-shape') : null;
    if (shape) toggleTooth(shape.dataset.tooth);
}

function renderOdontogramChart(editable = true) {
    const chart = document.getElementById(editable ? 'odontogramChart' : 'examOdontogramChart');
    if (!chart) return;
    chart.querySelectorAll('.tooth-shape').forEach(shape => {
        const entry = odontogram.find(o => o.tooth === shape.dataset.tooth);
        shape.classList.toggle('marked', !!entry);
        shape.style.fill = entry ? (PROCEDURE_COLORS[entry.procedure] || PROCEDURE_COLORS['Other']) : '';
    });

    const legendId = editable ? 'odontogramLegend' : 'examOdontogramLegend';
    const legend = document.getElementById(legendId);
    if (legend) {
        legend.innerHTML = '';
        Object.keys(PROCEDURE_COLORS).forEach(proc => {
            const chip = document.createElement('span');
            chip.className = 'odontogram-legend-chip';
            chip.style.background = PROCEDURE_COLORS[proc];
            chip.textContent = proc;
            legend.appendChild(chip);
        });
    }
}

function toggleTooth(tooth) {
    const idx = odontogram.findIndex(o => o.tooth === tooth);
    if (idx >= 0) {
        odontogram.splice(idx, 1);
    } else {
        odontogram.push({ tooth: tooth, procedure: 'Caries', note: '' });
    }
    renderOdontogramChart();
    renderOdontogramList();
    syncOdontogramInput();
}

function renderOdontogramList() {
    const list = document.getElementById('odontogramList');
    const noMsg = document.getElementById('noTeethMsg');
    if (!list) return;
    list.innerHTML = '';
    noMsg.style.display = odontogram.length ? 'none' : '';
    // Keep the list in tooth-number order so it reads left-to-right like the chart.
    const ordered = [...odontogram].sort((a, b) => UPPER_TEETH.concat(LOWER_TEETH).indexOf(a.tooth) - UPPER_TEETH.concat(LOWER_TEETH).indexOf(b.tooth));
    ordered.forEach(entry => {
        const card = document.createElement('div');
        card.className = 'injury-finding-card p-2';

        const head = document.createElement('div');
        head.className = 'd-flex justify-content-between align-items-center mb-1 gap-2';
        const badge = document.createElement('span');
        badge.className = 'badge';
        badge.style.background = PROCEDURE_COLORS[entry.procedure] || PROCEDURE_COLORS['Other'];
        badge.textContent = 'Tooth ' + entry.tooth;

        const procSelect = document.createElement('select');
        procSelect.className = 'form-select form-select-sm';
        procSelect.style.maxWidth = '150px';
        Object.keys(PROCEDURE_COLORS).forEach(proc => {
            const opt = document.createElement('option');
            opt.value = proc; opt.textContent = proc;
            if (proc === entry.procedure) opt.selected = true;
            procSelect.appendChild(opt);
        });
        procSelect.onchange = function () { entry.procedure = procSelect.value; renderOdontogramChart(); renderOdontogramList(); syncOdontogramInput(); };

        const rmBtn = document.createElement('button');
        rmBtn.type = 'button';
        rmBtn.className = 'btn btn-sm btn-outline-danger py-0 px-1';
        rmBtn.innerHTML = '<i class="ti ti-x"></i>';
        rmBtn.addEventListener('click', function (ev) { ev.preventDefault(); ev.stopPropagation(); try { toggleTooth(entry.tooth); } catch (err) { console.error('odontogram rm click error', err); } });

        head.appendChild(badge); head.appendChild(procSelect); head.appendChild(rmBtn);
        card.appendChild(head);

        const noteInput = document.createElement('input');
        noteInput.type = 'text';
        noteInput.className = 'form-control form-control-sm';
        noteInput.placeholder = 'Note (optional)';
        noteInput.value = entry.note;
        noteInput.oninput = function () { entry.note = noteInput.value; syncOdontogramInput(); };
        card.appendChild(noteInput);

        list.appendChild(card);
    });
}

function syncOdontogramInput() {
    const input = document.getElementById('odontogramInput');
    if (input) input.value = odontogram.length ? JSON.stringify(odontogram) : '';
}

// ── Dental Chart — read-only viewer (mirrors the Medico-Legal exam viewer) ─
function openOdontogramView(rec) {
    odontogram = rec.odontogram ? JSON.parse(rec.odontogram) : [];
    document.getElementById('examOdontoPatientName').textContent = rec.patient_name || '';
    const dateTxt = rec.service_date ? new Date(rec.service_date).toLocaleDateString() : '';
    document.getElementById('examOdontoMeta').textContent = (rec.patient_no ? rec.patient_no + ' · ' : '') + dateTxt;
    renderOdontogramChart(false);

    const list = document.getElementById('examOdontogramList');
    list.innerHTML = '';
    const ordered = [...odontogram].sort((a, b) => UPPER_TEETH.concat(LOWER_TEETH).indexOf(a.tooth) - UPPER_TEETH.concat(LOWER_TEETH).indexOf(b.tooth));
    ordered.forEach(entry => {
        const item = document.createElement('div');
        item.className = 'injury-finding-card p-2';
        const head = document.createElement('div');
        head.className = 'd-flex align-items-center gap-2 mb-1';
        const badge = document.createElement('span');
        badge.className = 'badge';
        badge.style.background = PROCEDURE_COLORS[entry.procedure] || PROCEDURE_COLORS['Other'];
        badge.textContent = 'Tooth ' + entry.tooth + ' · ' + entry.procedure;
        head.appendChild(badge);
        const noteP = document.createElement('div');
        noteP.className = 'text-muted';
        noteP.style.fontSize = '.85rem';
        noteP.textContent = entry.note || '(no note)';
        item.appendChild(head);
        item.appendChild(noteP);
        list.appendChild(item);
    });

    new bootstrap.Modal(document.getElementById('odontogramViewModal')).show();
}
