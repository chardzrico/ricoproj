// Glue script for modules/services/category.php — opening/populating the
// Add/Edit Sub-Service modal and the Record Service modal (which in turn
// resets the medico-legal body-diagram and dental odontogram widgets;
// see body-diagram.js and odontogram.js, both loaded before this file).
// Depends on the global PRMS_SERVICE_CONFIG object set inline by category.php.

function openServiceModal(s) {
    document.getElementById('svcId').value = s ? s.id : '';
    document.getElementById('svcName').value = s ? s.service_name : '';
    document.getElementById('svcDesc').value = s ? (s.description || '') : '';
    document.getElementById('svcFee').value = s ? s.fee : '';
    document.getElementById('svcModalTitle').innerHTML = (s ? '<i class="ti ti-edit me-2" style="color:#fff;"></i>Edit' : '<i class="ti ti-plus me-2" style="color:#fff;"></i>Add') + ' Sub-Service';
    new bootstrap.Modal(document.getElementById('serviceModal')).show();
}

function openRecordModal(r) {
    document.getElementById('recId').value = r ? r.id : '';
    document.getElementById('recPatient').value = r ? r.patient_id : '';
    document.getElementById('recService').value = r ? r.service_id : '';
    document.getElementById('recDate').value = r ? r.service_date : PRMS_SERVICE_CONFIG.todayDate;
    document.getElementById('recStatus').value = r ? r.status : 'done';
    document.getElementById('recNotes').value = r ? (r.notes || '') : '';
    document.getElementById('recModalTitle').innerHTML = '<i class="ti ti-file-plus me-2" style="color:#fff;"></i>' + (r ? 'Edit' : 'Record') + ' ' + PRMS_SERVICE_CONFIG.catLabel + ' Service';

    bodyFindings = (r && r.injury_map) ? normalizeFindings(JSON.parse(r.injury_map)) : [];
    cancelLinkMode();
    switchBodyView('front');
    renderFindingsList();
    syncInjuryMapInput();
    toggleInjurySection();

    if (document.getElementById('odontogramChart')) {
        odontogram = (r && r.odontogram) ? JSON.parse(r.odontogram) : [];
        renderOdontogramChart();
        renderOdontogramList();
        syncOdontogramInput();
    }

    new bootstrap.Modal(document.getElementById('recordModal')).show();
}
