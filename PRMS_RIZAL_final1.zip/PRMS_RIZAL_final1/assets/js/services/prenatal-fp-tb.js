// Prenatal / Family Planning / TB-DOTS structured fields — used by the
// Record Service modal in modules/services/category.php. Relies on a
// global PRMS_SERVICE_CONFIG (set inline by category.php) for serviceNames,
// same pattern as body-diagram.js's isMedicolegal().

function isPrenatal(serviceId) {
    const name = (PRMS_SERVICE_CONFIG.serviceNames[serviceId] || '').toLowerCase();
    return name.indexOf('prenatal') !== -1;
}
function isFamilyPlanning(serviceId) {
    const name = (PRMS_SERVICE_CONFIG.serviceNames[serviceId] || '').toLowerCase();
    return name.indexOf('family planning') !== -1;
}
function isTBDots(serviceId) {
    const name = (PRMS_SERVICE_CONFIG.serviceNames[serviceId] || '').toLowerCase();
    return name.indexOf('dots') !== -1 || name.indexOf('tuberculosis') !== -1;
}

function togglePrenatalSection() {
    const sid = parseInt(document.getElementById('recService').value) || 0;
    document.getElementById('prenatalSection').style.display = isPrenatal(sid) ? '' : 'none';
}
function toggleFPSection() {
    const sid = parseInt(document.getElementById('recService').value) || 0;
    document.getElementById('fpSection').style.display = isFamilyPlanning(sid) ? '' : 'none';
}
function toggleTBSection() {
    const sid = parseInt(document.getElementById('recService').value) || 0;
    document.getElementById('tbSection').style.display = isTBDots(sid) ? '' : 'none';
}

// Consolidated toggle called on #recService change — keeps
// toggleInjurySection() (defined in body-diagram.js) working alongside
// these three new sections.
function toggleSpecialSections() {
    if (typeof toggleInjurySection === 'function') toggleInjurySection();
    if (document.getElementById('prenatalSection')) togglePrenatalSection();
    if (document.getElementById('fpSection')) toggleFPSection();
    if (document.getElementById('tbSection')) toggleTBSection();
}

// Naegele's rule: EDD = LMP + 280 days (40 weeks).
function calcEDD() {
    const lmp = document.getElementById('pnLmp').value;
    if (!lmp) return;
    const d = new Date(lmp + 'T00:00:00');
    d.setDate(d.getDate() + 280);
    document.getElementById('pnEdd').value = d.toISOString().slice(0, 10);
    calcTrimester();
}
function calcTrimester() {
    const lmpEl = document.getElementById('pnLmp');
    if (!lmpEl) return; // section not present outside the Medical category
    const lmp = lmpEl.value;
    const asOf = document.getElementById('recDate').value || PRMS_SERVICE_CONFIG.todayDate;
    const trimesterEl = document.getElementById('pnTrimester');
    if (!lmp || !asOf) { trimesterEl.value = ''; return; }
    const weeks = Math.floor((new Date(asOf + 'T00:00:00') - new Date(lmp + 'T00:00:00')) / (7 * 24 * 3600 * 1000));
    if (weeks < 0 || weeks > 45) { trimesterEl.value = ''; return; }
    if (weeks < 13) trimesterEl.value = '1st Trimester (' + weeks + ' wks)';
    else if (weeks < 27) trimesterEl.value = '2nd Trimester (' + weeks + ' wks)';
    else trimesterEl.value = '3rd Trimester (' + weeks + ' wks)';
}

// Populates (or, when r is null, clears) all three sections — called from
// openRecordModal() in category.js right after the base fields are filled.
function fillSpecialSectionsForEdit(r) {
    if (!document.getElementById('prenatalSection')) return; // only present for Medical category
    r = r || {};

    document.getElementById('pnLmp').value = r.prenatal_lmp || '';
    document.getElementById('pnEdd').value = r.prenatal_edd || '';
    document.getElementById('pnBp').value = r.prenatal_bp || '';
    document.getElementById('pnGravida').value = r.prenatal_gravida || '';
    document.getElementById('pnPara').value = r.prenatal_para || '';
    document.getElementById('pnTt').value = r.prenatal_tt_status || '';
    calcTrimester();

    let dangerSigns = [];
    if (r.prenatal_danger_signs) {
        try { dangerSigns = JSON.parse(r.prenatal_danger_signs); } catch (e) { dangerSigns = []; }
    }
    document.querySelectorAll('input[name="prenatal_danger_signs[]"]').forEach(function (cb) {
        cb.checked = dangerSigns.indexOf(cb.value) !== -1;
    });

    document.getElementById('fpMethod').value = r.fp_method || '';
    document.getElementById('fpAcceptor').value = r.fp_acceptor_type || '';
    document.getElementById('fpNextVisit').value = r.fp_next_visit || '';

    document.getElementById('tbSputum').value = r.tb_sputum_result || '';
    document.getElementById('tbCategory').value = r.tb_treatment_category || '';
    document.getElementById('tbRegimen').value = r.tb_regimen || '';
    document.getElementById('tbAttendance').value = r.tb_attendance || '';

    toggleSpecialSections();
}
