// Medico-Legal Examination body diagram widget — used by the Record Service
// modal (marking findings) and the read-only exam viewer, both in
// modules/services/category.php. Extracted verbatim from that file's inline
// <script> block; relies on a global PRMS_SERVICE_CONFIG (set inline by
// category.php) for the two values that used to be PHP-templated directly
// into the script: catColor and serviceNames.

function isMedicolegal(serviceId) {
    const name = (PRMS_SERVICE_CONFIG.serviceNames[serviceId] || '').toLowerCase();
    return name.indexOf('medico-legal') !== -1 || name.indexOf('medico legal') !== -1;
}

const BODY_ZONES = [
    { label: 'Head',            x1: 37.5, y1: 2,     x2: 62.5, y2: 16.25 },
    { label: 'Neck',             x1: 42.5, y1: 16.25, x2: 57.5, y2: 20 },
    { label: 'Right Shoulder',   x1: 17.5, y1: 20,    x2: 32.5, y2: 27.5 },
    { label: 'Left Shoulder',    x1: 67.5, y1: 20,    x2: 82.5, y2: 27.5 },
    { label: 'Chest',            x1: 32.5, y1: 20,    x2: 67.5, y2: 35 },
    { label: 'Abdomen',          x1: 32.5, y1: 35,    x2: 67.5, y2: 47.5 },
    { label: 'Right Upper Arm',  x1: 12.5, y1: 27.5,  x2: 30,   y2: 45 },
    { label: 'Left Upper Arm',   x1: 70,   y1: 27.5,  x2: 87.5, y2: 45 },
    { label: 'Right Forearm',    x1: 10,   y1: 45,    x2: 27.5, y2: 60 },
    { label: 'Left Forearm',     x1: 72.5, y1: 45,    x2: 90,   y2: 60 },
    { label: 'Right Hand',       x1: 7.5,  y1: 60,    x2: 25,   y2: 66.25 },
    { label: 'Left Hand',        x1: 75,   y1: 60,    x2: 92.5, y2: 66.25 },
    { label: 'Pelvis / Groin',   x1: 37.5, y1: 47.5,  x2: 62.5, y2: 53.75 },
    { label: 'Right Thigh',      x1: 32.5, y1: 53.75, x2: 50,   y2: 72.5 },
    { label: 'Left Thigh',       x1: 50,   y1: 53.75, x2: 67.5, y2: 72.5 },
    { label: 'Right Knee',       x1: 32.5, y1: 72.5,  x2: 50,   y2: 77.5 },
    { label: 'Left Knee',        x1: 50,   y1: 72.5,  x2: 67.5, y2: 77.5 },
    { label: 'Right Lower Leg',  x1: 32.5, y1: 77.5,  x2: 50,   y2: 93.75 },
    { label: 'Left Lower Leg',   x1: 50,   y1: 77.5,  x2: 67.5, y2: 93.75 },
    { label: 'Right Foot',       x1: 30,   y1: 93.75, x2: 50,   y2: 98.75 },
    { label: 'Left Foot',        x1: 50,   y1: 93.75, x2: 70,   y2: 98.75 }
];
function zoneLabel(x, y) {
    for (const z of BODY_ZONES) { if (x >= z.x1 && x <= z.x2 && y >= z.y1 && y <= z.y2) return z.label; }
    return 'Body';
}

let bodyFindings = []; // each: { marks: [{view,x,y,zone,role}], note } — 1 mark = single point, 2 = linked entry/exit
let currentBodyView = 'front';
let linkMode = false;
let pendingEntry = null; // first mark clicked while linking an entry/exit pair

function toggleInjurySection() {
    const sid = parseInt(document.getElementById('recService').value) || 0;
    document.getElementById('injuryMapSection').style.display = isMedicolegal(sid) ? '' : 'none';
}

function switchBodyView(view) {
    currentBodyView = view;
    document.getElementById('frontSvg').style.display = view === 'front' ? '' : 'none';
    document.getElementById('backSvg').style.display = view === 'back' ? '' : 'none';
    document.getElementById('viewFrontBtn').classList.toggle('active', view === 'front');
    document.getElementById('viewBackBtn').classList.toggle('active', view === 'back');
    renderMarkers();
}

// ── Linked injury mode: click an entry point, then an exit point (any view) ─
function toggleLinkMode() {
    if (linkMode) { cancelLinkMode(); return; }
    linkMode = true;
    pendingEntry = null;
    document.getElementById('linkModeBtn').classList.add('active');
    document.getElementById('linkModeBtn').style.background = '#8e24aa';
    document.getElementById('linkModeBtn').style.color = '#fff';
    document.getElementById('linkModeLabel').textContent = 'Linking… click the diagram (Cancel to stop)';
    document.getElementById('linkModeBanner').style.display = '';
    document.getElementById('linkModeStatusText').textContent = 'Click the entry point on the diagram.';
    renderMarkers();
}
function cancelLinkMode() {
    linkMode = false;
    pendingEntry = null;
    document.getElementById('linkModeBtn').classList.remove('active');
    document.getElementById('linkModeBtn').style.background = '';
    document.getElementById('linkModeBtn').style.color = '#8e24aa';
    document.getElementById('linkModeLabel').textContent = 'Link Entry ⇄ Exit (one injury, two marks)';
    document.getElementById('linkModeBanner').style.display = 'none';
    renderMarkers();
}

// Prefer the actual zone shape under the cursor (data-zone, set per region
// in includes/helpers.php's bodyZoneDefs()) over the rough bounding-box
// guess in BODY_ZONES — the shapes now describe the real anatomy, so this
// is only a fallback for a click that lands in a gap between regions.
function zoneAt(target, x, y) {
    const el = target && target.closest ? target.closest('.body-zone') : null;
    return (el && el.dataset.zone) ? el.dataset.zone : zoneLabel(x, y);
}

function onBodyHover(e) {
    const label = document.getElementById('zoneHoverLabel');
    if (!label) return;
    const el = e.target && e.target.closest ? e.target.closest('.body-zone') : null;
    label.textContent = el ? el.dataset.zone : 'Hover the diagram to see each body region';
}
function onBodyHoverOut(e) {
    // Only reset once the pointer actually leaves the whole diagram, not
    // when it moves from one zone shape to another inside it.
    const wrap = document.getElementById('bodyDiagramWrap');
    if (wrap && e.relatedTarget && wrap.contains(e.relatedTarget)) return;
    const label = document.getElementById('zoneHoverLabel');
    if (label) label.textContent = 'Hover the diagram to see each body region';
}

function onBodyClick(e) {
    try {
        if (!e || typeof e.clientX === 'undefined') return;
        const wrap = document.getElementById('bodyDiagramWrap');
        if (!wrap) return;
        const rect = wrap.getBoundingClientRect();
        const x = Math.round(((e.clientX - rect.left) / rect.width) * 10000) / 100;
        const y = Math.round(((e.clientY - rect.top) / rect.height) * 10000) / 100;
        const mark = { view: currentBodyView, x: x, y: y, zone: zoneAt(e.target, x, y) };

        if (linkMode) {
            if (!pendingEntry) {
                pendingEntry = Object.assign({ role: 'entry' }, mark);
                const statusEl = document.getElementById('linkModeStatusText');
                if (statusEl) statusEl.textContent = 'Entry point set on ' + (currentBodyView === 'front' ? 'Front' : 'Back') + '. Switch view if needed, then click the exit point.';
                renderMarkers();
            } else {
                const exitMark = Object.assign({ role: 'exit' }, mark);
                bodyFindings.push({ marks: [pendingEntry, exitMark], note: '' });
                cancelLinkMode();
                renderFindingsList();
                syncInjuryMapInput();
            }
            return;
        }

        bodyFindings.push({ marks: [mark], note: '' });
        renderMarkers();
        renderFindingsList();
        syncInjuryMapInput();
    } catch (err) {
        console.error('onBodyClick error', err);
    }
}

function renderMarkers() {
    const layer = document.getElementById('markerLayer');
    layer.innerHTML = '';
    bodyFindings.forEach((f, i) => {
        f.marks.forEach(m => {
            if (m.view !== currentBodyView) return;
            const dot = document.createElement('div');
            dot.className = 'injury-marker' + (m.role === 'entry' ? ' linked-entry' : (m.role === 'exit' ? ' linked-exit' : ''));
            dot.style.left = m.x + '%';
            dot.style.top = m.y + '%';
            dot.title = m.role ? (m.role === 'entry' ? 'Entry point' : 'Exit point') : '';
            dot.textContent = (i + 1) + (m.role === 'entry' ? 'a' : (m.role === 'exit' ? 'b' : ''));
            layer.appendChild(dot);
        });
    });
    if (linkMode && pendingEntry && pendingEntry.view === currentBodyView) {
        const dot = document.createElement('div');
        dot.className = 'injury-marker pending-entry';
        dot.style.left = pendingEntry.x + '%';
        dot.style.top = pendingEntry.y + '%';
        dot.textContent = '?';
        layer.appendChild(dot);
    }
}

function renderFindingsList() {
    const list = document.getElementById('findingsList');
    const noMsg = document.getElementById('noFindingsMsg');
    list.innerHTML = '';
    noMsg.style.display = bodyFindings.length ? 'none' : '';
    bodyFindings.forEach((f, i) => {
        const isLinked = f.marks.length > 1;
        const card = document.createElement('div');
        card.className = 'injury-finding-card p-2' + (isLinked ? ' linked' : '');

        const head = document.createElement('div');
        head.className = 'd-flex justify-content-between align-items-center mb-1';
        const badge = document.createElement('span');
        badge.className = 'badge';
        const rmBtn = document.createElement('button');
        rmBtn.type = 'button';
        rmBtn.className = 'btn btn-sm btn-outline-danger py-0 px-1';
        rmBtn.innerHTML = '<i class="ti ti-x"></i>';
        rmBtn.addEventListener('click', function (ev) { ev.preventDefault(); ev.stopPropagation(); try { removeFinding(i); } catch (err) { console.error('removeFinding click error', err); } });

        if (isLinked) {
            badge.style.background = '#8e24aa';
            badge.textContent = '#' + (i + 1) + ' · Linked ⇄ (entry/exit)';
            head.appendChild(badge); head.appendChild(rmBtn);
            card.appendChild(head);

            const locLine = document.createElement('div');
            locLine.className = 'text-muted mb-1';
            locLine.style.fontSize = '.76rem';
            locLine.textContent = f.marks.map(m =>
                (m.role === 'entry' ? 'Entry' : 'Exit') + ': ' + (m.view === 'front' ? 'Front' : 'Back') + ' — ' + (m.zone || 'Body')
            ).join('  /  ');
            card.appendChild(locLine);
        } else {
            const m = f.marks[0];
            badge.style.background = PRMS_SERVICE_CONFIG.catColor;
            badge.textContent = '#' + (i + 1) + ' · ' + (m.view === 'front' ? 'Front' : 'Back');
            head.appendChild(badge); head.appendChild(rmBtn);
            card.appendChild(head);

            const zoneInput = document.createElement('input');
            zoneInput.type = 'text';
            zoneInput.className = 'form-control form-control-sm mb-1';
            zoneInput.placeholder = 'Location';
            zoneInput.value = m.zone;
            zoneInput.oninput = function () { m.zone = zoneInput.value; syncInjuryMapInput(); };
            card.appendChild(zoneInput);
        }

        const noteArea = document.createElement('textarea');
        noteArea.className = 'form-control form-control-sm';
        noteArea.rows = 2;
        noteArea.placeholder = isLinked
            ? 'Describe this injury (shared by both points), e.g. "Rod pierced through the left forearm — entry anterior, exit posterior"'
            : 'Describe the finding, e.g. "3.5cm x 4.5cm red bruise with tenderness"';
        noteArea.value = f.note;
        noteArea.oninput = function () { f.note = noteArea.value; syncInjuryMapInput(); };
        card.appendChild(noteArea);

        list.appendChild(card);
    });
}

function finalizeInjuryMap() {
    // If the sub-service was switched away from Medico-Legal after
    // findings were marked, don't submit stale diagram data with it.
    if (document.getElementById('injuryMapSection').style.display === 'none') {
        document.getElementById('injuryMapInput').value = '';
    }
}
function removeFinding(i) { try { bodyFindings.splice(i, 1); renderMarkers(); renderFindingsList(); syncInjuryMapInput(); } catch (err) { console.error('removeFinding error', err); } }
function syncInjuryMapInput() { document.getElementById('injuryMapInput').value = bodyFindings.length ? JSON.stringify(bodyFindings) : ''; }

// Back-compat: older records stored one mark per finding, flat on the object
// itself ({view,x,y,zone,note}) instead of nested under "marks".
function normalizeFindings(raw) {
    if (!Array.isArray(raw)) return [];
    return raw.map(f => {
        if (Array.isArray(f.marks)) return { marks: f.marks, note: f.note || '' };
        return { marks: [{ view: f.view || 'front', x: f.x || 0, y: f.y || 0, zone: f.zone || '' }], note: f.note || '' };
    });
}

// ── Medico-Legal Examination — read-only diagram viewer ─────────────────
let examFindings = [];
function openExamView(rec) {
    examFindings = rec.injury_map ? normalizeFindings(JSON.parse(rec.injury_map)) : [];
    document.getElementById('examPatientName').textContent = rec.patient_name || '';
    const dateTxt = rec.service_date ? new Date(rec.service_date).toLocaleDateString() : '';
    document.getElementById('examMeta').textContent = (rec.patient_no ? rec.patient_no + ' · ' : '') + dateTxt;

    const hasFront = examFindings.some(f => f.marks.some(m => m.view === 'front'));
    const hasBack = examFindings.some(f => f.marks.some(m => m.view === 'back'));
    document.getElementById('examFrontBtn').style.display = hasFront ? '' : 'none';
    document.getElementById('examBackBtn').style.display = hasBack ? '' : 'none';
    switchExamView(hasFront ? 'front' : 'back');

    new bootstrap.Modal(document.getElementById('examViewModal')).show();
}

let currentExamView = 'front';
function switchExamView(view) {
    currentExamView = view;
    document.getElementById('examFrontSvg').style.display = view === 'front' ? '' : 'none';
    document.getElementById('examBackSvg').style.display = view === 'back' ? '' : 'none';
    document.getElementById('examFrontBtn').classList.toggle('active', view === 'front');
    document.getElementById('examBackBtn').classList.toggle('active', view === 'back');

    const layer = document.getElementById('examMarkerLayer');
    layer.innerHTML = '';
    examFindings.forEach((f, i) => {
        f.marks.forEach(m => {
            if (m.view !== currentExamView) return;
            const dot = document.createElement('div');
            dot.className = 'injury-marker' + (m.role === 'entry' ? ' linked-entry' : (m.role === 'exit' ? ' linked-exit' : ''));
            dot.style.left = m.x + '%';
            dot.style.top = m.y + '%';
            dot.title = m.role ? (m.role === 'entry' ? 'Entry point' : 'Exit point') : '';
            dot.textContent = (i + 1) + (m.role === 'entry' ? 'a' : (m.role === 'exit' ? 'b' : ''));
            layer.appendChild(dot);
        });
    });

    const list = document.getElementById('examFindingsList');
    list.innerHTML = '';
    examFindings.forEach((f, i) => {
        const isLinked = f.marks.length > 1;
        const item = document.createElement('div');
        item.className = 'injury-finding-card p-2' + (isLinked ? ' linked' : '');
        const head = document.createElement('div');
        head.className = 'd-flex align-items-center gap-2 mb-1 flex-wrap';
        const badge = document.createElement('span');
        badge.className = 'badge';
        badge.style.background = isLinked ? '#8e24aa' : PRMS_SERVICE_CONFIG.catColor;
        badge.textContent = isLinked ? ('#' + (i + 1) + ' · Linked ⇄') : ('#' + (i + 1) + ' · ' + (f.marks[0].view === 'front' ? 'Front' : 'Back'));
        head.appendChild(badge);

        if (isLinked) {
            const locSpan = document.createElement('span');
            locSpan.className = 'text-muted';
            locSpan.style.fontSize = '.8rem';
            locSpan.textContent = f.marks.map(m =>
                (m.role === 'entry' ? 'Entry' : 'Exit') + ': ' + (m.view === 'front' ? 'Front' : 'Back') + ' — ' + (m.zone || 'Body')
            ).join('  /  ');
            head.appendChild(locSpan);
        } else {
            const zoneText = document.createElement('strong');
            zoneText.textContent = f.marks[0].zone || 'Body';
            head.appendChild(zoneText);
        }

        const noteP = document.createElement('div');
        noteP.className = 'text-muted';
        noteP.style.fontSize = '.85rem';
        noteP.textContent = f.note || '(no description)';
        item.appendChild(head);
        item.appendChild(noteP);
        list.appendChild(item);
    });
}
