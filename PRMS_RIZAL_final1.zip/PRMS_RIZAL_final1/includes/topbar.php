<?php
if (!function_exists('getCurrentUser')) {
    require_once __DIR__ . '/../config/session.php';
}
$currentUser   = $currentUser ?? getCurrentUser();
$userFullName  = trim($currentUser['full_name'] ?? '');
$userFirstName = $userFullName !== '' ? explode(' ', $userFullName)[0] : 'Guest';
$baseUrl       = defined('BASE_URL') ? BASE_URL : '';
?>
<style>
    .prms-topbar {
        position: fixed;
        top: 0;
        left: var(--sidebar-width, 264px);
        right: 0;
        height: 50px;
        background: linear-gradient(90deg, #1e3a5f 0%, #1a5276 60%, #0d6efd 100%);
        border-bottom: none;
        box-shadow: 0 2px 8px rgba(13,110,253,0.18);
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 20px;
        z-index: 1030;
    }
    @media (max-width: 1023px) { .prms-topbar { left: 0; } }
    @media (min-width: 1024px) {
        .pc-sidebar.pc-sidebar-hide ~ .prms-topbar { left: 0; }
    }

    .prms-hamburger {
        background: none;
        border: none;
        cursor: pointer;
        padding: 6px 8px;
        border-radius: 8px;
        color: rgba(255,255,255,0.85);
        display: flex;
        align-items: center;
        line-height: 1;
        transition: background 0.15s;
    }
    .prms-hamburger:hover { background: rgba(255,255,255,0.12); color: #fff; }

    .prms-greeting {
        position: absolute;
        left: 50%;
        transform: translateX(-50%);
        display: flex;
        align-items: center;
        gap: 8px;
        pointer-events: none;
    }
    .prms-greeting-icon { font-size: 1rem; }
    .prms-greeting-text {
        font-size: 0.82rem;
        font-weight: 600;
        color: rgba(255,255,255,0.95);
        white-space: nowrap;
        letter-spacing: 0.3px;
    }
    .prms-greeting-name {
        color: #ffd166;
    }

    .prms-profile-area { position: relative; }
    .prms-profile-toggle {
        display: flex;
        align-items: center;
        gap: 8px;
        background: rgba(255,255,255,0.12);
        border: 1px solid rgba(255,255,255,0.2);
        cursor: pointer;
        padding: 4px 10px 4px 5px;
        border-radius: 20px;
        white-space: nowrap;
        transition: background 0.15s;
    }
    .prms-profile-toggle:hover { background: rgba(255,255,255,0.22); }
    .prms-avatar {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        background: rgba(255,255,255,0.25);
        border: 1.5px solid rgba(255,255,255,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }
    .prms-profile-name {
        font-size: 0.8rem;
        font-weight: 600;
        color: #fff;
    }
    .prms-dropdown {
        display: none;
        position: absolute;
        top: calc(100% + 8px);
        right: 0;
        background: #fff;
        border: 0.5px solid #e9ecef;
        border-radius: 10px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.12);
        min-width: 140px;
        overflow: hidden;
        z-index: 9999;
    }
    .prms-dropdown.show { display: block; }
    .prms-dropdown a {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 10px 14px;
        font-size: 0.875rem;
        font-weight: 600;
        color: #dc3545;
        text-decoration: none;
    }
    .prms-dropdown a:hover { background: #fff5f5; }

    .pc-container { top: 50px !important; }
    .pc-footer { margin-top: 50px !important; }
</style>

<div class="prms-topbar">
    <!-- Left: Hamburger -->
    <button class="prms-hamburger" id="sidebar-hide">
        <i class="ti ti-menu-2" style="font-size:1.2rem;"></i>
    </button>

    <!-- Center: Greeting -->
    <div class="prms-greeting">
        <span class="prms-greeting-icon" id="greetIcon"></span>
        <span class="prms-greeting-text">
            <span id="greetText"></span>,&nbsp;<span class="prms-greeting-name"><?= htmlspecialchars($userFirstName) ?>!</span>
        </span>
    </div>

    <!-- Right: Profile -->
    <div class="prms-profile-area">
        <button class="prms-profile-toggle" id="prmsProfileBtn">
            <div class="prms-avatar">
                <i class="ti ti-user" style="font-size:0.85rem;color:#fff;"></i>
            </div>
            <span class="prms-profile-name"><?= htmlspecialchars($userFullName ?: 'Guest') ?></span>
            <i class="ti ti-chevron-down" style="font-size:0.65rem;color:rgba(255,255,255,0.7);"></i>
        </button>
        <div class="prms-dropdown" id="prmsProfileDropdown">
            <a href="<?= $baseUrl ?>/logout.php">
                <i class="ti ti-logout" style="font-size:1rem;"></i>
                Logout
            </a>
        </div>
    </div>
</div>

<script>
(function(){
    // Greeting by time
    var h = new Date().getHours();
    var greet, icon;
    if (h >= 5 && h < 12)       { greet = 'Good morning';   icon = '🌤️'; }
    else if (h >= 12 && h < 17) { greet = 'Good afternoon'; icon = '☀️'; }
    else if (h >= 17 && h < 21) { greet = 'Good evening';   icon = '🌇'; }
    else                         { greet = 'Good night';     icon = '🌙'; }
    document.getElementById('greetText').textContent = greet;
    document.getElementById('greetIcon').textContent = icon;

    // Dropdown toggle
    var btn = document.getElementById('prmsProfileBtn');
    var dd  = document.getElementById('prmsProfileDropdown');
    btn.addEventListener('click', function(e){
        e.stopPropagation();
        dd.classList.toggle('show');
    });
    document.addEventListener('click', function(){
        dd.classList.remove('show');
    });
})();
</script>

<div class="pc-container">
    <div class="pc-content">