-- ============================================================
-- PRMS Migration: Community / Household-Level Records
--   1. `barangays` — master list of Rizal, Cagayan's barangays, with
--      road-access and mountain/peak elevation (for terrain-aware
--      outreach planning), seeded from the LGU's barangay profile.
--   2. `patients.barangay_id` — structured barangay instead of only
--      free-text address, enabling barangay-level report breakdowns.
--   3. `households` — a "family folder": groups patients living under
--      one roof, per RHU convention, with a designated household head.
--   4. `patients.household_id` — links a patient to their household.
-- Safe to re-run: every statement checks INFORMATION_SCHEMA first, and
-- the barangay seed only inserts rows that aren't already there by name.
-- ============================================================
USE prms_db;

-- ── 1. Barangays ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS barangays (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    zone_note VARCHAR(100) NULL COMMENT 'cluster/zone the barangay is grouped under, e.g. Zinundungan, Villa Cruz',
    road_elevation_m DECIMAL(7,2) NULL COMMENT 'road-access elevation in meters',
    mountain_elevation_m DECIMAL(7,2) NULL COMMENT 'mountain/peak elevation in meters',
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO barangays (name, zone_note, road_elevation_m, mountain_elevation_m)
SELECT * FROM (SELECT
    'Anagguan' AS name, NULL AS zone_note, 567.3 AS road_elevation_m, 1400.0 AS mountain_elevation_m UNION ALL SELECT
    'Anurturu', NULL, 493.0, 493.0 UNION ALL SELECT
    'Anungu', NULL, 452.8, 452.8 UNION ALL SELECT
    'Baluncanag', NULL, 402.2, 402.2 UNION ALL SELECT
    'Batu', NULL, 570.0, 882.0 UNION ALL SELECT
    'Cambabangan', NULL, 682.6, 682.6 UNION ALL SELECT
    'Capacuan', NULL, 390.0, 390.0 UNION ALL SELECT
    'Dunggan', NULL, 685.0, 954.4 UNION ALL SELECT
    'Duyun', NULL, 239.7, 239.7 UNION ALL SELECT
    'Gaddangao', NULL, 109.0, 109.0 UNION ALL SELECT
    'Gaggabutan East', NULL, 579.8, 880.9 UNION ALL SELECT
    'Illuru Norte', NULL, 445.0, 843.0 UNION ALL SELECT
    'Lattut', NULL, 824.1, 824.1 UNION ALL SELECT
    'Linno', 'Villa Cruz', 690.0, 690.0 UNION ALL SELECT
    'Liuan', NULL, 390.0, 390.0 UNION ALL SELECT
    'Mabbang', NULL, 389.0, 389.0 UNION ALL SELECT
    'Mauanan', NULL, 569.0, 968.5 UNION ALL SELECT
    'Masi', 'Zinundungan', 1290.0, 1290.0 UNION ALL SELECT
    'Minanga', NULL, 790.0, 790.0 UNION ALL SELECT
    'Nanauatan', NULL, 580.7, 580.7 UNION ALL SELECT
    'Nanungaran', NULL, 577.1, 577.1 UNION ALL SELECT
    'Pasingan', NULL, 700.0, 700.0 UNION ALL SELECT
    'Poblacion', NULL, 1004.0, 1004.0 UNION ALL SELECT
    'San Juan', 'Zinundungan', 1292.0, 1292.0 UNION ALL SELECT
    'Sinicking', NULL, 230.0, 899.0 UNION ALL SELECT
    'Battut', NULL, 810.0, 810.0 UNION ALL SELECT
    'Bural', 'Zinundungan', 762.9, 762.9 UNION ALL SELECT
    'Gaggabutan West', NULL, 469.2, 880.7 UNION ALL SELECT
    'Illuru Sur', NULL, 456.0, 844.0
) AS seed
WHERE seed.name NOT IN (SELECT name FROM barangays);

-- ── 2. patients.barangay_id ──────────────────────────────────────────────
SET @col_exists := (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'patients' AND COLUMN_NAME = 'barangay_id'
);
SET @sql := IF(@col_exists = 0,
    'ALTER TABLE patients ADD COLUMN barangay_id INT NULL AFTER address, ADD CONSTRAINT fk_patients_barangay FOREIGN KEY (barangay_id) REFERENCES barangays(id) ON DELETE SET NULL',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ── 3. Households (family folder) ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS households (
    id INT AUTO_INCREMENT PRIMARY KEY,
    household_no VARCHAR(30) UNIQUE NOT NULL,
    barangay_id INT NULL,
    household_head_id INT NULL COMMENT 'patient who is the household head',
    address_details VARCHAR(255) NULL COMMENT 'sitio/purok/street, house number',
    contact_number VARCHAR(20) NULL,
    remarks TEXT NULL,
    status ENUM('active','inactive') DEFAULT 'active',
    created_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (barangay_id) REFERENCES barangays(id) ON DELETE SET NULL,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

-- ── 4. patients.household_id ─────────────────────────────────────────────
SET @col_exists := (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'patients' AND COLUMN_NAME = 'household_id'
);
SET @sql := IF(@col_exists = 0,
    'ALTER TABLE patients ADD COLUMN household_id INT NULL AFTER barangay_id, ADD CONSTRAINT fk_patients_household FOREIGN KEY (household_id) REFERENCES households(id) ON DELETE SET NULL',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- households.household_head_id references patients(id), added after both
-- tables exist to avoid a circular-creation ordering problem.
SET @fk_exists := (
    SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'households' AND CONSTRAINT_NAME = 'fk_households_head'
);
SET @sql := IF(@fk_exists = 0,
    'ALTER TABLE households ADD CONSTRAINT fk_households_head FOREIGN KEY (household_head_id) REFERENCES patients(id) ON DELETE SET NULL',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
