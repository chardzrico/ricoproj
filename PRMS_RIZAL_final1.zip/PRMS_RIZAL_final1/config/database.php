<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'ricopogi18jr');
define('DB_NAME', 'prms_db');

// IMPORTANT: since PHP 8.1, mysqli throws an exception on any DB error by
// default (it used to just return false). This whole codebase was written
// against the old behavior — every "if ($stmt)" / "if ($conn->connect_error)"
// check here assumes a failed query returns false rather than throwing.
// On PHP 8.1+ (the current default almost everywhere, including recent
// XAMPP), that mismatch means ANY database error — a missing column, a bad
// query, anything — becomes an uncaught exception, which PHP renders as a
// blank white page whenever display_errors is off. Restoring the legacy
// "just return false" behavior here fixes that for the whole app, not just
// one query.
if (function_exists('mysqli_report')) {
    mysqli_report(MYSQLI_REPORT_OFF);
}

$conn = null;

function getDBConnection() {
    global $conn;

    if (!class_exists('mysqli') || !extension_loaded('mysqli')) {
        die(json_encode([
            'error' => 'PHP MySQLi extension is not enabled. Please enable the mysqli extension in PHP and reload the web server.',
        ]));
    }

    if ($conn instanceof mysqli) {
        try {
            if ($conn->ping()) {
                return $conn;
            }
        } catch (Throwable $e) {
            // Reconnect if the previous connection is no longer usable.
        }
    }

    $databaseNames = array_values(array_unique(array_filter([
        DB_NAME,
        'prms_db',
        'prms_db1',
    ], static function ($name) {
        return is_string($name) && $name !== '';
    })));

    foreach ($databaseNames as $databaseName) {
        $candidate = @new mysqli(DB_HOST, DB_USER, DB_PASS, $databaseName);
        if ($candidate->connect_error) {
            $candidate->close();
            continue;
        }

        $conn = $candidate;
        $conn->set_charset('utf8mb4');
        ensureSchemaUpToDate($conn);
        return $conn;
    }

    die(json_encode([
        'error' => 'Connection failed. Please verify the database server and credentials.',
    ]));
}

/**
 * Self-healing schema check: some features (Medico-Legal body diagram,
 * Dental odontogram) were added after the base schema (prms_db1.sql) via
 * separate migration files. If a site was only ever set up from the base
 * dump and never had those migrations run against it, the "injury_map" /
 * "odontogram" columns don't exist — and since the Record Service save
 * handler always references both columns (for every category, not just
 * Dental/Physical), every single save would fail, which used to render as
 * a blank white page with no explanation.
 *
 * This adds the columns automatically (once, cheaply, idempotently — same
 * IF-NOT-EXISTS logic as the migration .sql files) so a missed migration
 * step can never silently break saving.
 */
function ensureSchemaUpToDate($conn) {
    static $checked = false;
    if ($checked) return;
    $checked = true;

    $columns = [
        ['patient_services', 'injury_map',          "ALTER TABLE patient_services ADD COLUMN injury_map LONGTEXT NULL AFTER notes"],
        ['patient_services', 'odontogram',           "ALTER TABLE patient_services ADD COLUMN odontogram LONGTEXT NULL AFTER injury_map"],
        ['users',            'reset_token',          "ALTER TABLE users ADD COLUMN reset_token VARCHAR(64) NULL AFTER password"],
        ['users',            'reset_token_expires',  "ALTER TABLE users ADD COLUMN reset_token_expires DATETIME NULL AFTER reset_token"],
        ['users',            'license_number',       "ALTER TABLE users ADD COLUMN license_number VARCHAR(50) NULL AFTER role"],
        ['patient_queue',    'appointment_id',       "ALTER TABLE patient_queue ADD COLUMN appointment_id INT NULL AFTER patient_id"],
        ['patient_queue',    'priority',              "ALTER TABLE patient_queue ADD COLUMN priority ENUM('normal','senior','pwd','pregnant') NOT NULL DEFAULT 'normal' AFTER category"],
        ['patient_queue',    'time_done',             "ALTER TABLE patient_queue ADD COLUMN time_done TIMESTAMP NULL AFTER time_served"],
        // prms_db1.sql always specified time_in, but this live DB's
        // patient_queue was set up with created_at instead — every query
        // referencing time_in (dashboard's staff_content.php, the queueing
        // module) was failing silently since mysqli_report is off. Add the
        // column code actually expects and backfill it from created_at
        // below, rather than rewriting every caller to match the drift.
        ['patient_queue',    'time_in',               "ALTER TABLE patient_queue ADD COLUMN time_in TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP AFTER status"],

        // Structured fields for the Prenatal, Family Planning, and TB-DOTS
        // sub-services (all seeded under the Medical category) — previously
        // just a free-text notes box, same as every other sub-service. See
        // modules/services/views/{prenatal,family_planning,tbdots}_section.php.
        ['patient_services', 'prenatal_lmp',           "ALTER TABLE patient_services ADD COLUMN prenatal_lmp DATE NULL AFTER odontogram"],
        ['patient_services', 'prenatal_edd',           "ALTER TABLE patient_services ADD COLUMN prenatal_edd DATE NULL AFTER prenatal_lmp"],
        ['patient_services', 'prenatal_gravida',       "ALTER TABLE patient_services ADD COLUMN prenatal_gravida INT NULL AFTER prenatal_edd"],
        ['patient_services', 'prenatal_para',          "ALTER TABLE patient_services ADD COLUMN prenatal_para INT NULL AFTER prenatal_gravida"],
        ['patient_services', 'prenatal_bp',            "ALTER TABLE patient_services ADD COLUMN prenatal_bp VARCHAR(20) NULL AFTER prenatal_para"],
        ['patient_services', 'prenatal_tt_status',     "ALTER TABLE patient_services ADD COLUMN prenatal_tt_status VARCHAR(20) NULL AFTER prenatal_bp"],
        ['patient_services', 'prenatal_danger_signs',  "ALTER TABLE patient_services ADD COLUMN prenatal_danger_signs LONGTEXT NULL AFTER prenatal_tt_status"],
        ['patient_services', 'fp_method',              "ALTER TABLE patient_services ADD COLUMN fp_method VARCHAR(50) NULL AFTER prenatal_danger_signs"],
        ['patient_services', 'fp_acceptor_type',       "ALTER TABLE patient_services ADD COLUMN fp_acceptor_type VARCHAR(20) NULL AFTER fp_method"],
        ['patient_services', 'fp_next_visit',          "ALTER TABLE patient_services ADD COLUMN fp_next_visit DATE NULL AFTER fp_acceptor_type"],
        ['patient_services', 'tb_sputum_result',       "ALTER TABLE patient_services ADD COLUMN tb_sputum_result VARCHAR(20) NULL AFTER fp_next_visit"],
        ['patient_services', 'tb_treatment_category',  "ALTER TABLE patient_services ADD COLUMN tb_treatment_category VARCHAR(20) NULL AFTER tb_sputum_result"],
        ['patient_services', 'tb_regimen',             "ALTER TABLE patient_services ADD COLUMN tb_regimen VARCHAR(100) NULL AFTER tb_treatment_category"],
        ['patient_services', 'tb_attendance',          "ALTER TABLE patient_services ADD COLUMN tb_attendance VARCHAR(20) NULL AFTER tb_regimen"],
    ];
    foreach ($columns as [$table, $col, $alterSql]) {
        $res = $conn->query(
            "SELECT COUNT(*) AS c FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '" . $conn->real_escape_string($table) . "' AND COLUMN_NAME = '" . $conn->real_escape_string($col) . "'"
        );
        $exists = $res ? (int)$res->fetch_assoc()['c'] > 0 : true; // if the check itself fails, don't try to alter
        if (!$exists) {
            $conn->query($alterSql);
        }
    }
    // NOTE: adding a TIMESTAMP column with DEFAULT CURRENT_TIMESTAMP backfills
    // every existing row with the ALTER's execution time, not NULL — so this
    // reconciles unconditionally rather than gating on "IS NULL" (which would
    // never match after the ALTER above already ran once). Harmless to keep
    // running: for rows inserted normally, time_in and created_at are already
    // stamped at the same moment.
    $conn->query("
        UPDATE patient_queue SET time_in = created_at
        WHERE created_at IS NOT NULL AND time_in != created_at
    ");

    // Prevents two concurrent "Add to Queue" submissions from ever landing on
    // the same queue_no within a category/day (the same class of race the
    // RX/certificate numbering had before it was given a transaction+retry —
    // see modules/services/queueing.php). If old data already has duplicates
    // this ALTER just fails silently and gets retried next request, same as
    // any other self-heal check here.
    $idx = $conn->query("
        SELECT COUNT(*) AS c FROM information_schema.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'patient_queue' AND INDEX_NAME = 'uniq_queue_no_per_day'
    ");
    $idxExists = $idx ? (int)$idx->fetch_assoc()['c'] > 0 : true;
    if (!$idxExists) {
        $conn->query("ALTER TABLE patient_queue ADD UNIQUE INDEX uniq_queue_no_per_day (category, queue_date, queue_no)");
    }

    // Family Planning and TB-DOTS structured fields (see category.php's
    // save_record handler and modules/services/views/{family_planning,tbdots}
    // _section.php) only ever show up in the Record Service modal when the
    // selected sub-service's name matches — but this specific database was
    // never actually seeded with those two sub-services (only "Prenatal
    // Service" and "Checkup" made it in under Medical), so the whole feature
    // would be unreachable without them. Add them once if no Medical
    // sub-service with a matching name exists yet — never touches an
    // existing one a clinic may have already renamed/customized.
    $hasFp = $conn->query("SELECT COUNT(*) AS c FROM services WHERE category='Medical' AND LOWER(service_name) LIKE '%family planning%'");
    if ($hasFp && (int)$hasFp->fetch_assoc()['c'] === 0) {
        $conn->query("INSERT INTO services (service_name, description, category, fee, status) VALUES ('Family Planning Counseling', 'Guidance and follow-up on family planning methods', 'Medical', 0.00, 'active')");
    }
    $hasTb = $conn->query("SELECT COUNT(*) AS c FROM services WHERE category='Medical' AND (LOWER(service_name) LIKE '%dots%' OR LOWER(service_name) LIKE '%tuberculosis%')");
    if ($hasTb && (int)$hasTb->fetch_assoc()['c'] === 0) {
        $conn->query("INSERT INTO services (service_name, description, category, fee, status) VALUES ('Tuberculosis (TB) DOTS', 'Directly Observed Treatment, Short-course for TB patients', 'Medical', 0.00, 'active')");
    }

    // Accountability trail (who logged in, who viewed/changed which patient,
    // who changed user accounts) — see logAudit() in config/session.php.
    // CREATE TABLE IF NOT EXISTS is naturally idempotent, no existence
    // check needed first like the ALTERs above.
    $conn->query("
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NULL,
            username_attempted VARCHAR(100) NULL,
            action VARCHAR(50) NOT NULL,
            target_type VARCHAR(50) NULL,
            target_id INT NULL,
            details VARCHAR(255) NULL,
            ip_address VARCHAR(45) NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_audit_user (user_id),
            INDEX idx_audit_action (action),
            INDEX idx_audit_created (created_at),
            INDEX idx_audit_target (target_type, target_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    // Medical certificates (Fit to Work/Travel, illness certification, etc.)
    // — see modules/certificates/certificate_log.php.
    $conn->query("
        CREATE TABLE IF NOT EXISTS medical_certificates (
            id INT AUTO_INCREMENT PRIMARY KEY,
            cert_number VARCHAR(50) NOT NULL UNIQUE,
            patient_id INT NOT NULL,
            cert_type VARCHAR(100) NOT NULL,
            findings TEXT NULL,
            recommendation TEXT NULL,
            valid_from DATE NULL,
            valid_until DATE NULL,
            issued_date DATE NOT NULL,
            issued_by INT NULL,
            status ENUM('active','voided') NOT NULL DEFAULT 'active',
            void_reason VARCHAR(255) NULL,
            printed_at TIMESTAMP NULL,
            printed_by INT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_cert_patient (patient_id),
            INDEX idx_cert_status (status),
            CONSTRAINT fk_cert_patient FOREIGN KEY (patient_id) REFERENCES patients(id),
            CONSTRAINT fk_cert_issued_by FOREIGN KEY (issued_by) REFERENCES users(id),
            CONSTRAINT fk_cert_printed_by FOREIGN KEY (printed_by) REFERENCES users(id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    // In-app notifications (e.g. "new appointment request" for staff,
    // "your appointment was approved" for a patient) — see
    // config/notifications.php and the bell icon in includes/topbar.php.
    // A notification is either a broadcast to a whole role (recipient_role
    // set, recipient_user_id NULL) or aimed at one specific user
    // (recipient_user_id set, recipient_role NULL) — never both.
    // notification_reads is a separate per-user "seen" table so a shared
    // broadcast can be read by one staff member and still show as unread
    // for everyone else.
    $conn->query("
        CREATE TABLE IF NOT EXISTS notifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            recipient_role VARCHAR(20) NULL,
            recipient_user_id INT NULL,
            type VARCHAR(50) NOT NULL,
            title VARCHAR(150) NOT NULL,
            message VARCHAR(255) NULL,
            link VARCHAR(255) NULL,
            target_type VARCHAR(50) NULL,
            target_id INT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_notif_role (recipient_role),
            INDEX idx_notif_user (recipient_user_id),
            INDEX idx_notif_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $conn->query("
        CREATE TABLE IF NOT EXISTS notification_reads (
            notification_id INT NOT NULL,
            user_id INT NOT NULL,
            read_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (notification_id, user_id),
            CONSTRAINT fk_notifread_notification FOREIGN KEY (notification_id) REFERENCES notifications(id) ON DELETE CASCADE,
            CONSTRAINT fk_notifread_user FOREIGN KEY (user_id) REFERENCES users(id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
}
?>