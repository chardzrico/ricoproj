<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'ricopogi18jr');
define('DB_NAME', 'prms_db');

// IMPORTANT: since PHP 8.1, mysqli throws an exception on any DB error by
// default (it used to just return false). This whole codebase was written
// against the old behavior — every "if ($stmt)" / "if ($conn->connect_error)"
// check here assumes a failed query returns false rather than throwing.
// On PHP 8.1+ (the current default almost everywhere, including recent
// XAMPP), that mismatch means ANY database error — a missing column, a bad
// query, anything — becomes an uncaught exception, which PHP renders as a
// blank white page whenever display_errors is off. Restoring the legacy
// "just return false" behavior here fixes that for the whole app, not just
// one query.
mysqli_report(MYSQLI_REPORT_OFF);

function getDBConnection() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        die(json_encode(['error' => 'Connection failed: ' . $conn->connect_error]));
    }
    $conn->set_charset('utf8mb4');
    ensureSchemaUpToDate($conn);
    return $conn;
}

/**
 * Self-healing schema check: some features (Medico-Legal body diagram,
 * Dental odontogram) were added after the base schema (prms_db1.sql) via
 * separate migration files. If a site was only ever set up from the base
 * dump and never had those migrations run against it, the "injury_map" /
 * "odontogram" columns don't exist — and since the Record Service save
 * handler always references both columns (for every category, not just
 * Dental/Physical), every single save would fail, which used to render as
 * a blank white page with no explanation.
 *
 * This adds the columns automatically (once, cheaply, idempotently — same
 * IF-NOT-EXISTS logic as the migration .sql files) so a missed migration
 * step can never silently break saving.
 */
function ensureSchemaUpToDate($conn) {
    static $checked = false;
    if ($checked) return;
    $checked = true;

    $columns = [
        'injury_map' => "ALTER TABLE patient_services ADD COLUMN injury_map LONGTEXT NULL AFTER notes",
        'odontogram' => "ALTER TABLE patient_services ADD COLUMN odontogram LONGTEXT NULL AFTER injury_map",
    ];
    foreach ($columns as $col => $alterSql) {
        $res = $conn->query(
            "SELECT COUNT(*) AS c FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'patient_services' AND COLUMN_NAME = '" . $conn->real_escape_string($col) . "'"
        );
        $exists = $res ? (int)$res->fetch_assoc()['c'] > 0 : true; // if the check itself fails, don't try to alter
        if (!$exists) {
            $conn->query($alterSql);
        }
    }
}
?>