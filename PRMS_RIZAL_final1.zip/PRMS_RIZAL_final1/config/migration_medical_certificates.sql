-- ============================================================
-- PRMS Migration: Medical Certificates
-- Fit to Work / Fit to Travel / illness certification etc., issued
-- against a patient record. See modules/certificates/certificate_log.php.
-- Run this once against an EXISTING prms_db database.
-- (Fresh installs already get this via prms_db1.sql, and it's also
-- created automatically the first time the app connects — see
-- ensureSchemaUpToDate() in config/database.php.)
-- ============================================================
USE prms_db;

ALTER TABLE users
    ADD COLUMN IF NOT EXISTS license_number VARCHAR(50) NULL AFTER role;

CREATE TABLE IF NOT EXISTS medical_certificates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cert_number VARCHAR(50) NOT NULL UNIQUE,
    patient_id INT NOT NULL,
    cert_type VARCHAR(100) NOT NULL,
    findings TEXT NULL,
    recommendation TEXT NULL,
    valid_from DATE NULL,
    valid_until DATE NULL,
    issued_date DATE NOT NULL,
    issued_by INT NULL,
    status ENUM('active','voided') NOT NULL DEFAULT 'active',
    void_reason VARCHAR(255) NULL,
    printed_at TIMESTAMP NULL,
    printed_by INT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_cert_patient (patient_id),
    INDEX idx_cert_status (status),
    CONSTRAINT fk_cert_patient FOREIGN KEY (patient_id) REFERENCES patients(id),
    CONSTRAINT fk_cert_issued_by FOREIGN KEY (issued_by) REFERENCES users(id),
    CONSTRAINT fk_cert_printed_by FOREIGN KEY (printed_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
