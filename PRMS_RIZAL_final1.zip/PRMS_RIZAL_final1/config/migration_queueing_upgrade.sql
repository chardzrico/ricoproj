-- Queueing upgrade: priority lanes (senior/PWD/pregnant per RA 9994 / RA 10754),
-- linking a queue entry back to the appointment it was checked in from, and a
-- time_done timestamp for service-duration stats. Applied automatically by
-- ensureSchemaUpToDate() in config/database.php; kept here for the record.

ALTER TABLE patient_queue ADD COLUMN appointment_id INT NULL AFTER patient_id;
ALTER TABLE patient_queue ADD COLUMN priority ENUM('normal','senior','pwd','pregnant') NOT NULL DEFAULT 'normal' AFTER category;
ALTER TABLE patient_queue ADD COLUMN time_done TIMESTAMP NULL AFTER time_served;
ALTER TABLE patient_queue ADD UNIQUE INDEX uniq_queue_no_per_day (category, queue_date, queue_no);

-- Schema-drift fix: this live DB has created_at where the code (and
-- prms_db1.sql) expects time_in. Add it and backfill from created_at.
-- NOTE: the ALTER below backfills every existing row's time_in with the
-- ALTER's own execution time (a TIMESTAMP + DEFAULT CURRENT_TIMESTAMP
-- quirk), not NULL, so the UPDATE must run unconditionally to actually
-- reconcile old rows back to their true created_at value.
ALTER TABLE patient_queue ADD COLUMN time_in TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP AFTER status;
UPDATE patient_queue SET time_in = created_at WHERE created_at IS NOT NULL AND time_in != created_at;
