-- Structured fields for the Prenatal, Family Planning, and TB-DOTS
-- sub-services (all seeded under the Medical category) — previously just a
-- free-text notes box, same as every other sub-service. Applied
-- automatically by ensureSchemaUpToDate() in config/database.php; kept here
-- for the record.

ALTER TABLE patient_services ADD COLUMN prenatal_lmp DATE NULL AFTER odontogram;
ALTER TABLE patient_services ADD COLUMN prenatal_edd DATE NULL AFTER prenatal_lmp;
ALTER TABLE patient_services ADD COLUMN prenatal_gravida INT NULL AFTER prenatal_edd;
ALTER TABLE patient_services ADD COLUMN prenatal_para INT NULL AFTER prenatal_gravida;
ALTER TABLE patient_services ADD COLUMN prenatal_bp VARCHAR(20) NULL AFTER prenatal_para;
ALTER TABLE patient_services ADD COLUMN prenatal_tt_status VARCHAR(20) NULL AFTER prenatal_bp;
ALTER TABLE patient_services ADD COLUMN prenatal_danger_signs LONGTEXT NULL AFTER prenatal_tt_status COMMENT 'JSON array of selected danger-sign strings';

ALTER TABLE patient_services ADD COLUMN fp_method VARCHAR(50) NULL AFTER prenatal_danger_signs;
ALTER TABLE patient_services ADD COLUMN fp_acceptor_type VARCHAR(20) NULL AFTER fp_method COMMENT 'new/current/switching/dropout';
ALTER TABLE patient_services ADD COLUMN fp_next_visit DATE NULL AFTER fp_acceptor_type;

ALTER TABLE patient_services ADD COLUMN tb_sputum_result VARCHAR(20) NULL AFTER fp_next_visit;
ALTER TABLE patient_services ADD COLUMN tb_treatment_category VARCHAR(20) NULL AFTER tb_sputum_result;
ALTER TABLE patient_services ADD COLUMN tb_regimen VARCHAR(100) NULL AFTER tb_treatment_category;
ALTER TABLE patient_services ADD COLUMN tb_attendance VARCHAR(20) NULL AFTER tb_regimen COMMENT 'taken/missed for this DOTS visit';
