<?php
require_once __DIR__ . '/database.php';

// Show real errors instead of a blank page. This is a local/school-project
// deployment (XAMPP), so it's safe and far more useful than a silent crash —
// remove/guard this behind an environment check if this ever goes to a
// public server.
error_reporting(E_ALL);
ini_set('display_errors', '1');

session_start();

// Compute BASE_URL from config directory (always PRMS1/config/)
// dirname(__DIR__) = PRMS1 root, regardless of which page is being served
$_prmsRoot = str_replace('\\', '/', dirname(__DIR__));
$_docRoot  = str_replace('\\', '/', rtrim($_SERVER['DOCUMENT_ROOT'], '/'));
$_urlPath  = str_replace($_docRoot, '', $_prmsRoot);
$_scheme   = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https' : 'http';
define('BASE_URL',   $_scheme . '://' . $_SERVER['HTTP_HOST'] . $_urlPath);
define('ASSETS_URL', BASE_URL . '/assets');

function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
}

function getCurrentUser() {
    return [
        'id'        => $_SESSION['user_id'] ?? null,
        'full_name' => $_SESSION['full_name'] ?? '',
        'username'  => $_SESSION['username'] ?? '',
        'role'      => $_SESSION['role'] ?? '',
        'email'     => $_SESSION['email'] ?? '',
    ];
}

function hasRole($role) {
    return ($_SESSION['role'] ?? '') === $role;
}

function isAdmin() {
    return hasRole('admin');
}

function isDoctor() {
    return hasRole('doctor');
}

// Restricts a patients-table query to the current doctor's assigned
// patients only. Returns an SQL fragment (leading " AND ...") to append
// to a WHERE clause — empty string for every other role, so admin/nurse/
// staff queries are unaffected.
// $alias: table alias used for `patients` in the query (e.g. 'p'), or ''
// if the query selects directly FROM patients with no alias.
function doctorScopeSql($alias = '') {
    if (!isDoctor()) return '';
    $col = $alias !== '' ? "$alias.assigned_doctor_id" : 'assigned_doctor_id';
    $id = (int)(getCurrentUser()['id'] ?? 0);
    return " AND $col = $id";
}

// doctorScopeSql() only ever narrowed read queries — nothing stopped a
// doctor from writing to a patient outside their assigned list by just
// knowing/guessing the ID. Call this at the top of every save/delete/
// toggle handler that takes a patient_id, right after validating it's a
// positive int. No-op (always passes) for every role except doctor.
function assertPatientInDoctorScope($conn, $patientId) {
    if (!isDoctor()) return;
    $patientId = (int)$patientId;
    $doctorId  = (int)(getCurrentUser()['id'] ?? 0);
    $stmt = $conn->prepare("SELECT id FROM patients WHERE id=? AND assigned_doctor_id=?");
    $stmt->bind_param('ii', $patientId, $doctorId);
    $stmt->execute();
    $ok = $stmt->get_result()->num_rows > 0;
    $stmt->close();
    if (!$ok) {
        http_response_code(403);
        die('You are not authorized to modify this patient\'s record.');
    }
}

function isPatient() {
    return hasRole('patient');
}

function isStaffRole() {
    return in_array($_SESSION['role'] ?? '', ['admin', 'doctor', 'nurse', 'staff'], true);
}

// Use on staff-only pages (clinical modules, admin, patient records list, etc.)
// Sends logged-in patients back to their own portal instead of the staff dashboard.
function requireStaffOnly() {
    requireLogin();
    if (isPatient()) {
        header('Location: ' . BASE_URL . '/patient/portal.php');
        exit;
    }
}

// Use on patient-portal pages. Sends staff back to the staff dashboard.
function requirePatientOnly() {
    requireLogin();
    if (!isPatient()) {
        header('Location: ' . BASE_URL . '/dashboard.php');
        exit;
    }
}

// ── CSRF protection ─────────────────────────────────────────────────
// One token per session, reused for every form/link so a page can have
// several protected actions without juggling multiple tokens.
function csrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Echo this inside a <form> tag, e.g.: echo csrfField();
function csrfField() {
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrfToken()) . '">';
}

// Append the token to a GET link/URL, e.g. csrfUrl('list.php?delete=' . $id)
function csrfUrl($url) {
    $sep = (strpos($url, '?') !== false) ? '&' : '?';
    return $url . $sep . 'csrf_token=' . urlencode(csrfToken());
}

// Call at the top of every POST handler and every GET-based mutation
// (delete/toggle/status-change links). Halts the request on mismatch.
function verifyCsrf() {
    $token = $_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '';
    if (!is_string($token) || $token === '' || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(403);
        die('Security check failed (invalid or expired form token). Please go back, refresh the page, and try again.');
    }
}