<?php
// Outgoing mail (SMTP) configuration — used by forgot_password.php to send
// password-reset links via PHPMailer (lib/PHPMailer/, vendored directly
// since this project has no Composer setup).
//
// SMTP_PASS must be a Gmail "App Password" (Google Account > Security >
// 2-Step Verification > App passwords), NOT the account's normal login
// password — Gmail rejects plain-password SMTP login.
//
// Same caveat as config/database.php's credentials: fine for this
// local/school deployment, but move these to environment variables (and
// keep this file out of version control) before deploying anywhere real.

require_once __DIR__ . '/../lib/PHPMailer/Exception.php';
require_once __DIR__ . '/../lib/PHPMailer/PHPMailer.php';
require_once __DIR__ . '/../lib/PHPMailer/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'jrico1531@gmail.com');
define('SMTP_PASS', 'chmbbomdkirsbqvo');
define('SMTP_FROM_NAME', 'PRMS - RHU Rizal');

// Sends the password-reset link. Returns true on success; on failure,
// logs the real SMTP error server-side and returns false so the caller
// can show the user a generic, non-leaky message.
function sendPasswordResetEmail(string $toEmail, string $toName, string $resetLink): bool {
    if (SMTP_USER === '' || SMTP_PASS === '') {
        error_log('sendPasswordResetEmail: SMTP_USER/SMTP_PASS not configured in config/mail.php');
        return false;
    }

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USER;
        $mail->Password   = SMTP_PASS;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;

        $mail->setFrom(SMTP_USER, SMTP_FROM_NAME);
        $mail->addAddress($toEmail, $toName);
        $mail->addReplyTo(SMTP_USER, SMTP_FROM_NAME);

        $mail->isHTML(true);
        $mail->Subject = 'Reset your PRMS password';
        $safeName = htmlspecialchars($toName ?: 'there');
        $safeLink = htmlspecialchars($resetLink);
        $mail->Body = "
            <div style=\"font-family:Arial,sans-serif;font-size:15px;color:#222;\">
                <p>Hi {$safeName},</p>
                <p>We received a request to reset the password for your PRMS account at Rural Health Unit, Rizal.</p>
                <p><a href=\"{$safeLink}\" style=\"display:inline-block;background:#0d6efd;color:#fff;padding:10px 22px;border-radius:8px;text-decoration:none;font-weight:600;\">Reset Password</a></p>
                <p>Or copy this link into your browser:<br><a href=\"{$safeLink}\">{$safeLink}</a></p>
                <p style=\"color:#888;font-size:.85em;\">This link expires in 1 hour. If you didn't request this, you can safely ignore this email — your password won't change.</p>
            </div>
        ";
        $mail->AltBody = "Hi {$toName},\n\nWe received a request to reset your PRMS password.\nReset it here (expires in 1 hour): {$resetLink}\n\nIf you didn't request this, you can ignore this email.";

        $mail->send();
        return true;
    } catch (PHPMailerException $e) {
        error_log('sendPasswordResetEmail failed: ' . $mail->ErrorInfo);
        return false;
    }
}
