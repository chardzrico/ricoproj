-- ============================================================
-- PRMS Migration: Accountability / audit trail
-- Records login attempts, patient record access/changes, and user
-- account changes so access to patient data can be traced after the
-- fact — see logAudit() in config/session.php and
-- modules/admin/audit_log.php for the viewer.
-- Run this once against an EXISTING prms_db database.
-- (Fresh installs already get this via prms_db1.sql, and it's also
-- created automatically the first time the app connects — see
-- ensureSchemaUpToDate() in config/database.php.)
-- ============================================================
USE prms_db;

CREATE TABLE IF NOT EXISTS audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    username_attempted VARCHAR(100) NULL,
    action VARCHAR(50) NOT NULL,
    target_type VARCHAR(50) NULL,
    target_id INT NULL,
    details VARCHAR(255) NULL,
    ip_address VARCHAR(45) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_audit_user (user_id),
    INDEX idx_audit_action (action),
    INDEX idx_audit_created (created_at),
    INDEX idx_audit_target (target_type, target_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
