<?php
// In-app notifications — the bell icon in includes/topbar.php.
// Schema (notifications / notification_reads) is created by
// ensureSchemaUpToDate() in config/database.php.
//
// A notification is either a broadcast to a whole role (recipientRole set,
// e.g. every staff member sees "new appointment request") or aimed at one
// specific user (recipientUserId set, e.g. a patient's own "your
// appointment was approved"). Never both on the same row.
//
// Like logAudit(), never lets a logging failure break the real action.

function notifyRole(string $role, string $type, string $title, ?string $message = null, ?string $link = null, ?string $targetType = null, ?int $targetId = null) {
    try {
        $conn = getDBConnection();
        $stmt = $conn->prepare("INSERT INTO notifications (recipient_role, type, title, message, link, target_type, target_id) VALUES (?,?,?,?,?,?,?)");
        $stmt->bind_param('ssssssi', $role, $type, $title, $message, $link, $targetType, $targetId);
        $stmt->execute();
    } catch (Throwable $e) {
        // Never break the caller's real action over a notification failure.
    }
}

function notifyUser(int $userId, string $type, string $title, ?string $message = null, ?string $link = null, ?string $targetType = null, ?int $targetId = null) {
    try {
        $conn = getDBConnection();
        $stmt = $conn->prepare("INSERT INTO notifications (recipient_user_id, type, title, message, link, target_type, target_id) VALUES (?,?,?,?,?,?,?)");
        $stmt->bind_param('isssssi', $userId, $type, $title, $message, $link, $targetType, $targetId);
        $stmt->execute();
    } catch (Throwable $e) {
        // Never break the caller's real action over a notification failure.
    }
}

// Notifications visible to the given user: broadcasts to their role, plus
// anything aimed at them directly.
function getVisibleNotifications($conn, int $userId, string $role, int $limit = 8): array {
    $limit = max(1, $limit);
    $stmt = $conn->prepare("
        SELECT n.*, (nr.user_id IS NOT NULL) AS is_read
        FROM notifications n
        LEFT JOIN notification_reads nr ON nr.notification_id = n.id AND nr.user_id = ?
        WHERE n.recipient_role = ? OR n.recipient_user_id = ?
        ORDER BY n.created_at DESC
        LIMIT ?
    ");
    $stmt->bind_param('isii', $userId, $role, $userId, $limit);
    $stmt->execute();
    $rows = [];
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) { $row['is_read'] = (bool)$row['is_read']; $rows[] = $row; }
    $stmt->close();
    return $rows;
}

function getUnreadNotificationCount($conn, int $userId, string $role): int {
    $stmt = $conn->prepare("
        SELECT COUNT(*) AS c
        FROM notifications n
        LEFT JOIN notification_reads nr ON nr.notification_id = n.id AND nr.user_id = ?
        WHERE (n.recipient_role = ? OR n.recipient_user_id = ?) AND nr.user_id IS NULL
    ");
    $stmt->bind_param('isi', $userId, $role, $userId);
    $stmt->execute();
    $c = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
    $stmt->close();
    return $c;
}

function markNotificationRead($conn, int $notificationId, int $userId) {
    $stmt = $conn->prepare("INSERT IGNORE INTO notification_reads (notification_id, user_id) VALUES (?,?)");
    $stmt->bind_param('ii', $notificationId, $userId);
    $stmt->execute();
    $stmt->close();
}

// Marks every notification currently visible to this user as read (used by
// "Mark all as read").
function markAllNotificationsRead($conn, int $userId, string $role) {
    $stmt = $conn->prepare("
        INSERT IGNORE INTO notification_reads (notification_id, user_id)
        SELECT n.id, ? FROM notifications n
        WHERE n.recipient_role = ? OR n.recipient_user_id = ?
    ");
    $stmt->bind_param('isi', $userId, $role, $userId);
    $stmt->execute();
    $stmt->close();
}
