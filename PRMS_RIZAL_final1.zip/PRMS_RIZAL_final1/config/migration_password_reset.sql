-- ============================================================
-- PRMS Migration: Forgot-password / reset-by-email support
-- Adds a one-time, expiring token per user for the reset flow in
-- forgot_password.php / reset_password.php.
-- Run this once against an EXISTING prms_db database.
-- (Fresh installs already get this via prms_db1.sql)
-- ============================================================
USE prms_db;

ALTER TABLE users
    ADD COLUMN reset_token VARCHAR(64) NULL AFTER password,
    ADD COLUMN reset_token_expires DATETIME NULL AFTER reset_token;
