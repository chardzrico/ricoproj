<?php
require_once __DIR__ . '/config/session.php';
require_once __DIR__ . '/config/database.php';

if (isLoggedIn()) {
    logAudit('logout', 'user', $_SESSION['user_id'], null, $_SESSION['user_id']);
}

session_destroy();
header('Location: login.php');
exit;
