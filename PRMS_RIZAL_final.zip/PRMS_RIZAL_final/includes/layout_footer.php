<?php
$assetsUrl = defined('ASSETS_URL')
    ? ASSETS_URL
    : (defined('BASE_URL') ? BASE_URL . '/assets' : '/assets');
?>
    </div><!-- .pc-content -->
</div><!-- .pc-container -->

<footer class="pc-footer" style="background: #fff; border-top: 1px solid #e9ecef; padding: 20px 0;">
    <div class="footer-wrapper container-fluid px-4">
        <div class="row align-items-center">
            <div class="col-md-6 text-center text-md-start">
                <span class="text-muted" style="font-size: 0.8rem; font-weight: 500;">
                    &copy; <?= date('Y') ?> <span class="fw-bold text-primary">PRMS</span> &bull; Patient Record Management System
                </span>
            </div>
            <div class="col-md-6 text-center text-md-end mt-2 mt-md-0">
                <span class="text-muted" style="font-size: 0.8rem; font-weight: 500;">
                    Rural Health Unit, Rizal &bull; <span class="text-primary">v1.0.0</span>
                </span>
            </div>
        </div>
    </div>
</footer>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?= $assetsUrl ?>/js/plugins/simplebar.min.js"></script>
<script src="<?= $assetsUrl ?>/js/icon/custom-icon.js"></script>
<script src="<?= $assetsUrl ?>/js/plugins/feather.min.js"></script>
<script src="<?= $assetsUrl ?>/js/component.js"></script>
<script src="<?= $assetsUrl ?>/js/theme.js"></script>
<script src="<?= $assetsUrl ?>/js/script.js"></script>
<script>
    // Initialize theme settings
    preset_change('preset-1');
    main_layout_change('vertical');
    layout_caption_change('true');
    
    // Initialize DataTables with consistent alignment and styling
    $(document).ready(function(){
        $('.prms-datatable').each(function() {
            if (!$.fn.DataTable.isDataTable(this)) {
                $(this).DataTable({
                    responsive: true,
                    language: {
                        search: '',
                        searchPlaceholder: 'Search records...',
                        lengthMenu: '_MENU_ per page',
                        info: 'Showing _START_ to _END_ of _TOTAL_ entries',
                        paginate: {
                            previous: '<i class="ti ti-chevron-left"></i>',
                            next: '<i class="ti ti-chevron-right"></i>'
                        },
                        emptyTable: '<div class="text-center text-muted py-4"><i class="ti ti-database-off mb-2" style="font-size: 2rem; opacity: 0.3;"></i><div>No records found in the database.</div></div>',
                        zeroRecords: '<div class="text-center text-muted py-4"><i class="ti ti-search-off mb-2" style="font-size: 2rem; opacity: 0.3;"></i><div>No matching records found.</div></div>'
                    },
                    pageLength: 10,
                    dom: '<"d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mb-4"lf>rt<"d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4"ip>'
                });
            }
        });

        // Add custom styling to DataTable search input
        $('.dataTables_filter input').addClass('form-control form-control-sm').css({
            'border-radius': '8px',
            'padding': '8px 12px',
            'width': '240px',
            'border': '1.5px solid #e0e0e0'
        });
        $('.dataTables_length select').addClass('form-select form-select-sm').css({
            'border-radius': '8px',
            'border': '1.5px solid #e0e0e0'
        });
    });
    
    // Professional delete confirmation
    function confirmDelete(url, name) {
        Swal.fire({
            title: 'Confirm Deletion',
            text: 'Are you sure you want to permanently delete "' + name + '"? This action cannot be undone.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#dc3545',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Yes, Delete Record',
            cancelButtonText: 'Cancel',
            reverseButtons: true,
            customClass: {
                confirmButton: 'btn btn-danger px-4',
                cancelButton: 'btn btn-light px-4'
            },
            buttonsStyling: false
        }).then(function(result) {
            if (result.isConfirmed) { 
                window.location.href = url; 
            }
        });
    }
    
    // Toast notification utility
    function showToast(msg, type) {
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        });
        Toast.fire({
            icon: type || 'success',
            title: msg
        });
    }
</script>
<?php if (isset($extraJS)) echo $extraJS; ?>
</body>
</html>
