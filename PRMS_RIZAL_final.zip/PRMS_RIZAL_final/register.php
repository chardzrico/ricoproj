<?php
require_once __DIR__ . '/config/session.php';
require_once __DIR__ . '/config/database.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . '/dashboard.php');
    exit;
}

$error = '';
$success = '';
$validRoles = ['patient', 'staff', 'nurse', 'doctor', 'admin'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role      = $_POST['role'] ?? 'patient';
    if (!in_array($role, $validRoles, true)) $role = 'patient';

    $username  = trim($_POST['username'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $password  = $_POST['password'] ?? '';
    $confirm   = $_POST['confirm_password'] ?? '';

    if ($role === 'patient') {
        // ── Patient self-registration fields ────────────────────────────
        $first_name  = trim($_POST['first_name'] ?? '');
        $last_name   = trim($_POST['last_name'] ?? '');
        $middle_name = trim($_POST['middle_name'] ?? '');
        $dob         = $_POST['date_of_birth'] ?? '';
        $gender      = $_POST['gender'] ?? '';
        $address     = trim($_POST['address'] ?? '');
        $contact     = trim($_POST['contact_number'] ?? '');
        $guardian    = trim($_POST['guardian_name'] ?? '');
        $gcontact    = trim($_POST['guardian_contact'] ?? '');
        $full_name   = trim($first_name . ' ' . $middle_name . ' ' . $last_name);
        $full_name   = preg_replace('/\s+/', ' ', $full_name);
    } else {
        $full_name = trim($_POST['full_name'] ?? '');
    }

    if (empty($username) || empty($email) || empty($password)) {
        $error = 'All fields are required.';
    } elseif ($role === 'patient' && (empty($first_name) || empty($last_name) || empty($dob) || empty($gender))) {
        $error = 'Please fill in your first name, last name, date of birth, and gender.';
    } elseif ($role !== 'patient' && empty($full_name)) {
        $error = 'All fields are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $conn = getDBConnection();
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1");
        $stmt->bind_param('ss', $username, $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $error = 'Username or email already exists.';
            $stmt->close();
            $conn->close();
        } else {
            $stmt->close();
            $hashed = password_hash($password, PASSWORD_DEFAULT);

            $conn->begin_transaction();
            try {
                $stmt = $conn->prepare("INSERT INTO users (full_name, username, email, password, role) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param('sssss', $full_name, $username, $email, $hashed, $role);
                if (!$stmt->execute()) throw new Exception('user insert failed');
                $newUserId = $conn->insert_id;
                $stmt->close();

                if ($role === 'patient') {
                    $r   = $conn->query("SELECT COUNT(*) as cnt FROM patients");
                    $cnt = (int)$r->fetch_assoc()['cnt'] + 1;
                    $patient_no = 'RHU-' . date('Y') . '-' . str_pad($cnt, 5, '0', STR_PAD_LEFT);

                    $stmt = $conn->prepare("INSERT INTO patients (user_id, patient_no, first_name, last_name, middle_name, date_of_birth, gender, address, contact_number, guardian_name, guardian_contact) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
                    $stmt->bind_param('issssssssss', $newUserId, $patient_no, $first_name, $last_name, $middle_name, $dob, $gender, $address, $contact, $guardian, $gcontact);
                    if (!$stmt->execute()) throw new Exception('patient insert failed');
                    $stmt->close();
                }

                $conn->commit();
                $success = 'Account created successfully! You can now <a href="' . BASE_URL . '/login.php" class="fw-semibold">sign in</a>.';
            } catch (Exception $e) {
                $conn->rollback();
                $error = 'Registration failed. Please try again.';
            }
            $conn->close();
        }
    }
}
?>
<!doctype html>
<html lang="en" data-pc-preset="preset-1" data-pc-direction="ltr" dir="ltr" data-pc-theme="light">
<head>
    <title>Register | PRMS - Patient Record Management System</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui"/>
    <link rel="icon" href="<?= ASSETS_URL ?>/images/favicon.svg" type="image/x-icon"/>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/fonts/tabler-icons.min.css"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/fonts/feather.css"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/fonts/fontawesome.css"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/css/style.css" id="main-style-link"/>
    <style>
        body { margin: 0; padding: 0; }
        .auth-main {
            background: linear-gradient(135deg, #1e3a5f 0%, #0d6efd 50%, #1e3a5f 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px 16px;
        }
        .auth-wrapper { width: 100%; max-width: 500px; }
        .auth-card { border-radius: 18px; box-shadow: 0 24px 64px rgba(0,0,0,.35); border: none; overflow: hidden; }
        .auth-logo-area {
            background: linear-gradient(135deg, #1e3a5f, #0d6efd);
            padding: 30px 30px 22px;
            text-align: center;
            color: white;
        }
        .rhu-logo-circle {
            width: 72px; height: 72px; border-radius: 50%;
            background: rgba(255,255,255,.15);
            border: 3px dashed rgba(255,255,255,.5);
            margin: 0 auto 14px;
            display: flex; align-items: center; justify-content: center;
        }
        .rhu-logo-circle .placeholder-icon { font-size: 2rem; color: rgba(255,255,255,.75); }
        .prms-badge { background: rgba(255,255,255,.2); border-radius: 50px; padding: 5px 18px; display: inline-block; font-size: .78rem; font-weight: 600; letter-spacing: 2px; margin-bottom: 12px; }
        .auth-logo-area h2 { font-weight: 700; font-size: 1.45rem; margin-bottom: 4px; }
        .auth-logo-area p  { opacity: .85; font-size: .87rem; margin: 0; }
        .auth-body { padding: 28px 36px 32px; }
        .form-control, .form-select {
            border-radius: 8px; padding: 11px 16px;
            border: 1.5px solid #e0e0e0; font-size: .92rem; transition: all .2s;
        }
        .form-control:focus, .form-select:focus { border-color: #0d6efd; box-shadow: 0 0 0 3px rgba(13,110,253,.1); }
        .input-group-text { border: 1.5px solid #e0e0e0; background: #f8f9fa; }
        .input-group .form-control { border-left: none; border-radius: 0 8px 8px 0 !important; }
        .input-group .input-group-text:first-child { border-right: none; border-radius: 8px 0 0 8px !important; }
        .input-group .input-group-text:last-child  { border-left: none;  border-radius: 0 8px 8px 0 !important; cursor: pointer; }
        .btn-register {
            background: linear-gradient(135deg, #1e3a5f, #0d6efd);
            border: none; padding: 13px; font-size: .95rem; font-weight: 600;
            border-radius: 10px; transition: all .3s; width: 100%; color: #fff;
        }
        .btn-register:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(13,110,253,.4); color: #fff; }
        .label-text { font-weight: 600; font-size: .85rem; color: #444; margin-bottom: 5px; display: block; }
        .error-alert   { border-radius: 8px; padding: 10px 14px; background: #fff3f3; border: 1px solid #ffcdd2; color: #c62828; font-size: .88rem; }
        .success-alert { border-radius: 8px; padding: 10px 14px; background: #f0fff4; border: 1px solid #a5d6a7; color: #2e7d32; font-size: .88rem; }
        .password-strength { height: 4px; border-radius: 4px; margin-top: 6px; transition: all .3s; background: #e0e0e0; }
        .two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
        @media(max-width:500px){ .two-col { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
<div class="loader-bg fixed inset-0 bg-white z-[1034]">
    <div class="loader-track h-[5px] w-full inline-block absolute overflow-hidden top-0">
        <div class="loader-fill w-[300px] h-[5px] bg-primary-500 absolute top-0 left-0"></div>
    </div>
</div>

<div class="auth-main">
    <div class="auth-wrapper">
        <div class="auth-card card">
            <div class="auth-logo-area">
                <div class="rhu-logo-circle">
                    <span class="placeholder-icon"><i class="ti ti-building-hospital"></i></span>
                </div>
                <div class="prms-badge"><i class="ti ti-heart-rate-monitor me-1"></i> PRMS</div>
                <h2>Create Your Account</h2>
                <p>Rural Health Unit &bull; Rizal</p>
            </div>

            <div class="auth-body">
                <h5 class="fw-bold mb-1" style="color:#1e3a5f;">Register</h5>
                <p class="text-muted mb-4" style="font-size:.88rem;">Fill in your details to request system access</p>

                <?php if ($error): ?>
                    <div class="error-alert mb-3 d-flex align-items-center gap-2">
                        <i class="ti ti-alert-circle"></i> <?= htmlspecialchars($error) ?>
                    </div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="success-alert mb-3 d-flex align-items-center gap-2">
                        <i class="ti ti-circle-check"></i> <?= $success ?>
                    </div>
                <?php endif; ?>

                <?php if (!$success):
                    $postRole = $_POST['role'] ?? 'patient';
                    $isPatientTab = $postRole === 'patient';
                ?>
                <form method="POST" action="" id="registerForm">
                    <!-- Register-as toggle -->
                    <div class="mb-3">
                        <label class="label-text">I am registering as</label>
                        <div class="btn-group w-100" role="group">
                            <input type="radio" class="btn-check" name="accountType" id="tabPatient" autocomplete="off" <?= $isPatientTab ? 'checked' : '' ?> onchange="toggleAccountType('patient')">
                            <label class="btn btn-outline-primary" for="tabPatient"><i class="ti ti-user-heart me-1"></i>Patient</label>

                            <input type="radio" class="btn-check" name="accountType" id="tabStaff" autocomplete="off" <?= !$isPatientTab ? 'checked' : '' ?> onchange="toggleAccountType('staff')">
                            <label class="btn btn-outline-primary" for="tabStaff"><i class="ti ti-stethoscope me-1"></i>Staff Member</label>
                        </div>
                        <small class="text-muted d-block mt-1" style="font-size:.78rem;">Patients get their own portal to request appointments. Staff accounts are for RHU personnel.</small>
                    </div>

                    <!-- ══ Patient-only fields ══ -->
                    <div id="patientFields" style="<?= $isPatientTab ? '' : 'display:none;' ?>">
                        <div class="two-col mb-3">
                            <div>
                                <label class="label-text">First Name</label>
                                <input type="text" class="form-control" name="first_name" placeholder="First name"
                                       value="<?= htmlspecialchars($_POST['first_name'] ?? '') ?>" <?= $isPatientTab ? 'required' : '' ?>>
                            </div>
                            <div>
                                <label class="label-text">Last Name</label>
                                <input type="text" class="form-control" name="last_name" placeholder="Last name"
                                       value="<?= htmlspecialchars($_POST['last_name'] ?? '') ?>" <?= $isPatientTab ? 'required' : '' ?>>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="label-text">Middle Name</label>
                            <input type="text" class="form-control" name="middle_name" placeholder="Middle name (optional)"
                                   value="<?= htmlspecialchars($_POST['middle_name'] ?? '') ?>">
                        </div>
                        <div class="two-col mb-3">
                            <div>
                                <label class="label-text">Date of Birth</label>
                                <input type="date" class="form-control" name="date_of_birth"
                                       value="<?= htmlspecialchars($_POST['date_of_birth'] ?? '') ?>" <?= $isPatientTab ? 'required' : '' ?>>
                            </div>
                            <div>
                                <label class="label-text">Gender</label>
                                <select class="form-select" name="gender">
                                    <option value="">Select Gender</option>
                                    <option value="Male"   <?= ($_POST['gender'] ?? '') === 'Male'   ? 'selected' : '' ?>>Male</option>
                                    <option value="Female" <?= ($_POST['gender'] ?? '') === 'Female' ? 'selected' : '' ?>>Female</option>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="label-text">Contact Number</label>
                            <input type="text" class="form-control" name="contact_number" placeholder="09XX-XXX-XXXX"
                                   value="<?= htmlspecialchars($_POST['contact_number'] ?? '') ?>">
                        </div>
                        <div class="mb-3">
                            <label class="label-text">Address</label>
                            <input type="text" class="form-control" name="address" placeholder="Barangay, Municipality, Province"
                                   value="<?= htmlspecialchars($_POST['address'] ?? '') ?>">
                        </div>
                        <div class="two-col mb-3">
                            <div>
                                <label class="label-text">Guardian Name <small class="text-muted">(if minor)</small></label>
                                <input type="text" class="form-control" name="guardian_name" placeholder="Parent / Guardian"
                                       value="<?= htmlspecialchars($_POST['guardian_name'] ?? '') ?>">
                            </div>
                            <div>
                                <label class="label-text">Guardian Contact</label>
                                <input type="text" class="form-control" name="guardian_contact" placeholder="Guardian contact number"
                                       value="<?= htmlspecialchars($_POST['guardian_contact'] ?? '') ?>">
                            </div>
                        </div>
                    </div>

                    <!-- ══ Staff-only fields ══ -->
                    <div id="staffFields" style="<?= $isPatientTab ? 'display:none;' : '' ?>">
                        <div class="mb-3">
                            <label class="label-text">Full Name</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="ti ti-id-badge" style="color:#0d6efd;"></i></span>
                                <input type="text" class="form-control" name="full_name" placeholder="e.g. Juan Dela Cruz"
                                       value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>" <?= $isPatientTab ? '' : 'required' ?>>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="label-text">Staff Role</label>
                            <select class="form-select" name="staffRole" id="staffRoleSelect">
                                <option value="staff"  <?= $postRole === 'staff'  ? 'selected' : '' ?>>Staff</option>
                                <option value="nurse"  <?= $postRole === 'nurse'  ? 'selected' : '' ?>>Nurse / Midwife</option>
                                <option value="doctor" <?= $postRole === 'doctor' ? 'selected' : '' ?>>Doctor</option>
                                <option value="admin"  <?= $postRole === 'admin'  ? 'selected' : '' ?>>Administrator</option>
                            </select>
                        </div>
                    </div>

                    <!-- Hidden field actually submitted as the account role -->
                    <input type="hidden" name="role" id="roleField" value="<?= htmlspecialchars($postRole) ?>">

                    <div class="two-col mb-3">
                        <div>
                            <label class="label-text">Username</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="ti ti-user" style="color:#0d6efd;"></i></span>
                                <input type="text" class="form-control" name="username" placeholder="Username"
                                       value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
                            </div>
                        </div>
                        <div>
                            <label class="label-text">Email Address</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="ti ti-mail" style="color:#0d6efd;"></i></span>
                                <input type="email" class="form-control" name="email" placeholder="your@email.com"
                                       value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="two-col mb-4">
                        <div>
                            <label class="label-text">Password</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="ti ti-lock" style="color:#0d6efd;"></i></span>
                                <input type="password" class="form-control" name="password" id="pw1"
                                       placeholder="Min. 8 characters" required oninput="checkStrength(this.value)"
                                       style="border-radius:0 8px 8px 0!important;">
                            </div>
                            <div class="password-strength" id="strengthBar" style="width:0%"></div>
                            <small id="strengthText" class="text-muted" style="font-size:.78rem;"></small>
                        </div>
                        <div>
                            <label class="label-text">Confirm Password</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="ti ti-lock-check" style="color:#0d6efd;"></i></span>
                                <input type="password" class="form-control" name="confirm_password" id="pw2"
                                       placeholder="Repeat password" required
                                       style="border-radius:0 8px 8px 0!important;">
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center">
                        <button type="submit" class="btn-register">
                            <i class="ti ti-user-plus me-2"></i>Create Account
                        </button>
                    </div>
                </form>
                <?php endif; ?>

                <div class="text-center mt-4">
                    <span class="text-muted" style="font-size:.88rem;">Already have an account?</span>
                    <a href="<?= BASE_URL ?>/login.php" class="fw-semibold ms-1" style="color:#0d6efd;">Sign In</a>
                </div>
            </div>
        </div>
        <p class="text-center text-white mt-3" style="font-size:.8rem;opacity:.7;">
            &copy; <?= date('Y') ?> PRMS &bull; Rural Health Unit, Rizal
        </p>
    </div>
</div>

<script src="<?= ASSETS_URL ?>/js/plugins/popper.min.js"></script>
<script src="<?= ASSETS_URL ?>/js/component.js"></script>
<script src="<?= ASSETS_URL ?>/js/theme.js"></script>
<script src="<?= ASSETS_URL ?>/js/script.js"></script>
<script>
function checkStrength(val) {
    const bar = document.getElementById('strengthBar');
    const txt = document.getElementById('strengthText');
    let score = 0;
    if (val.length >= 8) score++;
    if (/[A-Z]/.test(val)) score++;
    if (/[0-9]/.test(val)) score++;
    if (/[^A-Za-z0-9]/.test(val)) score++;
    const colors = ['#ef5350','#ff9800','#66bb6a','#2e7d32'];
    const labels = ['Weak','Fair','Good','Strong'];
    const widths = ['25%','50%','75%','100%'];
    if (!val.length) { bar.style.width = '0'; txt.textContent = ''; return; }
    const idx = Math.max(0, score - 1);
    bar.style.background = colors[idx]; bar.style.width = widths[idx];
    txt.textContent = labels[idx]; txt.style.color = colors[idx];
}
function toggleAccountType(type) {
    const patientBox = document.getElementById('patientFields');
    const staffBox    = document.getElementById('staffFields');
    const roleField   = document.getElementById('roleField');
    const staffSelect = document.getElementById('staffRoleSelect');
    const patientRequired = ['input[name="first_name"]', 'input[name="last_name"]', 'input[name="date_of_birth"]'];
    const staffRequired   = 'input[name="full_name"]';

    if (type === 'patient') {
        patientBox.style.display = '';
        staffBox.style.display   = 'none';
        roleField.value = 'patient';
        patientRequired.forEach(sel => document.querySelector(sel).required = true);
        document.querySelector(staffRequired).required = false;
    } else {
        patientBox.style.display = 'none';
        staffBox.style.display   = '';
        roleField.value = staffSelect.value;
        patientRequired.forEach(sel => document.querySelector(sel).required = false);
        document.querySelector(staffRequired).required = true;
    }
}
document.getElementById('staffRoleSelect')?.addEventListener('change', function() {
    if (document.getElementById('tabStaff').checked) {
        document.getElementById('roleField').value = this.value;
    }
});
preset_change('preset-1');
main_layout_change('vertical');
</script>
</body>
</html>
