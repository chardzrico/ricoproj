<?php
require_once __DIR__ . '/config/session.php';
require_once __DIR__ . '/config/database.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . (isPatient() ? '/patient/portal.php' : '/dashboard.php'));
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $error = 'Please enter username and password.';
    } else {
        $conn = getDBConnection();
        $stmt = $conn->prepare("SELECT id, full_name, username, email, password, role, status FROM users WHERE (username = ? OR email = ?) LIMIT 1");
        $stmt->bind_param('ss', $username, $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();
        $conn->close();

        if ($user && $user['status'] === 'active' && password_verify($password, $user['password'])) {
            $_SESSION['user_id']   = $user['id'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['username']  = $user['username'];
            $_SESSION['role']      = $user['role'];
            $_SESSION['email']     = $user['email'];

            if ($user['role'] === 'patient') {
                header('Location: ' . BASE_URL . '/patient/portal.php');
            } else {
                header('Location: ' . BASE_URL . '/dashboard.php');
            }
            exit;
        } else {
            $error = 'Invalid credentials or account is inactive.';
        }
    }
}
?>
<!doctype html>
<html lang="en" data-pc-preset="preset-1" data-pc-direction="ltr" dir="ltr" data-pc-theme="light">
<head>
    <title>Login | PRMS - Patient Record Management System</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <link rel="icon" href="<?= ASSETS_URL ?>/images/favicon.svg" type="image/x-icon"/>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/fonts/tabler-icons.min.css"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/fonts/feather.css"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/fonts/fontawesome.css"/>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/css/style.css" id="main-style-link"/>
    <style>
        body { margin: 0; padding: 0; }
        .auth-main {
            background: linear-gradient(135deg, #1e3a5f 0%, #0d6efd 50%, #1e3a5f 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .auth-wrapper { width: 100%; max-width: 440px; }
        .auth-card { border-radius: 18px; box-shadow: 0 24px 64px rgba(0,0,0,.35); border: none; overflow: hidden; }
        .auth-logo-area {
            background: linear-gradient(135deg, #1e3a5f, #0d6efd);
            padding: 36px 30px 28px;
            text-align: center;
            color: white;
        }
        /* ── RHU Logo circle ── */
        .rhu-logo-circle {
            width: 88px; height: 88px;
            border-radius: 50%;
            background: rgba(255,255,255,.15);
            border: 3px dashed rgba(255,255,255,.5);
            margin: 0 auto 18px;
            display: flex; align-items: center; justify-content: center;
            overflow: hidden;
            cursor: pointer;
            transition: border-color .2s, background .2s;
        }
        .rhu-logo-circle:hover { border-color: rgba(255,255,255,.85); background: rgba(255,255,255,.22); }
        .rhu-logo-circle img { width: 100%; height: 100%; object-fit: cover; border-radius: 50%; }
        .rhu-logo-circle .placeholder-icon { font-size: 2.6rem; color: rgba(255,255,255,.7); }
        .prms-badge {
            background: rgba(255,255,255,.2);
            border-radius: 50px; padding: 5px 20px;
            display: inline-block; font-size: .78rem;
            font-weight: 600; letter-spacing: 2px; margin-bottom: 12px;
        }
        .auth-logo-area h2 { font-weight: 700; font-size: 1.7rem; margin-bottom: 4px; }
        .auth-logo-area p  { opacity: .85; font-size: .88rem; margin: 0; }
        /* ── Form area ── */
        .auth-body { padding: 32px 36px 36px; text-align: center; }
        .auth-body .form-group-wrap { text-align: left; }
        .form-control { border-radius: 8px; padding: 12px 16px; border: 1.5px solid #e0e0e0; font-size: .95rem; transition: all .2s; }
        .form-control:focus { border-color: #0d6efd; box-shadow: 0 0 0 3px rgba(13,110,253,.1); }
        .input-group-text { border: 1.5px solid #e0e0e0; background: #f8f9fa; }
        .input-group .form-control { border-right: none; border-radius: 8px 0 0 8px !important; }
        .input-group .input-group-text:first-child { border-right: none; border-radius: 8px 0 0 8px !important; }
        .input-group .input-group-text:last-child  { border-left: none;  border-radius: 0 8px 8px 0 !important; cursor: pointer; }
        .icon-prefix { border-right: none !important; border-radius: 8px 0 0 8px !important; }
        .field-with-icon { border-left: none !important; border-radius: 0 8px 8px 0 !important; }
        .btn-login {
            background: linear-gradient(135deg, #1e3a5f, #0d6efd);
            border: none; padding: 13px; font-size: 1rem; font-weight: 600;
            border-radius: 10px; letter-spacing: .5px; transition: all .3s;
            width: 100%; color: #fff; margin: 0 auto; display: block;
        }
        .btn-login:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(13,110,253,.4); color: #fff; }
        .error-alert { border-radius: 8px; padding: 12px 16px; background: #fff3f3; border: 1px solid #ffcdd2; color: #c62828; font-size: .9rem; text-align: left; }
        .label-text { font-weight: 600; font-size: .87rem; color: #444; margin-bottom: 6px; display: block; }
        .divider-text { position: relative; text-align: center; margin: 22px 0 18px; }
        .divider-text::before, .divider-text::after { content: ''; position: absolute; top: 50%; width: 38%; height: 1px; background: #e0e0e0; }
        .divider-text::before { left: 0; } .divider-text::after { right: 0; }
        .divider-text span { background: white; padding: 0 12px; font-size: .84rem; color: #888; position: relative; z-index: 1; }
        .floating-shapes span { position: absolute; border-radius: 50%; animation: float 8s infinite; pointer-events: none; }
        @keyframes float { 0%,100%{transform:translateY(0) rotate(0)} 50%{transform:translateY(-20px) rotate(180deg)} }
    </style>
</head>
<body>
<div class="loader-bg fixed inset-0 bg-white z-[1034]">
    <div class="loader-track h-[5px] w-full inline-block absolute overflow-hidden top-0">
        <div class="loader-fill w-[300px] h-[5px] bg-primary-500 absolute top-0 left-0 animate-[hitZak_0.6s_ease-in-out_infinite_alternate]"></div>
    </div>
</div>

<div class="auth-main">
    <!-- Floating decorative shapes -->
    <div class="floating-shapes" aria-hidden="true" style="position:fixed;inset:0;overflow:hidden;pointer-events:none;z-index:0;">
        <span style="width:300px;height:300px;background:rgba(255,255,255,.05);top:-50px;left:-100px;animation-delay:0s"></span>
        <span style="width:200px;height:200px;background:rgba(255,255,255,.07);bottom:50px;right:-50px;animation-delay:3s"></span>
        <span style="width:100px;height:100px;background:rgba(255,255,255,.05);top:40%;left:10%;animation-delay:1.5s"></span>
    </div>

    <div class="auth-wrapper" style="position:relative;z-index:10;">
        <div class="auth-card card">
            <!-- Logo / Brand Area -->
            <div class="auth-logo-area">
                <!-- RHU Logo Circle — replace the icon with an <img> tag once you have the logo file -->
                <div class="rhu-logo-circle" title="RHU Logo">
                    <span class="placeholder-icon"><i class="ti ti-building-hospital"></i></span>
                </div>
                <div class="prms-badge">
                    <i class="ti ti-heart-rate-monitor me-1"></i> PRMS
                </div>
                <h2>Patient Record<br>Management System</h2>
                <p>Rural Health Unit &bull; Rizal</p>
            </div>

            <!-- Form Area -->
            <div class="auth-body">
                <div class="form-group-wrap">
                    <h5 class="fw-bold mb-1" style="color:#1e3a5f;">Welcome Back</h5>
                    <p class="text-muted mb-4" style="font-size:.9rem;">Sign in to your account to continue</p>

                    <?php if ($error): ?>
                        <div class="error-alert mb-3 d-flex align-items-center gap-2">
                            <i class="ti ti-alert-circle"></i> <?= htmlspecialchars($error) ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="">
                        <div class="mb-3">
                            <label class="label-text">Username or Email</label>
                            <div class="input-group">
                                <span class="input-group-text icon-prefix">
                                    <i class="ti ti-user" style="color:#0d6efd;"></i>
                                </span>
                                <input type="text" class="form-control field-with-icon" name="username"
                                       placeholder="Enter username or email"
                                       value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
                            </div>
                        </div>
                        <div class="mb-4">
                            <label class="label-text">Password</label>
                            <div class="input-group">
                                <span class="input-group-text icon-prefix">
                                    <i class="ti ti-lock" style="color:#0d6efd;"></i>
                                </span>
                                <input type="password" class="form-control" name="password" id="passwordField"
                                       placeholder="Enter password" required
                                       style="border-left:none;border-right:none;border-radius:0!important;">
                                <span class="input-group-text" onclick="togglePassword()" title="Show/Hide">
                                    <i class="ti ti-eye" id="eyeIcon"></i>
                                </span>
                            </div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <div class="form-check mb-0">
                                <input class="form-check-input" type="checkbox" id="rememberMe">
                                <label class="form-check-label text-muted" for="rememberMe" style="font-size:.88rem;">Remember me</label>
                            </div>
                        </div>
                        <!-- Sign In button — full width and centered -->
                        <div class="d-flex justify-content-center">
                            <button type="submit" class="btn-login">
                                <i class="ti ti-login me-2"></i>Sign In
                            </button>
                        </div>
                    </form>
                </div>

                <div class="divider-text"><span>Don't have an account?</span></div>

                <div class="d-flex justify-content-center">
                    <a href="<?= BASE_URL ?>/register.php" class="btn btn-outline-primary"
                       style="border-radius:8px;padding:10px 40px;font-weight:600;">
                        <i class="ti ti-user-plus me-2"></i>Create Account
                    </a>
                </div>
            </div>
        </div>
        <p class="text-center text-white mt-3" style="font-size:.8rem;opacity:.7;">
            &copy; <?= date('Y') ?> PRMS &bull; Rural Health Unit, Rizal &bull; All rights reserved
        </p>
    </div>
</div>

<script src="<?= ASSETS_URL ?>/js/plugins/popper.min.js"></script>
<script src="<?= ASSETS_URL ?>/js/plugins/feather.min.js"></script>
<script src="<?= ASSETS_URL ?>/js/component.js"></script>
<script src="<?= ASSETS_URL ?>/js/theme.js"></script>
<script src="<?= ASSETS_URL ?>/js/script.js"></script>
<script>
function togglePassword() {
    const field = document.getElementById('passwordField');
    const icon  = document.getElementById('eyeIcon');
    if (field.type === 'password') { field.type = 'text';     icon.className = 'ti ti-eye-off'; }
    else                           { field.type = 'password'; icon.className = 'ti ti-eye'; }
}
preset_change('preset-1');
main_layout_change('vertical');
</script>
</body>
</html>
