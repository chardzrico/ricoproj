<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();

$conn = getDBConnection();
$msg = '';
$uid = getCurrentUser()['id'];

// ── Update an appointment's status (approve / schedule / reject / complete) ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id            = (int)($_POST['id'] ?? 0);
    $status        = $_POST['status'] ?? 'pending';
    $scheduledDate = !empty($_POST['scheduled_date']) ? $_POST['scheduled_date'] : null;
    $scheduledTime = !empty($_POST['scheduled_time']) ? $_POST['scheduled_time'] : null;
    $staffNotes    = trim($_POST['staff_notes'] ?? '');
    $validStatuses = ['pending', 'approved', 'rejected', 'completed', 'cancelled'];

    if ($id > 0 && in_array($status, $validStatuses, true)) {
        $stmt = $conn->prepare("UPDATE appointments SET status=?, scheduled_date=?, scheduled_time=?, staff_notes=?, handled_by=? WHERE id=?");
        $stmt->bind_param('ssssii', $status, $scheduledDate, $scheduledTime, $staffNotes, $uid, $id);
        $stmt->execute();
        $stmt->close();
    }
    header('Location: ' . BASE_URL . '/modules/appointments/list.php?msg=updated');
    exit;
}

// ── Fetch appointments (with patient + service info) ────────────────────────
$appointments = [];
$r = $conn->query("
    SELECT a.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no, p.contact_number,
           s.service_name, u.full_name as handled_by_name
    FROM appointments a
    JOIN patients p ON p.id = a.patient_id
    LEFT JOIN services s ON s.id = a.service_id
    LEFT JOIN users u ON u.id = a.handled_by
    ORDER BY FIELD(a.status,'pending','approved','completed','rejected','cancelled'), a.preferred_date ASC
");
while ($row = $r->fetch_assoc()) $appointments[] = $row;

$pendingCount = 0;
foreach ($appointments as $a) if ($a['status'] === 'pending') $pendingCount++;

$conn->close();

if (isset($_GET['msg']) && $_GET['msg'] === 'updated') $msg = 'Appointment updated.';

$pageTitle = 'Appointments';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';

$statusBadge = [
    'pending'   => 'bg-warning text-dark',
    'approved'  => 'bg-success',
    'rejected'  => 'bg-danger',
    'completed' => 'bg-primary',
    'cancelled' => 'bg-secondary',
];
?>

<!-- ══ Breadcrumb ══ -->
<div class="page-header">
    <div class="page-block">
        <div class="row align-items-center">
            <div class="col-md-12">
                <h5 class="m-b-10">Appointments</h5>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li>
                    <li class="breadcrumb-item active">Appointments</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php if ($msg): ?>
<div class="alert alert-success alert-dismissible fade show d-flex align-items-center gap-2" role="alert">
    <i class="ti ti-circle-check fs-5"></i><span><?= htmlspecialchars($msg) ?></span>
    <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<!-- ══ Stat Cards ══ -->
<div class="row g-3 mb-4">
    <?php
    $counts = ['pending'=>0,'approved'=>0,'completed'=>0,'rejected'=>0];
    foreach ($appointments as $a) if (isset($counts[$a['status']])) $counts[$a['status']]++;
    $cards = [
        ['icon'=>'ti-clock',        'color'=>'#e65100','bg'=>'#fff3e0','value'=>$counts['pending'],  'label'=>'Pending Review'],
        ['icon'=>'ti-circle-check', 'color'=>'#2e7d32','bg'=>'#e8f5e9','value'=>$counts['approved'], 'label'=>'Approved / Scheduled'],
        ['icon'=>'ti-clipboard-check','color'=>'#1565c0','bg'=>'#e3f2fd','value'=>$counts['completed'],'label'=>'Completed'],
        ['icon'=>'ti-x',            'color'=>'#c62828','bg'=>'#fce4ec','value'=>$counts['rejected'], 'label'=>'Rejected'],
    ];
    foreach ($cards as $c):
    ?>
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card h-100">
            <div class="card-body d-flex align-items-center gap-3 py-3">
                <div class="stat-icon" style="background:<?= $c['bg'] ?>;flex-shrink:0;">
                    <i class="ti <?= $c['icon'] ?>" style="color:<?= $c['color'] ?>;font-size:1.45rem;"></i>
                </div>
                <div>
                    <div class="fw-bold" style="font-size:1.9rem;color:<?= $c['color'] ?>;line-height:1.1;"><?= $c['value'] ?></div>
                    <div class="text-muted" style="font-size:.82rem;"><?= $c['label'] ?></div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- ══ Appointments Table ══ -->
<div class="card">
    <div class="card-header">
        <h6 class="section-title mb-0">
            <i class="ti ti-calendar-event me-2" style="color:#0d6efd;"></i>Appointment Requests
            <?php if ($pendingCount > 0): ?><span class="badge bg-warning text-dark ms-1"><?= $pendingCount ?> pending</span><?php endif; ?>
        </h6>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0">
                <thead>
                    <tr>
                        <th>Patient</th>
                        <th>Category / Service</th>
                        <th>Preferred</th>
                        <th>Reason</th>
                        <th>Status</th>
                        <th>Scheduled</th>
                        <th>Handled By</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($appointments as $a): ?>
                    <tr>
                        <td>
                            <div class="fw-semibold" style="font-size:.88rem;"><?= htmlspecialchars($a['patient_name']) ?></div>
                            <div class="text-muted" style="font-size:.78rem;"><?= htmlspecialchars($a['patient_no']) ?> <?= $a['contact_number'] ? '&bull; ' . htmlspecialchars($a['contact_number']) : '' ?></div>
                        </td>
                        <td>
                            <span class="badge bg-info bg-opacity-15 text-info"><?= htmlspecialchars($a['category']) ?></span>
                            <?php if ($a['service_name']): ?><div class="text-muted" style="font-size:.78rem;margin-top:2px;"><?= htmlspecialchars($a['service_name']) ?></div><?php endif; ?>
                        </td>
                        <td>
                            <?= date('M d, Y', strtotime($a['preferred_date'])) ?>
                            <?php if ($a['preferred_time']): ?><br><small class="text-muted"><?= date('h:i A', strtotime($a['preferred_time'])) ?></small><?php endif; ?>
                        </td>
                        <td style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= htmlspecialchars($a['reason'] ?: '') ?>"><?= htmlspecialchars($a['reason'] ?: '—') ?></td>
                        <td><span class="badge <?= $statusBadge[$a['status']] ?? 'bg-secondary' ?>"><?= ucfirst($a['status']) ?></span></td>
                        <td>
                            <?= $a['scheduled_date'] ? date('M d, Y', strtotime($a['scheduled_date'])) . ($a['scheduled_time'] ? '<br><small class="text-muted">' . date('h:i A', strtotime($a['scheduled_time'])) . '</small>' : '') : '—' ?>
                        </td>
                        <td><?= htmlspecialchars($a['handled_by_name'] ?: '—') ?></td>
                        <td>
                            <button class="btn btn-sm btn-outline-primary" onclick="openActionModal(<?= htmlspecialchars(json_encode($a)) ?>)">
                                <i class="ti ti-edit"></i> Manage
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($appointments)): ?>
                    <tr><td colspan="8" class="text-center text-muted py-4">No appointment requests yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ══════════════════════════ MANAGE APPOINTMENT MODAL ══════════════════════════ -->
<div class="modal fade" id="apptModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="apptModalTitle"><i class="ti ti-calendar-event me-2"></i>Manage Appointment</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <input type="hidden" name="id" id="aId">
                <div class="modal-body">
                    <div class="mb-3 p-2" style="background:#f8f9fa;border-radius:8px;font-size:.85rem;">
                        <div id="aPatientLine" class="fw-semibold"></div>
                        <div id="aRequestLine" class="text-muted"></div>
                        <div id="aReasonLine" class="text-muted mt-1"></div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Status <span class="text-danger">*</span></label>
                        <select class="form-select" name="status" id="aStatus" required onchange="toggleScheduleFields()">
                            <option value="pending">Pending</option>
                            <option value="approved">Approved / Scheduled</option>
                            <option value="rejected">Rejected</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>
                    <div class="row g-3 mb-3" id="aScheduleFields">
                        <div class="col-md-6">
                            <label class="form-label">Scheduled Date</label>
                            <input type="date" class="form-control" name="scheduled_date" id="aSchedDate">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Scheduled Time</label>
                            <input type="time" class="form-control" name="scheduled_time" id="aSchedTime">
                        </div>
                    </div>
                    <div class="mb-1">
                        <label class="form-label">Staff Notes</label>
                        <textarea class="form-control" name="staff_notes" id="aStaffNotes" rows="2" placeholder="Visible to the patient, e.g. instructions or reason for rejection"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$extraJS = '
<script>
function toggleScheduleFields() {
    const status = document.getElementById("aStatus").value;
    document.getElementById("aScheduleFields").style.display = (status === "approved" || status === "completed") ? "" : "none";
}
function openActionModal(a) {
    document.getElementById("aId").value = a.id;
    document.getElementById("aPatientLine").textContent = a.patient_name + " (" + a.patient_no + ")";
    document.getElementById("aRequestLine").textContent = a.category + (a.service_name ? " — " + a.service_name : "") + " • Preferred: " + a.preferred_date + (a.preferred_time ? " " + a.preferred_time : "");
    document.getElementById("aReasonLine").textContent = a.reason ? ("Reason: " + a.reason) : "";
    document.getElementById("aStatus").value = a.status;
    document.getElementById("aSchedDate").value = a.scheduled_date || "";
    document.getElementById("aSchedTime").value = a.scheduled_time || "";
    document.getElementById("aStaffNotes").value = a.staff_notes || "";
    toggleScheduleFields();
    new bootstrap.Modal(document.getElementById("apptModal")).show();
}
</script>';
include __DIR__ . '/../../includes/layout_footer.php';
?>
