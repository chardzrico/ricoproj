<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();

$conn = getDBConnection();
$msg = '';

if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $conn->query("DELETE FROM checkups WHERE id=".(int)$_GET['delete']);
    header('Location: consultation_notes.php?msg=deleted'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id         = (int)($_POST['id'] ?? 0);
    $patient_id = (int)$_POST['patient_id'];
    $date       = $_POST['checkup_date'] ?? date('Y-m-d');
    $notes      = trim($_POST['consultation_notes'] ?? '');
    $diagnosis  = trim($_POST['diagnosis'] ?? '');
    $treatment  = trim($_POST['treatment_plan'] ?? '');
    $followup   = $_POST['follow_up_date'] ?: null;
    $status     = $_POST['status'] ?? 'completed';
    $staff_id   = getCurrentUser()['id'];

    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE checkups SET patient_id=?,checkup_date=?,consultation_notes=?,diagnosis=?,treatment_plan=?,follow_up_date=?,status=?,attending_staff=? WHERE id=?");
        $stmt->bind_param('isssssisi', $patient_id,$date,$notes,$diagnosis,$treatment,$followup,$status,$staff_id,$id);
    } else {
        $stmt = $conn->prepare("INSERT INTO checkups (patient_id,checkup_date,consultation_notes,diagnosis,treatment_plan,follow_up_date,status,attending_staff) VALUES (?,?,?,?,?,?,?,?)");
        $stmt->bind_param('issssssi', $patient_id,$date,$notes,$diagnosis,$treatment,$followup,$status,$staff_id);
    }
    $stmt->execute();
    header('Location: consultation_notes.php?msg=' . ($id > 0 ? 'updated' : 'added')); exit;
}

$patients = [];
$r = $conn->query("SELECT id, patient_no, CONCAT(first_name,' ',last_name) as name FROM patients WHERE status='active' ORDER BY last_name");
while ($row = $r->fetch_assoc()) $patients[] = $row;

$records = [];
$r = $conn->query("SELECT c.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no, u.full_name as staff_name FROM checkups c LEFT JOIN patients p ON c.patient_id=p.id LEFT JOIN users u ON c.attending_staff=u.id WHERE c.consultation_notes IS NOT NULL AND c.consultation_notes != '' ORDER BY c.checkup_date DESC LIMIT 100");
while ($row = $r->fetch_assoc()) $records[] = $row;
$conn->close();

if (isset($_GET['msg'])) { $msg = ['added'=>'Consultation saved.','updated'=>'Updated.','deleted'=>'Deleted.'][$_GET['msg']] ?? ''; }
$pageTitle = 'Consultation Notes';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<div class="page-header"><div class="page-block">
    <h5 class="m-b-10">Consultation Notes</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Checkups</li><li class="breadcrumb-item active">Consultation Notes</li></ul>
</div></div>

<?php if ($msg): ?><div class="alert alert-success alert-dismissible fade show"><i class="ti ti-circle-check me-2"></i><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0"><i class="ti ti-notes me-2" style="color:#0d6efd;"></i>Consultation Notes</h6>
        <button class="btn btn-primary btn-sm" onclick="openAddModal()">
            <i class="ti ti-plus me-1"></i>New Consultation
        </button>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0">
                <thead><tr><th>Patient</th><th>Date</th><th>Diagnosis</th><th>Treatment Plan</th><th>Follow-up</th><th>Status</th><th>Staff</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php foreach ($records as $rec): ?>
                    <tr>
                        <td>
                            <div class="fw-semibold" style="font-size:.88rem;"><?= htmlspecialchars($rec['patient_name']) ?></div>
                            <div class="text-muted" style="font-size:.78rem;"><?= htmlspecialchars($rec['patient_no']) ?></div>
                        </td>
                        <td><?= date('M d, Y', strtotime($rec['checkup_date'])) ?></td>
                        <td style="max-width:160px;"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= htmlspecialchars($rec['diagnosis']) ?>"><?= htmlspecialchars($rec['diagnosis'] ?: '—') ?></div></td>
                        <td style="max-width:160px;"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= htmlspecialchars($rec['treatment_plan']) ?>"><?= htmlspecialchars($rec['treatment_plan'] ?: '—') ?></div></td>
                        <td><?= $rec['follow_up_date'] ? date('M d, Y', strtotime($rec['follow_up_date'])) : '—' ?></td>
                        <td><span class="badge <?= $rec['status']==='completed' ? 'bg-success' : ($rec['status']==='pending' ? 'bg-warning text-dark' : 'bg-secondary') ?>"><?= ucfirst($rec['status']) ?></span></td>
                        <td><?= htmlspecialchars($rec['staff_name'] ?: '—') ?></td>
                        <td>
                            <button class="btn-edit btn btn-sm me-1" onclick="openEditModal(<?= htmlspecialchars(json_encode($rec)) ?>)"><i class="ti ti-edit"></i></button>
                            <button class="btn-delete btn btn-sm" onclick="confirmDelete('consultation_notes.php?delete=<?= $rec['id'] ?>','this record')"><i class="ti ti-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="consModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="consModalTitle"><i class="ti ti-notes me-2"></i>New Consultation</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="id" id="consId" value="0">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Patient *</label>
                            <select class="form-select" name="patient_id" id="cPatient" required>
                                <option value="">Select Patient</option>
                                <?php foreach ($patients as $p): ?><option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['patient_no'].' - '.$p['name']) ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3"><label class="form-label">Date *</label><input type="date" class="form-control" name="checkup_date" id="cDate" value="<?= date('Y-m-d') ?>" required></div>
                        <div class="col-md-3">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="status" id="cStatus">
                                <option value="completed">Completed</option>
                                <option value="pending">Pending</option>
                                <option value="cancelled">Cancelled</option>
                            </select>
                        </div>
                        <div class="col-12"><label class="form-label">Consultation Notes *</label><textarea class="form-control" name="consultation_notes" id="cNotes" rows="3" placeholder="Detailed consultation notes..." required></textarea></div>
                        <div class="col-12"><label class="form-label">Diagnosis</label><textarea class="form-control" name="diagnosis" id="cDiagnosis" rows="2" placeholder="Diagnosis / Assessment"></textarea></div>
                        <div class="col-12"><label class="form-label">Treatment Plan</label><textarea class="form-control" name="treatment_plan" id="cTreatment" rows="2" placeholder="Treatment plan / Instructions"></textarea></div>
                        <div class="col-md-4"><label class="form-label">Follow-up Date</label><input type="date" class="form-control" name="follow_up_date" id="cFollowup"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php
$extraJS = '<script>
function openAddModal(){
    document.getElementById("consModalTitle").innerHTML=\'<i class="ti ti-notes me-2"></i>New Consultation\';
    document.getElementById("consId").value="0";
    document.getElementById("cPatient").value="";
    ["cNotes","cDiagnosis","cTreatment","cFollowup"].forEach(id=>document.getElementById(id).value="");
    document.getElementById("cDate").value="'.date('Y-m-d').'";
    document.getElementById("cStatus").value="completed";

    new bootstrap.Modal(document.getElementById("consModal")).show();
}
function openEditModal(r){
    document.getElementById("consModalTitle").innerHTML=\'<i class="ti ti-edit me-2"></i>Edit Consultation\';
    document.getElementById("consId").value=r.id;
    document.getElementById("cPatient").value=r.patient_id;
    document.getElementById("cDate").value=r.checkup_date||"";
    document.getElementById("cNotes").value=r.consultation_notes||"";
    document.getElementById("cDiagnosis").value=r.diagnosis||"";
    document.getElementById("cTreatment").value=r.treatment_plan||"";
    document.getElementById("cFollowup").value=r.follow_up_date||"";
    document.getElementById("cStatus").value=r.status||"completed";
    new bootstrap.Modal(document.getElementById("consModal")).show();
}
</script>';
include __DIR__ . '/../../includes/layout_footer.php';
?>
