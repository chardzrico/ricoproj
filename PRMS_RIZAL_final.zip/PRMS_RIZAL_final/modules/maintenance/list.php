<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();
$conn = getDBConnection();
$msg = '';

if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $conn->query("UPDATE maintenance_records SET status='closed' WHERE id=".(int)$_GET['delete']);
    header('Location: list.php?msg=closed'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id     = (int)($_POST['id'] ?? 0);
    $pid    = (int)$_POST['patient_id'];
    $type   = trim($_POST['maintenance_type'] ?? '');
    $last   = $_POST['last_visit'] ?: null;
    $next   = $_POST['next_visit'] ?: null;
    $meds   = trim($_POST['current_medications'] ?? '');
    $labs   = trim($_POST['lab_results'] ?? '');
    $notes  = trim($_POST['notes'] ?? '');
    $status = $_POST['status'] ?? 'active';
    $uid    = getCurrentUser()['id'];

    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE maintenance_records SET patient_id=?,maintenance_type=?,last_visit=?,next_visit=?,current_medications=?,lab_results=?,notes=?,status=?,managed_by=? WHERE id=?");
        $stmt->bind_param('isssssssii',$pid,$type,$last,$next,$meds,$labs,$notes,$status,$uid,$id);
    } else {
        $stmt = $conn->prepare("INSERT INTO maintenance_records (patient_id,maintenance_type,last_visit,next_visit,current_medications,lab_results,notes,status,managed_by) VALUES (?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param('isssssssi',$pid,$type,$last,$next,$meds,$labs,$notes,$status,$uid);
    }
    $stmt->execute();
    header('Location: list.php?msg=' . ($id>0?'updated':'added')); exit;
}

$patients = [];
$r = $conn->query("SELECT id, patient_no, CONCAT(first_name,' ',last_name) as name FROM patients WHERE status='active' ORDER BY last_name");
while ($row = $r->fetch_assoc()) $patients[] = $row;

$records = [];
$r = $conn->query("SELECT mr.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no, u.full_name as staff_name FROM maintenance_records mr LEFT JOIN patients p ON mr.patient_id=p.id LEFT JOIN users u ON mr.managed_by=u.id WHERE mr.status='active' ORDER BY mr.next_visit ASC, mr.updated_at DESC LIMIT 100");
while ($row = $r->fetch_assoc()) $records[] = $row;
$conn->close();

if (isset($_GET['msg'])) { $msg = ['added'=>'Record added.','updated'=>'Updated.','closed'=>'Record closed.'][$_GET['msg']] ?? ''; }
$pageTitle = 'Maintenance Records';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<div class="page-header"><div class="page-block">
    <h5 class="m-b-10">Patient Maintenance</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Maintenance</li><li class="breadcrumb-item active">Records</li></ul>
</div></div>
<?php if ($msg): ?><div class="alert alert-success alert-dismissible fade show"><i class="ti ti-circle-check me-2"></i><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0"><i class="ti ti-refresh me-2" style="color:#0d6efd;"></i>Active Maintenance Records</h6>
        <button class="btn btn-primary btn-sm" onclick="openAddModal()"><i class="ti ti-plus me-1"></i>Add Record</button>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0">
                <thead><tr><th>Patient</th><th>Condition/Type</th><th>Current Medications</th><th>Last Visit</th><th>Next Visit</th><th>Lab Results</th><th>Managed By</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php foreach ($records as $rec):
                        $nextDate = $rec['next_visit'] ? new DateTime($rec['next_visit']) : null;
                        $today = new DateTime();
                        $overdue = $nextDate && $nextDate < $today;
                    ?>
                    <tr>
                        <td><div class="fw-semibold" style="font-size:.88rem;"><?= htmlspecialchars($rec['patient_name']) ?></div><div class="text-muted" style="font-size:.78rem;"><?= htmlspecialchars($rec['patient_no']) ?></div></td>
                        <td><span class="badge bg-primary bg-opacity-10 text-primary"><?= htmlspecialchars($rec['maintenance_type'] ?: '—') ?></span></td>
                        <td style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= htmlspecialchars($rec['current_medications']) ?>"><?= htmlspecialchars($rec['current_medications'] ?: '—') ?></td>
                        <td><?= $rec['last_visit'] ? date('M d, Y', strtotime($rec['last_visit'])) : '—' ?></td>
                        <td class="<?= $overdue ? 'text-danger fw-bold' : '' ?>"><?= $nextDate ? date('M d, Y', $nextDate->getTimestamp()) . ($overdue ? ' <span class="badge bg-danger">Overdue</span>' : '') : '—' ?></td>
                        <td style="max-width:130px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= htmlspecialchars($rec['lab_results'] ?: '—') ?></td>
                        <td><?= htmlspecialchars($rec['staff_name'] ?: '—') ?></td>
                        <td>
                            <button class="btn-edit btn btn-sm me-1" onclick="openEditModal(<?= htmlspecialchars(json_encode($rec)) ?>)"><i class="ti ti-edit"></i></button>
                            <button class="btn-delete btn btn-sm" onclick="confirmDelete('list.php?delete=<?= $rec['id'] ?>','this record')"><i class="ti ti-x"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($records)): ?><tr><td colspan="8" class="text-center text-muted py-4">No active maintenance records.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="mxModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="mxModalTitle"><i class="ti ti-refresh me-2"></i>Add Maintenance Record</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="id" id="mxId" value="0">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6"><label class="form-label">Patient *</label><select class="form-select" name="patient_id" id="mxPatient" required><option value="">Select Patient</option><?php foreach ($patients as $p): ?><option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['patient_no'].' - '.$p['name']) ?></option><?php endforeach; ?></select></div>
                        <div class="col-md-6">
                            <label class="form-label">Condition/Type *</label>
                            <input type="text" class="form-control" name="maintenance_type" id="mxType" required placeholder="e.g. Hypertension, Diabetes">
                        </div>
                        <div class="col-md-3"><label class="form-label">Last Visit</label><input type="date" class="form-control" name="last_visit" id="mxLast"></div>
                        <div class="col-md-3"><label class="form-label">Next Visit</label><input type="date" class="form-control" name="next_visit" id="mxNext"></div>
                        <div class="col-md-3"><label class="form-label">Status</label><select class="form-select" name="status" id="mxStatus"><option value="active">Active</option><option value="closed">Closed</option></select></div>
                        <div class="col-12"><label class="form-label">Current Medications</label><textarea class="form-control" name="current_medications" id="mxMeds" rows="2" placeholder="List current medications"></textarea></div>
                        <div class="col-12"><label class="form-label">Lab Results</label><textarea class="form-control" name="lab_results" id="mxLabs" rows="2" placeholder="Recent lab results/values"></textarea></div>
                        <div class="col-12"><label class="form-label">Notes</label><textarea class="form-control" name="notes" id="mxNotes" rows="2" placeholder="Additional notes"></textarea></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php
$extraJS='<script>
function openAddModal(){
    document.getElementById("mxModalTitle").innerHTML=\'<i class="ti ti-refresh me-2"></i>Add Maintenance Record\';
    document.getElementById("mxId").value="0";
    document.getElementById("mxPatient").value="";
    document.getElementById("mxType").value="";
    ["mxLast","mxNext","mxMeds","mxLabs","mxNotes"].forEach(id=>document.getElementById(id).value="");
    document.getElementById("mxStatus").value="active";

    new bootstrap.Modal(document.getElementById("mxModal")).show();
}
function openEditModal(r){
    document.getElementById("mxModalTitle").innerHTML=\'<i class="ti ti-edit me-2"></i>Edit Maintenance Record\';
    document.getElementById("mxId").value=r.id;
    document.getElementById("mxPatient").value=r.patient_id;
    document.getElementById("mxType").value=r.maintenance_type||"";
    document.getElementById("mxLast").value=r.last_visit||"";
    document.getElementById("mxNext").value=r.next_visit||"";
    document.getElementById("mxMeds").value=r.current_medications||"";
    document.getElementById("mxLabs").value=r.lab_results||"";
    document.getElementById("mxNotes").value=r.notes||"";
    document.getElementById("mxStatus").value=r.status||"active";
    new bootstrap.Modal(document.getElementById("mxModal")).show();
}
</script>';
include __DIR__ . '/../../includes/layout_footer.php';
?>
