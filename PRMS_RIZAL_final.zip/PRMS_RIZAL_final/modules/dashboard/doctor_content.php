<?php
// ── Doctor Dashboard: today's consultations / checkups queue ───────────────
// Expects: $conn (open mysqli connection) from dashboard.php

$stats = [];
$queries = [
    'checkups_today'  => "SELECT COUNT(*) as cnt FROM checkups WHERE checkup_date = CURDATE()",
    'pending_today'   => "SELECT COUNT(*) as cnt FROM checkups WHERE checkup_date = CURDATE() AND status = 'pending'",
    'completed_today' => "SELECT COUNT(*) as cnt FROM checkups WHERE checkup_date = CURDATE() AND status = 'completed'",
    'prescriptions'   => "SELECT COUNT(*) as cnt FROM prescriptions WHERE prescription_date = CURDATE()",
];
foreach ($queries as $key => $sql) {
    $r = $conn->query($sql);
    $stats[$key] = $r ? (int)$r->fetch_assoc()['cnt'] : 0;
}

// ── Today's consultation queue ───────────────────────────────────────────
$consultQueue = [];
$r = $conn->query("
    SELECT c.id, c.checkup_time, c.chief_complaint, c.status,
           CONCAT(p.first_name,' ',p.last_name) as name, p.patient_no
    FROM checkups c
    JOIN patients p ON p.id = c.patient_id
    WHERE c.checkup_date = CURDATE()
    ORDER BY (c.status = 'pending') DESC, c.checkup_time ASC
    LIMIT 12
");
while ($row = $r->fetch_assoc()) $consultQueue[] = $row;
?>

<!-- ══ Stat Cards ══ -->
<div class="row g-3 mb-4">
    <?php
    $cards = [
        ['icon'=>'ti-clipboard-list','color'=>'#1565c0','bg'=>'#e3f2fd','value'=>$stats['checkups_today'], 'label'=>"Today's Consultations"],
        ['icon'=>'ti-clock',         'color'=>'#e65100','bg'=>'#fff3e0','value'=>$stats['pending_today'],  'label'=>'Pending'],
        ['icon'=>'ti-circle-check',  'color'=>'#2e7d32','bg'=>'#e8f5e9','value'=>$stats['completed_today'],'label'=>'Completed Today'],
        ['icon'=>'ti-prescription',  'color'=>'#c62828','bg'=>'#fce4ec','value'=>$stats['prescriptions'],  'label'=>'Prescriptions Today'],
    ];
    foreach ($cards as $c):
    ?>
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card h-100">
            <div class="card-body d-flex align-items-center gap-3 py-3">
                <div class="stat-icon" style="background:<?= $c['bg'] ?>;flex-shrink:0;">
                    <i class="ti <?= $c['icon'] ?>" style="color:<?= $c['color'] ?>;font-size:1.45rem;"></i>
                </div>
                <div>
                    <div class="fw-bold" style="font-size:1.9rem;color:<?= $c['color'] ?>;line-height:1.1;"><?= $c['value'] ?></div>
                    <div class="text-muted" style="font-size:.82rem;"><?= $c['label'] ?></div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- ══ Quick Actions ══ -->
<div class="row g-3 mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-body d-flex flex-wrap gap-2">
                <a href="<?= BASE_URL ?>/modules/checkups/consultation_notes.php" class="btn btn-primary btn-sm">
                    <i class="ti ti-notes me-1"></i>Consultation Notes
                </a>
                <a href="<?= BASE_URL ?>/modules/checkups/patient_history.php" class="btn btn-outline-primary btn-sm">
                    <i class="ti ti-history me-1"></i>Patient History
                </a>
                <a href="<?= BASE_URL ?>/modules/medicine/prescription_log.php" class="btn btn-outline-secondary btn-sm">
                    <i class="ti ti-prescription me-1"></i>Prescription Log
                </a>
            </div>
        </div>
    </div>
</div>

<!-- ══ Today's Consultation Queue ══ -->
<div class="row g-3">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h6 class="section-title mb-0">
                    <i class="ti ti-clipboard-list me-2" style="color:#0d6efd;"></i>Today's Consultation Queue
                </h6>
                <a href="<?= BASE_URL ?>/modules/checkups/consultation_notes.php" class="btn btn-sm btn-outline-primary">Open Full List</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0" style="font-size:.88rem;">
                        <thead>
                            <tr>
                                <th>Time</th>
                                <th>Patient</th>
                                <th>Chief Complaint</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($consultQueue)): ?>
                            <tr><td colspan="4" class="text-center text-muted py-4">No consultations scheduled for today.</td></tr>
                            <?php else: foreach ($consultQueue as $c): ?>
                            <tr>
                                <td><?= $c['checkup_time'] ? date('h:i A', strtotime($c['checkup_time'])) : '—' ?></td>
                                <td class="fw-semibold"><?= htmlspecialchars($c['name']) ?> <span class="text-muted" style="font-size:.78rem;">(<?= htmlspecialchars($c['patient_no']) ?>)</span></td>
                                <td><?= htmlspecialchars($c['chief_complaint'] ?: '—') ?></td>
                                <td>
                                    <?php
                                    $statusBadge = ['pending'=>'bg-warning text-dark','completed'=>'bg-success','cancelled'=>'bg-secondary'][$c['status']] ?? 'bg-secondary';
                                    ?>
                                    <span class="badge <?= $statusBadge ?>"><?= ucfirst($c['status']) ?></span>
                                </td>
                            </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
