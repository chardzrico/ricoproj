<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();
$conn = getDBConnection();

// Handle Add Growth Record POST (same logic as growth_recording.php)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id      = (int)($_POST['id'] ?? 0);
    $pid     = (int)$_POST['patient_id'];
    $date    = $_POST['record_date'] ?? date('Y-m-d');
    $age     = (int)($_POST['age_months'] ?? 0);
    $weight  = (float)($_POST['weight'] ?? 0);
    $height  = (float)($_POST['height'] ?? 0);
    $bmi     = $height > 0 ? round($weight/(($height/100)*($height/100)),2) : null;
    $wfa     = trim($_POST['weight_for_age'] ?? '');
    $hfa     = trim($_POST['height_for_age'] ?? '');
    $wfh     = trim($_POST['weight_for_height'] ?? '');
    $status  = trim($_POST['nutritional_status'] ?? '');
    $remarks = trim($_POST['remarks'] ?? '');
    $uid     = getCurrentUser()['id'];
    $backMonth = substr($date, 0, 7);
    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE nutritional_records SET patient_id=?,record_date=?,age_months=?,weight=?,height=?,bmi=?,weight_for_age=?,height_for_age=?,weight_for_height=?,nutritional_status=?,remarks=?,recorded_by=? WHERE id=?");
        $stmt->bind_param('isiiddsssssi i',$pid,$date,$age,$weight,$height,$bmi,$wfa,$hfa,$wfh,$status,$remarks,$uid,$id);
    } else {
        $stmt = $conn->prepare("INSERT INTO nutritional_records (patient_id,record_date,age_months,weight,height,bmi,weight_for_age,height_for_age,weight_for_height,nutritional_status,remarks,recorded_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param('isiiddsssss i',$pid,$date,$age,$weight,$height,$bmi,$wfa,$hfa,$wfh,$status,$remarks,$uid);
    }
    $stmt->execute();
    header("Location: monthly_tracking.php?month=$backMonth&msg=saved"); exit;
}

$month = $_GET['month'] ?? date('Y-m');
$year  = substr($month, 0, 4);
$mon   = substr($month, 5, 2);

$records = [];
$r = $conn->query("SELECT nr.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_no, p.date_of_birth FROM nutritional_records nr LEFT JOIN patients p ON nr.patient_id=p.id WHERE YEAR(nr.record_date)=$year AND MONTH(nr.record_date)=$mon ORDER BY nr.record_date, p.last_name");
while ($row = $r->fetch_assoc()) $records[] = $row;

// Patients for modal
$patients = [];
$r2 = $conn->query("SELECT id, patient_no, CONCAT(first_name,' ',last_name) as name, date_of_birth FROM patients WHERE status='active' ORDER BY last_name");
while ($row = $r2->fetch_assoc()) $patients[] = $row;

// Summary counts
$summary = ['Normal'=>0,'At Risk'=>0,'Mild Undernutrition'=>0,'Moderate Undernutrition'=>0,'Severe Undernutrition'=>0,'Overweight'=>0,'Obese'=>0,'Other'=>0];
foreach ($records as $rec) {
    $ns = $rec['nutritional_status'] ?? '';
    if (isset($summary[$ns])) $summary[$ns]++; else $summary['Other']++;
}
$conn->close();

$pageTitle = 'Monthly Tracking';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
$msg = isset($_GET['msg']) && $_GET['msg']==='saved' ? 'Growth record saved successfully!' : '';
?>
<div class="page-header"><div class="page-block">
    <h5 class="m-b-10">Monthly Nutritional Tracking</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Nutritional Status</li><li class="breadcrumb-item active">Monthly Tracking</li></ul>
</div></div>

<?php if ($msg): ?><div class="alert alert-success alert-dismissible fade show"><i class="ti ti-circle-check me-2"></i><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

<!-- Month Filter -->
<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" class="d-flex gap-3 align-items-end">
            <div>
                <label class="form-label fw-bold mb-1" style="font-size:.83rem;">Select Month</label>
                <input type="month" class="form-control form-control-sm" name="month" value="<?= $month ?>" onchange="this.form.submit()">
            </div>
            <div class="fw-semibold align-self-center" style="color:#1e3a5f;font-size:1rem;">
                <?= date('F Y', mktime(0,0,0,$mon,1,$year)) ?> — <?= count($records) ?> record(s)
            </div>
        </form>
    </div>
</div>

<!-- Summary Cards -->
<div class="row g-2 mb-3">
    <?php
    $colors = ['Normal'=>['#e8f5e9','#2e7d32'],'At Risk'=>['#fff3e0','#e65100'],'Mild Undernutrition'=>['#fff8e1','#f57f17'],'Moderate Undernutrition'=>['#fce4ec','#c62828'],'Severe Undernutrition'=>['#ffebee','#b71c1c'],'Overweight'=>['#e3f2fd','#1565c0'],'Obese'=>['#f3e5f5','#6a1b9a'],'Other'=>['#f5f5f5','#616161']];
    foreach ($summary as $label => $count): if ($count === 0) continue;
    $c = $colors[$label] ?? ['#f5f5f5','#616161']; ?>
    <div class="col-md-3 col-6">
        <div class="card" style="border-left:3px solid <?= $c[1] ?>;">
            <div class="card-body py-2 px-3">
                <div class="fw-bold" style="font-size:1.4rem;color:<?= $c[1] ?>;"><?= $count ?></div>
                <div class="text-muted" style="font-size:.78rem;"><?= $label ?></div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Chart + Table -->
<div class="row g-3">
    <div class="col-md-4">
        <div class="card h-100">
            <div class="card-header"><h6 class="section-title mb-0"><i class="ti ti-chart-pie me-2" style="color:#0d6efd;"></i>Distribution</h6></div>
            <div class="card-body">
                <canvas id="nutriChart" style="max-height:250px;"></canvas>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h6 class="section-title mb-0"><i class="ti ti-calendar-stats me-2" style="color:#0d6efd;"></i><?= date('F Y', mktime(0,0,0,$mon,1,$year)) ?> Records</h6>
                <button class="btn btn-sm btn-primary" onclick="openAddModal()"><i class="ti ti-plus me-1"></i>Add Record</button>
            </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table prms-datatable mb-0">
                        <thead><tr><th>Patient</th><th>Age (mos)</th><th>Weight</th><th>Height</th><th>BMI</th><th>Status</th><th>Date</th></tr></thead>
                        <tbody>
                            <?php foreach ($records as $rec):
                                $ns = $rec['nutritional_status'] ?? '';
                                $c2 = $colors[$ns] ?? ['#f5f5f5','#616161'];
                            ?>
                            <tr>
                                <td><div class="fw-semibold" style="font-size:.88rem;"><?= htmlspecialchars($rec['patient_name']) ?></div><div class="text-muted" style="font-size:.78rem;"><?= htmlspecialchars($rec['patient_no']) ?></div></td>
                                <td><?= $rec['age_months'] ? $rec['age_months'].' mos' : '—' ?></td>
                                <td><?= $rec['weight'] ? $rec['weight'].' kg' : '—' ?></td>
                                <td><?= $rec['height'] ? $rec['height'].' cm' : '—' ?></td>
                                <td><?= $rec['bmi'] ?: '—' ?></td>
                                <td><?= $ns ? '<span class="badge" style="background:'.$c2[0].';color:'.$c2[1].';">'.htmlspecialchars($ns).'</span>' : '—' ?></td>
                                <td><?= date('M d', strtotime($rec['record_date'])) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ══ ADD GROWTH RECORD MODAL ══ -->
<div class="modal fade" id="growthModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="growthModalTitle"><i class="ti ti-trending-up me-2"></i>Add Growth Record</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <input type="hidden" name="id" id="growthId" value="0">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Patient *</label>
                            <select class="form-select" name="patient_id" id="gPatient" required>
                                <option value="">Select Patient</option>
                                <?php foreach ($patients as $p): ?><option value="<?= $p['id'] ?>" data-dob="<?= $p['date_of_birth'] ?>"><?= htmlspecialchars($p['patient_no'].' - '.$p['name']) ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3"><label class="form-label">Date *</label><input type="date" class="form-control" name="record_date" id="gDate" value="<?= date('Y-m-d') ?>" required onchange="calcAge()"></div>
                        <div class="col-md-3"><label class="form-label">Age (months)</label><input type="number" class="form-control" name="age_months" id="gAge" min="0" placeholder="Auto-calc"></div>
                        <div class="col-md-3"><label class="form-label">Weight (kg) *</label><input type="number" step="0.1" class="form-control" name="weight" id="gWeight" required placeholder="0.0" oninput="calcBMI()"></div>
                        <div class="col-md-3"><label class="form-label">Height (cm) *</label><input type="number" step="0.1" class="form-control" name="height" id="gHeight" required placeholder="0" oninput="calcBMI()"></div>
                        <div class="col-md-3"><label class="form-label">BMI</label><input type="text" class="form-control bg-light" id="gBMIDisplay" readonly placeholder="Auto-calc"></div>
                        <div class="col-md-4">
                            <label class="form-label">Weight for Age</label>
                            <select class="form-select" name="weight_for_age" id="gWFA"><option value="">Select</option><option>Normal</option><option>Underweight</option><option>Severely Underweight</option><option>Overweight</option></select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Height for Age</label>
                            <select class="form-select" name="height_for_age" id="gHFA"><option value="">Select</option><option>Normal</option><option>Stunted</option><option>Severely Stunted</option><option>Tall</option></select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Weight for Height</label>
                            <select class="form-select" name="weight_for_height" id="gWFH"><option value="">Select</option><option>Normal</option><option>Wasted</option><option>Severely Wasted</option><option>Obese</option></select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Nutritional Status</label>
                            <select class="form-select" name="nutritional_status" id="gStatus"><option value="">Select</option><option>Normal</option><option>At Risk</option><option>Mild Undernutrition</option><option>Moderate Undernutrition</option><option>Severe Undernutrition</option><option>Overweight</option><option>Obese</option></select>
                        </div>
                        <div class="col-12"><label class="form-label">Remarks</label><textarea class="form-control" name="remarks" id="gRemarks" rows="2" placeholder="Additional notes or observations"></textarea></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$chartData   = array_values(array_filter($summary));
$chartColors = array_map(fn($l) => ($colors[$l] ?? ['#ccc','#999'])[1], $chartLabels);
$patientOptions = '';
foreach ($patients as $p) {
    $patientOptions .= '<option value="'.$p['id'].'" data-dob="'.htmlspecialchars($p['date_of_birth']).'">'.htmlspecialchars($p['patient_no'].' - '.$p['name']).'</option>';
}
$extraJS='<script>
const ctx=document.getElementById("nutriChart").getContext("2d");
new Chart(ctx,{
    type:"doughnut",
    data:{
        labels:'.json_encode($chartLabels).',
        datasets:[{data:'.json_encode($chartData).',backgroundColor:'.json_encode($chartColors).',borderWidth:2,borderColor:"#fff"}]
    },
    options:{responsive:true,cutout:"60%",plugins:{legend:{position:"bottom",labels:{font:{size:11}}}}}
});
function calcBMI(){
    const w=parseFloat(document.getElementById("gWeight").value)||0;
    const h=parseFloat(document.getElementById("gHeight").value)||0;
    if(w>0&&h>0){ document.getElementById("gBMIDisplay").value=(w/((h/100)*(h/100))).toFixed(2); }
}
function calcAge(){
    const sel=document.getElementById("gPatient");
    const opt=sel.options[sel.selectedIndex];
    const dob=opt?opt.getAttribute("data-dob"):null;
    const recDate=document.getElementById("gDate").value;
    if(dob&&recDate){
        const d1=new Date(dob),d2=new Date(recDate);
        const months=(d2.getFullYear()-d1.getFullYear())*12+(d2.getMonth()-d1.getMonth());
        document.getElementById("gAge").value=months>0?months:0;
    }
}
function openAddModal(){
    document.getElementById("growthModalTitle").innerHTML=\'<i class="ti ti-trending-up me-2"></i>Add Growth Record\';
    document.getElementById("growthId").value="0";
    document.getElementById("gPatient").value="";
    ["gAge","gWeight","gHeight","gRemarks","gBMIDisplay"].forEach(id=>document.getElementById(id).value="");
    ["gWFA","gHFA","gWFH","gStatus"].forEach(id=>document.getElementById(id).value="");
    document.getElementById("gDate").value="'.date('Y-m-d').'";

    new bootstrap.Modal(document.getElementById("growthModal")).show();
}
document.getElementById("gPatient").addEventListener("change",calcAge);
</script>';
include __DIR__ . '/../../includes/layout_footer.php';
?>
