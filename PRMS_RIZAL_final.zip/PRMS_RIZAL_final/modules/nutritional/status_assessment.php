<?php
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/database.php';
requireLogin();
requireStaffOnly();
$conn = getDBConnection();

$patient_id = (int)($_GET['patient_id'] ?? 0);
$patients = [];
$r = $conn->query("SELECT id, patient_no, CONCAT(first_name,' ',last_name) as name FROM patients WHERE status='active' ORDER BY last_name");
while ($row = $r->fetch_assoc()) $patients[] = $row;

$history = [];
$patient  = null;
if ($patient_id > 0) {
    $r = $conn->query("SELECT id, patient_no, CONCAT(first_name,' ',last_name) as name, date_of_birth, gender FROM patients WHERE id=$patient_id LIMIT 1");
    $patient = $r->fetch_assoc();
    $r = $conn->query("SELECT * FROM nutritional_records WHERE patient_id=$patient_id ORDER BY record_date ASC");
    while ($row = $r->fetch_assoc()) $history[] = $row;
}
$conn->close();

$pageTitle = 'Status Assessment';
include __DIR__ . '/../../includes/layout_header.php';
include __DIR__ . '/../../includes/topbar.php';
?>
<div class="page-header"><div class="page-block">
    <h5 class="m-b-10">Nutritional Status Assessment</h5>
    <ul class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li><li class="breadcrumb-item">Nutritional Status</li><li class="breadcrumb-item active">Status Assessment</li></ul>
</div></div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET">
            <div class="row g-3">
                <div class="col-md-5">
                    <label class="form-label fw-bold">Select Patient</label>
                    <select class="form-select" name="patient_id" onchange="this.form.submit()">
                        <option value="">— Choose a patient —</option>
                        <?php foreach ($patients as $p): ?><option value="<?= $p['id'] ?>" <?= $patient_id==$p['id']?'selected':'' ?>><?= htmlspecialchars($p['patient_no'].' - '.$p['name']) ?></option><?php endforeach; ?>
                    </select>
                </div>
            </div>
        </form>
    </div>
</div>

<?php if ($patient && !empty($history)): 
    $latest = end($history);
    $ns = $latest['nutritional_status'] ?? '';
    $colors = ['Normal'=>['#e8f5e9','#2e7d32'],'At Risk'=>['#fff3e0','#e65100'],'Mild Undernutrition'=>['#fff8e1','#f57f17'],'Moderate Undernutrition'=>['#fce4ec','#c62828'],'Severe Undernutrition'=>['#ffebee','#b71c1c'],'Overweight'=>['#e3f2fd','#1565c0'],'Obese'=>['#f3e5f5','#6a1b9a']];
    $sc = $colors[$ns] ?? ['#f5f5f5','#616161'];
?>
<div class="row g-3">
    <div class="col-md-4">
        <div class="card" style="border-top:4px solid <?= $sc[1] ?>;">
            <div class="card-body text-center py-4">
                <div style="width:70px;height:70px;background:<?= $sc[0] ?>;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 16px;">
                    <i class="ti ti-chart-bar" style="font-size:2rem;color:<?= $sc[1] ?>;"></i>
                </div>
                <div class="fw-bold" style="font-size:1.1rem;"><?= htmlspecialchars($patient['name']) ?></div>
                <div class="text-muted mb-3" style="font-size:.85rem;"><?= htmlspecialchars($patient['patient_no']) ?></div>
                <div style="background:<?= $sc[0] ?>;border-radius:8px;padding:12px;">
                    <div class="text-muted" style="font-size:.78rem;">CURRENT STATUS</div>
                    <div class="fw-bold" style="color:<?= $sc[1] ?>;font-size:1.1rem;"><?= htmlspecialchars($ns ?: 'Not Set') ?></div>
                </div>
                <div class="row g-2 mt-2">
                    <div class="col-6"><div class="card" style="background:#f8f9fa;"><div class="card-body py-2 px-2 text-center"><div class="fw-bold" style="font-size:1.2rem;"><?= $latest['weight'] ?> kg</div><div class="text-muted" style="font-size:.72rem;">Weight</div></div></div></div>
                    <div class="col-6"><div class="card" style="background:#f8f9fa;"><div class="card-body py-2 px-2 text-center"><div class="fw-bold" style="font-size:1.2rem;"><?= $latest['height'] ?> cm</div><div class="text-muted" style="font-size:.72rem;">Height</div></div></div></div>
                    <div class="col-6"><div class="card" style="background:#f8f9fa;"><div class="card-body py-2 px-2 text-center"><div class="fw-bold" style="font-size:1.2rem;"><?= $latest['bmi'] ?: '—' ?></div><div class="text-muted" style="font-size:.72rem;">BMI</div></div></div></div>
                    <div class="col-6"><div class="card" style="background:#f8f9fa;"><div class="card-body py-2 px-2 text-center"><div class="fw-bold" style="font-size:1.2rem;"><?= $latest['age_months'] ?: '—' ?></div><div class="text-muted" style="font-size:.72rem;">Age (mos)</div></div></div></div>
                </div>
                <div class="mt-3 text-muted" style="font-size:.78rem;">Last recorded: <?= date('M d, Y', strtotime($latest['record_date'])) ?></div>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <!-- Weight & Height trend chart -->
        <div class="card mb-3">
            <div class="card-header"><h6 class="section-title mb-0"><i class="ti ti-chart-line me-2" style="color:#0d6efd;"></i>Growth Trend</h6></div>
            <div class="card-body"><canvas id="growthChart" height="120"></canvas></div>
        </div>
        <!-- History table -->
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h6 class="section-title mb-0"><i class="ti ti-history me-2" style="color:#0d6efd;"></i>Assessment History</h6>
                <a href="growth_recording.php" class="btn btn-sm btn-primary"><i class="ti ti-plus me-1"></i>Add Record</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0" style="font-size:.85rem;">
                        <thead><tr><th>Date</th><th>Age</th><th>Weight</th><th>Height</th><th>BMI</th><th>Status</th></tr></thead>
                        <tbody>
                            <?php foreach (array_reverse($history) as $h):
                                $sc2 = $colors[$h['nutritional_status'] ?? ''] ?? ['#f5f5f5','#616161'];
                            ?>
                            <tr>
                                <td><?= date('M d, Y', strtotime($h['record_date'])) ?></td>
                                <td><?= $h['age_months'] ? $h['age_months'].' mos' : '—' ?></td>
                                <td><?= $h['weight'] ? $h['weight'].' kg' : '—' ?></td>
                                <td><?= $h['height'] ? $h['height'].' cm' : '—' ?></td>
                                <td><?= $h['bmi'] ?: '—' ?></td>
                                <td><?= $h['nutritional_status'] ? '<span class="badge" style="background:'.$sc2[0].';color:'.$sc2[1].';">'.htmlspecialchars($h['nutritional_status']).'</span>' : '—' ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
$dates   = array_column($history, 'record_date');
$weights = array_column($history, 'weight');
$heights = array_column($history, 'height');
$extraJS='<script>
const gCtx=document.getElementById("growthChart").getContext("2d");
new Chart(gCtx,{
    type:"line",
    data:{
        labels:'.json_encode(array_map(fn($d)=>date('M d', strtotime($d)),$dates)).',
        datasets:[
            {label:"Weight (kg)",data:'.json_encode($weights).',borderColor:"#0d6efd",backgroundColor:"rgba(13,110,253,.1)",borderWidth:2,tension:.4,fill:true},
            {label:"Height (cm)",data:'.json_encode($heights).',borderColor:"#2e7d32",backgroundColor:"rgba(46,125,50,.07)",borderWidth:2,tension:.4,fill:false,yAxisID:"y2"}
        ]
    },
    options:{responsive:true,interaction:{mode:"index"},scales:{y:{beginAtZero:false,title:{display:true,text:"Weight (kg)"}},y2:{beginAtZero:false,position:"right",title:{display:true,text:"Height (cm)"},grid:{drawOnChartArea:false}}},plugins:{legend:{position:"top"}}}
});
</script>';
elseif ($patient && empty($history)): ?>
<div class="card"><div class="card-body text-center py-5 text-muted"><i class="ti ti-trending-up" style="font-size:3rem;opacity:.3;"></i><div class="mt-2">No growth records found for this patient.</div><a href="growth_recording.php" class="btn btn-primary btn-sm mt-3"><i class="ti ti-plus me-1"></i>Add First Record</a></div></div>
<?php else: ?>
<div class="card"><div class="card-body text-center py-5 text-muted"><i class="ti ti-user-search" style="font-size:3rem;opacity:.4;"></i><div class="mt-2">Select a patient to view their status assessment.</div></div></div>
<?php endif;
include __DIR__ . '/../../includes/layout_footer.php'; ?>
