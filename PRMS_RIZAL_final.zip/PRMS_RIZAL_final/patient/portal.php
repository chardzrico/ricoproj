<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/auth.php';
requirePatientOnly();

$conn = getDBConnection();
$currentUser = getCurrentUser();

// ── Load this patient's record ──────────────────────────────────────────────
$stmt = $conn->prepare("SELECT * FROM patients WHERE user_id = ? LIMIT 1");
$stmt->bind_param('i', $currentUser['id']);
$stmt->execute();
$patient = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$patient) {
    // Safety net: a patient-role account somehow has no linked patient record.
    $conn->close();
    $pageTitle = 'My Dashboard';
    include __DIR__ . '/includes/patient_header.php';
    include __DIR__ . '/../includes/topbar.php';
    echo '<div class="alert alert-danger">We could not find a patient record linked to your account. Please contact RHU staff for assistance.</div>';
    include __DIR__ . '/../includes/layout_footer.php';
    exit;
}

$patientId = (int)$patient['id'];

// ── Stats ────────────────────────────────────────────────────────────────
$stats = ['pending' => 0, 'approved' => 0, 'completed' => 0];
$r = $conn->prepare("SELECT status, COUNT(*) as cnt FROM appointments WHERE patient_id = ? GROUP BY status");
$r->bind_param('i', $patientId);
$r->execute();
$res = $r->get_result();
while ($row = $res->fetch_assoc()) {
    $stats[$row['status']] = (int)$row['cnt'];
}
$r->close();

// ── Upcoming / recent appointments ──────────────────────────────────────────
$appointments = [];
$stmt = $conn->prepare("
    SELECT a.*, s.service_name
    FROM appointments a
    LEFT JOIN services s ON s.id = a.service_id
    WHERE a.patient_id = ?
    ORDER BY a.created_at DESC
    LIMIT 5
");
$stmt->bind_param('i', $patientId);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $appointments[] = $row;
$stmt->close();
$conn->close();

$pageTitle = 'My Dashboard';
include __DIR__ . '/includes/patient_header.php';
include __DIR__ . '/../includes/topbar.php';

$statusBadge = [
    'pending'   => 'bg-warning text-dark',
    'approved'  => 'bg-success',
    'rejected'  => 'bg-danger',
    'completed' => 'bg-primary',
    'cancelled' => 'bg-secondary',
];
?>

<!-- ══ Breadcrumb ══ -->
<div class="page-header">
    <div class="page-block">
        <div class="row align-items-center">
            <div class="col-md-12">
                <h5 class="m-b-10">My Dashboard</h5>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/patient/portal.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- ══ Welcome / Patient Info ══ -->
<div class="card mb-4">
    <div class="card-body d-flex flex-wrap align-items-center justify-content-between gap-3">
        <div>
            <h5 class="fw-bold mb-1" style="color:#1e3a5f;">
                Welcome, <?= htmlspecialchars($patient['first_name']) ?>!
            </h5>
            <p class="text-muted mb-0" style="font-size:.88rem;">
                Patient No: <span class="fw-semibold"><?= htmlspecialchars($patient['patient_no']) ?></span>
            </p>
        </div>
        <a href="<?= BASE_URL ?>/patient/appointments.php?action=request" class="btn btn-primary">
            <i class="ti ti-calendar-plus me-1"></i>Request an Appointment
        </a>
    </div>
</div>

<!-- ══ Stat Cards ══ -->
<div class="row g-3 mb-4">
    <?php
    $cards = [
        ['icon'=>'ti-clock',        'color'=>'#e65100','bg'=>'#fff3e0','value'=>$stats['pending'],   'label'=>'Pending Requests'],
        ['icon'=>'ti-circle-check', 'color'=>'#2e7d32','bg'=>'#e8f5e9','value'=>$stats['approved'],  'label'=>'Approved / Scheduled'],
        ['icon'=>'ti-clipboard-check','color'=>'#1565c0','bg'=>'#e3f2fd','value'=>$stats['completed'],'label'=>'Completed Visits'],
    ];
    foreach ($cards as $c):
    ?>
    <div class="col-xl-4 col-md-6">
        <div class="card stat-card h-100">
            <div class="card-body d-flex align-items-center gap-3 py-3">
                <div class="stat-icon" style="background:<?= $c['bg'] ?>;flex-shrink:0;">
                    <i class="ti <?= $c['icon'] ?>" style="color:<?= $c['color'] ?>;font-size:1.45rem;"></i>
                </div>
                <div>
                    <div class="fw-bold" style="font-size:1.9rem;color:<?= $c['color'] ?>;line-height:1.1;"><?= $c['value'] ?></div>
                    <div class="text-muted" style="font-size:.82rem;"><?= $c['label'] ?></div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- ══ Recent Appointments ══ -->
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="section-title mb-0">
            <i class="ti ti-calendar-event me-2" style="color:#0d6efd;"></i>Recent Appointment Requests
        </h6>
        <a href="<?= BASE_URL ?>/patient/appointments.php" class="btn btn-sm btn-outline-primary">View All</a>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0" style="font-size:.88rem;">
                <thead>
                    <tr>
                        <th>Category</th>
                        <th>Service</th>
                        <th>Preferred Date</th>
                        <th>Status</th>
                        <th>Scheduled</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($appointments)): ?>
                    <tr><td colspan="5" class="text-center text-muted py-4">You have no appointment requests yet.</td></tr>
                    <?php else: foreach ($appointments as $a): ?>
                    <tr>
                        <td><?= htmlspecialchars($a['category']) ?></td>
                        <td><?= htmlspecialchars($a['service_name'] ?: '—') ?></td>
                        <td><?= date('M d, Y', strtotime($a['preferred_date'])) ?></td>
                        <td><span class="badge <?= $statusBadge[$a['status']] ?? 'bg-secondary' ?>"><?= ucfirst($a['status']) ?></span></td>
                        <td>
                            <?= $a['scheduled_date'] ? date('M d, Y', strtotime($a['scheduled_date'])) . ($a['scheduled_time'] ? ' ' . date('h:i A', strtotime($a['scheduled_time'])) : '') : '—' ?>
                        </td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../includes/layout_footer.php'; ?>
