<?php
require_once __DIR__ . '/config/session.php';
require_once __DIR__ . '/config/database.php';
requireLogin();
requireStaffOnly();

$conn = getDBConnection();
$msg  = '';

// ── DELETE ────────────────────────────────────────────────────────────────
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("UPDATE patients SET status='inactive' WHERE id=$id");
    header('Location: ' . BASE_URL . '/patients.php?msg=deleted');
    exit;
}

// ── ADD / EDIT ─────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id          = (int)($_POST['id'] ?? 0);
    $first_name  = trim($_POST['first_name']  ?? '');
    $last_name   = trim($_POST['last_name']   ?? '');
    $middle_name = trim($_POST['middle_name'] ?? '');
    $dob         = $_POST['date_of_birth'] ?? '';
    $gender      = $_POST['gender']      ?? '';
    $address     = trim($_POST['address'] ?? '');
    $contact     = trim($_POST['contact_number']  ?? '');
    $guardian    = trim($_POST['guardian_name']    ?? '');
    $gcontact    = trim($_POST['guardian_contact'] ?? '');
    $blood_type  = $_POST['blood_type'] ?? '';
    $religion    = trim($_POST['religion']  ?? '');
    $civil_stat  = trim($_POST['civil_status'] ?? '');
    $occupation  = trim($_POST['occupation']   ?? '');

    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE patients SET first_name=?,last_name=?,middle_name=?,date_of_birth=?,gender=?,address=?,contact_number=?,guardian_name=?,guardian_contact=?,blood_type=?,religion=?,civil_status=?,occupation=? WHERE id=?");
        $stmt->bind_param('sssssssssssssi',
            $first_name,$last_name,$middle_name,$dob,$gender,
            $address,$contact,$guardian,$gcontact,$blood_type,
            $religion,$civil_stat,$occupation,$id);
        $stmt->execute();
        header('Location: ' . BASE_URL . '/patients.php?msg=updated');
    } else {
        $r   = $conn->query("SELECT COUNT(*) as cnt FROM patients");
        $cnt = (int)$r->fetch_assoc()['cnt'] + 1;
        $patient_no = 'RHU-' . date('Y') . '-' . str_pad($cnt, 5, '0', STR_PAD_LEFT);
        $stmt = $conn->prepare("INSERT INTO patients (patient_no,first_name,last_name,middle_name,date_of_birth,gender,address,contact_number,guardian_name,guardian_contact,blood_type,religion,civil_status,occupation) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param('ssssssssssssss',
            $patient_no,$first_name,$last_name,$middle_name,$dob,$gender,
            $address,$contact,$guardian,$gcontact,$blood_type,
            $religion,$civil_stat,$occupation);
        $stmt->execute();
        header('Location: ' . BASE_URL . '/patients.php?msg=added');
    }
    exit;
}

// ── FETCH ─────────────────────────────────────────────────────────────────
$patients = [];
$r = $conn->query("SELECT * FROM patients WHERE status='active' ORDER BY created_at DESC");
while ($row = $r->fetch_assoc()) $patients[] = $row;
$conn->close();

if (isset($_GET['msg'])) {
    $msgs = ['added'=>'Patient registered successfully!','updated'=>'Patient updated successfully!','deleted'=>'Patient record deactivated.'];
    $msg  = $msgs[$_GET['msg']] ?? '';
}
$pageTitle = 'Patients';
include __DIR__ . '/includes/layout_header.php';
include __DIR__ . '/includes/topbar.php';
?>

<!-- ══ Breadcrumb ══ -->
<div class="page-header">
    <div class="page-block">
        <div class="row align-items-center">
            <div class="col-md-12">
                <h5 class="m-b-10">Patients</h5>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard.php">Home</a></li>
                    <li class="breadcrumb-item active">Patients</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php if ($msg): ?>
<div class="alert alert-success alert-dismissible fade show d-flex align-items-center gap-2" role="alert">
    <i class="ti ti-circle-check fs-5"></i><span><?= htmlspecialchars($msg) ?></span>
    <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<!-- ══ Patients Table Card ══ -->
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h6 class="section-title mb-0">
            <i class="ti ti-users me-2" style="color:#0d6efd;"></i>Patient List
        </h6>
        <button class="btn btn-primary btn-sm" onclick="openAddModal()">
            <i class="ti ti-user-plus me-1"></i>Register Patient
        </button>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table prms-datatable mb-0" id="patientTable" style="width:100%">
                <thead>
                    <tr>
                        <th>Patient No.</th>
                        <th>Name</th>
                        <th>Gender</th>
                        <th>Date of Birth</th>
                        <th>Contact</th>
                        <th>Blood Type</th>
                        <th>Registered</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($patients as $p): ?>
                    <tr>
                        <td>
                            <span class="badge bg-primary bg-opacity-10 text-primary fw-semibold">
                                <?= htmlspecialchars($p['patient_no']) ?>
                            </span>
                        </td>
                        <td class="fw-semibold">
                            <?= htmlspecialchars($p['last_name'] . ', ' . $p['first_name'] . ($p['middle_name'] ? ' ' . $p['middle_name'][0] . '.' : '')) ?>
                        </td>
                        <td><?= htmlspecialchars($p['gender']) ?></td>
                        <td><?= date('M d, Y', strtotime($p['date_of_birth'])) ?></td>
                        <td><?= htmlspecialchars($p['contact_number'] ?: '—') ?></td>
                        <td><?= htmlspecialchars($p['blood_type'] ?: '—') ?></td>
                        <td><?= date('M d, Y', strtotime($p['created_at'])) ?></td>
                        <td>
                            <button class="btn-edit btn btn-sm me-1"
                                    onclick="openEditModal(<?= htmlspecialchars(json_encode($p)) ?>)"
                                    title="Edit">
                                <i class="ti ti-edit"></i>
                            </button>
                            <button class="btn-delete btn btn-sm"
                                    onclick="confirmDelete('<?= BASE_URL ?>/patients.php?delete=<?= $p['id'] ?>', '<?= htmlspecialchars(addslashes($p['first_name'] . ' ' . $p['last_name'])) ?>')"
                                    title="Delete">
                                <i class="ti ti-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ══════════════════════════ REGISTER PATIENT MODAL ══════════════════════════ -->
<div class="modal fade" id="patientModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="patientModalTitle">
                    <i class="ti ti-user-plus me-2"></i>Register New Patient
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <input type="hidden" name="id" id="patientId" value="0">
                <div class="modal-body">

                    <!-- Section: Personal Information -->
                    <div class="mb-3">
                        <div class="d-flex align-items-center mb-3">
                            <div style="width:28px;height:28px;border-radius:50%;background:#e3f2fd;display:flex;align-items:center;justify-content:center;margin-right:10px;">
                                <i class="ti ti-user" style="color:#0d6efd;font-size:.9rem;"></i>
                            </div>
                            <h6 class="mb-0 fw-bold" style="color:#1e3a5f;">Personal Information</h6>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">First Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="first_name" id="pFirstName" required placeholder="First name">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Last Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="last_name" id="pLastName" required placeholder="Last name">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Middle Name</label>
                                <input type="text" class="form-control" name="middle_name" id="pMiddleName" placeholder="Middle name">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Date of Birth <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" name="date_of_birth" id="pDOB" required onchange="computeAge()">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Age</label>
                                <input type="text" class="form-control bg-light" id="pAgeDisplay" readonly placeholder="Auto">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Gender <span class="text-danger">*</span></label>
                                <select class="form-select" name="gender" id="pGender" required>
                                    <option value="">Select Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Blood Type</label>
                                <select class="form-select" name="blood_type" id="pBloodType">
                                    <option value="">Unknown</option>
                                    <?php foreach (['A+','A-','B+','B-','AB+','AB-','O+','O-'] as $bt): ?>
                                    <option value="<?= $bt ?>"><?= $bt ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Civil Status</label>
                                <select class="form-select" name="civil_status" id="pCivilStatus">
                                    <option value="">N/A</option>
                                    <option>Single</option><option>Married</option>
                                    <option>Widowed</option><option>Separated</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Religion</label>
                                <input type="text" class="form-control" name="religion" id="pReligion" placeholder="Religion (optional)">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Occupation</label>
                                <input type="text" class="form-control" name="occupation" id="pOccupation" placeholder="Occupation (optional)">
                            </div>
                        </div>
                    </div>

                    <hr class="my-3">

                    <!-- Section: Contact Information -->
                    <div class="mb-3">
                        <div class="d-flex align-items-center mb-3">
                            <div style="width:28px;height:28px;border-radius:50%;background:#e8f5e9;display:flex;align-items:center;justify-content:center;margin-right:10px;">
                                <i class="ti ti-phone" style="color:#2e7d32;font-size:.9rem;"></i>
                            </div>
                            <h6 class="mb-0 fw-bold" style="color:#1e3a5f;">Contact & Address</h6>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">Contact Number</label>
                                <input type="text" class="form-control" name="contact_number" id="pContact" placeholder="09XX-XXX-XXXX">
                            </div>
                            <div class="col-md-8">
                                <label class="form-label">Complete Address</label>
                                <input type="text" class="form-control" name="address" id="pAddress" placeholder="Barangay, Municipality, Province">
                            </div>
                        </div>
                    </div>

                    <hr class="my-3">

                    <!-- Section: Guardian Information -->
                    <div>
                        <div class="d-flex align-items-center mb-3">
                            <div style="width:28px;height:28px;border-radius:50%;background:#fff3e0;display:flex;align-items:center;justify-content:center;margin-right:10px;">
                                <i class="ti ti-users" style="color:#e65100;font-size:.9rem;"></i>
                            </div>
                            <h6 class="mb-0 fw-bold" style="color:#1e3a5f;">Guardian / Parent</h6>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Guardian Name</label>
                                <input type="text" class="form-control" name="guardian_name" id="pGuardian" placeholder="Parent / Guardian name">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Guardian Contact</label>
                                <input type="text" class="form-control" name="guardian_contact" id="pGContact" placeholder="Guardian contact number">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="ti ti-x me-1"></i>Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="ti ti-device-floppy me-1"></i>Save Patient
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$extraJS = '
<script>
function computeAge() {
    const dob = document.getElementById("pDOB").value;
    if (!dob) return;
    const today = new Date();
    const birth = new Date(dob);
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
    document.getElementById("pAgeDisplay").value = age >= 0 ? age + " yrs" : "";
}
function openAddModal() {
    document.getElementById("patientModalTitle").innerHTML = \'<i class="ti ti-user-plus me-2"></i>Register New Patient\';
    document.getElementById("patientId").value = "0";
    ["pFirstName","pLastName","pMiddleName","pContact","pGuardian","pGContact","pAddress","pReligion","pOccupation","pAgeDisplay"].forEach(id => document.getElementById(id).value = "");
    document.getElementById("pDOB").value = "";
    document.getElementById("pGender").value = "";
    document.getElementById("pBloodType").value = "";
    document.getElementById("pCivilStatus") && (document.getElementById("pCivilStatus").value = "");
    new bootstrap.Modal(document.getElementById("patientModal")).show();
}
function openEditModal(p) {
    document.getElementById("patientModalTitle").innerHTML = \'<i class="ti ti-edit me-2"></i>Edit Patient Record\';
    document.getElementById("patientId").value      = p.id;
    document.getElementById("pFirstName").value     = p.first_name  || "";
    document.getElementById("pLastName").value      = p.last_name   || "";
    document.getElementById("pMiddleName").value    = p.middle_name || "";
    document.getElementById("pDOB").value           = p.date_of_birth || "";
    document.getElementById("pGender").value        = p.gender      || "";
    document.getElementById("pBloodType").value     = p.blood_type  || "";
    document.getElementById("pContact").value       = p.contact_number  || "";
    document.getElementById("pGuardian").value      = p.guardian_name   || "";
    document.getElementById("pGContact").value      = p.guardian_contact|| "";
    document.getElementById("pAddress").value       = p.address || "";
    if (document.getElementById("pReligion"))    document.getElementById("pReligion").value    = p.religion    || "";
    if (document.getElementById("pOccupation"))  document.getElementById("pOccupation").value  = p.occupation  || "";
    if (document.getElementById("pCivilStatus")) document.getElementById("pCivilStatus").value = p.civil_status|| "";
    computeAge();
    new bootstrap.Modal(document.getElementById("patientModal")).show();
}
</script>';
include __DIR__ . '/includes/layout_footer.php';
?>
