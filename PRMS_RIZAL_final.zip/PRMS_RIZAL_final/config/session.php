<?php
session_start();

// Compute BASE_URL from config directory (always PRMS1/config/)
// dirname(__DIR__) = PRMS1 root, regardless of which page is being served
$_prmsRoot = str_replace('\\', '/', dirname(__DIR__));
$_docRoot  = str_replace('\\', '/', rtrim($_SERVER['DOCUMENT_ROOT'], '/'));
$_urlPath  = str_replace($_docRoot, '', $_prmsRoot);
$_scheme   = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https' : 'http';
define('BASE_URL',   $_scheme . '://' . $_SERVER['HTTP_HOST'] . $_urlPath);
define('ASSETS_URL', BASE_URL . '/assets');

function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
}

function getCurrentUser() {
    return [
        'id'        => $_SESSION['user_id'] ?? null,
        'full_name' => $_SESSION['full_name'] ?? '',
        'username'  => $_SESSION['username'] ?? '',
        'role'      => $_SESSION['role'] ?? '',
        'email'     => $_SESSION['email'] ?? '',
    ];
}

function hasRole($role) {
    return ($_SESSION['role'] ?? '') === $role;
}

function isAdmin() {
    return hasRole('admin');
}

function isPatient() {
    return hasRole('patient');
}

function isStaffRole() {
    return in_array($_SESSION['role'] ?? '', ['admin', 'doctor', 'nurse', 'staff'], true);
}

// Use on staff-only pages (clinical modules, admin, patient records list, etc.)
// Sends logged-in patients back to their own portal instead of the staff dashboard.
function requireStaffOnly() {
    requireLogin();
    if (isPatient()) {
        header('Location: ' . BASE_URL . '/patient/portal.php');
        exit;
    }
}

// Use on patient-portal pages. Sends staff back to the staff dashboard.
function requirePatientOnly() {
    requireLogin();
    if (!isPatient()) {
        header('Location: ' . BASE_URL . '/dashboard.php');
        exit;
    }
}
