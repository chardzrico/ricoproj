<?php
session_start();
require_once 'db_config.php';

requireLogin('employee', 'login_employee.php');

 $page_title = "Leave Request - DAR";

 $employee_id = $_SESSION['employee_id'];
 $employee_name = $_SESSION['employee_name'];

 $employee = $conn->query("SELECT * FROM employees WHERE id = $employee_id")->fetch_assoc();

// Handle leave request submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $leave_type = sanitize($conn, $_POST['leave_type']);
    $start_date = sanitize($conn, $_POST['start_date']);
    $end_date = sanitize($conn, $_POST['end_date']);
    $reason = sanitize($conn, $_POST['reason']);

    $days = (strtotime($end_date) - strtotime($start_date)) / (60 * 60 * 24) + 1;

    $conn->query("INSERT INTO leave_requests (employee_id, leave_type, start_date, end_date, days, reason, status, created_at) 
                  VALUES ($employee_id, '$leave_type', '$start_date', '$end_date', $days, '$reason', 'pending', NOW())");

    $_SESSION['success'] = "Leave request submitted successfully.";
    redirect('leave.php');
}

// Fetch leave requests
 $leaves = $conn->query("SELECT * FROM leave_requests WHERE employee_id = $employee_id ORDER BY created_at DESC");

// Stats
 $pending = 0; $approved = 0; $rejected = 0; $total_days_used = 0;
if ($leaves && $leaves->num_rows > 0) {
    $leaves->data_seek(0);
    while($l = $leaves->fetch_assoc()) {
        if ($l['status'] == 'pending') $pending++;
        elseif ($l['status'] == 'approved') { $approved++; $total_days_used += $l['days']; }
        elseif ($l['status'] == 'rejected') $rejected++;
    }
    $leaves->data_seek(0);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dar-green: #006400;
            --dar-dark-green: #004d00;
            --dar-light-green: #4CAF50;
            --dar-gold: #FFD700;
            --bg-light: #f8faf9;
            --sidebar-bg: #0d3b0d;
            --text-dark: #1a1a2e;
            --text-muted: #6b7280;
            --shadow: 0 4px 20px rgba(0,0,0,0.08);
            --shadow-lg: 0 10px 40px rgba(0,0,0,0.1);
            --radius: 12px;
            --transition: all 0.3s ease;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: var(--bg-light); color: var(--text-dark); }

        .dashboard { display: flex; min-height: 100vh; }

        /* ===== SIDEBAR ===== */
        .sidebar {
            width: 260px; background: var(--sidebar-bg);
            color: white; position: fixed; top: 0; left: 0; bottom: 0;
            z-index: 100; transition: var(--transition);
            display: flex; flex-direction: column;
        }
        .sidebar-header {
            padding: 25px 20px; text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            flex-shrink: 0;
        }
        .sidebar-logo {
            width: 55px; height: 55px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 800; font-size: 18px;
            margin: 0 auto 15px;
        }
        .sidebar-header h3 { font-size: 1rem; font-weight: 600; }
        .sidebar-header p { font-size: 0.75rem; opacity: 0.7; margin-top: 3px; }

        .nav-menu {
            padding: 20px 0;
            flex: 1;
            overflow-y: auto;
        }
        .nav-menu::-webkit-scrollbar { width: 4px; }
        .nav-menu::-webkit-scrollbar-track { background: transparent; }
        .nav-menu::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 4px; }
        .nav-menu::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.25); }

        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 14px 25px; color: rgba(255,255,255,0.8);
            text-decoration: none; font-size: 0.9rem; font-weight: 500;
            transition: var(--transition); border-left: 3px solid transparent;
        }
        .nav-item:hover, .nav-item.active {
            background: rgba(255,255,255,0.05);
            color: white; border-left-color: var(--dar-gold);
        }
        .nav-item i { width: 20px; text-align: center; }

        .sidebar-footer {
            padding: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
            flex-shrink: 0;
        }
        .user-info { display: flex; align-items: center; gap: 12px; }
        .user-avatar {
            width: 40px; height: 40px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 700; font-size: 0.9rem;
        }
        .user-details h4 { font-size: 0.85rem; font-weight: 600; }
        .user-details p { font-size: 0.75rem; opacity: 0.6; }
        .logout-btn {
            display: flex; align-items: center; gap: 8px;
            color: rgba(255,255,255,0.7); text-decoration: none;
            font-size: 0.8rem; margin-top: 12px; transition: var(--transition);
        }
        .logout-btn:hover { color: #ef4444; }

        /* ===== MAIN ===== */
        .main-content { flex: 1; margin-left: 260px; min-height: 100vh; }
        .top-bar {
            background: white; padding: 15px 30px;
            display: flex; justify-content: space-between; align-items: center;
            box-shadow: var(--shadow); position: sticky; top: 0; z-index: 50;
        }
        .top-bar h2 { font-size: 1.3rem; font-weight: 700; }

        .content { padding: 30px; }

        .alert {
            padding: 15px 20px; border-radius: 10px; margin-bottom: 25px;
            display: flex; align-items: center; gap: 10px; font-size: 0.95rem;
        }
        .alert-success { background: #f0fdf4; color: #16a34a; border: 1px solid #86efac; }

        /* ===== STATS ===== */
        .leave-stats {
            display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px; margin-bottom: 30px;
        }
        .leave-stat {
            background: white; border-radius: var(--radius);
            padding: 22px; box-shadow: var(--shadow);
            border: 1px solid #f0f0f0;
            display: flex; align-items: center; gap: 15px;
        }
        .leave-stat-icon {
            width: 50px; height: 50px; border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.2rem; flex-shrink: 0;
        }
        .leave-stat h4 { font-size: 1.5rem; font-weight: 800; }
        .leave-stat p { font-size: 0.8rem; color: var(--text-muted); }

        /* ===== GRID ===== */
        .leave-grid {
            display: grid; grid-template-columns: 1fr 1.5fr;
            gap: 25px;
        }
        .leave-form-card, .leave-list-card {
            background: white; border-radius: var(--radius);
            box-shadow: var(--shadow); border: 1px solid #f0f0f0;
            overflow: hidden;
        }
        .card-header {
            padding: 20px 25px; border-bottom: 1px solid #f0f0f0;
            display: flex; align-items: center; gap: 10px;
        }
        .card-header h3 { font-size: 1.05rem; font-weight: 700; color: var(--dar-green); }
        .card-body { padding: 25px; }
        .form-group { margin-bottom: 18px; }
        .form-group label {
            display: block; margin-bottom: 6px;
            font-weight: 600; font-size: 0.85rem; color: var(--text-dark);
        }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%; padding: 12px 15px;
            border: 2px solid #e5e7eb; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            transition: var(--transition); background: #fafafa;
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            outline: none; border-color: var(--dar-green);
            box-shadow: 0 0 0 4px rgba(0,100,0,0.08); background: white;
        }
        .form-group textarea { resize: vertical; min-height: 80px; }
        .date-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .btn-submit {
            width: 100%; padding: 13px;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; border: none; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.95rem;
            font-weight: 600; cursor: pointer; transition: var(--transition);
            display: flex; align-items: center; justify-content: center; gap: 8px;
        }
        .btn-submit:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,100,0,0.3); }

        /* ===== LEAVE LIST ===== */
        .leave-item {
            display: flex; align-items: flex-start; gap: 15px;
            padding: 18px 25px; border-bottom: 1px solid #f8f8f8;
            transition: var(--transition);
        }
        .leave-item:hover { background: #fafafa; }
        .leave-item:last-child { border-bottom: none; }
        .leave-type-icon {
            width: 45px; height: 45px; border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.1rem; flex-shrink: 0; margin-top: 2px;
        }
        .leave-info { flex: 1; }
        .leave-info h4 { font-size: 0.92rem; font-weight: 600; margin-bottom: 4px; }
        .leave-info p { font-size: 0.8rem; color: var(--text-muted); line-height: 1.6; }
        .leave-status {
            padding: 5px 14px; border-radius: 20px;
            font-size: 0.75rem; font-weight: 600;
            white-space: nowrap; flex-shrink: 0; margin-top: 5px;
        }
        .status-pending { background: #fefce8; color: #ca8a04; }
        .status-approved { background: #f0fdf4; color: #16a34a; }
        .status-rejected { background: #fef2f2; color: #ef4444; }
        .status-cancelled { background: #f1f5f9; color: #64748b; }

        .empty-state { text-align: center; padding: 50px 20px; }
        .empty-state i { font-size: 2.5rem; color: #ddd; margin-bottom: 15px; }
        .empty-state h4 { font-size: 1rem; margin-bottom: 5px; }
        .empty-state p { font-size: 0.85rem; color: var(--text-muted); }

        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .main-content { margin-left: 0; }
        }
        @media (max-width: 768px) {
            .leave-grid { grid-template-columns: 1fr; }
            .leave-stats { grid-template-columns: 1fr 1fr; }
            .date-row { grid-template-columns: 1fr; }
            .content { padding: 20px; }
        }
    </style>
</head>
<body>

    <div class="dashboard">
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">DAR</div>
                <h3>Employee Portal</h3>
                <p>Records Management</p>
            </div>
            <nav class="nav-menu">
                <a href="dashboard_employee.php" class="nav-item"><i class="fas fa-home"></i> Dashboard</a>
                <a href="profile.php" class="nav-item"><i class="fas fa-user"></i> My Profile</a>
                <a href="documents.php" class="nav-item"><i class="fas fa-folder-open"></i> My Documents</a>
                <a href="payslip.php" class="nav-item"><i class="fas fa-file-invoice-dollar"></i> Payslip</a>
                <a href="leave.php" class="nav-item active"><i class="fas fa-calendar-minus"></i> Leave Request</a>
                <a href="settings.php" class="nav-item"><i class="fas fa-cog"></i> Settings</a>
            </nav>
            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar"><?php echo strtoupper(substr($employee_name, 0, 1)); ?></div>
                    <div class="user-details">
                        <h4><?php echo htmlspecialchars($employee_name); ?></h4>
                        <p><?php echo htmlspecialchars($employee['position']); ?></p>
                    </div>
                </div>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </aside>

        <main class="main-content">
            <div class="top-bar">
                <h2><i class="fas fa-calendar-minus" style="margin-right: 10px; color: var(--dar-green);"></i>Leave Request</h2>
            </div>

            <div class="content">
                <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
                <?php endif; ?>

                <!-- Stats -->
                <div class="leave-stats">
                    <div class="leave-stat">
                        <div class="leave-stat-icon" style="background: #fefce8; color: #ca8a04;"><i class="fas fa-clock"></i></div>
                        <div>
                            <h4 style="color: #ca8a04;"><?php echo $pending; ?></h4>
                            <p>Pending</p>
                        </div>
                    </div>
                    <div class="leave-stat">
                        <div class="leave-stat-icon" style="background: #f0fdf4; color: #16a34a;"><i class="fas fa-check-circle"></i></div>
                        <div>
                            <h4 style="color: #16a34a;"><?php echo $approved; ?></h4>
                            <p>Approved</p>
                        </div>
                    </div>
                    <div class="leave-stat">
                        <div class="leave-stat-icon" style="background: #fef2f2; color: #ef4444;"><i class="fas fa-times-circle"></i></div>
                        <div>
                            <h4 style="color: #ef4444;"><?php echo $rejected; ?></h4>
                            <p>Rejected</p>
                        </div>
                    </div>
                    <div class="leave-stat">
                        <div class="leave-stat-icon" style="background: #eff6ff; color: #3b82f6;"><i class="fas fa-calendar-check"></i></div>
                        <div>
                            <h4 style="color: #3b82f6;"><?php echo $total_days_used; ?></h4>
                            <p>Days Used</p>
                        </div>
                    </div>
                </div>

                <!-- Form & List -->
                <div class="leave-grid">
                    <!-- Request Form -->
                    <div class="leave-form-card">
                        <div class="card-header">
                            <i class="fas fa-paper-plane" style="color: var(--dar-green);"></i>
                            <h3>New Leave Request</h3>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="">
                                <div class="form-group">
                                    <label><i class="fas fa-tag" style="margin-right: 6px; color: var(--dar-green);"></i>Leave Type</label>
                                    <select name="leave_type" required>
                                        <option value="">Select leave type</option>
                                        <option value="vacation">Vacation Leave</option>
                                        <option value="sick">Sick Leave</option>
                                        <option value="emergency">Emergency Leave</option>
                                        <option value="maternity">Maternity Leave</option>
                                        <option value="paternity">Paternity Leave</option>
                                        <option value="special">Special Leave</option>
                                        <option value="others">Others</option>
                                    </select>
                                </div>
                                <div class="date-row">
                                    <div class="form-group">
                                        <label><i class="fas fa-calendar" style="margin-right: 6px; color: var(--dar-green);"></i>Start Date</label>
                                        <input type="date" name="start_date" required>
                                    </div>
                                    <div class="form-group">
                                        <label><i class="fas fa-calendar" style="margin-right: 6px; color: var(--dar-green);"></i>End Date</label>
                                        <input type="date" name="end_date" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label><i class="fas fa-comment" style="margin-right: 6px; color: var(--dar-green);"></i>Reason</label>
                                    <textarea name="reason" placeholder="State your reason for leave..." required></textarea>
                                </div>
                                <button type="submit" class="btn-submit">
                                    <i class="fas fa-paper-plane"></i> Submit Request
                                </button>
                            </form>
                        </div>
                    </div>

                    <!-- Leave History -->
                    <div class="leave-list-card">
                        <div class="card-header">
                            <i class="fas fa-history" style="color: var(--dar-green);"></i>
                            <h3>Leave History</h3>
                        </div>
                        <div>
                            <?php if($leaves && $leaves->num_rows > 0): ?>
                                <?php 
                                $typeIcons = [
                                    'vacation' => ['fa-umbrella-beach', '#eff6ff', '#3b82f6'],
                                    'sick' => ['fa-medkit', '#fef2f2', '#ef4444'],
                                    'emergency' => ['fa-exclamation-triangle', '#fefce8', '#ca8a04'],
                                    'maternity' => ['fa-baby', '#fdf2f8', '#ec4899'],
                                    'paternity' => ['fa-baby-carriage', '#f0fdf4', '#16a34a'],
                                    'special' => ['fa-star', '#f5f3ff', '#7c3aed'],
                                    'others' => ['fa-ellipsis-h', '#f8f8f8', '#6b7280'],
                                ];
                                while($lv = $leaves->fetch_assoc()):
                                    $icon = $typeIcons[$lv['leave_type']] ?? $typeIcons['others'];
                                ?>
                                <div class="leave-item">
                                    <div class="leave-type-icon" style="background: <?php echo $icon[1]; ?>; color: <?php echo $icon[2]; ?>;">
                                        <i class="fas <?php echo $icon[0]; ?>"></i>
                                    </div>
                                    <div class="leave-info">
                                        <h4><?php echo ucfirst($lv['leave_type']); ?> Leave</h4>
                                        <p>
                                            <i class="fas fa-calendar"></i> <?php echo date('M d, Y', strtotime($lv['start_date'])); ?> — <?php echo date('M d, Y', strtotime($lv['end_date'])); ?>
                                            &nbsp;•&nbsp; <i class="fas fa-clock"></i> <?php echo $lv['days']; ?> day(s)
                                        </p>
                                        <?php if(!empty($lv['reason'])): ?>
                                        <p style="margin-top: 4px; font-style: italic;">"<?php echo htmlspecialchars(substr($lv['reason'], 0, 80)) . (strlen($lv['reason']) > 80 ? '...' : ''); ?>"</p>
                                        <?php endif; ?>
                                    </div>
                                    <span class="leave-status status-<?php echo $lv['status']; ?>">
                                        <?php echo ucfirst($lv['status']); ?>
                                    </span>
                                </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <div class="empty-state">
                                    <i class="fas fa-calendar-times"></i>
                                    <h4>No Leave Requests</h4>
                                    <p>You haven't submitted any leave requests yet.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

</body>
</html>