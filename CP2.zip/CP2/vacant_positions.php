<?php
session_start();
require_once 'db_config.php';

$page_title = "Vacant Positions - DAR";

// Fetch all open positions
$positions = $conn->query("SELECT * FROM vacant_positions WHERE status = 'open' ORDER BY date_posted DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dar-green: #006400;
            --dar-dark-green: #004d00;
            --dar-light-green: #4CAF50;
            --dar-gold: #FFD700;
            --bg-light: #f8faf9;
            --text-dark: #1a1a2e;
            --text-muted: #6b7280;
            --white: #ffffff;
            --shadow: 0 8px 30px rgba(0,0,0,0.08);
            --shadow-lg: 0 20px 50px rgba(0,0,0,0.12);
            --radius: 16px;
            --transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: var(--bg-light); color: var(--text-dark); line-height: 1.6; }

        /* Header */
        header { 
            background: linear-gradient(135deg, var(--dar-green), var(--dar-dark-green)); 
            color: white; padding: 20px 50px; 
            display: flex; justify-content: space-between; align-items: center;
            box-shadow: var(--shadow);
        }
        .logo-container { display: flex; align-items: center; gap: 15px; }
        .logo-placeholder { 
            width: 45px; height: 45px; 
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D); 
            border-radius: 50%; display: flex; align-items: center; justify-content: center; 
            color: var(--dar-green); font-weight: 800; font-size: 16px; 
        }
        .header-title h1 { font-size: 1.1rem; margin: 0; }
        .header-title p { font-size: 0.75rem; margin: 0; opacity: 0.9; }
        .back-btn {
            color: white; text-decoration: none; 
            display: flex; align-items: center; gap: 8px;
            padding: 10px 20px; border-radius: 30px;
            border: 2px solid rgba(255,255,255,0.3);
            transition: var(--transition); font-weight: 500;
        }
        .back-btn:hover { background: rgba(255,255,255,0.15); border-color: white; }

        /* Hero */
        .page-hero {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-dark-green));
            color: white; padding: 60px 20px; text-align: center;
            position: relative; overflow: hidden;
        }
        .page-hero::before {
            content: ''; position: absolute; top: 0; left: 0; right: 0; bottom: 0;
            background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
        }
        .page-hero h2 { font-size: 2.5rem; font-weight: 800; position: relative; margin-bottom: 10px; }
        .page-hero p { font-size: 1.1rem; opacity: 0.9; position: relative; max-width: 600px; margin: 0 auto; }

        /* Stats */
        .stats-bar {
            display: flex; justify-content: center; gap: 40px;
            padding: 30px; background: white;
            max-width: 800px; margin: -30px auto 40px;
            border-radius: var(--radius); box-shadow: var(--shadow);
            position: relative; z-index: 10;
        }
        .stat { text-align: center; }
        .stat h4 { font-size: 2rem; color: var(--dar-green); font-weight: 800; }
        .stat p { color: var(--text-muted); font-size: 0.85rem; }

        /* Positions Grid */
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px 60px; }
        .positions-grid {
            display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 25px;
        }
        .position-card {
            background: white; border-radius: var(--radius);
            box-shadow: var(--shadow); overflow: hidden;
            transition: var(--transition); border: 1px solid #f0f0f0;
            position: relative;
        }
        .position-card:hover {
            transform: translateY(-8px); box-shadow: var(--shadow-lg);
        }
        .position-header {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; padding: 25px 25px 20px;
            position: relative;
        }
        .position-badge {
            display: inline-block; background: rgba(255,215,0,0.2);
            color: var(--dar-gold); padding: 4px 12px;
            border-radius: 20px; font-size: 0.75rem; font-weight: 600;
            margin-bottom: 10px; border: 1px solid rgba(255,215,0,0.3);
        }
        .position-header h3 { font-size: 1.2rem; font-weight: 700; margin-bottom: 5px; }
        .position-header .dept { font-size: 0.85rem; opacity: 0.9; }
        .position-body { padding: 25px; }
        .detail-row {
            display: flex; justify-content: space-between;
            padding: 10px 0; border-bottom: 1px solid #f0f0f0;
            font-size: 0.9rem;
        }
        .detail-row:last-child { border-bottom: none; }
        .detail-row span:first-child { color: var(--text-muted); }
        .detail-row span:last-child { font-weight: 600; color: var(--text-dark); }
        .salary-highlight {
            color: var(--dar-green) !important; font-size: 1.1rem !important;
        }
        .qualifications {
            margin: 15px 0; padding: 15px;
            background: #f8faf9; border-radius: 10px;
            border-left: 4px solid var(--dar-green);
        }
        .qualifications h4 { font-size: 0.9rem; color: var(--dar-green); margin-bottom: 8px; }
        .qualifications p { font-size: 0.85rem; color: var(--text-muted); line-height: 1.6; }
        .position-footer {
            padding: 0 25px 25px;
            display: flex; gap: 10px;
        }
        .btn-apply {
            flex: 1; background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; text-decoration: none; padding: 12px 20px;
            border-radius: 10px; text-align: center; font-weight: 600;
            transition: var(--transition); border: none; cursor: pointer;
            display: flex; align-items: center; justify-content: center; gap: 8px;
        }
        .btn-apply:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0,100,0,0.3);
        }
        .btn-details {
            padding: 12px 20px; border: 2px solid #e5e7eb;
            background: white; color: var(--text-dark);
            border-radius: 10px; font-weight: 600;
            cursor: pointer; transition: var(--transition);
        }
        .btn-details:hover { border-color: var(--dar-green); color: var(--dar-green); }

        /* Modal */
        .modal-overlay {
            display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.6); z-index: 1000;
            justify-content: center; align-items: center;
            padding: 20px; backdrop-filter: blur(5px);
        }
        .modal-overlay.active { display: flex; }
        .modal {
            background: white; border-radius: var(--radius);
            max-width: 600px; width: 100%; max-height: 90vh;
            overflow-y: auto; box-shadow: var(--shadow-lg);
            animation: modalIn 0.3s ease;
        }
        @keyframes modalIn {
            from { opacity: 0; transform: scale(0.9) translateY(20px); }
            to { opacity: 1; transform: scale(1) translateY(0); }
        }
        .modal-header {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; padding: 25px; position: relative;
        }
        .modal-header h3 { font-size: 1.3rem; font-weight: 700; }
        .modal-close {
            position: absolute; top: 15px; right: 20px;
            background: none; border: none; color: white;
            font-size: 1.5rem; cursor: pointer; opacity: 0.8;
            transition: var(--transition);
        }
        .modal-close:hover { opacity: 1; transform: rotate(90deg); }
        .modal-body { padding: 25px; }
        .modal-section { margin-bottom: 20px; }
        .modal-section h4 {
            color: var(--dar-green); font-size: 1rem;
            margin-bottom: 10px; display: flex; align-items: center; gap: 8px;
        }
        .modal-section p, .modal-section ul {
            color: var(--text-muted); font-size: 0.9rem; line-height: 1.7;
        }
        .modal-section ul { padding-left: 20px; }
        .modal-section ul li { margin-bottom: 5px; }
        .modal-footer {
            padding: 20px 25px; border-top: 1px solid #f0f0f0;
            display: flex; justify-content: flex-end; gap: 10px;
        }
        .modal-footer .btn-apply { flex: none; padding: 12px 30px; }

        /* Empty State */
        .empty-state {
            text-align: center; padding: 80px 20px;
        }
        .empty-state i { font-size: 4rem; color: #e5e7eb; margin-bottom: 20px; }
        .empty-state h3 { color: var(--text-muted); font-size: 1.3rem; margin-bottom: 10px; }
        .empty-state p { color: #9ca3af; }

        /* Footer */
        footer { 
            background: linear-gradient(135deg, var(--dar-green), var(--dar-dark-green));
            color: white; text-align: center; padding: 30px 20px;
            font-size: 0.85rem;
        }

        @media (max-width: 768px) {
            header { padding: 15px 20px; flex-wrap: wrap; gap: 10px; }
            .page-hero h2 { font-size: 1.8rem; }
            .stats-bar { flex-wrap: wrap; gap: 20px; margin: -20px 15px 30px; }
            .positions-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

    <header>
        <div class="logo-container">
            <div class="logo-placeholder">DAR</div>
            <div class="header-title">
                <h1>Department of Agrarian Reform</h1>
                <p>Vacant Positions</p>
            </div>
        </div>
        <a href="index.php" class="back-btn"><i class="fas fa-arrow-left"></i> Back to Home</a>
    </header>

    <section class="page-hero">
        <h2><i class="fas fa-briefcase" style="margin-right: 12px;"></i>Career Opportunities</h2>
        <p>Join the Department of Agrarian Reform and be part of our mission to serve Filipino farmers and rural communities.</p>
    </section>

    <div class="stats-bar">
        <div class="stat">
            <h4><?php echo $positions->num_rows; ?></h4>
            <p>Open Positions</p>
        </div>
        <div class="stat">
            <h4><?php echo $conn->query("SELECT COUNT(*) as total FROM applicants WHERE status = 'pending'")->fetch_assoc()['total']; ?></h4>
            <p>Applications Received</p>
        </div>
        <div class="stat">
            <h4>15</h4>
            <p>Regional Offices</p>
        </div>
    </div>

    <div class="container">
        <?php if($positions->num_rows > 0): ?>
        <div class="positions-grid">
            <?php while($pos = $positions->fetch_assoc()): 
                $requirements = explode(',', $pos['requirements']);
            ?>
            <div class="position-card">
                <div class="position-header">
                    <span class="position-badge"><?php echo $pos['employment_type']; ?></span>
                    <h3><?php echo htmlspecialchars($pos['position_title']); ?></h3>
                    <p class="dept"><i class="fas fa-building" style="margin-right: 6px;"></i><?php echo htmlspecialchars($pos['department']); ?></p>
                </div>
                <div class="position-body">
                    <div class="detail-row">
                        <span><i class="fas fa-money-bill-wave" style="margin-right: 6px; color: var(--dar-green);"></i>Monthly Salary</span>
                        <span class="salary-highlight">₱<?php echo number_format($pos['monthly_salary'], 2); ?></span>
                    </div>
                    <div class="detail-row">
                        <span><i class="fas fa-layer-group" style="margin-right: 6px; color: var(--dar-green);"></i>Salary Grade</span>
                        <span><?php echo htmlspecialchars($pos['salary_grade']); ?></span>
                    </div>
                    <div class="detail-row">
                        <span><i class="fas fa-hashtag" style="margin-right: 6px; color: var(--dar-green);"></i>Plantilla Item No.</span>
                        <span><?php echo htmlspecialchars($pos['plantilla_item_no']); ?></span>
                    </div>
                    <div class="detail-row">
                        <span><i class="fas fa-users" style="margin-right: 6px; color: var(--dar-green);"></i>Slots Available</span>
                        <span><?php echo $pos['number_of_slots']; ?></span>
                    </div>
                    <div class="detail-row">
                        <span><i class="fas fa-calendar-alt" style="margin-right: 6px; color: var(--dar-green);"></i>Deadline</span>
                        <span style="color: #dc2626; font-weight: 700;"><?php echo date('F d, Y', strtotime($pos['deadline'])); ?></span>
                    </div>
                    <div class="qualifications">
                        <h4><i class="fas fa-graduation-cap"></i> Qualifications</h4>
                        <p><?php echo htmlspecialchars(substr($pos['qualifications'], 0, 120)) . '...'; ?></p>
                    </div>
                </div>
                <div class="position-footer">
                    <button class="btn-details" onclick="showDetails(<?php echo $pos['id']; ?>)">
                        <i class="fas fa-info-circle"></i> Details
                    </button>
                    <a href="applicant_register.php?position=<?php echo $pos['id']; ?>" class="btn-apply">
                        <i class="fas fa-paper-plane"></i> Apply Now
                    </a>
                </div>
            </div>

            <!-- Modal for this position -->
            <div class="modal-overlay" id="modal-<?php echo $pos['id']; ?>">
                <div class="modal">
                    <div class="modal-header">
                        <h3><i class="fas fa-briefcase" style="margin-right: 10px;"></i><?php echo htmlspecialchars($pos['position_title']); ?></h3>
                        <button class="modal-close" onclick="closeModal(<?php echo $pos['id']; ?>)"><i class="fas fa-times"></i></button>
                        <p style="margin-top: 5px; opacity: 0.9; font-size: 0.9rem;"><?php echo htmlspecialchars($pos['department']); ?></p>
                    </div>
                    <div class="modal-body">
                        <div class="modal-section">
                            <h4><i class="fas fa-money-bill-wave"></i> Compensation</h4>
                            <p><strong>Salary Grade:</strong> <?php echo htmlspecialchars($pos['salary_grade']); ?></p>
                            <p><strong>Monthly Salary:</strong> <span style="color: var(--dar-green); font-weight: 700; font-size: 1.1rem;">₱<?php echo number_format($pos['monthly_salary'], 2); ?></span></p>
                            <p><strong>Employment Type:</strong> <?php echo $pos['employment_type']; ?></p>
                        </div>
                        <div class="modal-section">
                            <h4><i class="fas fa-graduation-cap"></i> Qualifications</h4>
                            <p><?php echo nl2br(htmlspecialchars($pos['qualifications'])); ?></p>
                        </div>
                        <div class="modal-section">
                            <h4><i class="fas fa-file-alt"></i> Requirements</h4>
                            <ul>
                                <?php foreach($requirements as $req): ?>
                                <li><?php echo trim(htmlspecialchars($req)); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                        <div class="modal-section">
                            <h4><i class="fas fa-info-circle"></i> Additional Information</h4>
                            <p><strong>Plantilla Item No.:</strong> <?php echo htmlspecialchars($pos['plantilla_item_no']); ?></p>
                            <p><strong>Slots Available:</strong> <?php echo $pos['number_of_slots']; ?></p>
                            <p><strong>Posted:</strong> <?php echo date('F d, Y', strtotime($pos['date_posted'])); ?></p>
                            <p><strong>Application Deadline:</strong> <span style="color: #dc2626; font-weight: 700;"><?php echo date('F d, Y', strtotime($pos['deadline'])); ?></span></p>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn-details" onclick="closeModal(<?php echo $pos['id']; ?>)">Close</button>
                        <a href="applicant_register.php?position=<?php echo $pos['id']; ?>" class="btn-apply">
                            <i class="fas fa-paper-plane"></i> Apply for this Position
                        </a>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
        <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-folder-open"></i>
            <h3>No Vacant Positions Available</h3>
            <p>Please check back later for new career opportunities.</p>
        </div>
        <?php endif; ?>
    </div>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Department of Agrarian Reform - Employee Records Management System</p>
    </footer>

    <script>
        function showDetails(id) {
            document.getElementById('modal-' + id).classList.add('active');
            document.body.style.overflow = 'hidden';
        }
        function closeModal(id) {
            document.getElementById('modal-' + id).classList.remove('active');
            document.body.style.overflow = 'auto';
        }
        // Close modal on overlay click
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', function(e) {
                if(e.target === this) {
                    this.classList.remove('active');
                    document.body.style.overflow = 'auto';
                }
            });
        });
        // Close on Escape key
        document.addEventListener('keydown', function(e) {
            if(e.key === 'Escape') {
                document.querySelectorAll('.modal-overlay.active').forEach(m => {
                    m.classList.remove('active');
                });
                document.body.style.overflow = 'auto';
            }
        });
    </script>

</body>
</html>