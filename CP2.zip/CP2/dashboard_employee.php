<?php
session_start();
require_once 'db_config.php';

// Check if employee is logged in
requireLogin('employee', 'login_employee.php');

$page_title = "Employee Dashboard - DAR";

$employee_id = $_SESSION['employee_id'];
$employee_name = $_SESSION['employee_name'];

// Fetch employee details
$employee = $conn->query("SELECT * FROM employees WHERE id = $employee_id")->fetch_assoc();

// Fetch employee documents
$documents = $conn->query("SELECT * FROM documents WHERE uploaded_for = 'employee' AND user_id = $employee_id ORDER BY created_at DESC LIMIT 5");

// Fetch recent system activity for this employee
$logs = $conn->query("SELECT * FROM system_logs WHERE user_type = 'employee' AND user_id = $employee_id ORDER BY created_at DESC LIMIT 5");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dar-green: #006400;
            --dar-dark-green: #004d00;
            --dar-light-green: #4CAF50;
            --dar-gold: #FFD700;
            --bg-light: #f8faf9;
            --sidebar-bg: #0d3b0d;
            --text-dark: #1a1a2e;
            --text-muted: #6b7280;
            --shadow: 0 4px 20px rgba(0,0,0,0.08);
            --shadow-lg: 0 10px 40px rgba(0,0,0,0.1);
            --radius: 12px;
            --transition: all 0.3s ease;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: var(--bg-light); color: var(--text-dark); }

        .dashboard { display: flex; min-height: 100vh; }
        
        .sidebar {
            width: 260px; background: var(--sidebar-bg);
            color: white; position: fixed; top: 0; left: 0; bottom: 0;
            overflow-y: auto; z-index: 100; transition: var(--transition);
        }
        .sidebar-header {
            padding: 25px 20px; text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .sidebar-logo {
            width: 55px; height: 55px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 800; font-size: 18px;
            margin: 0 auto 15px;
        }
        .sidebar-header h3 { font-size: 1rem; font-weight: 600; }
        .sidebar-header p { font-size: 0.75rem; opacity: 0.7; margin-top: 3px; }

        .nav-menu { padding: 20px 0; }
        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 14px 25px; color: rgba(255,255,255,0.8);
            text-decoration: none; font-size: 0.9rem; font-weight: 500;
            transition: var(--transition); border-left: 3px solid transparent;
        }
        .nav-item:hover, .nav-item.active {
            background: rgba(255,255,255,0.05);
            color: white; border-left-color: var(--dar-gold);
        }
        .nav-item i { width: 20px; text-align: center; font-size: 1rem; }

        .sidebar-footer {
            position: absolute; bottom: 0; left: 0; right: 0;
            padding: 20px; border-top: 1px solid rgba(255,255,255,0.1);
        }
        .user-info { display: flex; align-items: center; gap: 12px; }
        .user-avatar {
            width: 40px; height: 40px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 700; font-size: 0.9rem;
        }
        .user-details h4 { font-size: 0.85rem; font-weight: 600; }
        .user-details p { font-size: 0.75rem; opacity: 0.6; }
        .logout-btn {
            display: flex; align-items: center; gap: 8px;
            color: rgba(255,255,255,0.7); text-decoration: none;
            font-size: 0.8rem; margin-top: 12px; transition: var(--transition);
        }
        .logout-btn:hover { color: #ef4444; }

        .main-content {
            flex: 1; margin-left: 260px; min-height: 100vh;
        }
        .top-bar {
            background: white; padding: 15px 30px;
            display: flex; justify-content: space-between; align-items: center;
            box-shadow: var(--shadow); position: sticky; top: 0; z-index: 50;
        }
        .top-bar h2 { font-size: 1.3rem; font-weight: 700; }
        .top-bar-actions { display: flex; align-items: center; gap: 15px; }
        .notification-btn {
            width: 40px; height: 40px; border-radius: 10px;
            background: var(--bg-light); border: none;
            display: flex; align-items: center; justify-content: center;
            color: var(--text-muted); cursor: pointer; transition: var(--transition);
        }
        .notification-btn:hover { background: #e8f5e9; color: var(--dar-green); }

        .content { padding: 30px; }

        /* Profile Card */
        .profile-card {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-dark-green));
            color: white; border-radius: var(--radius);
            padding: 35px; margin-bottom: 30px;
            display: flex; align-items: center; gap: 25px;
            box-shadow: var(--shadow-lg);
        }
        .profile-avatar {
            width: 90px; height: 90px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-size: 2rem; font-weight: 800;
            border: 4px solid rgba(255,255,255,0.2);
        }
        .profile-info h2 { font-size: 1.6rem; font-weight: 700; margin-bottom: 5px; }
        .profile-info p { opacity: 0.9; font-size: 0.95rem; margin-bottom: 3px; }
        .profile-badges {
            display: flex; gap: 10px; margin-top: 12px;
        }
        .profile-badge {
            background: rgba(255,255,255,0.15); padding: 5px 14px;
            border-radius: 20px; font-size: 0.8rem; backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.1);
        }

        /* Info Grid */
        .info-grid {
            display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px; margin-bottom: 30px;
        }
        .info-card {
            background: white; border-radius: var(--radius);
            padding: 25px; box-shadow: var(--shadow);
            border: 1px solid #f0f0f0;
        }
        .info-card h3 {
            font-size: 1rem; color: var(--dar-green);
            margin-bottom: 20px; padding-bottom: 12px;
            border-bottom: 2px solid #f0f0f0;
            display: flex; align-items: center; gap: 8px;
        }
        .info-row {
            display: flex; justify-content: space-between;
            padding: 10px 0; border-bottom: 1px solid #f8f8f8;
        }
        .info-row:last-child { border-bottom: none; }
        .info-row span:first-child { color: var(--text-muted); font-size: 0.9rem; }
        .info-row span:last-child { font-weight: 600; color: var(--text-dark); font-size: 0.9rem; }

        /* Documents */
        .documents-card {
            background: white; border-radius: var(--radius);
            box-shadow: var(--shadow); border: 1px solid #f0f0f0;
            overflow: hidden;
        }
        .documents-header {
            padding: 20px 25px; border-bottom: 1px solid #f0f0f0;
            display: flex; justify-content: space-between; align-items: center;
        }
        .documents-header h3 { font-size: 1.1rem; font-weight: 700; }
        .doc-list { padding: 0; }
        .doc-item {
            display: flex; align-items: center; gap: 15px;
            padding: 15px 25px; border-bottom: 1px solid #f8f8f8;
            transition: var(--transition);
        }
        .doc-item:hover { background: #fafafa; }
        .doc-icon {
            width: 45px; height: 45px; border-radius: 10px;
            background: #f0fdf4; color: var(--dar-green);
            display: flex; align-items: center; justify-content: center;
            font-size: 1.2rem;
        }
        .doc-info { flex: 1; }
        .doc-info h4 { font-size: 0.9rem; font-weight: 600; margin-bottom: 3px; }
        .doc-info p { font-size: 0.8rem; color: var(--text-muted); }
        .doc-action {
            color: var(--dar-green); text-decoration: none;
            padding: 8px 16px; border-radius: 8px;
            background: #f0fdf4; font-size: 0.85rem; font-weight: 600;
            transition: var(--transition);
        }
        .doc-action:hover { background: var(--dar-green); color: white; }

        .empty-docs {
            text-align: center; padding: 40px;
            color: var(--text-muted);
        }
        .empty-docs i { font-size: 2.5rem; margin-bottom: 10px; opacity: 0.3; }

        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .main-content { margin-left: 0; }
        }
        @media (max-width: 768px) {
            .profile-card { flex-direction: column; text-align: center; }
            .profile-badges { justify-content: center; }
            .content { padding: 20px; }
        }
    </style>
</head>
<body>

    <div class="dashboard">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">DAR</div>
                <h3>Employee Portal</h3>
                <p>Records Management</p>
            </div>
            
            <nav class="nav-menu">
                <a href="dashboard_employee.php" class="nav-item active">
                    <i class="fas fa-home"></i> Dashboard
                </a>
                <a href="profile.php" class="nav-item">
                    <i class="fas fa-user"></i> My Profile
                </a>
                <a href="document.php" class="nav-item">
                    <i class="fas fa-folder-open"></i> My Documents
                </a>
                
                <a href="leave.php" class="nav-item">
                    <i class="fas fa-calendar-minus"></i> Leave Request
                </a>
                <a href="settings.php" class="nav-item">
                    <i class="fas fa-cog"></i> Settings
                </a>
            </nav>

            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar"><?php echo strtoupper(substr($employee_name, 0, 1)); ?></div>
                    <div class="user-details">
                        <h4><?php echo htmlspecialchars($employee_name); ?></h4>
                        <p><?php echo htmlspecialchars($employee['position']); ?></p>
                    </div>
                </div>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <div class="top-bar">
                <h2><i class="fas fa-home" style="margin-right: 10px; color: var(--dar-green);"></i>Employee Dashboard</h2>
                <div class="top-bar-actions">
                    <button class="notification-btn"><i class="fas fa-bell"></i></button>
                    <span style="font-size: 0.9rem; color: var(--text-muted);"><?php echo date('F d, Y'); ?></span>
                </div>
            </div>

            <div class="content">
                <!-- Profile Card -->
                <div class="profile-card">
                    <div class="profile-avatar"><?php echo strtoupper(substr($employee['first_name'], 0, 1) . substr($employee['last_name'], 0, 1)); ?></div>
                    <div class="profile-info">
                        <h2><?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?></h2>
                        <p><i class="fas fa-id-badge" style="margin-right: 8px;"></i><?php echo htmlspecialchars($employee['employee_id']); ?></p>
                        <p><i class="fas fa-building" style="margin-right: 8px;"></i><?php echo htmlspecialchars($employee['department']); ?></p>
                        <div class="profile-badges">
                            <span class="profile-badge"><i class="fas fa-briefcase" style="margin-right: 5px;"></i><?php echo htmlspecialchars($employee['position']); ?></span>
                            <span class="profile-badge"><i class="fas fa-layer-group" style="margin-right: 5px;"></i><?php echo htmlspecialchars($employee['salary_grade']); ?></span>
                            <span class="profile-badge"><i class="fas fa-check-circle" style="margin-right: 5px;"></i><?php echo ucfirst($employee['employment_status']); ?></span>
                        </div>
                    </div>
                </div>

                <!-- Info Grid -->
                <div class="info-grid">
                    <div class="info-card">
                        <h3><i class="fas fa-user-circle" style="color: var(--dar-green);"></i> Personal Information</h3>
                        <div class="info-row">
                            <span>Full Name</span>
                            <span><?php echo htmlspecialchars($employee['first_name'] . ' ' . ($employee['middle_name'] ? $employee['middle_name'] . ' ' : '') . $employee['last_name'] . ($employee['suffix'] ? ' ' . $employee['suffix'] : '')); ?></span>
                        </div>
                        <div class="info-row">
                            <span>Date of Birth</span>
                            <span><?php echo date('F d, Y', strtotime($employee['date_of_birth'])); ?></span>
                        </div>
                        <div class="info-row">
                            <span>Gender</span>
                            <span><?php echo $employee['gender']; ?></span>
                        </div>
                        <div class="info-row">
                            <span>Civil Status</span>
                            <span><?php echo $employee['civil_status']; ?></span>
                        </div>
                        <div class="info-row">
                            <span>Email</span>
                            <span><?php echo htmlspecialchars($employee['email']); ?></span>
                        </div>
                        <div class="info-row">
                            <span>Phone</span>
                            <span><?php echo htmlspecialchars($employee['phone']); ?></span>
                        </div>
                        <div class="info-row">
                            <span>Address</span>
                            <span style="text-align: right; max-width: 200px;"><?php echo htmlspecialchars($employee['address']); ?></span>
                        </div>
                    </div>

                    <div class="info-card">
                        <h3><i class="fas fa-briefcase" style="color: var(--dar-green);"></i> Employment Details</h3>
                        <div class="info-row">
                            <span>Employee ID</span>
                            <span><?php echo htmlspecialchars($employee['employee_id']); ?></span>
                        </div>
                        <div class="info-row">
                            <span>Department</span>
                            <span><?php echo htmlspecialchars($employee['department']); ?></span>
                        </div>
                        <div class="info-row">
                            <span>Position</span>
                            <span><?php echo htmlspecialchars($employee['position']); ?></span>
                        </div>
                        <div class="info-row">
                            <span>Employment Status</span>
                            <span><?php echo $employee['employment_status']; ?></span>
                        </div>
                        <div class="info-row">
                            <span>Salary Grade</span>
                            <span><?php echo htmlspecialchars($employee['salary_grade']); ?></span>
                        </div>
                        <div class="info-row">
                            <span>Date Hired</span>
                            <span><?php echo date('F d, Y', strtotime($employee['date_hired'])); ?></span>
                        </div>
                        <div class="info-row">
                            <span>Years of Service</span>
                            <span><?php 
                                $years = floor((time() - strtotime($employee['date_hired'])) / (365.25 * 24 * 60 * 60));
                                echo $years . ' year' . ($years != 1 ? 's' : '');
                            ?></span>
                        </div>
                    </div>

                   
                        <div class="info-row">
                            <span>Status</span>
                            <span style="color: <?php echo $employee['status'] == 'active' ? '#16a34a' : '#f59e0b'; ?>; font-weight: 700;">
                                <i class="fas fa-circle" style="font-size: 0.5rem; margin-right: 5px; vertical-align: middle;"></i>
                                <?php echo ucfirst($employee['status']); ?>
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Documents -->
                <div class="documents-card">
                    <div class="documents-header">
                        <h3><i class="fas fa-folder-open" style="margin-right: 8px; color: var(--dar-green);"></i>My Documents</h3>
                        <a href="documents.php" style="color: var(--dar-green); text-decoration: none; font-size: 0.85rem; font-weight: 600;">View All</a>
                    </div>
                    <div class="doc-list">
                        <?php if($documents->num_rows > 0): ?>
                            <?php while($doc = $documents->fetch_assoc()): ?>
                            <div class="doc-item">
                                <div class="doc-icon"><i class="fas fa-file-pdf"></i></div>
                                <div class="doc-info">
                                    <h4><?php echo htmlspecialchars($doc['document_name']); ?></h4>
                                    <p><?php echo ucfirst($doc['document_type']); ?> • <?php echo date('M d, Y', strtotime($doc['created_at'])); ?></p>
                                </div>
                                <a href="<?php echo htmlspecialchars($doc['file_path']); ?>" class="doc-action" target="_blank">
                                    <i class="fas fa-download" style="margin-right: 5px;"></i>Download
                                </a>
                            </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="empty-docs">
                                <i class="fas fa-folder-open"></i>
                                <h4>No documents uploaded yet</h4>
                                <p style="font-size: 0.85rem;">Your documents will appear here once uploaded by HR.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

</body>
</html>