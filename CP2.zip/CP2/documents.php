<?php
session_start();
require_once 'db_config.php';

requireLogin('admin', 'login_admin.php');
 $page_title = "Manage Documents - DAR";

 $admin_id = $_SESSION['admin_id'];
 $admin_name = $_SESSION['admin_name'];
 $role = $_SESSION['admin_role'] ?? 'Admin';

// Handle Delete
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $doc = $conn->query("SELECT file_path FROM documents WHERE id = $id")->fetch_assoc();
    if ($doc && file_exists($doc['file_path'])) {
        unlink($doc['file_path']);
    }
    $conn->query("DELETE FROM documents WHERE id = $id");
    $_SESSION['success'] = "Document deleted successfully.";
    redirect('documents.php');
}

// Handle Upload
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['document'])) {
    $document_name = sanitize($conn, $_POST['document_name']);
    $document_type = sanitize($conn, $_POST['document_type']);
    $uploaded_for = sanitize($conn, $_POST['uploaded_for']);
    $user_id = (int)$_POST['user_id'];
    $description = sanitize($conn, $_POST['description'] ?? '');

    $upload_dir = 'uploads/documents/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    $file = $_FILES['document'];
    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed_exts = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'];
    
    if (in_array($file_ext, $allowed_exts)) {
        $file_name = uniqid() . '_' . basename($file['name']);
        $file_path = $upload_dir . $file_name;
        
        if (move_uploaded_file($file['tmp_name'], $file_path)) {
            $file_size = $file['size'];
            $sql = "INSERT INTO documents (document_name, document_type, file_path, file_size, uploaded_by, uploaded_for, user_id, description) 
                    VALUES ('$document_name', '$document_type', '$file_path', $file_size, $admin_id, '$uploaded_for', $user_id, '$description')";
            $conn->query($sql);
            $_SESSION['success'] = "Document uploaded successfully.";
        } else {
            $_SESSION['error'] = "Failed to upload file.";
        }
    } else {
        $_SESSION['error'] = "Invalid file type. Allowed: PDF, DOC, DOCX, JPG, PNG";
    }
    redirect('documents.php');
}

// Fetch all documents
 $documents = $conn->query("SELECT d.*, a.full_name as uploader_name,
                           CASE 
                               WHEN d.uploaded_for = 'employee' THEN e.first_name
                               WHEN d.uploaded_for = 'applicant' THEN ap.first_name
                           END as user_first_name,
                           CASE 
                               WHEN d.uploaded_for = 'employee' THEN e.last_name
                               WHEN d.uploaded_for = 'applicant' THEN ap.last_name
                           END as user_last_name
                           FROM documents d
                           LEFT JOIN admins a ON d.uploaded_by = a.id
                           LEFT JOIN employees e ON d.uploaded_for = 'employee' AND d.user_id = e.id
                           LEFT JOIN applicants ap ON d.uploaded_for = 'applicant' AND d.user_id = ap.id
                           ORDER BY d.created_at DESC");

// Fetch employees and applicants for dropdown
 $employees_list = $conn->query("SELECT id, first_name, last_name, employee_id FROM employees WHERE status = 'active' ORDER BY last_name");
 $applicants_list = $conn->query("SELECT id, first_name, last_name, applicant_id FROM applicants ORDER BY last_name");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dar-green: #006400;
            --dar-dark-green: #004d00;
            --dar-light-green: #4CAF50;
            --dar-gold: #FFD700;
            --bg-light: #f8faf9;
            --sidebar-bg: #0d3b0d;
            --text-dark: #1a1a2e;
            --text-muted: #6b7280;
            --shadow: 0 4px 20px rgba(0,0,0,0.08);
            --shadow-lg: 0 10px 40px rgba(0,0,0,0.1);
            --radius: 12px;
            --transition: all 0.3s ease;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: var(--bg-light); color: var(--text-dark); }

        .dashboard { display: flex; min-height: 100vh; }

        .sidebar {
            width: 260px; background: var(--sidebar-bg);
            color: white; position: fixed; top: 0; left: 0; bottom: 0;
            z-index: 100; transition: var(--transition);
            display: flex; flex-direction: column;
        }
        .sidebar-header {
            padding: 25px 20px; text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            flex-shrink: 0;
        }
        .sidebar-logo {
            width: 55px; height: 55px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 800; font-size: 18px;
            margin: 0 auto 15px;
        }
        .sidebar-header h3 { font-size: 1rem; font-weight: 600; }
        .sidebar-header p { font-size: 0.75rem; opacity: 0.7; margin-top: 3px; }

        .nav-menu {
            padding: 20px 0;
            flex: 1;
            overflow-y: auto;
        }
        .nav-menu::-webkit-scrollbar { width: 4px; }
        .nav-menu::-webkit-scrollbar-track { background: transparent; }
        .nav-menu::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 4px; }
        .nav-menu::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.25); }

        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 14px 25px; color: rgba(255,255,255,0.8);
            text-decoration: none; font-size: 0.9rem; font-weight: 500;
            transition: var(--transition); border-left: 3px solid transparent;
            cursor: pointer;
        }
        .nav-item:hover, .nav-item.active {
            background: rgba(255,255,255,0.05);
            color: white; border-left-color: var(--dar-gold);
        }
        .nav-item i { width: 20px; text-align: center; font-size: 1rem; }

        .nav-divider {
            height: 1px; background: rgba(255,255,255,0.08);
            margin: 10px 25px;
        }
        .nav-label {
            font-size: 0.68rem; font-weight: 600;
            text-transform: uppercase; letter-spacing: 1.5px;
            color: rgba(255,255,255,0.35); padding: 10px 25px 5px;
        }

        .sidebar-footer {
            padding: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
            flex-shrink: 0;
        }
        .user-info { display: flex; align-items: center; gap: 12px; }
        .user-avatar {
            width: 40px; height: 40px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 700; font-size: 0.9rem;
        }
        .user-details h4 { font-size: 0.85rem; font-weight: 600; }
        .user-details p { font-size: 0.75rem; opacity: 0.6; }
        .logout-btn {
            display: flex; align-items: center; gap: 8px;
            color: rgba(255,255,255,0.7); text-decoration: none;
            font-size: 0.8rem; margin-top: 12px; transition: var(--transition);
        }
        .logout-btn:hover { color: #ef4444; }

        .main-content { flex: 1; margin-left: 260px; min-height: 100vh; }
        .top-bar {
            background: white; padding: 15px 30px;
            display: flex; justify-content: space-between; align-items: center;
            box-shadow: var(--shadow); position: sticky; top: 0; z-index: 50;
        }
        .top-bar h2 { font-size: 1.3rem; font-weight: 700; }
        .content { padding: 30px; }

        .alert {
            padding: 15px 20px; border-radius: 10px; margin-bottom: 25px;
            display: flex; align-items: center; gap: 10px; font-size: 0.95rem;
        }
        .alert-success { background: #f0fdf4; color: #16a34a; border: 1px solid #86efac; }
        .alert-error { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }

        .action-bar {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 25px; flex-wrap: wrap; gap: 15px;
        }
        .search-box {
            display: flex; align-items: center; gap: 10px;
            background: white; padding: 10px 15px; border-radius: 10px;
            box-shadow: var(--shadow); border: 1px solid #f0f0f0;
        }
        .search-box input {
            border: none; outline: none; font-family: 'Poppins', sans-serif;
            font-size: 0.9rem; width: 250px;
        }
        .btn-add {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; padding: 12px 25px; border: none; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.95rem; font-weight: 600;
            cursor: pointer; display: flex; align-items: center; gap: 8px;
            transition: var(--transition); text-decoration: none;
        }
        .btn-add:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,100,0,0.3); }

        .table-card {
            background: white; border-radius: var(--radius);
            box-shadow: var(--shadow); overflow: hidden;
        }
        .data-table { width: 100%; border-collapse: collapse; }
        .data-table th {
            text-align: left; padding: 14px 20px;
            font-size: 0.8rem; font-weight: 600; color: var(--text-muted);
            text-transform: uppercase; letter-spacing: 0.5px;
            background: #fafafa; border-bottom: 1px solid #f0f0f0;
        }
        .data-table td {
            padding: 14px 20px; font-size: 0.9rem;
            border-bottom: 1px solid #f8f8f8;
        }
        .data-table tr:hover td { background: #fafafa; }
        .doc-icon {
            width: 40px; height: 40px; border-radius: 10px;
            background: #f0fdf4; color: var(--dar-green);
            display: flex; align-items: center; justify-content: center;
            font-size: 1.1rem;
        }
        .file-size { color: var(--text-muted); font-size: 0.8rem; }
        .action-btns { display: flex; gap: 6px; }
        .btn-action {
            width: 32px; height: 32px; border-radius: 8px;
            border: none; cursor: pointer; display: flex;
            align-items: center; justify-content: center;
            font-size: 0.85rem; transition: var(--transition); text-decoration: none;
        }
        .btn-download { background: #eff6ff; color: #3b82f6; }
        .btn-download:hover { background: #3b82f6; color: white; }
        .btn-delete { background: #fef2f2; color: #ef4444; }
        .btn-delete:hover { background: #ef4444; color: white; }

        /* Upload Modal */
        .modal-overlay {
            display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.5); z-index: 1000;
            justify-content: center; align-items: center;
            padding: 20px; backdrop-filter: blur(5px);
        }
        .modal-overlay.active { display: flex; }
        .modal {
            background: white; border-radius: var(--radius);
            max-width: 600px; width: 100%;
            box-shadow: var(--shadow-lg);
            animation: modalIn 0.3s ease;
        }
        @keyframes modalIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }
        .modal-header {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; padding: 25px; display: flex;
            justify-content: space-between; align-items: center;
        }
        .modal-header h3 { font-size: 1.3rem; font-weight: 700; }
        .modal-close {
            background: none; border: none; color: white;
            font-size: 1.5rem; cursor: pointer;
        }
        .modal-body { padding: 25px; }
        .form-group { margin-bottom: 15px; }
        .form-group label {
            display: block; margin-bottom: 6px;
            font-weight: 600; font-size: 0.85rem; color: var(--text-dark);
        }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%; padding: 12px 15px;
            border: 2px solid #e5e7eb; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            outline: none; border-color: var(--dar-green);
            box-shadow: 0 0 0 4px rgba(0,100,0,0.08);
        }
        .file-input-wrapper {
            border: 2px dashed #e5e7eb; border-radius: 10px;
            padding: 30px; text-align: center;
            cursor: pointer; transition: var(--transition);
        }
        .file-input-wrapper:hover { border-color: var(--dar-green); background: #f8faf9; }
        .file-input-wrapper i { font-size: 2rem; color: var(--text-muted); margin-bottom: 10px; }
        .file-input-wrapper p { color: var(--text-muted); font-size: 0.9rem; }
        .file-input-wrapper input[type="file"] { display: none; }
        .modal-footer {
            padding: 20px 25px; border-top: 1px solid #f0f0f0;
            display: flex; justify-content: flex-end; gap: 10px;
        }
        .btn-cancel {
            padding: 12px 25px; border: 2px solid #e5e7eb;
            background: white; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            font-weight: 600; cursor: pointer;
        }
        .btn-save {
            padding: 12px 30px;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; border: none; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            font-weight: 600; cursor: pointer;
        }

        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; }
        }
        @media (max-width: 768px) {
            .content { padding: 20px; }
        }
    </style>
</head>
<body>

    <div class="dashboard">
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">DAR</div>
                <h3>Admin Dashboard</h3>
                <p>Employee Records Management</p>
            </div>

            <nav class="nav-menu">
                <a href="dashboard_admin.php" class="nav-item">
                    <i class="fas fa-home"></i> Dashboard
                </a>

                <div class="nav-divider"></div>
                <div class="nav-label">People</div>

                <a href="employees.php" class="nav-item">
                    <i class="fas fa-users"></i> Employees
                </a>
                

                <div class="nav-divider"></div>
                <div class="nav-label">Recruitment</div>

                <a href="positions.php" class="nav-item">
                    <i class="fas fa-briefcase"></i> Vacant Positions
                </a>
                <a href="applications.php" class="nav-item">
                    <i class="fas fa-file-alt"></i> Job Applications
                </a>

                <div class="nav-divider"></div>
                <div class="nav-label">Records</div>

                <a href="trainings.php" class="nav-item">
                    <i class="fas fa-graduation-cap"></i> Trainings
                </a>
                <a href="document_tracking.php" class="nav-item">
                    <i class="fas fa-exchange-alt"></i> Doc Tracking
                </a>
                <a href="documents.php" class="nav-item active">
                    <i class="fas fa-folder-open"></i> Documents
                </a>

                <div class="nav-divider"></div>
                <div class="nav-label">System</div>

                <a href="reports.php" class="nav-item">
                    <i class="fas fa-chart-bar"></i> Reports
                </a>
                <a href="calendar_admin.php" class="nav-item">
                    <i class="fas fa-calendar-alt"></i> Calendar
                </a>
                <a href="settings.php" class="nav-item">
                    <i class="fas fa-cog"></i> Settings
                </a>
            </nav>

            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar"><?php echo strtoupper(substr($admin_name, 0, 1)); ?></div>
                    <div class="user-details">
                        <h4><?php echo htmlspecialchars($admin_name); ?></h4>
                        <p><?php echo ucfirst($role); ?></p>
                    </div>
                </div>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </aside>

        <main class="main-content">
            <div class="top-bar">
                <h2><i class="fas fa-folder-open" style="margin-right: 10px; color: var(--dar-green);"></i>Manage Documents</h2>
            </div>

            <div class="content">
                <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
                <?php endif; ?>
                <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                </div>
                <?php endif; ?>

                <div class="action-bar">
                    <div class="search-box">
                        <i class="fas fa-search" style="color: var(--text-muted);"></i>
                        <input type="text" id="searchInput" placeholder="Search documents..." onkeyup="searchTable()">
                    </div>
                    <button class="btn-add" onclick="openModal()">
                        <i class="fas fa-cloud-upload-alt"></i> Upload Document
                    </button>
                </div>

                <div class="table-card">
                    <table class="data-table" id="documentsTable">
                        <thead>
                            <tr>
                                <th>Document</th>
                                <th>Type</th>
                                <th>For</th>
                                <th>User</th>
                                <th>Size</th>
                                <th>Uploaded By</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($doc = $documents->fetch_assoc()): 
                                $file_ext = strtolower(pathinfo($doc['file_path'], PATHINFO_EXTENSION));
                                $icon_class = 'fa-file';
                                if (in_array($file_ext, ['pdf'])) $icon_class = 'fa-file-pdf';
                                elseif (in_array($file_ext, ['doc', 'docx'])) $icon_class = 'fa-file-word';
                                elseif (in_array($file_ext, ['jpg', 'jpeg', 'png'])) $icon_class = 'fa-file-image';
                            ?>
                            <tr>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 12px;">
                                        <div class="doc-icon"><i class="fas <?php echo $icon_class; ?>"></i></div>
                                        <div>
                                            <div style="font-weight: 600;"><?php echo htmlspecialchars($doc['document_name']); ?></div>
                                            <div style="font-size: 0.8rem; color: var(--text-muted);"><?php echo ucfirst($doc['document_type']); ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td><span style="text-transform: capitalize;"><?php echo $doc['document_type']; ?></span></td>
                                <td><span style="text-transform: capitalize;"><?php echo $doc['uploaded_for']; ?></span></td>
                                <td><?php echo htmlspecialchars(($doc['user_first_name'] ?? '') . ' ' . ($doc['user_last_name'] ?? '')); ?></td>
                                <td class="file-size"><?php echo number_format($doc['file_size'] / 1024, 2); ?> KB</td>
                                <td><?php echo htmlspecialchars($doc['uploader_name'] ?? 'System'); ?></td>
                                <td><?php echo date('M d, Y', strtotime($doc['created_at'])); ?></td>
                                <td>
                                    <div class="action-btns">
                                        <a href="<?php echo htmlspecialchars($doc['file_path']); ?>" class="btn-action btn-download" title="Download" target="_blank" download>
                                            <i class="fas fa-download"></i>
                                        </a>
                                        <a href="documents.php?delete=<?php echo $doc['id']; ?>" class="btn-action btn-delete" title="Delete" onclick="return confirm('Delete this document?')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <!-- Upload Modal -->
    <div class="modal-overlay" id="uploadModal">
        <div class="modal">
            <div class="modal-header">
                <h3><i class="fas fa-cloud-upload-alt" style="margin-right: 10px;"></i>Upload Document</h3>
                <button class="modal-close" onclick="closeModal()"><i class="fas fa-times"></i></button>
            </div>
            <form method="POST" action="" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="form-group">
                        <label>Document Name</label>
                        <input type="text" name="document_name" required placeholder="e.g. Employee Contract 2026">
                    </div>
                    <div class="form-group">
                        <label>Document Type</label>
                        <select name="document_type" required>
                            <option value="personal">Personal</option>
                            <option value="employment">Employment</option>
                            <option value="certificate">Certificate</option>
                            <option value="memo">Memo</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Upload For</label>
                        <select name="uploaded_for" id="uploadFor" required onchange="updateUserList()">
                            <option value="">Select</option>
                            <option value="employee">Employee</option>
                            <option value="applicant">Applicant</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Select User</label>
                        <select name="user_id" id="userSelect" required>
                            <option value="">First select "Upload For"</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Description (Optional)</label>
                        <textarea name="description" rows="3" placeholder="Add a brief description..."></textarea>
                    </div>
                    <div class="form-group">
                        <label>File</label>
                        <div class="file-input-wrapper" onclick="document.getElementById('fileInput').click()">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <p>Click to select file or drag and drop</p>
                            <p style="font-size: 0.8rem;">PDF, DOC, DOCX, JPG, PNG (Max 10MB)</p>
                            <input type="file" id="fileInput" name="document" required onchange="updateFileName(this)">
                        </div>
                        <p id="fileName" style="margin-top: 10px; font-size: 0.9rem; color: var(--dar-green);"></p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-cancel" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn-save"><i class="fas fa-upload" style="margin-right: 8px;"></i>Upload Document</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const employees = <?php 
            $emps = [];
            $employees_list->data_seek(0);
            while($e = $employees_list->fetch_assoc()) $emps[] = ['id' => $e['id'], 'name' => $e['last_name'] . ', ' . $e['first_name'] . ' (' . $e['employee_id'] . ')'];
            echo json_encode($emps);
        ?>;
        const applicants = <?php 
            $apps = [];
            $applicants_list->data_seek(0);
            while($a = $applicants_list->fetch_assoc()) $apps[] = ['id' => $a['id'], 'name' => $a['last_name'] . ', ' . $a['first_name'] . ' (' . $a['applicant_id'] . ')'];
            echo json_encode($apps);
        ?>;

        function updateUserList() {
            const type = document.getElementById('uploadFor').value;
            const select = document.getElementById('userSelect');
            select.innerHTML = '<option value="">Select ' + (type === 'employee' ? 'Employee' : 'Applicant') + '</option>';
            
            const list = type === 'employee' ? employees : applicants;
            list.forEach(item => {
                const option = document.createElement('option');
                option.value = item.id;
                option.textContent = item.name;
                select.appendChild(option);
            });
        }

        function updateFileName(input) {
            if (input.files && input.files[0]) {
                document.getElementById('fileName').textContent = 'Selected: ' + input.files[0].name;
            }
        }

        function openModal() {
            document.getElementById('uploadModal').classList.add('active');
            document.body.style.overflow = 'hidden';
        }
        function closeModal() {
            document.getElementById('uploadModal').classList.remove('active');
            document.body.style.overflow = 'auto';
        }
        function searchTable() {
            const input = document.getElementById('searchInput').value.toLowerCase();
            const rows = document.querySelectorAll('#documentsTable tbody tr');
            rows.forEach(row => {
                row.style.display = row.textContent.toLowerCase().includes(input) ? '' : 'none';
            });
        }
        document.getElementById('uploadModal').addEventListener('click', function(e) {
            if(e.target === this) closeModal();
        });
    </script>

</body>
</html>