<?php
session_start();
require_once 'db_config.php';

requireLogin('admin', 'login_admin.php');
 $page_title = "Job Applications - DAR";

 $admin_id = $_SESSION['admin_id'];
 $admin_name = $_SESSION['admin_name'];
 $role = $_SESSION['admin_role'] ?? 'Admin';

// Handle Status Update
if (isset($_POST['update_status']) && isset($_POST['application_id'])) {
    $app_id = (int)$_POST['application_id'];
    $new_status = sanitize($conn, $_POST['new_status']);
    $remarks = sanitize($conn, $_POST['remarks'] ?? '');

    $conn->query("UPDATE job_applications SET status = '$new_status', remarks = '$remarks', updated_at = NOW() WHERE id = $app_id");

    if ($new_status == 'hired') {
        $app_check = $conn->query("SHOW COLUMNS FROM job_applications LIKE 'remarks'");
        if ($app_check && $app_check->num_rows > 0) {
            // remarks column exists, already updated above
        } else {
            $conn->query("UPDATE job_applications SET status = '$new_status', updated_at = NOW() WHERE id = $app_id");
        }

        $app_result = $conn->query("SELECT ja.applicant_id, ja.position_id FROM job_applications ja WHERE ja.id = $app_id");
        if ($app_result && $app_result->num_rows > 0) {
            $app_row = $app_result->fetch_assoc();
            $app_data = $conn->query("SELECT a.first_name, a.middle_name, a.last_name, a.email, a.phone, 
                                         a.date_of_birth, a.gender, a.civil_status, a.address, a.education_level,
                                         vp.position_title, vp.department, vp.salary_grade, vp.monthly_salary, 
                                         vp.employment_type
                                  FROM applicants a
                                  JOIN vacant_positions vp ON vp.id = " . (int)$app_row['position_id'] . "
                                  WHERE a.id = " . (int)$app_row['applicant_id']);

            if ($app_data && $app_data->num_rows > 0) {
                $ad = $app_data->fetch_assoc();
                $exists = $conn->query("SELECT id FROM employees WHERE email = '" . $ad['email'] . "'");
                if ($exists && $exists->num_rows == 0) {
                    $emp_id = 'DAR-' . date('Y') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
                    $username = strtolower(str_replace(' ', '', $ad['first_name'] . $ad['last_name'])) . rand(10, 99);
                    $password = password_hash('password123', PASSWORD_DEFAULT);

                    // Check which columns exist
                    $col_check = $conn->query("SHOW COLUMNS FROM employees LIKE 'employment_status'");
                    $has_emp_status = ($col_check && $col_check->num_rows > 0);

                    if ($has_emp_status) {
                        $conn->query("INSERT INTO employees (employee_id, first_name, middle_name, last_name, 
                                         date_of_birth, gender, civil_status, email, phone, address,
                                         department, position, employment_status, salary_grade, date_hired, 
                                         username, password, status, created_by)
                                         VALUES ('$emp_id', 
                                         '" . $ad['first_name'] . "', 
                                         '" . ($ad['middle_name'] ?? '') . "',
                                         '" . $ad['last_name'] . "',
                                         '" . ($ad['date_of_birth'] ?? '') . "',
                                         '" . ($ad['gender'] ?? '') . "',
                                         '" . ($ad['civil_status'] ?? '') . "',
                                         '" . $ad['email'] . "',
                                         '" . ($ad['phone'] ?? '') . "',
                                         '" . ($ad['address'] ?? '') . "',
                                         '" . $ad['department'] . "',
                                         '" . $ad['position_title'] . "',
                                         '" . ($ad['employment_type'] ?? '') . "',
                                         '" . $ad['salary_grade'] . "',
                                         CURDATE(),
                                         '$username', '$password', 'active', $admin_id)");
                    } else {
                        $conn->query("INSERT INTO employees (employee_id, first_name, middle_name, last_name, 
                                         date_of_birth, gender, civil_status, email, phone, address,
                                         department, position, salary_grade, date_hired, 
                                         username, password, status, created_by)
                                         VALUES ('$emp_id', 
                                         '" . $ad['first_name'] . "', 
                                         '" . ($ad['middle_name'] ?? '') . "',
                                         '" . $ad['last_name'] . "',
                                         '" . ($ad['date_of_birth'] ?? '') . "',
                                         '" . ($ad['gender'] ?? '') . "',
                                         '" . ($ad['civil_status'] ?? '') . "',
                                         '" . $ad['email'] . "',
                                         '" . ($ad['phone'] ?? '') . "',
                                         '" . ($ad['address'] ?? '') . "',
                                         '" . $ad['department'] . "',
                                         '" . $ad['position_title'] . "',
                                         '" . $ad['salary_grade'] . "',
                                         CURDATE(),
                                         '$username', '$password', 'active', $admin_id)");
                    }
                    $_SESSION['success'] = "Application marked as Hired. Employee created — ID: $emp_id | Username: $username | Password: password123";
                } else {
                    $_SESSION['success'] = "Application marked as Hired. Employee record already exists for this email.";
                }
            }
        }
    } else {
        $_SESSION['success'] = "Application status updated to " . ucfirst(str_replace('_', ' ', $new_status)) . ".";
    }
    redirect('applications.php');
}

// Handle Delete
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM job_applications WHERE id = $id");
    $_SESSION['success'] = "Application deleted successfully.";
    redirect('applications.php');
}

// Check what columns exist in job_applications
 $ja_cols = [];
 $col_result = $conn->query("SHOW COLUMNS FROM job_applications");
if ($col_result) {
    while ($c = $col_result->fetch_assoc()) {
        $ja_cols[] = $c['Field'];
    }
}
 $has_remarks = in_array('remarks', $ja_cols);
 $has_updated_at = in_array('updated_at', $ja_cols);
 $has_applied_at = in_array('applied_at', $ja_cols);

// Build select columns dynamically
 $ja_select = "ja.id, ja.applicant_id, ja.position_id, ja.application_code, ja.status";
if ($has_remarks) $ja_select .= ", ja.remarks";
if ($has_updated_at) $ja_select .= ", ja.updated_at";
 $applied_col = $has_applied_at ? 'ja.applied_at' : 'ja.created_at';
 $ja_select .= ", $applied_col as applied_at";

// Fetch all applications
 $applications = $conn->query("SELECT $ja_select,
                              a.first_name as app_first, a.last_name as app_last, a.middle_name as app_middle,
                              a.email as app_email, a.phone as app_phone, a.education_level,
                              vp.position_title, vp.department, vp.employment_type, vp.monthly_salary,
                              vp.deadline
                              FROM job_applications ja
                              JOIN applicants a ON ja.applicant_id = a.id
                              JOIN vacant_positions vp ON ja.position_id = vp.id
                              ORDER BY $applied_col DESC");

// Status counts with fallback — UPDATED: 6 statuses
 $cnt_result = $conn->query("SELECT status, COUNT(*) as total FROM job_applications GROUP BY status");
 $status_counts = ['submitted' => 0, 'under_review' => 0, 'shortlisted' => 0, 'interview' => 0, 'exam' => 0, 'hired' => 0, 'total' => 0];
if ($cnt_result) {
    while ($cr = $cnt_result->fetch_assoc()) {
        $key = $cr['status'];
        if (isset($status_counts[$key])) {
            $status_counts[$key] = (int)$cr['total'];
        }
        $status_counts['total'] += (int)$cr['total'];
    }
}
 $status_submitted = $status_counts['submitted'];
 $status_under_review = $status_counts['under_review'];
 $status_shortlisted = $status_counts['shortlisted'];
 $status_interview = $status_counts['interview'];
 $status_exam = $status_counts['exam'];
 $status_hired = $status_counts['hired'];
 $status_total = $status_counts['total'];

// Safe num_rows helper
function safeNumRows($result) {
    return ($result && is_object($result)) ? $result->num_rows : 0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dar-green: #006400;
            --dar-dark-green: #004d00;
            --dar-light-green: #4CAF50;
            --dar-gold: #FFD700;
            --bg-light: #f8faf9;
            --sidebar-bg: #0d3b0d;
            --text-dark: #1a1a2e;
            --text-muted: #6b7280;
            --shadow: 0 4px 20px rgba(0,0,0,0.08);
            --shadow-lg: 0 10px 40px rgba(0,0,0,0.1);
            --radius: 12px;
            --transition: all 0.3s ease;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: var(--bg-light); color: var(--text-dark); }

        .dashboard { display: flex; min-height: 100vh; }

        .sidebar {
            width: 260px; background: var(--sidebar-bg);
            color: white; position: fixed; top: 0; left: 0; bottom: 0;
            z-index: 100; transition: var(--transition);
            display: flex; flex-direction: column;
        }
        .sidebar-header {
            padding: 25px 20px; text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            flex-shrink: 0;
        }
        .sidebar-logo {
            width: 55px; height: 55px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 800; font-size: 18px;
            margin: 0 auto 15px;
        }
        .sidebar-header h3 { font-size: 1rem; font-weight: 600; }
        .sidebar-header p { font-size: 0.75rem; opacity: 0.7; margin-top: 3px; }

        .nav-menu { padding: 20px 0; flex: 1; overflow-y: auto; }
        .nav-menu::-webkit-scrollbar { width: 4px; }
        .nav-menu::-webkit-scrollbar-track { background: transparent; }
        .nav-menu::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 4px; }
        .nav-menu::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.25); }

        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 14px 25px; color: rgba(255,255,255,0.8);
            text-decoration: none; font-size: 0.9rem; font-weight: 500;
            transition: var(--transition); border-left: 3px solid transparent;
            cursor: pointer;
        }
        .nav-item:hover, .nav-item.active {
            background: rgba(255,255,255,0.05);
            color: white; border-left-color: var(--dar-gold);
        }
        .nav-item i { width: 20px; text-align: center; font-size: 1rem; }

        .nav-divider { height: 1px; background: rgba(255,255,255,0.08); margin: 10px 25px; }
        .nav-label {
            font-size: 0.68rem; font-weight: 600;
            text-transform: uppercase; letter-spacing: 1.5px;
            color: rgba(255,255,255,0.35); padding: 10px 25px 5px;
        }

        .sidebar-footer {
            padding: 20px; border-top: 1px solid rgba(255,255,255,0.1); flex-shrink: 0;
        }
        .user-info { display: flex; align-items: center; gap: 12px; }
        .user-avatar {
            width: 40px; height: 40px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 700; font-size: 0.9rem;
        }
        .user-details h4 { font-size: 0.85rem; font-weight: 600; }
        .user-details p { font-size: 0.75rem; opacity: 0.6; }
        .logout-btn {
            display: flex; align-items: center; gap: 8px;
            color: rgba(255,255,255,0.7); text-decoration: none;
            font-size: 0.8rem; margin-top: 12px; transition: var(--transition);
        }
        .logout-btn:hover { color: #ef4444; }

        .main-content { flex: 1; margin-left: 260px; min-height: 100vh; }
        .top-bar {
            background: white; padding: 15px 30px;
            display: flex; justify-content: space-between; align-items: center;
            box-shadow: var(--shadow); position: sticky; top: 0; z-index: 50;
        }
        .top-bar h2 { font-size: 1.3rem; font-weight: 700; }
        .content { padding: 30px; }

        .alert {
            padding: 15px 20px; border-radius: 10px; margin-bottom: 25px;
            display: flex; align-items: center; gap: 10px; font-size: 0.95rem;
        }
        .alert-success { background: #f0fdf4; color: #16a34a; border: 1px solid #86efac; }
        .alert-error { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }

        /* Status Summary Cards — UPDATED: 7 columns (total + 6 statuses) */
        .status-summary {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 12px;
            margin-bottom: 25px;
        }
        .status-card {
            background: white;
            border-radius: 10px;
            padding: 16px 10px;
            box-shadow: var(--shadow);
            border: 1px solid #f0f0f0;
            text-align: center;
            cursor: pointer;
            transition: var(--transition);
        }
        .status-card:hover { transform: translateY(-3px); box-shadow: var(--shadow-lg); }
        .status-card.active-filter { border-color: var(--dar-green); box-shadow: 0 0 0 3px rgba(0,100,0,0.12); }
        .status-card h4 { font-size: 1.5rem; font-weight: 800; margin-bottom: 2px; }
        .status-card small { font-size: 0.65rem; color: var(--text-muted); font-weight: 500; text-transform: uppercase; letter-spacing: 0.3px; }
        .status-card.sc-total h4 { color: var(--text-dark); }
        .status-card.sc-submitted h4 { color: #ca8a04; }
        .status-card.sc-review h4 { color: #3b82f6; }
        .status-card.sc-shortlisted h4 { color: #f59e0b; }
        .status-card.sc-interview h4 { color: #8b5cf6; }
        .status-card.sc-exam h4 { color: #0891b2; }
        .status-card.sc-hired h4 { color: #16a34a; }

        /* Action Bar */
        .action-bar {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 25px; flex-wrap: wrap; gap: 15px;
        }
        .search-box {
            display: flex; align-items: center; gap: 10px;
            background: white; padding: 10px 15px; border-radius: 10px;
            box-shadow: var(--shadow); border: 1px solid #f0f0f0;
        }
        .search-box input {
            border: none; outline: none; font-family: 'Poppins', sans-serif;
            font-size: 0.9rem; width: 280px;
        }
        .filter-select {
            padding: 10px 15px;
            border: 1px solid #f0f0f0;
            border-radius: 10px;
            background: white;
            box-shadow: var(--shadow);
            font-family: 'Poppins', sans-serif;
            font-size: 0.88rem;
            color: var(--text-dark);
            cursor: pointer;
            outline: none;
        }
        .filter-select:focus { border-color: var(--dar-green); }

        /* Table */
        .table-card {
            background: white; border-radius: var(--radius);
            box-shadow: var(--shadow); overflow: hidden;
        }
        .data-table { width: 100%; border-collapse: collapse; }
        .data-table th {
            text-align: left; padding: 14px 18px;
            font-size: 0.78rem; font-weight: 600; color: var(--text-muted);
            text-transform: uppercase; letter-spacing: 0.5px;
            background: #fafafa; border-bottom: 1px solid #f0f0f0;
            white-space: nowrap;
        }
        .data-table td {
            padding: 14px 18px; font-size: 0.88rem;
            border-bottom: 1px solid #f8f8f8;
            vertical-align: middle;
        }
        .data-table tr:hover td { background: #fafafa; }
        .data-table tr:last-child td { border-bottom: none; }

        .user-cell { display: flex; align-items: center; gap: 12px; }
        .user-avatar-sm {
            width: 36px; height: 36px; border-radius: 50%;
            background: linear-gradient(135deg, #3b82f6, #60a5fa);
            display: flex; align-items: center; justify-content: center;
            color: white; font-weight: 600; font-size: 0.8rem;
            flex-shrink: 0;
        }

        .app-code {
            font-family: monospace;
            font-size: 0.82rem;
            color: var(--dar-green);
            font-weight: 600;
            background: rgba(0,100,0,0.06);
            padding: 3px 8px;
            border-radius: 4px;
        }

        .dept-tag {
            padding: 3px 10px;
            border-radius: 6px;
            font-size: 0.78rem;
            font-weight: 500;
            background: rgba(62,168,212,0.1);
            color: #3b82f6;
            white-space: nowrap;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            white-space: nowrap;
        }
        .status-badge .dot { width: 6px; height: 6px; border-radius: 50%; background: currentColor; }

        /* UPDATED: 6 status badge styles */
        .status-submitted { background: #fefce8; color: #ca8a04; }
        .status-under_review { background: #eff6ff; color: #3b82f6; }
        .status-shortlisted { background: #fffbeb; color: #d97706; }
        .status-interview { background: #f5f3ff; color: #7c3aed; }
        .status-exam { background: #ecfeff; color: #0891b2; }
        .status-hired { background: #f0fdf4; color: #16a34a; }

        .action-btns { display: flex; gap: 6px; }
        .btn-action {
            width: 32px; height: 32px; border-radius: 8px;
            border: none; cursor: pointer; display: flex;
            align-items: center; justify-content: center;
            font-size: 0.82rem; transition: var(--transition); text-decoration: none;
        }
        .btn-view { background: #eff6ff; color: #3b82f6; }
        .btn-view:hover { background: #3b82f6; color: white; }
        .btn-edit { background: #f0fdf4; color: #16a34a; }
        .btn-edit:hover { background: #16a34a; color: white; }
        .btn-delete { background: #fef2f2; color: #ef4444; }
        .btn-delete:hover { background: #ef4444; color: white; }

        /* Modal */
        .modal-overlay {
            display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.5); z-index: 1000;
            justify-content: center; align-items: center;
            padding: 20px; backdrop-filter: blur(5px);
        }
        .modal-overlay.active { display: flex; }
        .modal {
            background: white; border-radius: var(--radius);
            max-width: 650px; width: 100%; max-height: 90vh;
            overflow-y: auto; box-shadow: var(--shadow-lg);
            animation: modalIn 0.3s ease;
        }
        @keyframes modalIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }
        .modal-header {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; padding: 25px; display: flex;
            justify-content: space-between; align-items: center;
        }
        .modal-header h3 { font-size: 1.2rem; font-weight: 700; }
        .modal-close {
            background: none; border: none; color: white;
            font-size: 1.5rem; cursor: pointer;
        }
        .modal-body { padding: 25px; }

        .view-section { margin-bottom: 22px; }
        .view-section:last-child { margin-bottom: 0; }
        .view-section-title {
            font-size: 0.82rem; font-weight: 700; color: var(--dar-green);
            margin-bottom: 12px; display: flex; align-items: center; gap: 8px;
            text-transform: uppercase; letter-spacing: 0.5px;
        }
        .view-grid {
            display: grid; grid-template-columns: 1fr 1fr; gap: 12px;
        }
        .view-field label {
            display: block; font-size: 0.7rem; font-weight: 600;
            color: var(--text-muted); text-transform: uppercase;
            letter-spacing: 0.5px; margin-bottom: 2px;
        }
        .view-field p { font-size: 0.9rem; font-weight: 500; color: var(--text-dark); }
        .view-field.full { grid-column: 1 / -1; }

        .form-group { margin-bottom: 18px; }
        .form-group label {
            display: block; margin-bottom: 6px;
            font-weight: 600; font-size: 0.85rem; color: var(--text-dark);
        }
        .form-group select, .form-group textarea {
            width: 100%; padding: 12px 15px;
            border: 2px solid #e5e7eb; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            transition: var(--transition);
        }
        .form-group select:focus, .form-group textarea:focus {
            outline: none; border-color: var(--dar-green);
            box-shadow: 0 0 0 4px rgba(0,100,0,0.08);
        }
        .form-group textarea { resize: vertical; min-height: 80px; }

        .modal-footer {
            padding: 20px 25px; border-top: 1px solid #f0f0f0;
            display: flex; justify-content: flex-end; gap: 10px;
        }
        .btn-cancel {
            padding: 12px 25px; border: 2px solid #e5e7eb;
            background: white; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            font-weight: 600; cursor: pointer; transition: var(--transition);
        }
        .btn-cancel:hover { border-color: var(--dar-green); color: var(--dar-green); }
        .btn-save {
            padding: 12px 30px;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; border: none; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            font-weight: 600; cursor: pointer; transition: var(--transition);
        }
        .btn-save:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,100,0,0.3); }
        .btn-danger {
            padding: 12px 25px;
            background: linear-gradient(135deg, #ef4444, #f87171);
            color: white; border: none; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            font-weight: 600; cursor: pointer; transition: var(--transition);
            display: flex; align-items: center; gap: 8px;
        }
        .btn-danger:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(239,68,68,0.3); }

        /* Timeline for view modal — UPDATED with all 6 statuses */
        .status-timeline { padding-left: 20px; border-left: 2px solid #e5e7eb; }
        .timeline-item { position: relative; padding: 0 0 18px 20px; }
        .timeline-item:last-child { padding-bottom: 0; }
        .timeline-item::before {
            content: '';
            position: absolute;
            left: -27px;
            top: 4px;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #e5e7eb;
            border: 2px solid white;
        }
        .timeline-item.active::before { background: var(--dar-light-green); }
        .timeline-item.ti-review::before { background: #3b82f6; }
        .timeline-item.ti-shortlisted::before { background: #f59e0b; }
        .timeline-item.ti-interview::before { background: #8b5cf6; }
        .timeline-item.ti-exam::before { background: #0891b2; }
        .timeline-item.ti-hired::before { background: #16a34a; }
        .timeline-item p { font-size: 0.85rem; color: var(--text-dark); font-weight: 500; }
        .timeline-item small { font-size: 0.75rem; color: var(--text-muted); }

        @media (max-width: 1280px) {
            .status-summary { grid-template-columns: repeat(4, 1fr); }
        }
        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; }
            .status-summary { grid-template-columns: repeat(3, 1fr); }
        }
        @media (max-width: 768px) {
            .content { padding: 20px; }
            .status-summary { grid-template-columns: repeat(2, 1fr); }
            .view-grid { grid-template-columns: 1fr; }
            .action-bar { flex-direction: column; align-items: stretch; }
            .search-box input { width: 100%; }
        }
    </style>
</head>
<body>

    <div class="dashboard">
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">DAR</div>
                <h3>Admin Dashboard</h3>
                <p>Employee Records Management</p>
            </div>
            <nav class="nav-menu">
                <a href="dashboard_admin.php" class="nav-item"><i class="fas fa-home"></i> Dashboard</a>
                <div class="nav-divider"></div>
                <div class="nav-label">People</div>
                <a href="employees.php" class="nav-item"><i class="fas fa-users"></i> Employees</a>
                <a href="applicants.php" class="nav-item"><i class="fas fa-user-plus"></i> Applicants</a>
                <div class="nav-divider"></div>
                <div class="nav-label">Recruitment</div>
                <a href="positions.php" class="nav-item"><i class="fas fa-briefcase"></i> Vacant Positions</a>
                <a href="applications.php" class="nav-item active"><i class="fas fa-file-alt"></i> Job Applications</a>
                <div class="nav-divider"></div>
                <div class="nav-label">Records</div>
                <a href="trainings.php" class="nav-item"><i class="fas fa-graduation-cap"></i> Trainings</a>
                <a href="document_tracking.php" class="nav-item"><i class="fas fa-exchange-alt"></i> Doc Tracking</a>
                <a href="documents.php" class="nav-item"><i class="fas fa-folder-open"></i> Documents</a>
                <div class="nav-divider"></div>
                <div class="nav-label">System</div>
                <a href="reports.php" class="nav-item"><i class="fas fa-chart-bar"></i> Reports</a>
                <a href="calendar_admin.php" class="nav-item"><i class="fas fa-calendar-alt"></i> Calendar</a>
                <a href="settings.php" class="nav-item"><i class="fas fa-cog"></i> Settings</a>
            </nav>
            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar"><?php echo strtoupper(substr($admin_name, 0, 1)); ?></div>
                    <div class="user-details">
                        <h4><?php echo htmlspecialchars($admin_name); ?></h4>
                        <p><?php echo ucfirst($role); ?></p>
                    </div>
                </div>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </aside>

        <main class="main-content">
            <div class="top-bar">
                <h2><i class="fas fa-file-alt" style="margin-right:10px;color:var(--dar-green);"></i>Job Applications</h2>
            </div>

            <div class="content">
                <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
                <?php endif; ?>

                <!-- Status Summary — UPDATED: 7 cards (Total + 6 statuses) -->
                <div class="status-summary">
                    <div class="status-card sc-total active-filter" onclick="filterByStatus('all', this)">
                        <h4><?php echo $status_total; ?></h4>
                        <small>Total</small>
                    </div>
                    <div class="status-card sc-submitted" onclick="filterByStatus('submitted', this)">
                        <h4><?php echo $status_submitted; ?></h4>
                        <small>Submitted</small>
                    </div>
                    <div class="status-card sc-review" onclick="filterByStatus('under_review', this)">
                        <h4><?php echo $status_under_review; ?></h4>
                        <small>Under Review</small>
                    </div>
                    <div class="status-card sc-shortlisted" onclick="filterByStatus('shortlisted', this)">
                        <h4><?php echo $status_shortlisted; ?></h4>
                        <small>Shortlisted</small>
                    </div>
                    <div class="status-card sc-interview" onclick="filterByStatus('interview', this)">
                        <h4><?php echo $status_interview; ?></h4>
                        <small>Interview</small>
                    </div>
                    <div class="status-card sc-exam" onclick="filterByStatus('exam', this)">
                        <h4><?php echo $status_exam; ?></h4>
                        <small>Exam</small>
                    </div>
                    <div class="status-card sc-hired" onclick="filterByStatus('hired', this)">
                        <h4><?php echo $status_hired; ?></h4>
                        <small>Hired</small>
                    </div>
                </div>

                <!-- Action Bar -->
                <div class="action-bar">
                    <div class="search-box">
                        <i class="fas fa-search" style="color:var(--text-muted);"></i>
                        <input type="text" id="searchInput" placeholder="Search by applicant, position, code..." onkeyup="filterTable()">
                    </div>
                    <!-- UPDATED: 6 status filter options -->
                    <select class="filter-select" id="statusFilter" onchange="filterTable()">
                        <option value="all">All Statuses</option>
                        <option value="submitted">Submitted</option>
                        <option value="under_review">Under Review</option>
                        <option value="shortlisted">Shortlisted</option>
                        <option value="interview">Interview</option>
                        <option value="exam">Exam</option>
                        <option value="hired">Hired</option>
                    </select>
                </div>

                <!-- Table -->
                <div class="table-card">
                    <table class="data-table" id="applicationsTable">
                        <thead>
                            <tr>
                                <th>Applicant</th>
                                <th>Application Code</th>
                                <th>Position</th>
                                <th>Department</th>
                                <th>Education</th>
                                <th>Status</th>
                                <th>Date Applied</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($applications->num_rows > 0): ?>
                                <?php while($app = $applications->fetch_assoc()):
                                    $full_name = trim(($app['app_first'] ?? '') . ' ' . ($app['app_middle'] ?? '') . ' ' . ($app['app_last'] ?? ''));
                                    $initials = strtoupper(substr($app['app_first'], 0, 1) . substr($app['app_last'], 0, 1));
                                    $status_class = 'status-' . str_replace(' ', '_', $app['status']);
                                    $status_label = str_replace('_', ' ', ucfirst($app['status']));
                                    // Allow edit for all statuses except hired
                                    $can_edit = ($app['status'] != 'hired');
                                ?>
                                <tr data-status="<?php echo $app['status']; ?>" data-search="<?php echo strtolower($full_name . ' ' . $app['position_title'] . ' ' . $app['department'] . ' ' . $app['application_code']); ?>">
                                    <td>
                                        <div class="user-cell">
                                            <div class="user-avatar-sm"><?php echo $initials; ?></div>
                                            <div>
                                                <div style="font-weight:600;font-size:0.9rem;"><?php echo htmlspecialchars($full_name); ?></div>
                                                <div style="font-size:0.75rem;color:var(--text-muted);"><?php echo htmlspecialchars($app['app_email']); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><span class="app-code"><?php echo htmlspecialchars($app['application_code']); ?></span></td>
                                    <td style="font-weight:500;"><?php echo htmlspecialchars($app['position_title']); ?></td>
                                    <td><span class="dept-tag"><?php echo htmlspecialchars($app['department']); ?></span></td>
                                    <td style="color:var(--text-muted);font-size:0.85rem;"><?php echo htmlspecialchars($app['education_level']); ?></td>
                                    <td><span class="status-badge <?php echo $status_class; ?>"><span class="dot"></span> <?php echo $status_label; ?></span></td>
                                    <td style="color:var(--text-muted);font-size:0.85rem;"><?php echo date('M d, Y', strtotime($app['applied_at'])); ?></td>
                                    <td>
                                        <div class="action-btns">
                                            <button class="btn-action btn-view" title="View Details" onclick='viewApplication(<?php echo htmlspecialchars(json_encode($app)); ?>)'><i class="fas fa-eye"></i></button>
                                            <?php if($can_edit): ?>
                                            <button class="btn-action btn-edit" title="Update Status" onclick='editApplication(<?php echo $app['id']; ?>, "<?php echo $app['application_code']; ?>", "<?php echo $full_name; ?>", "<?php echo $app['status']; ?>", "<?php echo htmlspecialchars($app['remarks'] ?? ''); ?>")'><i class="fas fa-edit"></i></button>
                                            <?php endif; ?>
                                            <a href="applications.php?delete=<?php echo $app['id']; ?>" class="btn-action btn-delete" title="Delete" onclick="return confirm('Delete this application permanently?')"><i class="fas fa-trash"></i></a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" style="text-align:center;padding:60px 20px;color:var(--text-muted);">
                                        <i class="fas fa-inbox" style="font-size:2.5rem;display:block;margin-bottom:12px;opacity:0.3;"></i>
                                        <strong style="font-size:1rem;color:var(--text-dark);display:block;margin-bottom:4px;">No Applications Found</strong>
                                        There are no job applications to display.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <!-- View Modal -->
    <div class="modal-overlay" id="viewModal">
        <div class="modal" style="max-width:620px;">
            <div class="modal-header">
                <h3><i class="fas fa-eye" style="margin-right:10px;"></i>Application Details</h3>
                <button class="modal-close" onclick="closeViewModal()"><i class="fas fa-times"></i></button>
            </div>
            <div class="modal-body" id="viewModalBody"></div>
            <div class="modal-footer">
                <button type="button" class="btn-cancel" onclick="closeViewModal()">Close</button>
                <button type="button" class="btn-save" id="viewEditBtn"><i class="fas fa-edit" style="margin-right:8px;"></i>Update Status</button>
            </div>
        </div>
    </div>

    <!-- Edit Modal — UPDATED: 6 status options in dropdown -->
    <div class="modal-overlay" id="editModal">
        <div class="modal" style="max-width:520px;">
            <div class="modal-header">
                <h3><i class="fas fa-edit" style="margin-right:10px;"></i>Update Application</h3>
                <button class="modal-close" onclick="closeEditModal()"><i class="fas fa-times"></i></button>
            </div>
            <form method="POST" action="">
                <input type="hidden" name="update_status" value="1">
                <input type="hidden" name="application_id" id="editAppId">
                <div class="modal-body">
                    <div style="background:var(--bg-light);padding:14px 18px;border-radius:10px;margin-bottom:20px;">
                        <div style="font-size:0.8rem;color:var(--text-muted);">Application</div>
                        <div style="font-weight:700;font-size:1rem;color:var(--text-dark);" id="editAppInfo"></div>
                    </div>
                    <div class="form-group">
                        <label>New Status</label>
                        <select name="new_status" id="editStatus" required>
                            <option value="">Select Status</option>
                            <option value="submitted">Submitted</option>
                            <option value="under_review">Under Review</option>
                            <option value="shortlisted">Shortlisted</option>
                            <option value="interview">Interview</option>
                            <option value="exam">Exam</option>
                            <option value="hired">Hired</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Remarks / Notes</label>
                        <textarea name="remarks" id="editRemarks" placeholder="Add remarks about this decision..."></textarea>
                    </div>
                    <div style="background:#fefce8;border:1px solid #fde68a;border-radius:10px;padding:14px 18px;margin-bottom:10px;">
                        <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
                            <i class="fas fa-info-circle" style="color:#ca8a04;"></i>
                            <strong style="font-size:0.85rem;color:#ca8a04;">Auto-Create Employee on "Hired"</strong>
                        </div>
                        <p style="font-size:0.8rem;color:var(--text-muted);line-height:1.5;">Setting the status to <strong>"Hired"</strong> will automatically create an employee record with default credentials if no existing employee uses the same email.</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-cancel" onclick="closeEditModal()">Cancel</button>
                    <button type="submit" class="btn-save"><i class="fas fa-check" style="margin-right:8px;"></i>Update</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function filterByStatus(status, el) {
            document.querySelectorAll('.status-card').forEach(c => c.classList.remove('active-filter'));
            el.classList.add('active-filter');
            document.getElementById('statusFilter').value = status;
            filterTable();
        }

        function filterTable() {
            const search = document.getElementById('searchInput').value.toLowerCase();
            const status = document.getElementById('statusFilter').value;
            document.querySelectorAll('#applicationsTable tbody tr[data-status]').forEach(row => {
                const matchSearch = row.dataset.search.includes(search);
                const matchStatus = status === 'all' || row.dataset.status === status;
                row.style.display = (matchSearch && matchStatus) ? '' : 'none';
            });
        }

        // UPDATED: Timeline now reflects all 6 statuses
        const statusOrder = ['submitted', 'under_review', 'shortlisted', 'interview', 'exam', 'hired'];
        const statusLabels = {
            'submitted': 'Application Submitted',
            'under_review': 'Under Review',
            'shortlisted': 'Shortlisted',
            'interview': 'Interview',
            'exam': 'Exam',
            'hired': 'Hired'
        };
        const timelineClasses = {
            'submitted': 'active',
            'under_review': 'ti-review',
            'shortlisted': 'ti-shortlisted',
            'interview': 'ti-interview',
            'exam': 'ti-exam',
            'hired': 'ti-hired'
        };

        function viewApplication(app) {
            const body = document.getElementById('viewModalBody');
            const statusClass = 'status-' + app.status.replace(' ', '_');
            const statusLabel = app.status.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());

            // Build timeline based on current status position
            const currentIndex = statusOrder.indexOf(app.status);
            let timeline = '<div class="status-timeline">';
            for (let i = 0; i <= currentIndex; i++) {
                const sKey = statusOrder[i];
                const isActive = (i === currentIndex);
                const dateVal = (i === 0) ? app.applied_at : app.updated_at;
                timeline += `
                    <div class="timeline-item ${timelineClasses[sKey]}"${!isActive ? ' style="opacity:0.55;"' : ''}>
                        <p>${statusLabels[sKey]}${isActive ? ' <span style="font-size:0.75rem;color:var(--dar-green);font-weight:700;">— Current</span>' : ''}</p>
                        <small>${dateVal ? formatDate(dateVal) : '—'}</small>
                    </div>
                `;
            }
            timeline += '</div>';

            body.innerHTML = `
                <div class="view-section">
                    <div class="view-section-title"><i class="fas fa-user"></i> Applicant Information</div>
                    <div class="view-grid">
                        <div class="view-field">
                            <label>Full Name</label>
                            <p>${app.app_first || ''} ${app.app_middle || ''} ${app.app_last || ''}</p>
                        </div>
                        <div class="view-field">
                            <label>Application Code</label>
                            <p><span class="app-code">${app.application_code}</span></p>
                        </div>
                        <div class="view-field">
                            <label>Email</label>
                            <p>${app.app_email || '—'}</p>
                        </div>
                        <div class="view-field">
                            <label>Phone</label>
                            <p>${app.app_phone || '—'}</p>
                        </div>
                        <div class="view-field full">
                            <label>Education</label>
                            <p>${app.education_level || '—'}</p>
                        </div>
                    </div>
                </div>
                <div class="view-section">
                    <div class="view-section-title"><i class="fas fa-briefcase"></i> Position Applied</div>
                    <div class="view-grid">
                        <div class="view-field">
                            <label>Position</label>
                            <p>${app.position_title || '—'}</p>
                        </div>
                        <div class="view-field">
                            <label>Department</label>
                            <p>${app.department || '—'}</p>
                        </div>
                        <div class="view-field">
                            <label>Employment Type</label>
                            <p>${app.employment_type || '—'}</p>
                        </div>
                        <div class="view-field">
                            <label>Monthly Salary</label>
                            <p style="color:var(--dar-green);font-weight:700;">₱${app.monthly_salary ? Number(app.monthly_salary).toLocaleString('en-PH', {minimumFractionDigits:2}) : '0.00'}</p>
                        </div>
                    </div>
                </div>
                <div class="view-section">
                    <div class="view-section-title"><i class="fas fa-flag"></i> Current Status</div>
                    <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
                        <span class="status-badge ${statusClass}"><span class="dot"></span> ${statusLabel}</span>
                    </div>
                    ${app.remarks ? '<div style="background:var(--bg-light);padding:12px 16px;border-radius:8px;font-size:0.88rem;color:var(--text-dark);"><strong style="color:var(--text-muted);font-size:0.75rem;display:block;margin-bottom:4px;">REMARKS</strong>' + app.remarks + '</div>' : ''}
                </div>
                <div class="view-section">
                    <div class="view-section-title"><i class="fas fa-history"></i> Application Timeline</div>
                    ${timeline}
                </div>
            `;

            // Hide "Update Status" button if already hired
            const viewEditBtn = document.getElementById('viewEditBtn');
            if (app.status === 'hired') {
                viewEditBtn.style.display = 'none';
            } else {
                viewEditBtn.style.display = '';
                viewEditBtn.onclick = function() {
                    closeViewModal();
                    editApplication(app.id, app.application_code, app.app_first + ' ' + app.app_last, app.status, app.remarks || '');
                };
            }

            document.getElementById('viewModal').classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function editApplication(id, code, name, status, remarks) {
            document.getElementById('editAppId').value = id;
            document.getElementById('editAppInfo').textContent = code + ' – ' + name;
            document.getElementById('editStatus').value = status;
            document.getElementById('editRemarks').value = remarks;
            document.getElementById('editModal').classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeViewModal() {
            document.getElementById('viewModal').classList.remove('active');
            document.body.style.overflow = 'auto';
        }
        function closeEditModal() {
            document.getElementById('editModal').classList.remove('active');
            document.body.style.overflow = 'auto';
        }

        function formatDate(dateStr) {
            if (!dateStr) return '—';
            const d = new Date(dateStr);
            return d.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' });
        }

        document.getElementById('viewModal').addEventListener('click', function(e) { if(e.target === this) closeViewModal(); });
        document.getElementById('editModal').addEventListener('click', function(e) { if(e.target === this) closeEditModal(); });
        document.addEventListener('keydown', function(e) { if(e.key === 'Escape') { closeViewModal(); closeEditModal(); } });
    </script>

</body>
</html>