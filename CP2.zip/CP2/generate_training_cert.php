<?php
session_start();
require_once 'db_config.php';

requireLogin('admin', 'login_admin.php');

if (!isset($_GET['emp']) || !is_numeric($_GET['emp'])) {
    die('Invalid employee.');
}

 $emp_id = (int)$_GET['emp'];
 $employee = $conn->query("SELECT * FROM employees WHERE id = $emp_id")->fetch_assoc();
 $trainings = $conn->query("SELECT * FROM employee_trainings WHERE employee_id = $emp_id ORDER BY training_date ASC");

if (!$employee) die('Employee not found.');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Training Certification - <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background: #f0f0f0; }
        .cert-page {
            width: 210mm; min-height: 297mm; margin: 20px auto;
            background: white; padding: 50px 60px;
            box-shadow: 0 4px 30px rgba(0,0,0,0.15);
            position: relative;
        }
        /* DAR Header */
        .dar-header { text-align: center; border-bottom: 3px double #006400; padding-bottom: 20px; margin-bottom: 35px; }
        .dar-header h1 { font-size: 0.85rem; font-weight: 600; letter-spacing: 3px; text-transform: uppercase; color: #333; }
        .dar-header h2 { font-size: 1.3rem; font-weight: 800; color: #006400; margin: 4px 0; text-transform: uppercase; }
        .dar-header p { font-size: 0.75rem; color: #555; font-style: italic; }
        .cert-title {
            text-align: center; margin: 30px 0 25px;
            font-size: 1.6rem; font-weight: 800; color: #006400;
            letter-spacing: 5px; text-transform: uppercase;
        }
        .cert-body { font-size: 0.95rem; line-height: 1.8; color: #333; margin-bottom: 30px; }
        .cert-body .name { font-weight: 700; text-transform: uppercase; font-size: 1.05rem; }
        .cert-body .details { color: #555; }
        .cert-table { width: 100%; border-collapse: collapse; margin: 25px 0 35px; }
        .cert-table th {
            background: #006400; color: white; padding: 10px 14px;
            font-size: 0.78rem; font-weight: 600; text-transform: uppercase;
            letter-spacing: 0.5px; text-align: left;
        }
        .cert-table td {
            padding: 10px 14px; font-size: 0.85rem;
            border-bottom: 1px solid #e5e7eb; vertical-align: top;
        }
        .cert-table tr:nth-child(even) { background: #f9fafb; }
        .cert-footer { margin-top: 50px; }
        .cert-footer .row { display: flex; justify-content: space-between; }
        .cert-footer .sign-block { text-align: center; width: 45%; }
        .cert-footer .sign-line {
            border-top: 1px solid #333; margin-top: 60px; padding-top: 8px;
            font-size: 0.85rem; font-weight: 600;
        }
        .cert-footer .sign-title { font-size: 0.78rem; color: #666; font-weight: 400; }
        .cert-date {
            text-align: right; font-size: 0.85rem; color: #555;
            margin-bottom: 15px;
        }
        .no-trainings { text-align: center; padding: 40px; color: #999; font-style: italic; }
        /* Print Button */
        .print-bar {
            position: fixed; top: 20px; right: 20px; z-index: 100;
            display: flex; gap: 10px;
        }
        .btn-print, .btn-back-print {
            padding: 12px 25px; border: none; border-radius: 8px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            font-weight: 600; cursor: pointer; display: flex;
            align-items: center; gap: 8px; text-decoration: none;
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
        }
        .btn-print { background: #006400; color: white; }
        .btn-print:hover { background: #004d00; }
        .btn-back-print { background: white; color: #333; }
        .btn-back-print:hover { background: #f0f0f0; }

        @media print {
            body { background: white; }
            .cert-page { margin: 0; box-shadow: none; padding: 40px 50px; }
            .print-bar { display: none !important; }
            .cert-table th { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        }
    </style>
</head>
<body>

<div class="print-bar">
    <a href="trainings.php?emp=<?php echo $emp_id; ?>" class="btn-back-print"><i class="fas fa-arrow-left"></i> Back</a>
    <button class="btn-print" onclick="window.print()"><i class="fas fa-print"></i> Print Certification</button>
</div>

<div class="cert-page">
    <div class="dar-header">
        <h1>Republic of the Philippines</h1>
        <h2>Department of Agrarian Reform</h2>
        <p>Tunay na Pagbabago sa Repormang Agraryo</p>
    </div>

    <div class="cert-title">Certification</div>

    <div class="cert-body">
        <p>TO WHOM IT MAY CONCERN:</p>
        <br>
        <p>This is to certify that <span class="name"><?php echo htmlspecialchars($employee['first_name'] . ' ' . ($employee['middle_name'] ? $employee['middle_name'] . ' ' : '') . $employee['last_name'] . ($employee['suffix'] ? ' ' . $employee['suffix'] : '')); ?></span>, <span class="details">Employee ID No. <?php echo htmlspecialchars($employee['employee_id']); ?></span>, <span class="details">holding the position of <?php echo htmlspecialchars($employee['position']); ?> at the <?php echo htmlspecialchars($employee['department']); ?></span>, has attended the following trainings/seminars/workshops:</p>
    </div>

    <?php if ($trainings->num_rows > 0): ?>
    <table class="cert-table">
        <thead>
            <tr>
                <th style="width: 5%;">#</th>
                <th style="width: 35%;">Training Title</th>
                <th style="width: 18%;">Date</th>
                <th style="width: 22%;">Division/Office</th>
                <th style="width: 10%;">Hours</th>
                <th style="width: 10%;">Venue</th>
            </tr>
        </thead>
        <tbody>
            <?php $ctr = 1; $total = 0; while($tr = $trainings->fetch_assoc()):
                $total += $tr['hours'];
                $date_str = date('M d, Y', strtotime($tr['training_date']));
                if ($tr['training_end_date'] && $tr['training_end_date'] != $tr['training_date']) {
                    $date_str .= ' - ' . date('M d, Y', strtotime($tr['training_end_date']));
                }
            ?>
            <tr>
                <td><?php echo $ctr++; ?></td>
                <td><?php echo htmlspecialchars($tr['training_title']); ?></td>
                <td><?php echo $date_str; ?></td>
                <td><?php echo htmlspecialchars($tr['division']); ?></td>
                <td style="text-align: center;"><?php echo $tr['hours']; ?></td>
                <td><?php echo htmlspecialchars($tr['venue'] ?? '—'); ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="4" style="text-align: right; font-weight: 700; border-bottom: none;">Total Training Hours:</td>
                <td style="text-align: center; font-weight: 800; color: #006400; border-bottom: none; font-size: 1rem;"><?php echo $total; ?></td>
                <td style="border-bottom: none;"></td>
            </tr>
        </tfoot>
    </table>
    <?php else: ?>
    <div class="no-trainings">No training records found for this employee.</div>
    <?php endif; ?>

    <div class="cert-body" style="margin-top: 10px;">
        <p>This certification is issued upon the request of the employee for whatever purpose it may serve.</p>
    </div>

    <div class="cert-date">
        Date Issued: <?php echo date('F d, Y'); ?>
    </div>

    <div class="cert-footer">
        <div class="row">
            <div class="sign-block">
                <div class="sign-line">
                    <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?>
                    <div class="sign-title">Employee</div>
                </div>
            </div>
            <div class="sign-block">
                <div class="sign-line">
                    _________________________
                    <div class="sign-title">Authorized Signatory</div>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>