<?php
session_start();
require_once 'db_config.php';

// Log the logout if user was logged in
if (isset($_SESSION['admin_id'])) {
    $conn->query("INSERT INTO system_logs (user_type, user_id, action, ip_address) 
                  VALUES ('admin', " . $_SESSION['admin_id'] . ", 'Admin logout', '" . $_SERVER['REMOTE_ADDR'] . "')");
} elseif (isset($_SESSION['employee_id'])) {
    $conn->query("INSERT INTO system_logs (user_type, user_id, action, ip_address) 
                  VALUES ('employee', " . $_SESSION['employee_id'] . ", 'Employee logout', '" . $_SERVER['REMOTE_ADDR'] . "')");
} elseif (isset($_SESSION['applicant_id'])) {
    $conn->query("INSERT INTO system_logs (user_type, user_id, action, ip_address) 
                  VALUES ('applicant', " . $_SESSION['applicant_id'] . ", 'Applicant logout', '" . $_SERVER['REMOTE_ADDR'] . "')");
}

// Clear all session data
$_SESSION = array();

// Destroy session cookie
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time() - 3600, '/');
}

// Destroy the session
session_destroy();

// Redirect to home page
header("Location: index.php");
exit();
?>