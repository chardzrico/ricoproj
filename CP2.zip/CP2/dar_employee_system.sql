-- =====================================================================
-- DAR Employee Records System - Database Schema
-- Reverse-engineered from the CP2 PHP codebase (db_config.php uses
-- database name: dar_employee_system)
--
-- This was built by reading every SQL query in the PHP files (no .sql
-- dump was included in the project zip), so double-check field types
-- against what your forms actually need. A few notes are left inline
-- where the code was ambiguous or inconsistent.
-- =====================================================================

CREATE DATABASE IF NOT EXISTS dar_employee_system
  CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

USE dar_employee_system;

SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- admins
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS admins;
CREATE TABLE admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(150) DEFAULT NULL UNIQUE,
    phone VARCHAR(30) DEFAULT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'Admin',
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    last_login DATETIME DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Default login -> username: admin / password: admin123
INSERT INTO admins (full_name, username, email, phone, password, role, status)
VALUES ('System Administrator', 'admin', 'admin@dar.gov.ph', '(045) 455-1234',
        '$2y$10$UjuQBPXQZK8v6uBv6eZzv.cXtRrT1mzJX5jdJwuZGbI85pByVIpk.',
        'Super Admin', 'active');

-- ---------------------------------------------------------------------
-- employees
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS employees;
CREATE TABLE employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id VARCHAR(50) NOT NULL UNIQUE,
    first_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100) DEFAULT NULL,
    last_name VARCHAR(100) NOT NULL,
    suffix VARCHAR(20) DEFAULT NULL,
    date_of_birth DATE DEFAULT NULL,
    gender VARCHAR(20) DEFAULT NULL,
    civil_status VARCHAR(30) DEFAULT NULL,
    email VARCHAR(150) DEFAULT NULL,
    phone VARCHAR(30) DEFAULT NULL,
    address VARCHAR(255) DEFAULT NULL,
    emergency_contact_name VARCHAR(150) DEFAULT NULL,
    emergency_contact_phone VARCHAR(30) DEFAULT NULL,
    department VARCHAR(100) DEFAULT NULL,
    position VARCHAR(100) DEFAULT NULL,
    employment_status VARCHAR(50) DEFAULT NULL,
    salary_grade VARCHAR(20) DEFAULT NULL,
    date_hired DATE DEFAULT NULL,
    username VARCHAR(100) DEFAULT NULL UNIQUE,
    password VARCHAR(255) DEFAULT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'active',
    created_by INT DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES admins(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- applicants
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS applicants;
CREATE TABLE applicants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    applicant_id VARCHAR(50) NOT NULL UNIQUE,
    first_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100) DEFAULT NULL,
    last_name VARCHAR(100) NOT NULL,
    suffix VARCHAR(20) DEFAULT NULL,
    date_of_birth DATE DEFAULT NULL,
    gender VARCHAR(20) DEFAULT NULL,
    civil_status VARCHAR(30) DEFAULT NULL,
    email VARCHAR(150) DEFAULT NULL,
    phone VARCHAR(30) DEFAULT NULL,
    address VARCHAR(255) DEFAULT NULL,
    present_address VARCHAR(255) DEFAULT NULL,
    permanent_address VARCHAR(255) DEFAULT NULL,
    region VARCHAR(100) DEFAULT NULL,
    province VARCHAR(100) DEFAULT NULL,
    education_level VARCHAR(100) DEFAULT NULL,
    school_graduated VARCHAR(150) DEFAULT NULL,
    course VARCHAR(150) DEFAULT NULL,
    years_experience INT DEFAULT 0,
    username VARCHAR(100) DEFAULT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- applicant_education (child of applicants)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS applicant_education;
CREATE TABLE applicant_education (
    id INT AUTO_INCREMENT PRIMARY KEY,
    applicant_id INT NOT NULL,
    level VARCHAR(100) DEFAULT NULL,
    degree VARCHAR(150) DEFAULT NULL,
    school VARCHAR(150) DEFAULT NULL,
    year_from YEAR DEFAULT NULL,
    year_to YEAR DEFAULT NULL,
    year_graduated YEAR DEFAULT NULL,
    FOREIGN KEY (applicant_id) REFERENCES applicants(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- applicant_experience (child of applicants)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS applicant_experience;
CREATE TABLE applicant_experience (
    id INT AUTO_INCREMENT PRIMARY KEY,
    applicant_id INT NOT NULL,
    position VARCHAR(150) DEFAULT NULL,
    company VARCHAR(150) DEFAULT NULL,
    start_date DATE DEFAULT NULL,
    end_date DATE DEFAULT NULL,
    description TEXT,
    FOREIGN KEY (applicant_id) REFERENCES applicants(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- applicant_documents (child of applicants)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS applicant_documents;
CREATE TABLE applicant_documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    applicant_id INT NOT NULL,
    document_type VARCHAR(100) DEFAULT NULL,
    file_name VARCHAR(255) NOT NULL,
    uploaded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (applicant_id) REFERENCES applicants(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- vacant_positions
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS vacant_positions;
CREATE TABLE vacant_positions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    position_code VARCHAR(50) NOT NULL UNIQUE,
    position_title VARCHAR(150) NOT NULL,
    department VARCHAR(100) DEFAULT NULL,
    salary_grade VARCHAR(20) DEFAULT NULL,
    monthly_salary DECIMAL(12,2) DEFAULT NULL,
    employment_type VARCHAR(50) DEFAULT NULL,
    plantilla_item_no VARCHAR(50) DEFAULT NULL,
    qualifications TEXT,
    requirements TEXT,
    number_of_slots INT DEFAULT 1,
    date_posted DATE DEFAULT NULL,
    deadline DATE DEFAULT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'open',
    posted_by INT DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (posted_by) REFERENCES admins(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- job_applications
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS job_applications;
CREATE TABLE job_applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    application_code VARCHAR(50) NOT NULL UNIQUE,
    applicant_id INT NOT NULL,
    position_id INT NOT NULL,
    resume_path VARCHAR(255) DEFAULT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'submitted',
    remarks TEXT,
    applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (applicant_id) REFERENCES applicants(id) ON DELETE CASCADE,
    FOREIGN KEY (position_id) REFERENCES vacant_positions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- leave_requests
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS leave_requests;
CREATE TABLE leave_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    leave_type VARCHAR(50) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    days INT NOT NULL,
    reason TEXT,
    status VARCHAR(30) NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- documents (general employee/applicant documents)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS documents;
CREATE TABLE documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    document_name VARCHAR(150) NOT NULL,
    document_type VARCHAR(100) DEFAULT NULL,
    file_path VARCHAR(255) NOT NULL,
    file_size INT DEFAULT NULL,
    uploaded_by INT DEFAULT NULL,
    uploaded_for VARCHAR(50) DEFAULT NULL,
    user_id INT DEFAULT NULL,
    description TEXT,
    uploaded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (uploaded_by) REFERENCES admins(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- employee_trainings
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS employee_trainings;
CREATE TABLE employee_trainings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    training_title VARCHAR(200) NOT NULL,
    training_date DATE DEFAULT NULL,
    training_end_date DATE DEFAULT NULL,
    venue VARCHAR(150) DEFAULT NULL,
    division VARCHAR(100) DEFAULT NULL,
    hours DECIMAL(5,2) DEFAULT NULL,
    certificate_file VARCHAR(255) DEFAULT NULL,
    remarks TEXT,
    created_by INT DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES admins(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- calendar_events
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS calendar_events;
CREATE TABLE calendar_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_title VARCHAR(200) NOT NULL,
    event_date DATE NOT NULL,
    event_type VARCHAR(50) DEFAULT NULL,
    description TEXT,
    created_by INT DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES admins(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- tracked_documents (document tracking / routing system)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS tracked_documents;
CREATE TABLE tracked_documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tracking_number VARCHAR(50) NOT NULL UNIQUE,
    document_type VARCHAR(100) DEFAULT NULL,
    subject VARCHAR(255) DEFAULT NULL,
    source_from VARCHAR(150) DEFAULT NULL,
    received_by VARCHAR(150) DEFAULT NULL,
    date_received DATE DEFAULT NULL,
    current_status VARCHAR(50) NOT NULL DEFAULT 'received',
    current_division VARCHAR(100) DEFAULT NULL,
    current_handler VARCHAR(150) DEFAULT NULL,
    priority VARCHAR(30) DEFAULT 'normal',
    remarks TEXT,
    created_by INT DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES admins(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- document_logs (routing history for tracked_documents)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS document_logs;
CREATE TABLE document_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    document_id INT NOT NULL,
    action VARCHAR(100) NOT NULL,
    from_division VARCHAR(100) DEFAULT NULL,
    to_division VARCHAR(100) DEFAULT NULL,
    action_by VARCHAR(150) DEFAULT NULL,
    remarks TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (document_id) REFERENCES tracked_documents(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- contact_messages
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS contact_messages;
CREATE TABLE contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- system_logs (login/logout audit trail)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS system_logs;
CREATE TABLE system_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_type VARCHAR(30) NOT NULL,
    user_id INT DEFAULT NULL,
    action VARCHAR(255) NOT NULL,
    ip_address VARCHAR(50) DEFAULT NULL,
    user_agent VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- system_settings (key/value store, uses ON DUPLICATE KEY UPDATE)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS system_settings;
CREATE TABLE system_settings (
    setting_key VARCHAR(100) NOT NULL PRIMARY KEY,
    setting_value TEXT
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;
