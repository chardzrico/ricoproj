<?php
session_start();
require_once 'db_config.php';

requireLogin('admin', 'login_admin.php');
 $page_title = "Settings - DAR Admin";

 $admin_id = $_SESSION['admin_id'];
 $admin_name = $_SESSION['admin_name'];
 $role = $_SESSION['admin_role'] ?? 'Admin';

// === FETCH CURRENT ADMIN INFO ===
 $admin_info = null;
 $admin_result = $conn->query("SELECT * FROM admins WHERE id = '$admin_id'");
if ($admin_result && $admin_result->num_rows > 0) {
    $admin_info = $admin_result->fetch_assoc();
}

// === FETCH SYSTEM SETTINGS FROM DB (if table exists) ===
 $system_settings = [
    'system_name' => 'DAR Employee Records System',
    'system_version' => '2.0.0',
    'office_name' => 'Department of Agrarian Reform',
    'region' => 'Region III',
    'contact_email' => 'dar.info@dar.gov.ph',
    'contact_phone' => '(045) 455-1234',
    'allow_registration' => 1,
    'email_notifications' => 1,
    'auto_backup' => 0,
    'maintenance_mode' => 0,
    'session_timeout' => 30,
    'max_login_attempts' => 5,
    'password_min_length' => 8,
    'date_format' => 'M d, Y',
    'items_per_page' => 15,
];

// Try to load from settings table
 $settings_table_exists = false;
try {
    $st = $conn->query("SELECT setting_key, setting_value FROM system_settings");
    if ($st) {
        $settings_table_exists = true;
        while ($row = $st->fetch_assoc()) {
            $system_settings[$row['setting_key']] = $row['setting_value'];
        }
    }
} catch (Exception $e) {}

// === GET DATABASE SIZE ===
 $db_size = 'Unknown';
try {
    $db_name = $conn->query("SELECT DATABASE()")->fetch_assoc()['DATABASE()'];
    $sz = $conn->query("SELECT ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS size FROM information_schema.TABLES WHERE table_schema = '$db_name'")->fetch_assoc();
    if ($sz) $db_size = $sz['size'] . ' MB';
} catch (Exception $e) {}

// === GET TABLE COUNTS ===
 $table_info = [];
try {
    $tables = $conn->query("SHOW TABLES");
    if ($tables) {
        $db_name = $conn->query("SELECT DATABASE()")->fetch_assoc()['DATABASE()'];
        while ($t = $tables->fetch_array()) {
            $tname = $t[0];
            $cnt = $conn->query("SELECT COUNT(*) as c FROM `$tname`")->fetch_assoc()['c'];
            $table_info[] = ['name' => $tname, 'rows' => (int)$cnt];
        }
    }
} catch (Exception $e) {}

// === GET SERVER INFO ===
 $server_info = [
    'PHP Version' => phpversion(),
    'Server Software' => $_SERVER['SERVER_SOFTWARE'] ?? 'N/A',
    'Database' => 'MySQL ' . ($conn->server_info ?? 'N/A'),
    'Max Upload' => ini_get('upload_max_filesize'),
    'Post Max Size' => ini_get('post_max_size'),
    'Memory Limit' => ini_get('memory_limit'),
    'Max Execution Time' => ini_get('max_execution_time') . 's',
    'Timezone' => date_default_timezone_get(),
];

// === HANDLE FORM SUBMISSIONS ===
 $toast_msg = '';
 $toast_type = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_profile') {
        $new_name = trim($_POST['admin_name'] ?? '');
        $new_email = trim($_POST['admin_email'] ?? '');
        $new_phone = trim($_POST['admin_phone'] ?? '');

        if (empty($new_name)) {
            $toast_msg = 'Admin name is required.';
            $toast_type = 'error';
        } else {
            $stmt = $conn->prepare("UPDATE admins SET name = ?, email = ?, phone = ? WHERE id = ?");
            $stmt->bind_param("sssi", $new_name, $new_email, $new_phone, $admin_id);
            if ($stmt->execute()) {
                $_SESSION['admin_name'] = $new_name;
                $admin_name = $new_name;
                if ($admin_info) {
                    $admin_info['name'] = $new_name;
                    $admin_info['email'] = $new_email;
                    $admin_info['phone'] = $new_phone;
                }
                logActivity($conn, $admin_id, 'admin', 'Updated admin profile settings');
                $toast_msg = 'Profile updated successfully!';
                $toast_type = 'success';
            } else {
                $toast_msg = 'Failed to update profile.';
                $toast_type = 'error';
            }
            $stmt->close();
        }
    }

    elseif ($action === 'change_password') {
        $current_pw = $_POST['current_password'] ?? '';
        $new_pw = $_POST['new_password'] ?? '';
        $confirm_pw = $_POST['confirm_password'] ?? '';

        if (empty($current_pw) || empty($new_pw) || empty($confirm_pw)) {
            $toast_msg = 'All password fields are required.';
            $toast_type = 'error';
        } elseif ($new_pw !== $confirm_pw) {
            $toast_msg = 'New passwords do not match.';
            $toast_type = 'error';
        } elseif (strlen($new_pw) < 8) {
            $toast_msg = 'Password must be at least 8 characters.';
            $toast_type = 'error';
        } else {
            $pw_check = $conn->query("SELECT password FROM admins WHERE id = '$admin_id'");
            if ($pw_check && $pw_check->num_rows > 0) {
                $stored_pw = $pw_check->fetch_assoc()['password'];
                if (password_verify($current_pw, $stored_pw)) {
                    $hashed = password_hash($new_pw, PASSWORD_DEFAULT);
                    $conn->query("UPDATE admins SET password = '$hashed' WHERE id = '$admin_id'");
                    logActivity($conn, $admin_id, 'admin', 'Changed admin password');
                    $toast_msg = 'Password changed successfully!';
                    $toast_type = 'success';
                } else {
                    $toast_msg = 'Current password is incorrect.';
                    $toast_type = 'error';
                }
            }
        }
    }

    elseif ($action === 'update_system') {
        $fields = ['system_name','office_name','region','contact_email','contact_phone','date_format','items_per_page','session_timeout','max_login_attempts','password_min_length'];
        $updates = [];
        foreach ($fields as $f) {
            $val = $_POST[$f] ?? '';
            if ($settings_table_exists) {
                $conn->query("INSERT INTO system_settings (setting_key, setting_value) VALUES ('$f', '" . $conn->real_escape_string($val) . "') ON DUPLICATE KEY UPDATE setting_value = '" . $conn->real_escape_string($val) . "'");
            }
            $system_settings[$f] = $val;
        }
        // Toggle fields
        $toggles = ['allow_registration','email_notifications','auto_backup','maintenance_mode'];
        foreach ($toggles as $t) {
            $val = isset($_POST[$t]) ? 1 : 0;
            if ($settings_table_exists) {
                $conn->query("INSERT INTO system_settings (setting_key, setting_value) VALUES ('$t', '$val') ON DUPLICATE KEY UPDATE setting_value = '$val'");
            }
            $system_settings[$t] = $val;
        }
        logActivity($conn, $admin_id, 'admin', 'Updated system settings');
        $toast_msg = 'System settings saved!';
        $toast_type = 'success';
    }

    elseif ($action === 'clear_logs') {
        $conn->query("DELETE FROM system_logs");
        logActivity($conn, $admin_id, 'admin', 'Cleared all system logs');
        $toast_msg = 'System logs cleared.';
        $toast_type = 'success';
    }

    elseif ($action === 'optimize_db') {
        $optimized = 0;
        foreach ($table_info as $ti) {
            $conn->query("OPTIMIZE TABLE `{$ti['name']}`");
            $optimized++;
        }
        logActivity($conn, $admin_id, 'admin', "Optimized $optimized database tables");
        $toast_msg = "Optimized $optimized tables successfully!";
        $toast_type = 'success';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dar-green: #006400;
            --dar-dark-green: #004d00;
            --dar-light-green: #4CAF50;
            --dar-gold: #FFD700;
            --bg-light: #f8faf9;
            --sidebar-bg: #0d3b0d;
            --text-dark: #1a1a2e;
            --text-muted: #6b7280;
            --white: #ffffff;
            --shadow: 0 4px 20px rgba(0,0,0,0.08);
            --shadow-lg: 0 10px 40px rgba(0,0,0,0.12);
            --radius: 12px;
            --transition: all 0.3s ease;
            --danger: #ef4444;
            --warning: #f59e0b;
            --info: #3b82f6;
            --success: #16a34a;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: var(--bg-light); color: var(--text-dark); }
        .dashboard { display: flex; min-height: 100vh; }

        /* SIDEBAR */
        .sidebar {
            width: 260px; background: var(--sidebar-bg);
            color: white; position: fixed; top: 0; left: 0; bottom: 0;
            z-index: 100; transition: var(--transition); display: flex; flex-direction: column;
        }
        .sidebar-header {
            padding: 25px 20px; text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1); flex-shrink: 0;
        }
        .sidebar-logo {
            width: 55px; height: 55px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 800; font-size: 18px; margin: 0 auto 15px;
        }
        .sidebar-header h3 { font-size: 1rem; font-weight: 600; }
        .sidebar-header p { font-size: 0.75rem; opacity: 0.7; margin-top: 3px; }
        .nav-menu { padding: 20px 0; flex: 1; overflow-y: auto; }
        .nav-menu::-webkit-scrollbar { width: 4px; }
        .nav-menu::-webkit-scrollbar-track { background: transparent; }
        .nav-menu::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 4px; }
        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 14px 25px; color: rgba(255,255,255,0.8);
            text-decoration: none; font-size: 0.9rem; font-weight: 500;
            transition: var(--transition); border-left: 3px solid transparent; cursor: pointer;
        }
        .nav-item:hover, .nav-item.active {
            background: rgba(255,255,255,0.05); color: white; border-left-color: var(--dar-gold);
        }
        .nav-item i { width: 20px; text-align: center; font-size: 1rem; }
        .nav-divider { height: 1px; background: rgba(255,255,255,0.08); margin: 10px 25px; }
        .nav-label {
            font-size: 0.68rem; font-weight: 600; text-transform: uppercase;
            letter-spacing: 1.5px; color: rgba(255,255,255,0.35); padding: 10px 25px 5px;
        }
        .sidebar-footer {
            padding: 20px; border-top: 1px solid rgba(255,255,255,0.1); flex-shrink: 0;
        }
        .user-info { display: flex; align-items: center; gap: 12px; }
        .user-avatar {
            width: 40px; height: 40px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 700; font-size: 0.9rem;
        }
        .user-details h4 { font-size: 0.85rem; font-weight: 600; }
        .user-details p { font-size: 0.75rem; opacity: 0.6; }
        .logout-btn {
            display: flex; align-items: center; gap: 8px;
            color: rgba(255,255,255,0.7); text-decoration: none;
            font-size: 0.8rem; margin-top: 12px; transition: var(--transition);
        }
        .logout-btn:hover { color: #ef4444; }

        /* MAIN */
        .main-content { flex: 1; margin-left: 260px; min-height: 100vh; }
        .top-bar {
            background: white; padding: 15px 30px;
            display: flex; justify-content: space-between; align-items: center;
            box-shadow: var(--shadow); position: sticky; top: 0; z-index: 50;
        }
        .top-bar h2 { font-size: 1.3rem; font-weight: 700; }
        .top-bar-actions { display: flex; align-items: center; gap: 15px; }
        .content { padding: 30px; max-width: 1100px; }

        /* TOAST */
        .toast {
            position: fixed; top: 20px; right: 20px; z-index: 9999;
            padding: 16px 24px; border-radius: 10px; color: white;
            font-size: 0.88rem; font-weight: 500; display: flex; align-items: center; gap: 10px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.2); transform: translateX(120%);
            transition: transform 0.4s cubic-bezier(0.68,-0.55,0.27,1.55);
        }
        .toast.show { transform: translateX(0); }
        .toast.success { background: linear-gradient(135deg, #16a34a, #15803d); }
        .toast.error { background: linear-gradient(135deg, #ef4444, #dc2626); }

        /* SETTINGS TABS */
        .settings-tabs {
            display: flex; gap: 6px; margin-bottom: 24px;
            background: white; border-radius: var(--radius);
            padding: 6px; box-shadow: var(--shadow); border: 1px solid #f0f0f0;
            flex-wrap: wrap;
        }
        .tab-btn {
            padding: 11px 20px; border: none; background: transparent;
            border-radius: 8px; font-size: 0.85rem; font-weight: 600;
            color: var(--text-muted); cursor: pointer; transition: var(--transition);
            display: flex; align-items: center; gap: 8px; white-space: nowrap;
            font-family: 'Poppins', sans-serif;
        }
        .tab-btn:hover { background: #f0fdf4; color: var(--dar-green); }
        .tab-btn.active { background: var(--dar-green); color: white; box-shadow: 0 2px 10px rgba(0,100,0,0.3); }
        .tab-btn i { font-size: 0.9rem; }

        /* SETTINGS PANELS */
        .settings-panel { display: none; }
        .settings-panel.active { display: block; }

        .card {
            background: white; border-radius: var(--radius);
            box-shadow: var(--shadow); border: 1px solid #f0f0f0; overflow: hidden;
            margin-bottom: 22px;
        }
        .card-header {
            padding: 18px 24px; border-bottom: 1px solid #f0f0f0;
            display: flex; justify-content: space-between; align-items: center;
        }
        .card-header h3 { font-size: 0.95rem; font-weight: 700; display: flex; align-items: center; gap: 10px; }
        .card-header h3 i { color: var(--dar-green); font-size: 0.95rem; }
        .card-body { padding: 24px; }

        /* FORM ELEMENTS */
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .form-grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; }
        .form-group { margin-bottom: 0; }
        .form-group.full { grid-column: 1 / -1; }
        .form-label {
            display: block; font-size: 0.82rem; font-weight: 600;
            color: var(--text-dark); margin-bottom: 7px;
        }
        .form-label .required { color: var(--danger); margin-left: 2px; }
        .form-label small { font-weight: 400; color: var(--text-muted); margin-left: 6px; }
        .form-input, .form-select, .form-textarea {
            width: 100%; padding: 11px 14px; border: 1.5px solid #e5e7eb;
            border-radius: 8px; font-size: 0.88rem; font-family: 'Poppins', sans-serif;
            color: var(--text-dark); background: white; transition: var(--transition);
            outline: none;
        }
        .form-input:focus, .form-select:focus, .form-textarea:focus {
            border-color: var(--dar-green); box-shadow: 0 0 0 3px rgba(0,100,0,0.08);
        }
        .form-input:disabled, .form-select:disabled { background: #f9fafb; color: var(--text-muted); }
        .form-textarea { resize: vertical; min-height: 80px; }
        .form-hint { font-size: 0.75rem; color: var(--text-muted); margin-top: 5px; }

        /* TOGGLE SWITCH */
        .toggle-row {
            display: flex; justify-content: space-between; align-items: center;
            padding: 16px 0; border-bottom: 1px solid #f5f5f5;
        }
        .toggle-row:last-child { border-bottom: none; }
        .toggle-info h4 { font-size: 0.88rem; font-weight: 600; margin-bottom: 2px; }
        .toggle-info p { font-size: 0.78rem; color: var(--text-muted); }
        .toggle-switch { position: relative; width: 48px; height: 26px; flex-shrink: 0; }
        .toggle-switch input { opacity: 0; width: 0; height: 0; }
        .toggle-slider {
            position: absolute; cursor: pointer; inset: 0;
            background: #d1d5db; border-radius: 26px; transition: var(--transition);
        }
        .toggle-slider::before {
            content: ''; position: absolute; height: 20px; width: 20px;
            left: 3px; bottom: 3px; background: white;
            border-radius: 50%; transition: var(--transition); box-shadow: 0 1px 4px rgba(0,0,0,0.15);
        }
        .toggle-switch input:checked + .toggle-slider { background: var(--dar-green); }
        .toggle-switch input:checked + .toggle-slider::before { transform: translateX(22px); }

        /* BUTTONS */
        .btn {
            padding: 11px 24px; border: none; border-radius: 8px;
            font-size: 0.88rem; font-weight: 600; cursor: pointer;
            transition: var(--transition); display: inline-flex;
            align-items: center; gap: 8px; font-family: 'Poppins', sans-serif;
        }
        .btn-primary { background: var(--dar-green); color: white; }
        .btn-primary:hover { background: var(--dar-dark-green); box-shadow: 0 4px 14px rgba(0,100,0,0.3); }
        .btn-danger { background: var(--danger); color: white; }
        .btn-danger:hover { background: #dc2626; box-shadow: 0 4px 14px rgba(239,68,68,0.3); }
        .btn-outline {
            background: transparent; color: var(--text-muted);
            border: 1.5px solid #e5e7eb;
        }
        .btn-outline:hover { border-color: var(--dar-green); color: var(--dar-green); background: #f0fdf4; }
        .btn-warning { background: var(--warning); color: white; }
        .btn-warning:hover { background: #d97706; }
        .btn-sm { padding: 8px 16px; font-size: 0.82rem; }
        .form-actions { display: flex; gap: 12px; margin-top: 24px; padding-top: 20px; border-top: 1px solid #f0f0f0; }

        /* INFO GRID */
        .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0; }
        .info-item {
            padding: 16px 24px; border-bottom: 1px solid #f5f5f5;
            display: flex; justify-content: space-between; align-items: center;
        }
        .info-item:nth-child(odd) { border-right: 1px solid #f5f5f5; }
        .info-item .label { font-size: 0.82rem; color: var(--text-muted); font-weight: 500; }
        .info-item .value { font-size: 0.85rem; font-weight: 600; color: var(--text-dark); text-align: right; }
        .info-item .value.mono { font-family: 'Courier New', monospace; font-size: 0.82rem; color: var(--dar-green); }

        /* TABLE LIST */
        .table-list { width: 100%; border-collapse: collapse; }
        .table-list th {
            text-align: left; padding: 12px 20px; font-size: 0.75rem;
            font-weight: 600; color: var(--text-muted); text-transform: uppercase;
            letter-spacing: 0.5px; background: #fafafa; border-bottom: 1px solid #f0f0f0;
        }
        .table-list td {
            padding: 12px 20px; font-size: 0.87rem;
            border-bottom: 1px solid #f8f8f8;
        }
        .table-list tr:hover td { background: #fafafa; }
        .table-list tr:last-child td { border-bottom: none; }
        .table-name { font-family: 'Courier New', monospace; font-weight: 600; color: var(--dar-green); font-size: 0.84rem; }
        .row-count {
            display: inline-flex; align-items: center; gap: 5px;
            padding: 3px 10px; border-radius: 20px; font-size: 0.75rem; font-weight: 600;
            background: #f0fdf4; color: var(--success);
        }

        /* DANGER ZONE */
        .danger-zone { border-color: #fecaca; }
        .danger-zone .card-header { background: #fef2f2; border-bottom-color: #fecaca; }
        .danger-zone .card-header h3 i { color: var(--danger); }
        .danger-item {
            display: flex; justify-content: space-between; align-items: center;
            padding: 18px 0; border-bottom: 1px solid #f5f5f5;
        }
        .danger-item:last-child { border-bottom: none; }
        .danger-item h4 { font-size: 0.88rem; font-weight: 600; color: var(--text-dark); margin-bottom: 3px; }
        .danger-item p { font-size: 0.78rem; color: var(--text-muted); }

        /* AVATAR SECTION */
        .profile-header {
            display: flex; align-items: center; gap: 24px;
            padding: 24px; background: linear-gradient(135deg, #f0fdf4, #ecfdf5);
            border-bottom: 1px solid #e5e7eb;
        }
        .profile-avatar-lg {
            width: 80px; height: 80px; border-radius: 50%;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            display: flex; align-items: center; justify-content: center;
            color: white; font-weight: 800; font-size: 1.8rem; flex-shrink: 0;
            box-shadow: 0 4px 14px rgba(0,100,0,0.2);
        }
        .profile-header-info h3 { font-size: 1.15rem; font-weight: 700; margin-bottom: 2px; }
        .profile-header-info p { font-size: 0.85rem; color: var(--text-muted); }
        .profile-header-info .role-badge {
            display: inline-flex; align-items: center; gap: 5px;
            padding: 4px 12px; border-radius: 20px; font-size: 0.72rem;
            font-weight: 600; background: var(--dar-green); color: white; margin-top: 6px;
        }

        /* PASSWORD STRENGTH */
        .pw-strength { display: flex; gap: 4px; margin-top: 8px; }
        .pw-bar { height: 4px; flex: 1; border-radius: 4px; background: #e5e7eb; transition: var(--transition); }
        .pw-strength-text { font-size: 0.75rem; margin-top: 4px; font-weight: 600; }

        /* MODAL */
        .modal-overlay {
            position: fixed; inset: 0; background: rgba(0,0,0,0.5);
            z-index: 9998; display: none; align-items: center; justify-content: center;
            backdrop-filter: blur(4px);
        }
        .modal-overlay.show { display: flex; }
        .modal-box {
            background: white; border-radius: var(--radius);
            padding: 32px; max-width: 440px; width: 90%;
            box-shadow: var(--shadow-lg); text-align: center;
            animation: modalIn 0.3s ease;
        }
        @keyframes modalIn { from { transform: scale(0.9); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        .modal-icon {
            width: 60px; height: 60px; border-radius: 50%; margin: 0 auto 16px;
            display: flex; align-items: center; justify-content: center; font-size: 1.5rem;
        }
        .modal-icon.danger { background: #fef2f2; color: var(--danger); }
        .modal-icon.warning { background: #fefce8; color: var(--warning); }
        .modal-box h3 { font-size: 1.1rem; font-weight: 700; margin-bottom: 8px; }
        .modal-box p { font-size: 0.88rem; color: var(--text-muted); margin-bottom: 24px; line-height: 1.5; }
        .modal-actions { display: flex; gap: 10px; justify-content: center; }

        /* SECTION DIVIDER */
        .section-divider {
            font-size: 0.78rem; font-weight: 700; text-transform: uppercase;
            letter-spacing: 1px; color: var(--text-muted); margin: 28px 0 16px;
            padding-bottom: 8px; border-bottom: 2px solid #f0f0f0;
            display: flex; align-items: center; gap: 8px;
        }
        .section-divider:first-child { margin-top: 0; }

        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; }
            .form-grid { grid-template-columns: 1fr; }
            .form-grid-3 { grid-template-columns: 1fr; }
            .info-grid { grid-template-columns: 1fr; }
            .info-item:nth-child(odd) { border-right: none; }
        }
        @media (max-width: 640px) {
            .content { padding: 20px; }
            .settings-tabs { gap: 4px; padding: 4px; }
            .tab-btn { padding: 9px 14px; font-size: 0.8rem; }
            .profile-header { flex-direction: column; text-align: center; }
            .form-actions { flex-direction: column; }
            .form-actions .btn { justify-content: center; }
        }
    </style>
</head>
<body>

<!-- TOAST -->
<?php if (!empty($toast_msg)): ?>
<div class="toast <?php echo $toast_type; ?>" id="toast">
    <i class="fas fa-<?php echo $toast_type === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
    <?php echo htmlspecialchars($toast_msg); ?>
</div>
<?php endif; ?>

<!-- CONFIRM MODAL -->
<div class="modal-overlay" id="confirmModal">
    <div class="modal-box">
        <div class="modal-icon danger" id="modalIcon"><i class="fas fa-exclamation-triangle"></i></div>
        <h3 id="modalTitle">Are you sure?</h3>
        <p id="modalMessage">This action cannot be undone.</p>
        <div class="modal-actions">
            <button class="btn btn-outline btn-sm" onclick="closeModal()">Cancel</button>
            <button class="btn btn-danger btn-sm" id="modalConfirmBtn" onclick="closeModal()">Confirm</button>
        </div>
    </div>
</div>

<div class="dashboard">
    <!-- SIDEBAR -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">DAR</div>
            <h3>Admin Dashboard</h3>
            <p>Employee Records Management</p>
        </div>
        <nav class="nav-menu">
            <a href="dashboard_admin.php" class="nav-item"><i class="fas fa-home"></i> Dashboard</a>
            <div class="nav-divider"></div>
            <div class="nav-label">People</div>
            <a href="employees.php" class="nav-item"><i class="fas fa-users"></i> Employees</a>
            <div class="nav-divider"></div>
            <div class="nav-label">Recruitment</div>
            <a href="positions.php" class="nav-item"><i class="fas fa-briefcase"></i> Vacant Positions</a>
            <a href="applications.php" class="nav-item"><i class="fas fa-file-alt"></i> Job Applications</a>
            <div class="nav-divider"></div>
            <div class="nav-label">Records</div>
            <a href="trainings.php" class="nav-item"><i class="fas fa-graduation-cap"></i> Trainings</a>
            <a href="document_tracking.php" class="nav-item"><i class="fas fa-exchange-alt"></i> Doc Tracking</a>
            <a href="documents.php" class="nav-item"><i class="fas fa-folder-open"></i> Documents</a>
            <div class="nav-divider"></div>
            <div class="nav-label">System</div>
            <a href="reports.php" class="nav-item"><i class="fas fa-chart-bar"></i> Reports</a>
            <a href="calendar_admin.php" class="nav-item"><i class="fas fa-calendar-alt"></i> Calendar</a>
            <a href="settings.php" class="nav-item active"><i class="fas fa-cog"></i> Settings</a>
        </nav>
        <div class="sidebar-footer">
            <div class="user-info">
                <div class="user-avatar"><?php echo strtoupper(substr($admin_name, 0, 1)); ?></div>
                <div class="user-details">
                    <h4><?php echo htmlspecialchars($admin_name); ?></h4>
                    <p><?php echo ucfirst($role); ?></p>
                </div>
            </div>
            <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </aside>

    <!-- MAIN -->
    <main class="main-content">
        <div class="top-bar">
            <div style="display:flex;align-items:center;gap:12px;">
                <button class="btn-outline btn-sm" style="display:none;padding:8px 10px;border-radius:8px;border:1.5px solid #e5e7eb;background:transparent;cursor:pointer;" id="menuToggle" onclick="document.getElementById('sidebar').classList.toggle('open')">
                    <i class="fas fa-bars"></i>
                </button>
                <h2><i class="fas fa-cog" style="margin-right:10px;color:var(--dar-green);"></i>Settings</h2>
            </div>
            <div class="top-bar-actions">
                <span style="font-size:0.88rem;color:var(--text-muted);font-weight:500;">
                    <i class="fas fa-calendar-day" style="margin-right:6px;"></i><?php echo date('l, F d, Y'); ?>
                </span>
            </div>
        </div>

        <div class="content">

            <!-- TABS -->
            <div class="settings-tabs">
                <button class="tab-btn active" data-tab="profile"><i class="fas fa-user-circle"></i> Profile</button>
                <button class="tab-btn" data-tab="system"><i class="fas fa-sliders-h"></i> System</button>
                <button class="tab-btn" data-tab="notifications"><i class="fas fa-bell"></i> Notifications</button>
                <button class="tab-btn" data-tab="security"><i class="fas fa-shield-alt"></i> Security</button>
                <button class="tab-btn" data-tab="database"><i class="fas fa-database"></i> Database</button>
                <button class="tab-btn" data-tab="about"><i class="fas fa-info-circle"></i> About</button>
            </div>

            <!-- ===================== PROFILE TAB ===================== -->
            <div class="settings-panel active" id="panel-profile">

                <!-- Profile Header -->
                <div class="card">
                    <div class="profile-header">
                        <div class="profile-avatar-lg"><?php echo strtoupper(substr($admin_name, 0, 1)); ?></div>
                        <div class="profile-header-info">
                            <h3><?php echo htmlspecialchars($admin_name); ?></h3>
                            <p><?php echo htmlspecialchars($admin_info['email'] ?? 'No email set'); ?></p>
                            <span class="role-badge"><i class="fas fa-shield-alt" style="font-size:0.65rem;"></i> <?php echo ucfirst($role); ?></span>
                        </div>
                    </div>
                </div>

                <!-- Edit Profile -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-edit"></i> Edit Profile</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="action" value="update_profile">
                            <div class="form-grid">
                                <div class="form-group">
                                    <label class="form-label">Full Name <span class="required">*</span></label>
                                    <input type="text" class="form-input" name="admin_name" value="<?php echo htmlspecialchars($admin_info['name'] ?? $admin_name); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Email Address</label>
                                    <input type="email" class="form-input" name="admin_email" value="<?php echo htmlspecialchars($admin_info['email'] ?? ''); ?>">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Phone Number</label>
                                    <input type="text" class="form-input" name="admin_phone" value="<?php echo htmlspecialchars($admin_info['phone'] ?? ''); ?>" placeholder="e.g. 0917-123-4567">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Username</label>
                                    <input type="text" class="form-input" value="<?php echo htmlspecialchars($admin_info['username'] ?? ''); ?>" disabled>
                                    <div class="form-hint">Username cannot be changed here.</div>
                                </div>
                            </div>
                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
                                <button type="reset" class="btn btn-outline">Reset</button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Change Password -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-key"></i> Change Password</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST" id="pwForm">
                            <input type="hidden" name="action" value="change_password">
                            <div class="form-grid">
                                <div class="form-group">
                                    <label class="form-label">Current Password <span class="required">*</span></label>
                                    <input type="password" class="form-input" name="current_password" id="current_password" required placeholder="Enter current password">
                                </div>
                                <div class="form-group"></div>
                                <div class="form-group">
                                    <label class="form-label">New Password <span class="required">*</span></label>
                                    <input type="password" class="form-input" name="new_password" id="new_password" required placeholder="Min. 8 characters" oninput="checkPwStrength(this.value)">
                                    <div class="pw-strength" id="pwStrength">
                                        <div class="pw-bar" id="pwBar1"></div>
                                        <div class="pw-bar" id="pwBar2"></div>
                                        <div class="pw-bar" id="pwBar3"></div>
                                        <div class="pw-bar" id="pwBar4"></div>
                                    </div>
                                    <div class="pw-strength-text" id="pwStrengthText"></div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Confirm New Password <span class="required">*</span></label>
                                    <input type="password" class="form-input" name="confirm_password" id="confirm_password" required placeholder="Re-enter new password">
                                </div>
                            </div>
                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary"><i class="fas fa-lock"></i> Update Password</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- ===================== SYSTEM TAB ===================== -->
            <div class="settings-panel" id="panel-system">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-building"></i> Office Information</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="action" value="update_system">
                            <div class="form-grid">
                                <div class="form-group full">
                                    <label class="form-label">System Name</label>
                                    <input type="text" class="form-input" name="system_name" value="<?php echo htmlspecialchars($system_settings['system_name']); ?>">
                                </div>
                                <div class="form-group full">
                                    <label class="form-label">Office / Agency Name</label>
                                    <input type="text" class="form-input" name="office_name" value="<?php echo htmlspecialchars($system_settings['office_name']); ?>">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Region</label>
                                    <input type="text" class="form-input" name="region" value="<?php echo htmlspecialchars($system_settings['region']); ?>">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Contact Email</label>
                                    <input type="email" class="form-input" name="contact_email" value="<?php echo htmlspecialchars($system_settings['contact_email']); ?>">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Contact Phone</label>
                                    <input type="text" class="form-input" name="contact_phone" value="<?php echo htmlspecialchars($system_settings['contact_phone']); ?>">
                                </div>
                            </div>

                            <div class="section-divider"><i class="fas fa-palette"></i> Display Settings</div>
                            <div class="form-grid">
                                <div class="form-group">
                                    <label class="form-label">Date Format</label>
                                    <select class="form-select" name="date_format">
                                        <?php
                                        $date_formats = [
                                            'M d, Y' => 'Jan 15, 2025',
                                            'F d, Y' => 'January 15, 2025',
                                            'm/d/Y' => '01/15/2025',
                                            'd-m-Y' => '15-01-2025',
                                            'Y-m-d' => '2025-01-15',
                                        ];
                                        foreach ($date_formats as $val => $label): ?>
                                        <option value="<?php echo $val; ?>" <?php echo $system_settings['date_format'] === $val ? 'selected' : ''; ?>><?php echo $label; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Items Per Page <small>(Tables)</small></label>
                                    <select class="form-select" name="items_per_page">
                                        <?php foreach ([10,15,25,50,100] as $n): ?>
                                        <option value="<?php echo $n; ?>" <?php echo $system_settings['items_per_page'] == $n ? 'selected' : ''; ?>><?php echo $n; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save System Settings</button>
                                <button type="reset" class="btn btn-outline">Reset</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- ===================== NOTIFICATIONS TAB ===================== -->
            <div class="settings-panel" id="panel-notifications">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-bell"></i> Notification Preferences</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="action" value="update_system">

                            <div class="section-divider"><i class="fas fa-envelope"></i> Email Notifications</div>
                            <div class="toggle-row">
                                <div class="toggle-info">
                                    <h4>Email Notifications</h4>
                                    <p>Send email alerts for important system events</p>
                                </div>
                                <label class="toggle-switch">
                                    <input type="checkbox" name="email_notifications" value="1" <?php echo $system_settings['email_notifications'] == 1 ? 'checked' : ''; ?>>
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>
                            <div class="toggle-row">
                                <div class="toggle-info">
                                    <h4>New Application Alerts</h4>
                                    <p>Get notified when a new job application is submitted</p>
                                </div>
                                <label class="toggle-switch">
                                    <input type="checkbox" name="new_app_alert" value="1" checked>
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>
                            <div class="toggle-row">
                                <div class="toggle-info">
                                    <h4>Document Routing Alerts</h4>
                                    <p>Receive alerts when documents are forwarded to your office</p>
                                </div>
                                <label class="toggle-switch">
                                    <input type="checkbox" name="doc_routing_alert" value="1" checked>
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>

                            <div class="section-divider"><i class="fas fa-cog"></i> System Preferences</div>
                            <div class="toggle-row">
                                <div class="toggle-info">
                                    <h4>Allow Public Registration</h4>
                                    <p>Let applicants create accounts without admin approval</p>
                                </div>
                                <label class="toggle-switch">
                                    <input type="checkbox" name="allow_registration" value="1" <?php echo $system_settings['allow_registration'] == 1 ? 'checked' : ''; ?>>
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>
                            <div class="toggle-row">
                                <div class="toggle-info">
                                    <h4>Automatic Database Backup</h4>
                                    <p>Automatically backup database daily (requires cron job setup)</p>
                                </div>
                                <label class="toggle-switch">
                                    <input type="checkbox" name="auto_backup" value="1" <?php echo $system_settings['auto_backup'] == 1 ? 'checked' : ''; ?>>
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>
                            <div class="toggle-row">
                                <div class="toggle-info">
                                    <h4>Maintenance Mode</h4>
                                    <p>Temporarily disable public access for system updates</p>
                                </div>
                                <label class="toggle-switch">
                                    <input type="checkbox" name="maintenance_mode" value="1" <?php echo $system_settings['maintenance_mode'] == 1 ? 'checked' : ''; ?>>
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>

                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Preferences</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- ===================== SECURITY TAB ===================== -->
            <div class="settings-panel" id="panel-security">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-shield-alt"></i> Security Settings</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="action" value="update_system">
                            <div class="form-grid">
                                <div class="form-group">
                                    <label class="form-label">Session Timeout <small>(minutes)</small></label>
                                    <input type="number" class="form-input" name="session_timeout" value="<?php echo htmlspecialchars($system_settings['session_timeout']); ?>" min="5" max="240">
                                    <div class="form-hint">Auto-logout after inactivity (5–240 min)</div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Max Login Attempts</label>
                                    <input type="number" class="form-input" name="max_login_attempts" value="<?php echo htmlspecialchars($system_settings['max_login_attempts']); ?>" min="1" max="20">
                                    <div class="form-hint">Lock account after failed attempts</div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Min. Password Length</label>
                                    <input type="number" class="form-input" name="password_min_length" value="<?php echo htmlspecialchars($system_settings['password_min_length']); ?>" min="6" max="32">
                                    <div class="form-hint">Minimum characters for new passwords</div>
                                </div>
                            </div>
                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Security Settings</button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Active Sessions Info -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-desktop"></i> Current Session</h3>
                    </div>
                    <div class="card-body" style="padding:0;">
                        <div class="info-grid">
                            <div class="info-item">
                                <span class="label">Browser</span>
                                <span class="value"><?php echo htmlspecialchars($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="label">IP Address</span>
                                <span class="value mono"><?php echo $_SERVER['REMOTE_ADDR'] ?? 'Unknown'; ?></span>
                            </div>
                            <div class="info-item">
                                <span class="label">Login Time</span>
                                <span class="value"><?php echo date('M d, Y h:i A', strtotime($_SESSION['login_time'] ?? 'now')); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="label">Session ID</span>
                                <span class="value mono" style="font-size:0.7rem;"><?php echo substr(session_id(), 0, 16) . '...'; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ===================== DATABASE TAB ===================== -->
            <div class="settings-panel" id="panel-database">

                <!-- DB Info -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-database"></i> Database Overview</h3>
                        <span style="font-size:0.82rem;color:var(--text-muted);font-weight:600;">Size: <?php echo $db_size; ?></span>
                    </div>
                    <div class="card-body" style="padding:0;">
                        <table class="table-list">
                            <thead>
                                <tr>
                                    <th>Table Name</th>
                                    <th>Rows</th>
                                    <th style="width:100px;">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($table_info as $ti): ?>
                                <tr>
                                    <td><span class="table-name"><?php echo htmlspecialchars($ti['name']); ?></span></td>
                                    <td><span class="row-count"><i class="fas fa-table" style="font-size:0.6rem;"></i> <?php echo number_format($ti['rows']); ?></span></td>
                                    <td><span style="font-size:0.78rem;color:var(--success);font-weight:600;"><i class="fas fa-check-circle"></i> OK</span></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Maintenance Actions -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-wrench"></i> Maintenance Actions</h3>
                    </div>
                    <div class="card-body">
                        <div class="danger-item">
                            <div>
                                <h4>Optimize Database</h4>
                                <p>Reorganize tables and reclaim unused space. Safe operation.</p>
                            </div>
                            <button class="btn btn-primary btn-sm" onclick="confirmAction('optimize', 'Optimize Database?', 'This will run OPTIMIZE TABLE on all database tables. The process is safe and may take a few moments.')">
                                <i class="fas fa-compress-arrows-alt"></i> Optimize
                            </button>
                        </div>
                        <div class="danger-item">
                            <div>
                                <h4>Clear System Logs</h4>
                                <p>Permanently delete all activity logs. This cannot be undone.</p>
                            </div>
                            <button class="btn btn-danger btn-sm" onclick="confirmAction('clear_logs', 'Clear All Logs?', 'This will permanently delete all system activity logs. This action cannot be undone.')">
                                <i class="fas fa-trash-alt"></i> Clear Logs
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Hidden form for actions -->
                <form method="POST" id="actionForm" style="display:none;">
                    <input type="hidden" name="action" id="actionInput" value="">
                </form>
            </div>

            <!-- ===================== ABOUT TAB ===================== -->
            <div class="settings-panel" id="panel-about">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-info-circle"></i> System Information</h3>
                    </div>
                    <div class="card-body" style="padding:0;">
                        <div class="info-grid">
                            <div class="info-item">
                                <span class="label">System Name</span>
                                <span class="value"><?php echo htmlspecialchars($system_settings['system_name']); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="label">Version</span>
                                <span class="value mono"><?php echo htmlspecialchars($system_settings['system_version']); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="label">Office</span>
                                <span class="value"><?php echo htmlspecialchars($system_settings['office_name']); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="label">Region</span>
                                <span class="value"><?php echo htmlspecialchars($system_settings['region']); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="label">Database Size</span>
                                <span class="value mono"><?php echo $db_size; ?></span>
                            </div>
                            <div class="info-item">
                                <span class="label">Total Tables</span>
                                <span class="value"><?php echo count($table_info); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-server"></i> Server Environment</h3>
                    </div>
                    <div class="card-body" style="padding:0;">
                        <div class="info-grid">
                            <?php foreach ($server_info as $label => $value): ?>
                            <div class="info-item">
                                <span class="label"><?php echo htmlspecialchars($label); ?></span>
                                <span class="value mono" style="font-size:0.8rem;"><?php echo htmlspecialchars($value); ?></span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <div style="text-align:center;padding:30px 0;color:var(--text-muted);font-size:0.82rem;">
                    <p style="margin-bottom:4px;"><strong style="color:var(--dar-green);">DAR Employee Records Management System</strong></p>
                    <p>&copy; <?php echo date('Y'); ?> Department of Agrarian Reform. All rights reserved.</p>
                    <p style="margin-top:8px;font-size:0.75rem;">Developed for DAR Regional Office III</p>
                </div>
            </div>

        </div>
    </main>
</div>

<script>
// === TAB SWITCHING ===
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.settings-panel').forEach(p => p.classList.remove('active'));
        this.classList.add('active');
        document.getElementById('panel-' + this.dataset.tab).classList.add('active');
    });
});

// === TOAST ===
<?php if (!empty($toast_msg)): ?>
setTimeout(() => {
    const t = document.getElementById('toast');
    if (t) { t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 4000); }
}, 200);
<?php endif; ?>

// === PASSWORD STRENGTH ===
function checkPwStrength(pw) {
    let score = 0;
    if (pw.length >= 8) score++;
    if (pw.length >= 12) score++;
    if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
    if (/[0-9]/.test(pw)) score++;
    if (/[^A-Za-z0-9]/.test(pw)) score++;
    score = Math.min(score, 4);

    const colors = ['#ef4444','#f59e0b','#eab308','#22c55e'];
    const labels = ['Weak','Fair','Good','Strong'];
    const bars = [document.getElementById('pwBar1'),document.getElementById('pwBar2'),document.getElementById('pwBar3'),document.getElementById('pwBar4')];
    const txt = document.getElementById('pwStrengthText');

    bars.forEach((b, i) => {
        b.style.background = i < score ? colors[score - 1] : '#e5e7eb';
    });
    if (pw.length === 0) {
        txt.textContent = '';
    } else {
        txt.textContent = labels[score - 1] || 'Too short';
        txt.style.color = score > 0 ? colors[score - 1] : '#ef4444';
    }
}

// === CONFIRM MODAL ===
let pendingAction = '';
function confirmAction(action, title, message) {
    pendingAction = action;
    document.getElementById('modalTitle').textContent = title;
    document.getElementById('modalMessage').textContent = message;
    document.getElementById('confirmModal').classList.add('show');
}
function closeModal() {
    document.getElementById('confirmModal').classList.remove('show');
    if (pendingAction) {
        document.getElementById('actionInput').value = pendingAction;
        document.getElementById('actionForm').submit();
        pendingAction = '';
    }
}
// Close modal on overlay click
document.getElementById('confirmModal').addEventListener('click', function(e) {
    if (e.target === this) closeModal();
});

// === MOBILE MENU ===
function checkMobile() {
    const toggle = document.getElementById('menuToggle');
    if (window.innerWidth <= 1024) {
        toggle.style.display = 'flex';
    } else {
        toggle.style.display = 'none';
        document.getElementById('sidebar').classList.remove('open');
    }
}
checkMobile();
window.addEventListener('resize', checkMobile);

// === PASSWORD FORM VALIDATION ===
document.getElementById('pwForm').addEventListener('submit', function(e) {
    const np = document.getElementById('new_password').value;
    const cp = document.getElementById('confirm_password').value;
    if (np !== cp) {
        e.preventDefault();
        alert('New passwords do not match.');
        return false;
    }
    if (np.length < 8) {
        e.preventDefault();
        alert('Password must be at least 8 characters.');
        return false;
    }
});
</script>

</body>
</html>