<?php
session_start();
require_once 'db_config.php';

// Check if applicant is logged in
requireLogin('applicant', 'login_applicant.php');

$page_title = "Applicant Dashboard - DAR";

$applicant_id = $_SESSION['applicant_id'];
$applicant_name = $_SESSION['applicant_name'];

// Fetch applicant details
$applicant = $conn->query("SELECT * FROM applicants WHERE id = $applicant_id")->fetch_assoc();

// Fetch application status
$application = $conn->query("SELECT ja.*, p.position_title, p.department, p.salary_grade, p.monthly_salary 
                               FROM job_applications ja 
                               LEFT JOIN vacant_positions p ON ja.position_id = p.id 
                               WHERE ja.applicant_id = $applicant_id 
                               ORDER BY ja.created_at DESC LIMIT 1")->fetch_assoc();

// Application status steps
$status_steps = [
    'submitted' => 1,
    'under_review' => 2,
    'shortlisted' => 3,
    'interview' => 4,
    'exam' => 5,
    'hired' => 6,
    'rejected' => 0
];

$current_step = $application ? ($status_steps[$application['status']] ?? 1) : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dar-green: #006400;
            --dar-dark-green: #004d00;
            --dar-light-green: #4CAF50;
            --dar-gold: #FFD700;
            --bg-light: #f8faf9;
            --sidebar-bg: #0d3b0d;
            --text-dark: #1a1a2e;
            --text-muted: #6b7280;
            --shadow: 0 4px 20px rgba(0,0,0,0.08);
            --shadow-lg: 0 10px 40px rgba(0,0,0,0.1);
            --radius: 12px;
            --transition: all 0.3s ease;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: var(--bg-light); color: var(--text-dark); }

        .dashboard { display: flex; min-height: 100vh; }
        
        .sidebar {
            width: 260px; background: var(--sidebar-bg);
            color: white; position: fixed; top: 0; left: 0; bottom: 0;
            overflow-y: auto; z-index: 100; transition: var(--transition);
        }
        .sidebar-header {
            padding: 25px 20px; text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .sidebar-logo {
            width: 55px; height: 55px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 800; font-size: 18px;
            margin: 0 auto 15px;
        }
        .sidebar-header h3 { font-size: 1rem; font-weight: 600; }
        .sidebar-header p { font-size: 0.75rem; opacity: 0.7; margin-top: 3px; }

        .nav-menu { padding: 20px 0; }
        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 14px 25px; color: rgba(255,255,255,0.8);
            text-decoration: none; font-size: 0.9rem; font-weight: 500;
            transition: var(--transition); border-left: 3px solid transparent;
        }
        .nav-item:hover, .nav-item.active {
            background: rgba(255,255,255,0.05);
            color: white; border-left-color: var(--dar-gold);
        }
        .nav-item i { width: 20px; text-align: center; font-size: 1rem; }

        .sidebar-footer {
            position: absolute; bottom: 0; left: 0; right: 0;
            padding: 20px; border-top: 1px solid rgba(255,255,255,0.1);
        }
        .user-info { display: flex; align-items: center; gap: 12px; }
        .user-avatar {
            width: 40px; height: 40px;
            background: linear-gradient(135deg, #3b82f6, #60a5fa);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: white; font-weight: 700; font-size: 0.9rem;
        }
        .user-details h4 { font-size: 0.85rem; font-weight: 600; }
        .user-details p { font-size: 0.75rem; opacity: 0.6; }
        .logout-btn {
            display: flex; align-items: center; gap: 8px;
            color: rgba(255,255,255,0.7); text-decoration: none;
            font-size: 0.8rem; margin-top: 12px; transition: var(--transition);
        }
        .logout-btn:hover { color: #ef4444; }

        .main-content {
            flex: 1; margin-left: 260px; min-height: 100vh;
        }
        .top-bar {
            background: white; padding: 15px 30px;
            display: flex; justify-content: space-between; align-items: center;
            box-shadow: var(--shadow); position: sticky; top: 0; z-index: 50;
        }
        .top-bar h2 { font-size: 1.3rem; font-weight: 700; }
        .top-bar-actions { display: flex; align-items: center; gap: 15px; }
        .notification-btn {
            width: 40px; height: 40px; border-radius: 10px;
            background: var(--bg-light); border: none;
            display: flex; align-items: center; justify-content: center;
            color: var(--text-muted); cursor: pointer; transition: var(--transition);
        }
        .notification-btn:hover { background: #e8f5e9; color: var(--dar-green); }

        .content { padding: 30px; }

        /* Welcome Card */
        .welcome-card {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-dark-green));
            color: white; border-radius: var(--radius);
            padding: 35px; margin-bottom: 30px;
            box-shadow: var(--shadow-lg);
        }
        .welcome-card h2 { font-size: 1.8rem; font-weight: 700; margin-bottom: 8px; }
        .welcome-card p { opacity: 0.9; font-size: 1rem; }
        .welcome-stats {
            display: flex; gap: 30px; margin-top: 25px;
        }
        .welcome-stat {
            background: rgba(255,255,255,0.1); padding: 15px 25px;
            border-radius: var(--radius); backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.1);
        }
        .welcome-stat h4 { font-size: 1.4rem; font-weight: 800; }
        .welcome-stat p { font-size: 0.8rem; opacity: 0.8; margin: 0; }

        /* Application Status */
        .status-card {
            background: white; border-radius: var(--radius);
            padding: 30px; box-shadow: var(--shadow);
            border: 1px solid #f0f0f0; margin-bottom: 30px;
        }
        .status-card h3 {
            font-size: 1.2rem; font-weight: 700;
            margin-bottom: 25px; display: flex; align-items: center; gap: 10px;
        }
        .status-card h3 i { color: var(--dar-green); }

        .progress-tracker {
            display: flex; justify-content: space-between;
            position: relative; margin-bottom: 30px;
        }
        .progress-tracker::before {
            content: ''; position: absolute; top: 20px; left: 0; right: 0;
            height: 4px; background: #f0f0f0; border-radius: 2px;
        }
        .progress-line {
            position: absolute; top: 20px; left: 0;
            height: 4px; background: linear-gradient(90deg, var(--dar-green), var(--dar-light-green));
            border-radius: 2px; transition: width 0.5s ease;
        }
        .progress-step {
            display: flex; flex-direction: column; align-items: center;
            position: relative; z-index: 1;
        }
        .step-circle {
            width: 44px; height: 44px; border-radius: 50%;
            background: white; border: 3px solid #e5e7eb;
            display: flex; align-items: center; justify-content: center;
            font-size: 0.9rem; font-weight: 700; color: #9ca3af;
            transition: var(--transition);
        }
        .step-circle.active {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            border-color: var(--dar-green); color: white;
            box-shadow: 0 4px 15px rgba(0,100,0,0.3);
        }
        .step-circle.completed {
            background: var(--dar-green); border-color: var(--dar-green); color: white;
        }
        .step-circle.rejected {
            background: #ef4444; border-color: #ef4444; color: white;
        }
        .step-label {
            margin-top: 10px; font-size: 0.75rem;
            font-weight: 600; color: var(--text-muted);
            text-align: center; max-width: 80px;
        }
        .step-label.active { color: var(--dar-green); }

        .status-detail {
            background: #f8faf9; border-radius: var(--radius);
            padding: 20px; border-left: 4px solid var(--dar-green);
        }
        .status-detail h4 { color: var(--dar-green); font-size: 1rem; margin-bottom: 8px; }
        .status-detail p { color: var(--text-muted); font-size: 0.9rem; }
        .status-detail.rejected { border-left-color: #ef4444; }
        .status-detail.rejected h4 { color: #ef4444; }

        /* Info Cards */
        .info-grid {
            display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px; margin-bottom: 30px;
        }
        .info-card {
            background: white; border-radius: var(--radius);
            padding: 25px; box-shadow: var(--shadow);
            border: 1px solid #f0f0f0;
        }
        .info-card h3 {
            font-size: 1rem; color: var(--dar-green);
            margin-bottom: 20px; padding-bottom: 12px;
            border-bottom: 2px solid #f0f0f0;
                        display: flex; align-items: center; gap: 8px;
        }
        .info-row {
            display: flex; justify-content: space-between;
            padding: 10px 0; border-bottom: 1px solid #f8f8f8;
        }
        .info-row:last-child { border-bottom: none; }
        .info-row span:first-child { color: var(--text-muted); font-size: 0.9rem; }
        .info-row span:last-child { font-weight: 600; color: var(--text-dark); font-size: 0.9rem; }

        /* No Application State */
        .no-application {
            text-align: center; padding: 50px 20px;
        }
        .no-application i { font-size: 3.5rem; color: #e5e7eb; margin-bottom: 20px; }
        .no-application h3 { color: var(--text-dark); font-size: 1.3rem; margin-bottom: 10px; }
        .no-application p { color: var(--text-muted); margin-bottom: 25px; font-size: 0.95rem; }
        .btn-apply-now {
            display: inline-block;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; padding: 14px 35px; border-radius: 12px;
            text-decoration: none; font-weight: 600;
            transition: var(--transition);
        }
        .btn-apply-now:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0,100,0,0.3);
        }

        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .main-content { margin-left: 0; }
        }
        @media (max-width: 768px) {
            .welcome-stats { flex-wrap: wrap; gap: 15px; }
            .progress-tracker { overflow-x: auto; padding-bottom: 10px; }
            .step-label { font-size: 0.65rem; max-width: 60px; }
            .content { padding: 20px; }
        }
    </style>
</head>
<body>

    <div class="dashboard">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">DAR</div>
                <h3>Applicant Portal</h3>
                <p>Job Application Tracker</p>
            </div>
            
            <nav class="nav-menu">
                <a href="dashboard_applicant.php" class="nav-item active">
                    <i class="fas fa-home"></i> Dashboard
                </a>
                <a href="profile_applicant.php" class="nav-item">
                    <i class="fas fa-user"></i> My Profile
                </a>
                <a href="my_applications.php" class="nav-item">
                    <i class="fas fa-file-alt"></i> My Applications
                </a>
                <a href="vacant_positions.php" class="nav-item">
                    <i class="fas fa-briefcase"></i> Browse Jobs
                </a>
                <a href="settings_applicant.php" class="nav-item">
                    <i class="fas fa-cog"></i> Settings
                </a>
            </nav>

            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar"><?php echo strtoupper(substr($applicant_name, 0, 1)); ?></div>
                    <div class="user-details">
                        <h4><?php echo htmlspecialchars($applicant_name); ?></h4>
                        <p>Applicant</p>
                    </div>
                </div>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <div class="top-bar">
                <h2><i class="fas fa-home" style="margin-right: 10px; color: var(--dar-green);"></i>Applicant Dashboard</h2>
                <div class="top-bar-actions">
                    <button class="notification-btn"><i class="fas fa-bell"></i></button>
                    <span style="font-size: 0.9rem; color: var(--text-muted);"><?php echo date('F d, Y'); ?></span>
                </div>
            </div>

            <div class="content">
                <!-- Welcome Card -->
                <div class="welcome-card">
                    <h2>Welcome, <?php echo htmlspecialchars($applicant['first_name']); ?>! 👋</h2>
                    <p>Track your job application status and manage your profile here.</p>
                    <div class="welcome-stats">
                        <div class="welcome-stat">
                            <h4><?php echo htmlspecialchars($applicant['applicant_id']); ?></h4>
                            <p>Applicant ID</p>
                        </div>
                        <div class="welcome-stat">
                            <h4><?php echo ucfirst($applicant['education_level']); ?></h4>
                            <p>Education</p>
                        </div>
                        <div class="welcome-stat">
                            <h4><?php echo $applicant['years_experience']; ?> yr<?php echo $applicant['years_experience'] != 1 ? 's' : ''; ?></h4>
                            <p>Experience</p>
                        </div>
                    </div>
                </div>

                <?php if($application): ?>
                <!-- Application Status Tracker -->
                <div class="status-card">
                    <h3><i class="fas fa-tasks"></i> Application Status</h3>
                    
                    <div class="progress-tracker">
                        <div class="progress-line" style="width: <?php echo ($current_step - 1) * 20; ?>%;"></div>
                        
                        <div class="progress-step">
                            <div class="step-circle <?php echo $current_step >= 1 ? ($application['status'] == 'rejected' ? '' : 'completed') : ''; ?> <?php echo $application['status'] == 'submitted' ? 'active' : ''; ?>">
                                <i class="fas fa-paper-plane"></i>
                            </div>
                            <span class="step-label <?php echo $application['status'] == 'submitted' ? 'active' : ''; ?>">Submitted</span>
                        </div>
                        
                        <div class="progress-step">
                            <div class="step-circle <?php echo $current_step >= 2 ? 'completed' : ''; ?> <?php echo $application['status'] == 'under_review' ? 'active' : ''; ?>">
                                <i class="fas fa-search"></i>
                            </div>
                            <span class="step-label <?php echo $application['status'] == 'under_review' ? 'active' : ''; ?>">Under Review</span>
                        </div>
                        
                        <div class="progress-step">
                            <div class="step-circle <?php echo $current_step >= 3 ? 'completed' : ''; ?> <?php echo $application['status'] == 'shortlisted' ? 'active' : ''; ?>">
                                <i class="fas fa-list-check"></i>
                            </div>
                            <span class="step-label <?php echo $application['status'] == 'shortlisted' ? 'active' : ''; ?>">Shortlisted</span>
                        </div>
                        
                        <div class="progress-step">
                            <div class="step-circle <?php echo $current_step >= 4 ? 'completed' : ''; ?> <?php echo $application['status'] == 'interview' ? 'active' : ''; ?>">
                                <i class="fas fa-user-tie"></i>
                            </div>
                            <span class="step-label <?php echo $application['status'] == 'interview' ? 'active' : ''; ?>">Interview</span>
                        </div>
                        
                        <div class="progress-step">
                            <div class="step-circle <?php echo $current_step >= 5 ? 'completed' : ''; ?> <?php echo $application['status'] == 'exam' ? 'active' : ''; ?>">
                                <i class="fas fa-clipboard-check"></i>
                            </div>
                            <span class="step-label <?php echo $application['status'] == 'exam' ? 'active' : ''; ?>">Exam</span>
                        </div>
                        
                        <div class="progress-step">
                            <div class="step-circle <?php echo $current_step >= 6 ? 'completed' : ''; ?> <?php echo $application['status'] == 'hired' ? 'active' : ''; ?>">
                                <i class="fas fa-check"></i>
                            </div>
                            <span class="step-label <?php echo $application['status'] == 'hired' ? 'active' : ''; ?>">Hired</span>
                        </div>
                    </div>

                    <div class="status-detail <?php echo $application['status'] == 'rejected' ? 'rejected' : ''; ?>">
                        <h4>
                            <?php if($application['status'] == 'rejected'): ?>
                                <i class="fas fa-times-circle" style="margin-right: 8px;"></i>Application Rejected
                            <?php elseif($application['status'] == 'hired'): ?>
                                <i class="fas fa-trophy" style="margin-right: 8px;"></i>Congratulations! You've been hired!
                            <?php else: ?>
                                <i class="fas fa-info-circle" style="margin-right: 8px;"></i>Current Status: <?php echo ucwords(str_replace('_', ' ', $application['status'])); ?>
                            <?php endif; ?>
                        </h4>
                        <p>
                            <?php if($application['status'] == 'submitted'): ?>
                                Your application has been received and is awaiting review by our HR team.
                            <?php elseif($application['status'] == 'under_review'): ?>
                                Our HR team is currently reviewing your qualifications and documents.
                            <?php elseif($application['status'] == 'shortlisted'): ?>
                                Congratulations! You have been shortlisted for the next stage.
                            <?php elseif($application['status'] == 'interview'): ?>
                                You have been scheduled for an interview. Please check your email for details.
                            <?php elseif($application['status'] == 'exam'): ?>
                                You are required to take an examination. Details will be sent to your email.
                            <?php elseif($application['status'] == 'hired'): ?>
                                Welcome to DAR! Please proceed to HR for onboarding requirements.
                            <?php elseif($application['status'] == 'rejected'): ?>
                                We regret to inform you that your application was not successful at this time.
                            <?php endif; ?>
                        </p>
                        <?php if($application['remarks']): ?>
                        <p style="margin-top: 10px; padding-top: 10px; border-top: 1px dashed #e5e7eb;">
                            <strong>Remarks:</strong> <?php echo htmlspecialchars($application['remarks']); ?>
                        </p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Position Details -->
                <div class="info-grid">
                    <div class="info-card">
                        <h3><i class="fas fa-briefcase" style="color: var(--dar-green);"></i> Position Applied For</h3>
                        <div class="info-row">
                            <span>Position</span>
                            <span><?php echo htmlspecialchars($application['position_title']); ?></span>
                        </div>
                        <div class="info-row">
                            <span>Department</span>
                            <span><?php echo htmlspecialchars($application['department']); ?></span>
                        </div>
                        <div class="info-row">
                            <span>Salary Grade</span>
                            <span><?php echo htmlspecialchars($application['salary_grade']); ?></span>
                        </div>
                        <div class="info-row">
                            <span>Monthly Salary</span>
                            <span style="color: var(--dar-green); font-weight: 700;">₱<?php echo number_format($application['monthly_salary'], 2); ?></span>
                        </div>
                        <div class="info-row">
                            <span>Application Date</span>
                            <span><?php echo date('F d, Y', strtotime($application['created_at'])); ?></span>
                        </div>
                        <div class="info-row">
                            <span>Application Code</span>
                            <span style="font-family: monospace; font-size: 0.85rem;"><?php echo htmlspecialchars($application['application_code']); ?></span>
                        </div>
                    </div>

                    <div class="info-card">
                        <h3><i class="fas fa-user" style="color: var(--dar-green);"></i> Personal Information</h3>
                        <div class="info-row">
                            <span>Full Name</span>
                            <span><?php echo htmlspecialchars($applicant['first_name'] . ' ' . ($applicant['middle_name'] ? $applicant['middle_name'] . ' ' : '') . $applicant['last_name']); ?></span>
                        </div>
                        <div class="info-row">
                            <span>Date of Birth</span>
                            <span><?php echo date('F d, Y', strtotime($applicant['date_of_birth'])); ?></span>
                        </div>
                        <div class="info-row">
                            <span>Gender</span>
                            <span><?php echo $applicant['gender']; ?></span>
                        </div>
                        <div class="info-row">
                            <span>Civil Status</span>
                            <span><?php echo $applicant['civil_status']; ?></span>
                        </div>
                        <div class="info-row">
                            <span>Email</span>
                            <span><?php echo htmlspecialchars($applicant['email']); ?></span>
                        </div>
                        <div class="info-row">
                            <span>Phone</span>
                            <span><?php echo htmlspecialchars($applicant['phone']); ?></span>
                        </div>
                    </div>

                    <div class="info-card">
                        <h3><i class="fas fa-graduation-cap" style="color: var(--dar-green);"></i> Education & Experience</h3>
                        <div class="info-row">
                            <span>Education Level</span>
                            <span><?php echo $applicant['education_level']; ?></span>
                        </div>
                        <div class="info-row">
                            <span>School Graduated</span>
                            <span><?php echo htmlspecialchars($applicant['school_graduated'] ?: 'Not specified'); ?></span>
                        </div>
                        <div class="info-row">
                            <span>Course/Degree</span>
                            <span><?php echo htmlspecialchars($applicant['course'] ?: 'Not specified'); ?></span>
                        </div>
                        <div class="info-row">
                            <span>Years of Experience</span>
                            <span><?php echo $applicant['years_experience']; ?> year<?php echo $applicant['years_experience'] != 1 ? 's' : ''; ?></span>
                        </div>
                    </div>
                </div>

                <?php else: ?>
                <!-- No Application State -->
                <div class="status-card">
                    <div class="no-application">
                        <i class="fas fa-folder-open"></i>
                        <h3>No Active Application</h3>
                        <p>You haven't applied for any position yet. Browse our vacant positions and submit your application today!</p>
                        <a href="vacant_positions.php" class="btn-apply-now">
                            <i class="fas fa-search" style="margin-right: 8px;"></i>Browse Vacant Positions
                        </a>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

</body>
</html>