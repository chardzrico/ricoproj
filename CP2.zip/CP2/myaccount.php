<?php
session_start();
require_once 'db_config.php';

requireLogin('applicant', 'login_applicant.php');

 $page_title = "My Account - DAR Applicant Portal";

 $applicant_id = $_SESSION['applicant_id'];
 $applicant_name = $_SESSION['applicant_name'];

// Fetch applicant data
 $stmt = $conn->prepare("SELECT * FROM applicants WHERE id = ?");
 $stmt->bind_param("i", $applicant_id);
 $stmt->execute();
 $result = $stmt->get_result();
 $applicant = $result->fetch_assoc();

if (!$applicant) {
    die("Applicant record not found!");
}

// Handle password change
if (isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $_SESSION['error'] = "All password fields are required.";
    } elseif (!password_verify($current_password, $applicant['password'])) {
        $_SESSION['error'] = "Current password is incorrect.";
    } elseif (strlen($new_password) < 8) {
        $_SESSION['error'] = "New password must be at least 8 characters.";
    } elseif ($new_password !== $confirm_password) {
        $_SESSION['error'] = "New password and confirm password do not match.";
    } else {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE applicants SET password = ? WHERE id = ?");
        $stmt->bind_param("si", $hashed_password, $applicant_id);
        if ($stmt->execute()) {
            $_SESSION['success'] = "Password changed successfully.";
        } else {
            $_SESSION['error'] = "Failed to change password.";
        }
    }
    redirect('myaccount.php');
}

// Handle email change
if (isset($_POST['change_email'])) {
    $new_email = sanitize($conn, $_POST['new_email']);
    $email_password = $_POST['email_password'];

    if (empty($new_email) || empty($email_password)) {
        $_SESSION['error'] = "Email and password are required.";
    } elseif (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error'] = "Please enter a valid email address.";
    } elseif (!password_verify($email_password, $applicant['password'])) {
        $_SESSION['error'] = "Password is incorrect.";
    } else {
        // Check if email already exists
        $stmt = $conn->prepare("SELECT id FROM applicants WHERE email = ? AND id != ?");
        $stmt->bind_param("si", $new_email, $applicant_id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $_SESSION['error'] = "Email address is already in use.";
        } else {
            $stmt = $conn->prepare("UPDATE applicants SET email = ? WHERE id = ?");
            $stmt->bind_param("si", $new_email, $applicant_id);
            if ($stmt->execute()) {
                $_SESSION['success'] = "Email updated successfully.";
            } else {
                $_SESSION['error'] = "Failed to update email.";
            }
        }
    }
    redirect('myaccount.php');
}

// Handle account deactivation
if (isset($_POST['deactivate_account'])) {
    $deactivate_password = $_POST['deactivate_password'];
    if (empty($deactivate_password)) {
        $_SESSION['error'] = "Password is required to deactivate account.";
    } elseif (!password_verify($deactivate_password, $applicant['password'])) {
        $_SESSION['error'] = "Password is incorrect.";
    } else {
        $stmt = $conn->prepare("UPDATE applicants SET status = 'inactive' WHERE id = ?");
        $stmt->bind_param("i", $applicant_id);
        if ($stmt->execute()) {
            session_destroy();
            header("Location: login_applicant.php?msg=deactivated");
            exit();
        } else {
            $_SESSION['error'] = "Failed to deactivate account.";
        }
        redirect('myaccount.php');
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dar-green: #006400;
            --dar-dark-green: #004d00;
            --dar-light-green: #4CAF50;
            --dar-gold: #FFD700;
            --bg-light: #f8faf9;
            --sidebar-bg: #0d3b0d;
            --text-dark: #1a1a2e;
            --text-muted: #6b7280;
            --shadow: 0 4px 20px rgba(0,0,0,0.08);
            --shadow-lg: 0 10px 40px rgba(0,0,0,0.1);
            --radius: 12px;
            --transition: all 0.3s ease;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: var(--bg-light); color: var(--text-dark); }

        .dashboard { display: flex; min-height: 100vh; }

        .sidebar {
            width: 260px; background: var(--sidebar-bg);
            color: white; position: fixed; top: 0; left: 0; bottom: 0;
            overflow-y: auto; z-index: 100;
        }
        .sidebar-header { padding: 25px 20px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .sidebar-logo {
            width: 55px; height: 55px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 800; font-size: 18px; margin: 0 auto 15px;
        }
        .sidebar-header h3 { font-size: 1rem; font-weight: 600; }
        .sidebar-header p { font-size: 0.75rem; opacity: 0.7; margin-top: 3px; }

        .nav-menu { padding: 20px 0; }
        .nav-item {
            display: flex; align-items: center; gap: 12px; padding: 14px 25px;
            color: rgba(255,255,255,0.8); text-decoration: none; font-size: 0.9rem;
            font-weight: 500; transition: var(--transition); border-left: 3px solid transparent;
        }
        .nav-item:hover, .nav-item.active { background: rgba(255,255,255,0.05); color: white; border-left-color: var(--dar-gold); }
        .nav-item i { width: 20px; text-align: center; }

        .sidebar-footer { position: absolute; bottom: 0; left: 0; right: 0; padding: 20px; border-top: 1px solid rgba(255,255,255,0.1); }
        .user-info { display: flex; align-items: center; gap: 12px; }
        .user-avatar {
            width: 40px; height: 40px; background: linear-gradient(135deg, #3b82f6, #60a5fa);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: white; font-weight: 700; font-size: 0.9rem;
        }
        .user-details h4 { font-size: 0.85rem; font-weight: 600; }
        .user-details p { font-size: 0.75rem; opacity: 0.6; }
        .logout-btn {
            display: flex; align-items: center; gap: 8px; color: rgba(255,255,255,0.7);
            text-decoration: none; font-size: 0.8rem; margin-top: 12px; transition: var(--transition);
        }
        .logout-btn:hover { color: #ef4444; }

        .main-content { flex: 1; margin-left: 260px; min-height: 100vh; }
        .top-bar {
            background: white; padding: 15px 30px; display: flex; justify-content: space-between;
            align-items: center; box-shadow: var(--shadow); position: sticky; top: 0; z-index: 50;
        }
        .top-bar h2 { font-size: 1.3rem; font-weight: 700; }
        .content { padding: 30px; max-width: 800px; }

        .alert {
            padding: 15px 20px; border-radius: 10px; margin-bottom: 25px;
            display: flex; align-items: center; gap: 10px; font-size: 0.95rem;
            animation: slideDown 0.3s ease;
        }
        .alert-success { background: #f0fdf4; color: #16a34a; border: 1px solid #86efac; }
        .alert-error { background: #fef2f2; color: #dc2626; border: 1px solid #fca5a5; }
        @keyframes slideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }

        /* Account Overview */
        .account-overview {
            background: white; border-radius: var(--radius); padding: 30px;
            box-shadow: var(--shadow); border: 1px solid #f0f0f0; margin-bottom: 30px;
        }
        .account-header {
            display: flex; align-items: center; gap: 20px; margin-bottom: 25px;
            padding-bottom: 20px; border-bottom: 2px solid #f0f0f0;
        }
        .account-avatar {
            width: 70px; height: 70px; background: linear-gradient(135deg, #3b82f6, #60a5fa);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: white; font-size: 1.6rem; font-weight: 800; flex-shrink: 0;
        }
        .account-info h3 { font-size: 1.2rem; font-weight: 700; }
        .account-info p { color: var(--text-muted); font-size: 0.9rem; }
        .status-badge {
            display: inline-flex; align-items: center; gap: 5px; padding: 4px 12px;
            border-radius: 20px; font-size: 0.75rem; font-weight: 600; margin-top: 5px;
        }
        .status-active { background: #f0fdf4; color: #16a34a; }
        .status-inactive { background: #fef2f2; color: #dc2626; }

        .account-meta {
            display: grid; grid-template-columns: 1fr 1fr; gap: 15px;
        }
        .meta-item {
            display: flex; align-items: center; gap: 12px; padding: 12px 15px;
            background: var(--bg-light); border-radius: 10px;
        }
        .meta-icon {
            width: 40px; height: 40px; border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            font-size: 0.95rem; flex-shrink: 0;
        }
        .meta-icon.green { background: #f0fdf4; color: #16a34a; }
        .meta-icon.blue { background: #eff6ff; color: #3b82f6; }
        .meta-icon.yellow { background: #fefce8; color: #ca8a04; }
        .meta-icon.purple { background: #faf5ff; color: #9333ea; }
        .meta-text span { display: block; font-size: 0.75rem; color: var(--text-muted); }
        .meta-text strong { font-size: 0.9rem; color: var(--text-dark); }

        /* Settings Card */
        .settings-card {
            background: white; border-radius: var(--radius); padding: 30px;
            box-shadow: var(--shadow); border: 1px solid #f0f0f0; margin-bottom: 25px;
        }
        .settings-card h3 {
            font-size: 1.05rem; color: var(--dar-green); margin-bottom: 5px;
            display: flex; align-items: center; gap: 10px; font-weight: 700;
        }
        .settings-card .subtitle { color: var(--text-muted); font-size: 0.85rem; margin-bottom: 25px; }
        .form-group { margin-bottom: 18px; }
        .form-group label {
            display: block; margin-bottom: 6px; font-weight: 600; font-size: 0.85rem; color: var(--text-dark);
        }
        .form-group label i { margin-right: 6px; color: var(--dar-green); }
        .form-group input {
            width: 100%; padding: 12px 15px; border: 2px solid #e5e7eb; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            transition: var(--transition); background: #fafafa;
        }
        .form-group input:focus {
            outline: none; border-color: var(--dar-green);
            box-shadow: 0 0 0 4px rgba(0,100,0,0.08); background: white;
        }
        .form-group input::placeholder { color: #9ca3af; }
        .form-hint { font-size: 0.78rem; color: var(--text-muted); margin-top: 5px; }

        .password-strength { display: flex; gap: 4px; margin-top: 8px; }
        .strength-bar { height: 4px; flex: 1; border-radius: 2px; background: #e5e7eb; transition: var(--transition); }
        .strength-bar.weak { background: #ef4444; }
        .strength-bar.medium { background: #f59e0b; }
        .strength-bar.strong { background: #16a34a; }

        .btn-save {
            padding: 12px 30px;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; border: none; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            font-weight: 600; cursor: pointer; transition: var(--transition);
            display: inline-flex; align-items: center; gap: 8px;
        }
        .btn-save:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,100,0,0.3); }

        /* Danger Zone */
        .danger-zone {
            border: 2px solid #fecaca; background: #fff5f5;
        }
        .danger-zone h3 { color: #dc2626 !important; }
        .danger-zone h3 i { color: #dc2626 !important; }
        .btn-danger {
            padding: 12px 30px; background: #dc2626; color: white; border: none;
            border-radius: 10px; font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            font-weight: 600; cursor: pointer; transition: var(--transition);
            display: inline-flex; align-items: center; gap: 8px;
        }
        .btn-danger:hover { background: #b91c1c; transform: translateY(-2px); box-shadow: 0 8px 20px rgba(220,38,38,0.3); }

        .warning-box {
            background: #fefce8; border: 1px solid #fde68a; border-radius: 10px;
            padding: 15px; margin-bottom: 20px; display: flex; align-items: flex-start; gap: 10px;
        }
        .warning-box i { color: #ca8a04; margin-top: 2px; }
        .warning-box p { font-size: 0.85rem; color: #92400e; }

        @media (max-width: 1024px) { .sidebar { transform: translateX(-100%); } .main-content { margin-left: 0; } }
        @media (max-width: 768px) {
            .account-meta { grid-template-columns: 1fr; }
            .content { padding: 20px; }
        }
    </style>
</head>
<body>

    <div class="dashboard">
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">DAR</div>
                <h3>Applicant Portal</h3>
                <p>Job Application Tracker</p>
            </div>
            <nav class="nav-menu">
                <a href="dashboard_applicant.php" class="nav-item"><i class="fas fa-home"></i> Dashboard</a>
                <a href="profile_applicant.php" class="nav-item"><i class="fas fa-user"></i> My Profile</a>
                <a href="my_applications.php" class="nav-item"><i class="fas fa-file-alt"></i> My Applications</a>
                <a href="vacant_positions.php" class="nav-item"><i class="fas fa-briefcase"></i> Browse Jobs</a>
                <a href="myaccount.php" class="nav-item active"><i class="fas fa-user-cog"></i> My Account</a>
                <a href="settings_applicant.php" class="nav-item"><i class="fas fa-cog"></i> Settings</a>
            </nav>
            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar"><?php echo strtoupper(substr($applicant_name, 0, 1)); ?></div>
                    <div class="user-details">
                        <h4><?php echo htmlspecialchars($applicant_name); ?></h4>
                        <p>Applicant</p>
                    </div>
                </div>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </aside>

        <main class="main-content">
            <div class="top-bar">
                <h2><i class="fas fa-user-cog" style="margin-right: 10px; color: var(--dar-green);"></i>My Account</h2>
            </div>

            <div class="content">
                <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
                <?php endif; ?>

                <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                </div>
                <?php endif; ?>

                <!-- Account Overview -->
                <div class="account-overview">
                    <div class="account-header">
                        <div class="account-avatar"><?php echo strtoupper(substr($applicant['first_name'], 0, 1) . substr($applicant['last_name'], 0, 1)); ?></div>
                        <div class="account-info">
                            <h3><?php echo htmlspecialchars($applicant['first_name'] . ' ' . $applicant['last_name']); ?></h3>
                            <p><?php echo htmlspecialchars($applicant['email']); ?></p>
                            <span class="status-badge status-active">
                                <i class="fas fa-circle" style="font-size: 0.4rem;"></i>
                                <?php echo ucfirst($applicant['status'] ?? 'active'); ?>
                            </span>
                        </div>
                    </div>
                    <div class="account-meta">
                        <div class="meta-item">
                            <div class="meta-icon green"><i class="fas fa-id-card"></i></div>
                            <div class="meta-text">
                                <span>Applicant ID</span>
                                <strong><?php echo htmlspecialchars($applicant['applicant_id']); ?></strong>
                            </div>
                        </div>
                        <div class="meta-item">
                            <div class="meta-icon blue"><i class="fas fa-calendar"></i></div>
                            <div class="meta-text">
                                <span>Member Since</span>
                                <strong><?php echo date('F d, Y', strtotime($applicant['created_at'])); ?></strong>
                            </div>
                        </div>
                        <div class="meta-item">
                            <div class="meta-icon yellow"><i class="fas fa-clock"></i></div>
                            <div class="meta-text">
                                <span>Last Updated</span>
                                <strong><?php echo date('F d, Y', strtotime($applicant['updated_at'])); ?></strong>
                            </div>
                        </div>
                        <div class="meta-item">
                            <div class="meta-icon purple"><i class="fas fa-shield-alt"></i></div>
                            <div class="meta-text">
                                <span>Account Type</span>
                                <strong>Applicant</strong>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Change Password -->
                <div class="settings-card">
                    <h3><i class="fas fa-lock"></i> Change Password</h3>
                    <p class="subtitle">Ensure your account is secure by using a strong password.</p>
                    <form method="POST" action="">
                        <div class="form-group">
                            <label><i class="fas fa-key"></i>Current Password</label>
                            <input type="password" name="current_password" placeholder="Enter your current password" required>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-lock"></i>New Password</label>
                            <input type="password" name="new_password" id="new_password" placeholder="Enter new password (min 8 chars)" required>
                            <div class="password-strength">
                                <div class="strength-bar" id="str1"></div>
                                <div class="strength-bar" id="str2"></div>
                                <div class="strength-bar" id="str3"></div>
                                <div class="strength-bar" id="str4"></div>
                            </div>
                            <p class="form-hint" id="strength-text">Use 8+ characters with mix of letters, numbers & symbols</p>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-lock"></i>Confirm New Password</label>
                            <input type="password" name="confirm_password" placeholder="Re-enter new password" required>
                        </div>
                        <button type="submit" name="change_password" class="btn-save"><i class="fas fa-save"></i> Update Password</button>
                    </form>
                </div>

                <!-- Change Email -->
                <div class="settings-card">
                    <h3><i class="fas fa-envelope"></i> Change Email Address</h3>
                    <p class="subtitle">Update your email address used for login and notifications.</p>
                    <form method="POST" action="">
                        <div class="form-group">
                            <label><i class="fas fa-envelope"></i>Current Email</label>
                            <input type="email" value="<?php echo htmlspecialchars($applicant['email']); ?>" disabled style="opacity: 0.6; cursor: not-allowed;">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-at"></i>New Email Address</label>
                            <input type="email" name="new_email" placeholder="Enter new email address" required>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-key"></i>Confirm Password</label>
                            <input type="password" name="email_password" placeholder="Enter your password to confirm" required>
                        </div>
                        <button type="submit" name="change_email" class="btn-save"><i class="fas fa-save"></i> Update Email</button>
                    </form>
                </div>

                <!-- Danger Zone -->
                <div class="settings-card danger-zone">
                    <h3><i class="fas fa-exclamation-triangle"></i> Danger Zone</h3>
                    <p class="subtitle">Irreversible actions for your account.</p>
                    <div class="warning-box">
                        <i class="fas fa-info-circle"></i>
                        <p>Deactivating your account will remove your access to this portal. Your application data will be retained but you won't be able to log in. Contact HR to reactivate.</p>
                    </div>
                    <form method="POST" action="" onsubmit="return confirm('Are you sure you want to deactivate your account? This action cannot be easily undone.');">
                        <div class="form-group">
                            <label><i class="fas fa-key"></i>Enter Password to Confirm</label>
                            <input type="password" name="deactivate_password" placeholder="Enter your password" required>
                        </div>
                        <button type="submit" name="deactivate_account" class="btn-danger"><i class="fas fa-power-off"></i> Deactivate Account</button>
                    </form>
                </div>
            </div>
        </main>
    </div>

    <script>
        // Password strength checker
        const newPassInput = document.getElementById('new_password');
        const bars = [document.getElementById('str1'), document.getElementById('str2'), document.getElementById('str3'), document.getElementById('str4')];
        const strengthText = document.getElementById('strength-text');

        newPassInput.addEventListener('input', function() {
            const val = this.value;
            let score = 0;
            if (val.length >= 8) score++;
            if (/[A-Z]/.test(val)) score++;
            if (/[0-9]/.test(val)) score++;
            if (/[^A-Za-z0-9]/.test(val)) score++;

            bars.forEach(bar => bar.className = 'strength-bar');

            if (val.length === 0) {
                strengthText.textContent = 'Use 8+ characters with mix of letters, numbers & symbols';
                strengthText.style.color = '#6b7280';
            } else if (score <= 1) {
                for (let i = 0; i < score; i++) bars[i].classList.add('weak');
                strengthText.textContent = 'Weak password';
                strengthText.style.color = '#ef4444';
            } else if (score <= 2) {
                for (let i = 0; i < score; i++) bars[i].classList.add('medium');
                strengthText.textContent = 'Fair password';
                strengthText.style.color = '#f59e0b';
            } else if (score <= 3) {
                for (let i = 0; i < score; i++) bars[i].classList.add('strong');
                strengthText.textContent = 'Good password';
                strengthText.style.color = '#16a34a';
            } else {
                bars.forEach(bar => bar.classList.add('strong'));
                strengthText.textContent = 'Strong password!';
                strengthText.style.color = '#16a34a';
            }
        });
    </script>

</body>
</html>