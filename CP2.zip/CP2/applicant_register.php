<?php
session_start();
require_once 'db_config.php';

$page_title = "Applicant Registration - DAR";

// Get pre-selected position if provided
$selected_position = isset($_GET['position']) ? (int)$_GET['position'] : 0;

// Fetch open positions for dropdown
$positions = $conn->query("SELECT id, position_title FROM vacant_positions WHERE status = 'open' ORDER BY position_title");

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = sanitize($conn, $_POST['first_name']);
    $middle_name = sanitize($conn, $_POST['middle_name'] ?? '');
    $last_name = sanitize($conn, $_POST['last_name']);
    $suffix = sanitize($conn, $_POST['suffix'] ?? '');
    $date_of_birth = sanitize($conn, $_POST['date_of_birth']);
    $gender = sanitize($conn, $_POST['gender']);
    $civil_status = sanitize($conn, $_POST['civil_status']);
    $email = sanitize($conn, $_POST['email']);
    $phone = sanitize($conn, $_POST['phone']);
    $address = sanitize($conn, $_POST['address']);
    $education_level = sanitize($conn, $_POST['education_level']);
    $school_graduated = sanitize($conn, $_POST['school_graduated'] ?? '');
    $course = sanitize($conn, $_POST['course'] ?? '');
    $years_experience = (int)($_POST['years_experience'] ?? 0);
    $username = sanitize($conn, $_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $position_id = (int)$_POST['position_id'];

    // Validation
    if (empty($first_name) || empty($last_name)) $errors[] = "First and last name are required.";
    if (empty($date_of_birth)) $errors[] = "Date of birth is required.";
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Valid email is required.";
    if (empty($phone)) $errors[] = "Phone number is required.";
    if (empty($address)) $errors[] = "Address is required.";
    if (empty($username)) $errors[] = "Username is required.";
    if (strlen($password) < 6) $errors[] = "Password must be at least 6 characters.";
    if ($password !== $confirm_password) $errors[] = "Passwords do not match.";
    if ($position_id == 0) $errors[] = "Please select a position to apply for.";

    // Check if username or email exists
    $check = $conn->query("SELECT id FROM applicants WHERE username = '$username' OR email = '$email'");
    if ($check->num_rows > 0) $errors[] = "Username or email already exists.";

    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $applicant_id = 'APP-' . date('Y') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);

        $sql = "INSERT INTO applicants (applicant_id, first_name, middle_name, last_name, suffix, date_of_birth, gender, civil_status, email, phone, address, education_level, school_graduated, course, years_experience, username, password, status) 
                VALUES ('$applicant_id', '$first_name', '$middle_name', '$last_name', '$suffix', '$date_of_birth', '$gender', '$civil_status', '$email', '$phone', '$address', '$education_level', '$school_graduated', '$course', $years_experience, '$username', '$hashed_password', 'pending')";

        if ($conn->query($sql)) {
            $new_applicant_id = $conn->insert_id;
            
            // Create job application
            $app_code = 'APP-' . date('Y') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
            $conn->query("INSERT INTO job_applications (application_code, applicant_id, position_id, resume_path, status) 
                          VALUES ('$app_code', $new_applicant_id, $position_id, '', 'submitted')");

            $success = true;
            $_SESSION['success'] = "Registration successful! Your Applicant ID is: $applicant_id. You can now login.";
        } else {
            $errors[] = "Registration failed. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dar-green: #006400;
            --dar-dark-green: #004d00;
            --dar-light-green: #4CAF50;
            --dar-gold: #FFD700;
            --bg-light: #f8faf9;
            --text-dark: #1a1a2e;
            --text-muted: #6b7280;
            --white: #ffffff;
            --shadow: 0 8px 30px rgba(0,0,0,0.08);
            --shadow-lg: 0 20px 50px rgba(0,0,0,0.12);
            --radius: 16px;
            --transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: linear-gradient(135deg, #f0f8f0, #e8f5e9); min-height: 100vh; }

        .register-container {
            display: flex; min-height: 100vh;
        }
        .register-sidebar {
            width: 40%; background: linear-gradient(135deg, var(--dar-green), var(--dar-dark-green));
            color: white; padding: 60px 40px;
            display: flex; flex-direction: column; justify-content: center;
            position: relative; overflow: hidden;
        }
        .register-sidebar::before {
            content: ''; position: absolute; top: 0; left: 0; right: 0; bottom: 0;
            background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
        }
        .register-sidebar .logo {
            width: 70px; height: 70px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 800; font-size: 24px;
            margin-bottom: 30px;
        }
        .register-sidebar h2 { font-size: 2.2rem; font-weight: 800; margin-bottom: 15px; position: relative; }
        .register-sidebar p { opacity: 0.9; line-height: 1.7; position: relative; }
        .sidebar-features { margin-top: 40px; position: relative; }
        .sidebar-feature {
            display: flex; align-items: center; gap: 15px;
            margin-bottom: 20px; padding: 15px;
            background: rgba(255,255,255,0.1); border-radius: 12px;
            backdrop-filter: blur(10px);
        }
        .sidebar-feature i { font-size: 1.3rem; color: var(--dar-gold); }
        .sidebar-feature span { font-size: 0.9rem; }

        .register-form-area {
            flex: 1; padding: 40px 60px;
            overflow-y: auto; max-height: 100vh;
        }
        .form-header { margin-bottom: 30px; }
        .form-header h2 { color: var(--text-dark); font-size: 1.8rem; font-weight: 700; }
        .form-header p { color: var(--text-muted); margin-top: 5px; }
        .back-link {
            color: var(--dar-green); text-decoration: none;
            display: inline-flex; align-items: center; gap: 6px;
            margin-bottom: 20px; font-weight: 500; font-size: 0.9rem;
            transition: var(--transition);
        }
        .back-link:hover { gap: 10px; }

        .form-grid {
            display: grid; grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        .form-group { margin-bottom: 5px; }
        .form-group.full { grid-column: 1 / -1; }
        .form-group label {
            display: block; margin-bottom: 6px;
            font-weight: 600; color: var(--text-dark);
            font-size: 0.85rem;
        }
        .form-group label span { color: #dc2626; }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%; padding: 12px 15px;
            border: 2px solid #e5e7eb; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            transition: var(--transition); background: white;
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            outline: none; border-color: var(--dar-green);
            box-shadow: 0 0 0 4px rgba(0,100,0,0.08);
        }
        .form-group textarea { resize: vertical; min-height: 80px; }

        .section-title {
            grid-column: 1 / -1;
            color: var(--dar-green); font-size: 1rem;
            font-weight: 700; margin: 15px 0 5px;
            padding-bottom: 8px; border-bottom: 2px solid #e5e7eb;
            display: flex; align-items: center; gap: 8px;
        }

        .btn-submit {
            grid-column: 1 / -1;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; padding: 14px; border: none; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 1rem; font-weight: 600;
            cursor: pointer; transition: var(--transition);
            margin-top: 10px;
        }
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,100,0,0.3);
        }
        .login-link {
            grid-column: 1 / -1; text-align: center;
            margin-top: 15px; color: var(--text-muted); font-size: 0.9rem;
        }
        .login-link a { color: var(--dar-green); text-decoration: none; font-weight: 600; }

        .error-box {
            grid-column: 1 / -1;
            background: #fef2f2; border: 1px solid #fecaca;
            color: #dc2626; padding: 15px; border-radius: 10px;
            margin-bottom: 15px; font-size: 0.9rem;
        }
        .error-box ul { padding-left: 20px; }
        .success-box {
            grid-column: 1 / -1;
            background: #f0fdf4; border: 1px solid #86efac;
            color: #16a34a; padding: 20px; border-radius: 10px;
            margin-bottom: 15px; text-align: center;
        }
        .success-box a {
            display: inline-block; margin-top: 10px;
            background: var(--dar-green); color: white;
            padding: 10px 25px; border-radius: 8px;
            text-decoration: none; font-weight: 600;
        }

        @media (max-width: 968px) {
            .register-sidebar { display: none; }
            .register-form-area { padding: 30px 20px; }
            .form-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

    <div class="register-container">
        <div class="register-sidebar">
            <div class="logo">DAR</div>
            <h2>Join Our Team</h2>
            <p>Start your career with the Department of Agrarian Reform. Fill out the application form and become part of our mission to serve Filipino farmers.</p>
            <div class="sidebar-features">
                <div class="sidebar-feature">
                    <i class="fas fa-shield-alt"></i>
                    <span>Secure application process</span>
                </div>
                <div class="sidebar-feature">
                    <i class="fas fa-clock"></i>
                    <span>Track your application status</span>
                </div>
                <div class="sidebar-feature">
                    <i class="fas fa-bell"></i>
                    <span>Get notified of updates</span>
                </div>
            </div>
        </div>

        <div class="register-form-area">
            <a href="index.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Home</a>
            
            <div class="form-header">
                <h2>Applicant Registration</h2>
                <p>Complete the form below to create your applicant account and apply for a position.</p>
            </div>

            <?php if(!empty($errors)): ?>
            <div class="error-box">
                <ul>
                    <?php foreach($errors as $error): ?>
                    <li><?php echo $error; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>

            <?php if($success): ?>
            <div class="success-box">
                <i class="fas fa-check-circle" style="font-size: 2rem; margin-bottom: 10px;"></i>
                <h3 style="margin-bottom: 10px;">Registration Successful!</h3>
                <p><?php echo $_SESSION['success']; ?></p>
                <a href="login_applicant.php"><i class="fas fa-sign-in-alt"></i> Login Now</a>
            </div>
            <?php else: ?>

            <form method="POST" action="" class="form-grid">
                <div class="section-title"><i class="fas fa-briefcase"></i> Position Applying For</div>
                
                <div class="form-group full">
                    <label>Select Position <span>*</span></label>
                    <select name="position_id" required>
                        <option value="">-- Select a Position --</option>
                        <?php 
                        $positions->data_seek(0);
                        while($pos = $positions->fetch_assoc()): 
                        ?>
                        <option value="<?php echo $pos['id']; ?>" <?php echo ($selected_position == $pos['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($pos['position_title']); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="section-title"><i class="fas fa-user"></i> Personal Information</div>

                <div class="form-group">
                    <label>First Name <span>*</span></label>
                    <input type="text" name="first_name" required value="<?php echo $_POST['first_name'] ?? ''; ?>">
                </div>
                <div class="form-group">
                    <label>Middle Name</label>
                    <input type="text" name="middle_name" value="<?php echo $_POST['middle_name'] ?? ''; ?>">
                </div>
                <div class="form-group">
                    <label>Last Name <span>*</span></label>
                    <input type="text" name="last_name" required value="<?php echo $_POST['last_name'] ?? ''; ?>">
                </div>
                <div class="form-group">
                    <label>Suffix (Jr., Sr., III, etc.)</label>
                    <input type="text" name="suffix" value="<?php echo $_POST['suffix'] ?? ''; ?>">
                </div>
                <div class="form-group">
                    <label>Date of Birth <span>*</span></label>
                    <input type="date" name="date_of_birth" required value="<?php echo $_POST['date_of_birth'] ?? ''; ?>">
                </div>
                <div class="form-group">
                    <label>Gender <span>*</span></label>
                    <select name="gender" required>
                        <option value="">Select Gender</option>
                        <option value="Male" <?php echo (($_POST['gender'] ?? '') == 'Male') ? 'selected' : ''; ?>>Male</option>
                        <option value="Female" <?php echo (($_POST['gender'] ?? '') == 'Female') ? 'selected' : ''; ?>>Female</option>
                        <option value="Other" <?php echo (($_POST['gender'] ?? '') == 'Other') ? 'selected' : ''; ?>>Other</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Civil Status <span>*</span></label>
                    <select name="civil_status" required>
                        <option value="">Select Status</option>
                        <option value="Single" <?php echo (($_POST['civil_status'] ?? '') == 'Single') ? 'selected' : ''; ?>>Single</option>
                        <option value="Married" <?php echo (($_POST['civil_status'] ?? '') == 'Married') ? 'selected' : ''; ?>>Married</option>
                        <option value="Widowed" <?php echo (($_POST['civil_status'] ?? '') == 'Widowed') ? 'selected' : ''; ?>>Widowed</option>
                        <option value="Separated" <?php echo (($_POST['civil_status'] ?? '') == 'Separated') ? 'selected' : ''; ?>>Separated</option>
                        <option value="Divorced" <?php echo (($_POST['civil_status'] ?? '') == 'Divorced') ? 'selected' : ''; ?>>Divorced</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Email Address <span>*</span></label>
                    <input type="email" name="email" required value="<?php echo $_POST['email'] ?? ''; ?>">
                </div>
                <div class="form-group">
                    <label>Phone Number <span>*</span></label>
                    <input type="tel" name="phone" required placeholder="09XXXXXXXXX" value="<?php echo $_POST['phone'] ?? ''; ?>">
                </div>
                <div class="form-group full">
                    <label>Complete Address <span>*</span></label>
                    <textarea name="address" required><?php echo $_POST['address'] ?? ''; ?></textarea>
                </div>

                <div class="section-title"><i class="fas fa-graduation-cap"></i> Educational Background</div>

                <div class="form-group">
                    <label>Education Level <span>*</span></label>
                    <select name="education_level" required>
                        <option value="">Select Level</option>
                        <option value="High School" <?php echo (($_POST['education_level'] ?? '') == 'High School') ? 'selected' : ''; ?>>High School</option>
                        <option value="Vocational" <?php echo (($_POST['education_level'] ?? '') == 'Vocational') ? 'selected' : ''; ?>>Vocational</option>
                        <option value="College Undergraduate" <?php echo (($_POST['education_level'] ?? '') == 'College Undergraduate') ? 'selected' : ''; ?>>College Undergraduate</option>
                        <option value="College Graduate" <?php echo (($_POST['education_level'] ?? '') == 'College Graduate') ? 'selected' : ''; ?>>College Graduate</option>
                        <option value="Master Degree" <?php echo (($_POST['education_level'] ?? '') == 'Master Degree') ? 'selected' : ''; ?>>Master Degree</option>
                        <option value="Doctorate" <?php echo (($_POST['education_level'] ?? '') == 'Doctorate') ? 'selected' : ''; ?>>Doctorate</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>School Graduated</label>
                    <input type="text" name="school_graduated" value="<?php echo $_POST['school_graduated'] ?? ''; ?>">
                </div>
                <div class="form-group">
                    <label>Course/Degree</label>
                    <input type="text" name="course" value="<?php echo $_POST['course'] ?? ''; ?>">
                </div>
                <div class="form-group">
                    <label>Years of Experience</label>
                    <input type="number" name="years_experience" min="0" value="<?php echo $_POST['years_experience'] ?? '0'; ?>">
                </div>

                <div class="section-title"><i class="fas fa-lock"></i> Account Credentials</div>

                <div class="form-group">
                    <label>Username <span>*</span></label>
                    <input type="text" name="username" required value="<?php echo $_POST['username'] ?? ''; ?>">
                </div>
                <div class="form-group">
                    <label>Password <span>*</span></label>
                    <input type="password" name="password" required minlength="6" placeholder="At least 6 characters">
                </div>
                <div class="form-group">
                    <label>Confirm Password <span>*</span></label>
                    <input type="password" name="confirm_password" required placeholder="Re-enter password">
                </div>

                <button type="submit" class="btn-submit">
                    <i class="fas fa-user-plus" style="margin-right: 8px;"></i> Create Account & Apply
                </button>
                
                <p class="login-link">
                    Already have an account? <a href="login_applicant.php">Login here</a>
                </p>
            </form>
            <?php endif; ?>
        </div>
    </div>

</body>
</html>