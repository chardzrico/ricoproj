<?php
session_start();
require_once 'db_config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = sanitize($conn, $_POST['name']);
    $email = sanitize($conn, $_POST['email']);
    $message = sanitize($conn, $_POST['message']);

    if (!empty($name) && !empty($email) && !empty($message)) {
        $stmt = $conn->prepare("INSERT INTO contact_messages (full_name, email, message) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $message);
        
        if ($stmt->execute()) {
            $_SESSION['success'] = "Thank you! Your message has been sent successfully. We'll get back to you soon.";
        } else {
            $_SESSION['error'] = "Sorry, there was an error sending your message. Please try again.";
        }
    } else {
        $_SESSION['error'] = "Please fill in all fields.";
    }
}

header("Location: index.php#contact");
exit();
?>