<?php
session_start();
require_once 'db_config.php';

requireLogin('employee', 'login_employee.php');

 $page_title = "My Documents - DAR";

 $employee_id = $_SESSION['employee_id'];
 $employee_name = $_SESSION['employee_name'];

 $employee = $conn->query("SELECT * FROM employees WHERE id = $employee_id")->fetch_assoc();

// Fetch all documents for this employee
 $documents = $conn->query("SELECT * FROM documents WHERE uploaded_for = 'employee' AND user_id = $employee_id ORDER BY created_at DESC");

// Document type icon mapping
function getDocIcon($type) {
    $icons = [
        'pds' => 'fa-id-card',
        'service_record' => 'fa-file-alt',
        'certificate' => 'fa-certificate',
        'contract' => 'fa-file-contract',
        'memo' => 'fa-sticky-note',
        'others' => 'fa-file',
    ];
    return $icons[$type] ?? 'fa-file';
}

function getDocColor($type) {
    $colors = [
        'pds' => '#eff6ff',
        'service_record' => '#f0fdf4',
        'certificate' => '#fefce8',
        'contract' => '#fef2f2',
        'memo' => '#f5f3ff',
        'others' => '#f8f8f8',
    ];
    return $colors[$type] ?? '#f8f8f8';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dar-green: #006400;
            --dar-dark-green: #004d00;
            --dar-light-green: #4CAF50;
            --dar-gold: #FFD700;
            --bg-light: #f8faf9;
            --sidebar-bg: #0d3b0d;
            --text-dark: #1a1a2e;
            --text-muted: #6b7280;
            --shadow: 0 4px 20px rgba(0,0,0,0.08);
            --shadow-lg: 0 10px 40px rgba(0,0,0,0.1);
            --radius: 12px;
            --transition: all 0.3s ease;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: var(--bg-light); color: var(--text-dark); }

        .dashboard { display: flex; min-height: 100vh; }

        .sidebar {
            width: 260px; background: var(--sidebar-bg);
            color: white; position: fixed; top: 0; left: 0; bottom: 0;
            overflow-y: auto; z-index: 100;
        }
        .sidebar-header {
            padding: 25px 20px; text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .sidebar-logo {
            width: 55px; height: 55px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 800; font-size: 18px;
            margin: 0 auto 15px;
        }
        .sidebar-header h3 { font-size: 1rem; font-weight: 600; }
        .sidebar-header p { font-size: 0.75rem; opacity: 0.7; margin-top: 3px; }

        .nav-menu { padding: 20px 0; }
        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 14px 25px; color: rgba(255,255,255,0.8);
            text-decoration: none; font-size: 0.9rem; font-weight: 500;
            transition: var(--transition); border-left: 3px solid transparent;
        }
        .nav-item:hover, .nav-item.active {
            background: rgba(255,255,255,0.05);
            color: white; border-left-color: var(--dar-gold);
        }
        .nav-item i { width: 20px; text-align: center; }

        .sidebar-footer {
            position: absolute; bottom: 0; left: 0; right: 0;
            padding: 20px; border-top: 1px solid rgba(255,255,255,0.1);
        }
        .user-info { display: flex; align-items: center; gap: 12px; }
        .user-avatar {
            width: 40px; height: 40px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 700; font-size: 0.9rem;
        }
        .user-details h4 { font-size: 0.85rem; font-weight: 600; }
        .user-details p { font-size: 0.75rem; opacity: 0.6; }
        .logout-btn {
            display: flex; align-items: center; gap: 8px;
            color: rgba(255,255,255,0.7); text-decoration: none;
            font-size: 0.8rem; margin-top: 12px; transition: var(--transition);
        }
        .logout-btn:hover { color: #ef4444; }

        .main-content { flex: 1; margin-left: 260px; min-height: 100vh; }
        .top-bar {
            background: white; padding: 15px 30px;
            display: flex; justify-content: space-between; align-items: center;
            box-shadow: var(--shadow); position: sticky; top: 0; z-index: 50;
        }
        .top-bar h2 { font-size: 1.3rem; font-weight: 700; }

        .content { padding: 30px; }

        /* Stats */
        .doc-stats {
            display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 20px; margin-bottom: 30px;
        }
        .doc-stat-card {
            background: white; border-radius: var(--radius);
            padding: 22px; box-shadow: var(--shadow);
            display: flex; align-items: center; gap: 15px;
            border: 1px solid #f0f0f0;
        }
        .doc-stat-icon {
            width: 50px; height: 50px; border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.3rem;
        }
        .doc-stat-info h4 { font-size: 1.5rem; font-weight: 800; color: var(--dar-green); }
        .doc-stat-info p { font-size: 0.8rem; color: var(--text-muted); }

        /* Filter Bar */
        .filter-bar {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 25px; flex-wrap: wrap; gap: 15px;
        }
        .search-box {
            display: flex; align-items: center; gap: 10px;
            background: white; padding: 10px 15px; border-radius: 10px;
            box-shadow: var(--shadow); border: 1px solid #f0f0f0;
        }
        .search-box input {
            border: none; outline: none; font-family: 'Poppins', sans-serif;
            font-size: 0.9rem; width: 250px;
        }
        .filter-select {
            padding: 10px 15px; border: 1px solid #e5e7eb; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            background: white; cursor: pointer;
        }

        /* Document List */
        .doc-list-card {
            background: white; border-radius: var(--radius);
            box-shadow: var(--shadow); overflow: hidden;
            border: 1px solid #f0f0f0;
        }
        .doc-item {
            display: flex; align-items: center; gap: 18px;
            padding: 20px 25px; border-bottom: 1px solid #f8f8f8;
            transition: var(--transition);
        }
        .doc-item:hover { background: #fafafa; }
        .doc-item:last-child { border-bottom: none; }
        .doc-icon-box {
            width: 52px; height: 52px; border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.4rem; color: var(--dar-green); flex-shrink: 0;
        }
        .doc-info { flex: 1; }
        .doc-info h4 { font-size: 0.95rem; font-weight: 600; margin-bottom: 4px; }
        .doc-info p { font-size: 0.82rem; color: var(--text-muted); display: flex; gap: 12px; }
        .doc-actions { display: flex; gap: 8px; }
        .btn-doc {
            padding: 8px 18px; border-radius: 8px;
            font-size: 0.82rem; font-weight: 600; text-decoration: none;
            transition: var(--transition); display: inline-flex;
            align-items: center; gap: 6px; border: none; cursor: pointer;
            font-family: 'Poppins', sans-serif;
        }
        .btn-download { background: #f0fdf4; color: #16a34a; }
        .btn-download:hover { background: #16a34a; color: white; }
        .btn-view-doc { background: #eff6ff; color: #3b82f6; }
        .btn-view-doc:hover { background: #3b82f6; color: white; }

        .empty-state {
            text-align: center; padding: 60px 20px;
        }
        .empty-icon {
            width: 80px; height: 80px; border-radius: 50%;
            background: #f0f0f0; display: flex; align-items: center;
            justify-content: center; margin: 0 auto 20px;
            font-size: 2rem; color: #ccc;
        }
        .empty-state h4 { font-size: 1.1rem; margin-bottom: 8px; }
        .empty-state p { font-size: 0.9rem; color: var(--text-muted); }

        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .main-content { margin-left: 0; }
        }
        @media (max-width: 768px) {
            .doc-stats { grid-template-columns: 1fr 1fr; }
            .filter-bar { flex-direction: column; align-items: stretch; }
            .search-box { width: 100%; }
            .search-box input { width: 100%; }
            .doc-item { flex-wrap: wrap; }
            .doc-actions { width: 100%; justify-content: flex-end; }
            .content { padding: 20px; }
        }
    </style>
</head>
<body>

    <div class="dashboard">
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">DAR</div>
                <h3>Employee Portal</h3>
                <p>Records Management</p>
            </div>
            <nav class="nav-menu">
                <a href="dashboard_employee.php" class="nav-item"><i class="fas fa-home"></i> Dashboard</a>
                <a href="profile.php" class="nav-item"><i class="fas fa-user"></i> My Profile</a>
                <a href="documents.php" class="nav-item active"><i class="fas fa-folder-open"></i> My Documents</a>
                <a href="payslip.php" class="nav-item"><i class="fas fa-file-invoice-dollar"></i> Payslip</a>
                <a href="leave.php" class="nav-item"><i class="fas fa-calendar-minus"></i> Leave Request</a>
                <a href="settings.php" class="nav-item"><i class="fas fa-cog"></i> Settings</a>
            </nav>
            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar"><?php echo strtoupper(substr($employee_name, 0, 1)); ?></div>
                    <div class="user-details">
                        <h4><?php echo htmlspecialchars($employee_name); ?></h4>
                        <p><?php echo htmlspecialchars($employee['position']); ?></p>
                    </div>
                </div>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </aside>

        <main class="main-content">
            <div class="top-bar">
                <h2><i class="fas fa-folder-open" style="margin-right: 10px; color: var(--dar-green);"></i>My Documents</h2>
            </div>

            <div class="content">
                <!-- Stats -->
                <?php
                $total_docs = $documents->num_rows;
                $pds_count = 0; $cert_count = 0; $other_count = 0;
                // Reset pointer
                $documents->data_seek(0);
                while($d = $documents->fetch_assoc()) {
                    if($d['document_type'] == 'pds') $pds_count++;
                    elseif($d['document_type'] == 'certificate') $cert_count++;
                    else $other_count++;
                }
                $documents->data_seek(0);
                ?>
                <div class="doc-stats">
                    <div class="doc-stat-card">
                        <div class="doc-stat-icon" style="background: #f0fdf4; color: #16a34a;"><i class="fas fa-file-alt"></i></div>
                        <div class="doc-stat-info">
                            <h4><?php echo $total_docs; ?></h4>
                            <p>Total Documents</p>
                        </div>
                    </div>
                    <div class="doc-stat-card">
                        <div class="doc-stat-icon" style="background: #eff6ff; color: #3b82f6;"><i class="fas fa-id-card"></i></div>
                        <div class="doc-stat-info">
                            <h4><?php echo $pds_count; ?></h4>
                            <p>PDS / Records</p>
                        </div>
                    </div>
                    <div class="doc-stat-card">
                        <div class="doc-stat-icon" style="background: #fefce8; color: #ca8a04;"><i class="fas fa-certificate"></i></div>
                        <div class="doc-stat-info">
                            <h4><?php echo $cert_count; ?></h4>
                            <p>Certificates</p>
                        </div>
                    </div>
                    <div class="doc-stat-card">
                        <div class="doc-stat-icon" style="background: #f5f3ff; color: #7c3aed;"><i class="fas fa-file"></i></div>
                        <div class="doc-stat-info">
                            <h4><?php echo $other_count; ?></h4>
                            <p>Others</p>
                        </div>
                    </div>
                </div>

                <!-- Filter -->
                <div class="filter-bar">
                    <div class="search-box">
                        <i class="fas fa-search" style="color: var(--text-muted);"></i>
                        <input type="text" id="searchDoc" placeholder="Search documents..." onkeyup="filterDocs()">
                    </div>
                    <select class="filter-select" id="filterType" onchange="filterDocs()">
                        <option value="">All Types</option>
                        <option value="pds">PDS</option>
                        <option value="service_record">Service Record</option>
                        <option value="certificate">Certificate</option>
                        <option value="contract">Contract</option>
                        <option value="memo">Memo</option>
                        <option value="others">Others</option>
                    </select>
                </div>

                <!-- Document List -->
                <div class="doc-list-card" id="docList">
                    <?php if($documents->num_rows > 0): ?>
                        <?php while($doc = $documents->fetch_assoc()): ?>
                        <div class="doc-item" data-type="<?php echo $doc['document_type']; ?>" data-name="<?php echo strtolower($doc['document_name']); ?>">
                            <div class="doc-icon-box" style="background: <?php echo getDocColor($doc['document_type']); ?>;">
                                <i class="fas <?php echo getDocIcon($doc['document_type']); ?>"></i>
                            </div>
                            <div class="doc-info">
                                <h4><?php echo htmlspecialchars($doc['document_name']); ?></h4>
                                <p>
                                    <span><i class="fas fa-tag"></i> <?php echo ucfirst(str_replace('_', ' ', $doc['document_type'])); ?></span>
                                    <span><i class="fas fa-calendar"></i> <?php echo date('M d, Y', strtotime($doc['created_at'])); ?></span>
                                </p>
                            </div>
                            <div class="doc-actions">
                                <a href="<?php echo htmlspecialchars($doc['file_path']); ?>" class="btn-doc btn-view-doc" target="_blank">
                                    <i class="fas fa-eye"></i> View
                                </a>
                                <a href="<?php echo htmlspecialchars($doc['file_path']); ?>" class="btn-doc btn-download" download>
                                    <i class="fas fa-download"></i> Download
                                </a>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="empty-state">
                            <div class="empty-icon"><i class="fas fa-folder-open"></i></div>
                            <h4>No Documents Yet</h4>
                            <p>Your documents will appear here once uploaded by the HR department.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>

    <script>
        function filterDocs() {
            const search = document.getElementById('searchDoc').value.toLowerCase();
            const type = document.getElementById('filterType').value;
            const items = document.querySelectorAll('.doc-item');

            items.forEach(item => {
                const name = item.getAttribute('data-name');
                const itemType = item.getAttribute('data-type');
                const matchSearch = name.includes(search);
                const matchType = !type || itemType === type;
                item.style.display = (matchSearch && matchType) ? 'flex' : 'none';
            });
        }
    </script>

</body>
</html>