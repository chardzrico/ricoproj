<?php
session_start();
require_once 'db_config.php';

requireLogin('admin', 'login_admin.php');
 $page_title = "Calendar Management - DAR";

 $admin_id = $_SESSION['admin_id'];
 $admin_name = $_SESSION['admin_name'];
 $role = $_SESSION['admin_role'] ?? 'Admin';

// Handle Delete
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM calendar_events WHERE id = $id");
    $_SESSION['success'] = "Event deleted successfully.";
    redirect('calendar_admin.php');
}

// Handle Add/Edit
 $edit_mode = false;
 $edit_data = null;

if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $edit_mode = true;
    $edit_id = (int)$_GET['edit'];
    $edit_result = $conn->query("SELECT * FROM calendar_events WHERE id = $edit_id");
    $edit_data = $edit_result->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $event_title = sanitize($conn, $_POST['event_title']);
    $event_date = sanitize($conn, $_POST['event_date']);
    $event_type = sanitize($conn, $_POST['event_type']);
    $description = sanitize($conn, $_POST['description'] ?? '');

    if (isset($_POST['id']) && !empty($_POST['id'])) {
        $id = (int)$_POST['id'];
        $sql = "UPDATE calendar_events SET event_title = '$event_title', event_date = '$event_date',
                event_type = '$event_type', description = '$description' WHERE id = $id";
        $conn->query($sql);
        $_SESSION['success'] = "Event updated successfully.";
    } else {
        $sql = "INSERT INTO calendar_events (event_title, event_date, event_type, description, created_by)
                VALUES ('$event_title', '$event_date', '$event_type', '$description', $admin_id)";
        $conn->query($sql);
        $_SESSION['success'] = "Event added successfully.";
    }
    redirect('calendar_admin.php');
}

// Fetch all events
 $events = $conn->query("SELECT ce.*, a.full_name as creator_name 
                        FROM calendar_events ce 
                        LEFT JOIN admins a ON ce.created_by = a.id 
                        ORDER BY ce.event_date DESC");

// Calendar Navigation
 $month = isset($_GET['m']) ? (int)$_GET['m'] : date('n');
 $year = isset($_GET['y']) ? (int)$_GET['y'] : date('Y');
if ($month < 1) { $month = 12; $year--; }
if ($month > 12) { $month = 1; $year++; }
 $month_name = date('F', mktime(0,0,0, $month, 1, $year));
 $days_in_month = cal_days_in_month(CAL_GREGORIAN, $month, $year);
 $first_day = date('w', mktime(0,0,0, $month, 1, $year));
 $today_m = date('n'); $today_d = date('j'); $today_y = date('Y');

// Get events for calendar
 $cal_events = [];
 $start = "$year-$month-01";
 $end = "$year-$month-$days_in_month";
 $cal_result = $conn->query("SELECT * FROM calendar_events WHERE event_date BETWEEN '$start' AND '$end'");
while($row = $cal_result->fetch_assoc()) {
    $cal_events[$row['event_date']] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dar-green: #006400;
            --dar-dark-green: #004d00;
            --dar-light-green: #4CAF50;
            --dar-gold: #FFD700;
            --bg-light: #f8faf9;
            --sidebar-bg: #0d3b0d;
            --text-dark: #1a1a2e;
            --text-muted: #6b7280;
            --white: #ffffff;
            --shadow: 0 4px 20px rgba(0,0,0,0.08);
            --shadow-lg: 0 10px 40px rgba(0,0,0,0.12);
            --radius: 12px;
            --transition: all 0.3s ease;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: var(--bg-light); color: var(--text-dark); }

        .dashboard { display: flex; min-height: 100vh; }

        /* ===== SIDEBAR (Exact match sa dashboard_admin.php) ===== */
        .sidebar {
            width: 260px; background: var(--sidebar-bg);
            color: white; position: fixed; top: 0; left: 0; bottom: 0;
            z-index: 100; transition: var(--transition); display: flex; flex-direction: column;
        }
        .sidebar-header {
            padding: 25px 20px; text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1); flex-shrink: 0;
        }
        .sidebar-logo {
            width: 55px; height: 55px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 800; font-size: 18px; margin: 0 auto 15px;
        }
        .sidebar-header h3 { font-size: 1rem; font-weight: 600; }
        .sidebar-header p { font-size: 0.75rem; opacity: 0.7; margin-top: 3px; }
        .nav-menu { padding: 20px 0; flex: 1; overflow-y: auto; }
        .nav-menu::-webkit-scrollbar { width: 4px; }
        .nav-menu::-webkit-scrollbar-track { background: transparent; }
        .nav-menu::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 4px; }
        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 14px 25px; color: rgba(255,255,255,0.8);
            text-decoration: none; font-size: 0.9rem; font-weight: 500;
            transition: var(--transition); border-left: 3px solid transparent; cursor: pointer;
        }
        .nav-item:hover, .nav-item.active {
            background: rgba(255,255,255,0.05); color: white; border-left-color: var(--dar-gold);
        }
        .nav-item i { width: 20px; text-align: center; font-size: 1rem; }
        .nav-divider { height: 1px; background: rgba(255,255,255,0.08); margin: 10px 25px; }
        .nav-label {
            font-size: 0.68rem; font-weight: 600; text-transform: uppercase;
            letter-spacing: 1.5px; color: rgba(255,255,255,0.35); padding: 10px 25px 5px;
        }
        .sidebar-footer {
            padding: 20px; border-top: 1px solid rgba(255,255,255,0.1); flex-shrink: 0;
        }
        .user-info { display: flex; align-items: center; gap: 12px; }
        .user-avatar {
            width: 40px; height: 40px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 700; font-size: 0.9rem;
        }
        .user-details h4 { font-size: 0.85rem; font-weight: 600; }
        .user-details p { font-size: 0.75rem; opacity: 0.6; }
        .logout-btn {
            display: flex; align-items: center; gap: 8px;
            color: rgba(255,255,255,0.7); text-decoration: none;
            font-size: 0.8rem; margin-top: 12px; transition: var(--transition);
        }
        .logout-btn:hover { color: #ef4444; }

        /* ===== MAIN ===== */
        .main-content { flex: 1; margin-left: 260px; min-height: 100vh; }
        .top-bar {
            background: white; padding: 15px 30px;
            display: flex; justify-content: space-between; align-items: center;
            box-shadow: var(--shadow); position: sticky; top: 0; z-index: 50;
        }
        .top-bar h2 { font-size: 1.3rem; font-weight: 700; }
        .top-bar-actions { display: flex; align-items: center; gap: 15px; }
        .content { padding: 30px; }

        .alert {
            padding: 15px 20px; border-radius: 10px; margin-bottom: 25px;
            display: flex; align-items: center; gap: 10px; font-size: 0.95rem;
        }
        .alert-success { background: #f0fdf4; color: #16a34a; border: 1px solid #86efac; }

        .two-col {
            display: grid; grid-template-columns: 1fr 1fr;
            gap: 25px;
        }

        /* Calendar */
        .calendar-card {
            background: white; border-radius: var(--radius);
            box-shadow: var(--shadow); padding: 25px;
            border: 1px solid #f0f0f0;
        }
        .calendar-nav {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 20px;
        }
        .cal-btn {
            background: var(--dar-green); color: white;
            padding: 8px 16px; text-decoration: none; border-radius: 8px;
            font-size: 0.85rem; font-weight: 600; border: none;
            cursor: pointer; transition: var(--transition);
            display: inline-flex; align-items: center; gap: 6px;
        }
        .cal-btn:hover { background: var(--dar-dark-green); }
        .calendar-header h3 { color: var(--dar-green); font-size: 1.2rem; text-align: center; font-weight: 700; }
        .cal-table {
            width: 100%; border-collapse: separate; border-spacing: 4px;
        }
        .cal-table th {
            font-size: 0.75rem; color: var(--text-muted); padding: 10px 0;
            font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;
        }
        .cal-table td {
            text-align: center; font-size: 0.9rem; padding: 12px 0;
            border-radius: 8px; cursor: pointer; transition: var(--transition);
            position: relative; font-weight: 500;
        }
        .cal-table td:hover:not(.empty) { background: rgba(0,100,0,0.08); color: var(--dar-green); }
        .cal-table td.today {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; font-weight: 700;
            box-shadow: 0 3px 12px rgba(0,100,0,0.3);
        }
        .cal-table td.has-event::after {
            content: ''; position: absolute; bottom: 3px; left: 50%;
            transform: translateX(-50%); width: 6px; height: 6px;
            background: var(--dar-gold); border-radius: 50%;
            box-shadow: 0 0 4px rgba(255,215,0,0.5);
        }
        .cal-table td.today.has-event::after { background: white; box-shadow: none; }
        .cal-table td.empty { cursor: default; }

        /* Events List */
        .events-card {
            background: white; border-radius: var(--radius);
            box-shadow: var(--shadow); overflow: hidden;
            border: 1px solid #f0f0f0;
            display: flex; flex-direction: column;
        }
        .events-header {
            padding: 20px 25px; border-bottom: 1px solid #f0f0f0;
            display: flex; justify-content: space-between; align-items: center;
            flex-shrink: 0;
        }
        .events-header h3 {
            font-size: 1.05rem; font-weight: 700;
            display: flex; align-items: center; gap: 8px;
        }
        .events-header h3 i { color: var(--dar-green); }
        .btn-add-sm {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; padding: 9px 18px; border: none; border-radius: 8px;
            font-size: 0.85rem; font-weight: 600; cursor: pointer;
            transition: var(--transition); font-family: 'Poppins', sans-serif;
            display: inline-flex; align-items: center; gap: 6px;
        }
        .btn-add-sm:hover { transform: translateY(-1px); box-shadow: 0 4px 14px rgba(0,100,0,0.3); }

        .events-list { flex: 1; overflow-y: auto; max-height: 520px; }
        .events-list::-webkit-scrollbar { width: 4px; }
        .events-list::-webkit-scrollbar-track { background: transparent; }
        .events-list::-webkit-scrollbar-thumb { background: #d1d5db; border-radius: 4px; }

        .event-item {
            display: flex; align-items: center; gap: 15px;
            padding: 16px 25px; border-bottom: 1px solid #f8f8f8;
            transition: var(--transition);
        }
        .event-item:hover { background: #fafafa; }
        .event-item:last-child { border-bottom: none; }
        .event-date {
            width: 52px; height: 52px; border-radius: 10px;
            display: flex; flex-direction: column; align-items: center; justify-content: center;
            font-weight: 700; flex-shrink: 0;
        }
        .event-date.holiday { background: #fef2f2; color: #ef4444; }
        .event-date.deadline { background: #fefce8; color: #ca8a04; }
        .event-date.meeting { background: #eff6ff; color: #3b82f6; }
        .event-date.training { background: #f0fdf4; color: var(--dar-green); }
        .event-date.other { background: #f3f4f6; color: #6b7280; }
        .event-date .day { font-size: 1.2rem; line-height: 1; }
        .event-date .month { font-size: 0.62rem; text-transform: uppercase; letter-spacing: 0.5px; margin-top: 1px; }
        .event-info { flex: 1; min-width: 0; }
        .event-info h4 { font-size: 0.92rem; font-weight: 600; margin-bottom: 4px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .event-info p { font-size: 0.78rem; color: var(--text-muted); margin-bottom: 5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .event-type {
            display: inline-block; padding: 3px 10px;
            border-radius: 20px; font-size: 0.68rem; font-weight: 600;
            text-transform: uppercase; letter-spacing: 0.3px;
        }
        .event-actions { display: flex; gap: 6px; flex-shrink: 0; }
        .btn-action {
            width: 30px; height: 30px; border-radius: 7px;
            border: none; cursor: pointer; display: flex;
            align-items: center; justify-content: center;
            font-size: 0.8rem; text-decoration: none; transition: var(--transition);
        }
        .btn-edit { background: #eff6ff; color: #3b82f6; }
        .btn-edit:hover { background: #3b82f6; color: white; }
        .btn-delete { background: #fef2f2; color: #ef4444; }
        .btn-delete:hover { background: #ef4444; color: white; }

        .empty-events {
            text-align: center; padding: 50px 20px; color: var(--text-muted);
        }
        .empty-events i { font-size: 2.5rem; opacity: 0.2; margin-bottom: 12px; display: block; }
        .empty-events h4 { font-size: 0.95rem; font-weight: 600; color: var(--text-dark); margin-bottom: 4px; }
        .empty-events p { font-size: 0.85rem; }

        /* Modal */
        .modal-overlay {
            display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.5); z-index: 1000;
            justify-content: center; align-items: center;
            padding: 20px; backdrop-filter: blur(5px);
        }
        .modal-overlay.active { display: flex; }
        .modal {
            background: white; border-radius: var(--radius);
            max-width: 500px; width: 100%;
            box-shadow: var(--shadow-lg);
            animation: modalIn 0.3s ease;
        }
        @keyframes modalIn {
            from { opacity: 0; transform: scale(0.95) translateY(10px); }
            to { opacity: 1; transform: scale(1) translateY(0); }
        }
        .modal-header {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; padding: 22px 25px; display: flex;
            justify-content: space-between; align-items: center;
        }
        .modal-header h3 { font-size: 1.15rem; font-weight: 700; }
        .modal-close { background: none; border: none; color: white; font-size: 1.5rem; cursor: pointer; transition: var(--transition); }
        .modal-close:hover { transform: rotate(90deg); }
        .modal-body { padding: 25px; }
        .form-group { margin-bottom: 16px; }
        .form-group label {
            display: block; margin-bottom: 7px; font-weight: 600; font-size: 0.85rem; color: var(--text-dark);
        }
        .form-group label i { margin-right: 6px; color: var(--dar-green); }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%; padding: 12px 15px;
            border: 2px solid #e5e7eb; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            transition: var(--transition); background: #fafafa;
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            outline: none; border-color: var(--dar-green);
            box-shadow: 0 0 0 4px rgba(0,100,0,0.08); background: white;
        }
        .form-group textarea { resize: vertical; min-height: 80px; }
        .modal-footer {
            padding: 18px 25px; border-top: 1px solid #f0f0f0;
            display: flex; justify-content: flex-end; gap: 10px;
        }
        .btn-cancel {
            padding: 11px 24px; border: 2px solid #e5e7eb; background: white;
            border-radius: 10px; font-family: 'Poppins', sans-serif;
            font-size: 0.88rem; font-weight: 600; cursor: pointer; transition: var(--transition);
        }
        .btn-cancel:hover { border-color: var(--dar-green); color: var(--dar-green); }
        .btn-save {
            padding: 11px 28px;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; border: none; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.88rem;
            font-weight: 600; cursor: pointer; transition: var(--transition);
        }
        .btn-save:hover { transform: translateY(-1px); box-shadow: 0 4px 14px rgba(0,100,0,0.3); }

        @media print {
            .sidebar, .top-bar { display: none !important; }
            .main-content { margin-left: 0 !important; }
        }
        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; }
            .two-col { grid-template-columns: 1fr; }
        }
        @media (max-width: 768px) {
            .content { padding: 20px; }
            .calendar-card { padding: 16px; }
            .cal-table td { padding: 8px 0; font-size: 0.82rem; }
            .event-item { padding: 12px 16px; gap: 10px; }
        }
    </style>
</head>
<body>

<div class="dashboard">
    <!-- ===== SIDEBAR (Exact copy ng dashboard_admin.php) ===== -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">DAR</div>
            <h3>Admin Dashboard</h3>
            <p>Employee Records Management</p>
        </div>
        <nav class="nav-menu">
            <a href="dashboard_admin.php" class="nav-item"><i class="fas fa-home"></i> Dashboard</a>
            <div class="nav-divider"></div>
            <div class="nav-label">People</div>
            <a href="employees.php" class="nav-item"><i class="fas fa-users"></i> Employees</a>
            <div class="nav-divider"></div>
            <div class="nav-label">Recruitment</div>
            <a href="positions.php" class="nav-item"><i class="fas fa-briefcase"></i> Vacant Positions</a>
            <a href="applications.php" class="nav-item"><i class="fas fa-file-alt"></i> Job Applications</a>
            <div class="nav-divider"></div>
            <div class="nav-label">Records</div>
            <a href="trainings.php" class="nav-item"><i class="fas fa-graduation-cap"></i> Trainings</a>
            <a href="document_tracking.php" class="nav-item"><i class="fas fa-exchange-alt"></i> Doc Tracking</a>
            <a href="documents.php" class="nav-item"><i class="fas fa-folder-open"></i> Documents</a>
            <div class="nav-divider"></div>
            <div class="nav-label">System</div>
            <a href="reports.php" class="nav-item"><i class="fas fa-chart-bar"></i> Reports</a>
            <a href="calendar_admin.php" class="nav-item active"><i class="fas fa-calendar-alt"></i> Calendar</a>
            <a href="settings.php" class="nav-item"><i class="fas fa-cog"></i> Settings</a>
        </nav>
        <div class="sidebar-footer">
            <div class="user-info">
                <div class="user-avatar"><?php echo strtoupper(substr($admin_name, 0, 1)); ?></div>
                <div class="user-details">
                    <h4><?php echo htmlspecialchars($admin_name); ?></h4>
                    <p><?php echo ucfirst($role); ?></p>
                </div>
            </div>
            <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </aside>

    <!-- ===== MAIN ===== -->
    <main class="main-content">
        <div class="top-bar">
            <div style="display:flex;align-items:center;gap:12px;">
                <button style="display:none;padding:8px 10px;border-radius:8px;border:1.5px solid #e5e7eb;background:transparent;cursor:pointer;" id="menuToggle" onclick="document.getElementById('sidebar').classList.toggle('open')">
                    <i class="fas fa-bars"></i>
                </button>
                <h2><i class="fas fa-calendar-alt" style="margin-right:10px;color:var(--dar-green);"></i>Calendar Management</h2>
            </div>
            <div class="top-bar-actions">
                <span style="font-size:0.88rem;color:var(--text-muted);font-weight:500;">
                    <i class="fas fa-calendar-day" style="margin-right:6px;"></i><?php echo date('l, F d, Y'); ?>
                </span>
            </div>
        </div>

        <div class="content">
            <?php if(isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
            <?php endif; ?>

            <div class="two-col">
                <!-- Calendar -->
                <div class="calendar-card">
                    <div class="calendar-nav">
                        <a href="?m=<?php echo $month-1; ?>&y=<?php echo $year; ?>" class="cal-btn"><i class="fas fa-chevron-left"></i></a>
                        <div class="calendar-header">
                            <h3><?php echo $month_name . ' ' . $year; ?></h3>
                        </div>
                        <a href="?m=<?php echo $month+1; ?>&y=<?php echo $year; ?>" class="cal-btn"><i class="fas fa-chevron-right"></i></a>
                    </div>
                    <table class="cal-table">
                        <thead>
                            <tr>
                                <th>Sun</th><th>Mon</th><th>Tue</th><th>Wed</th><th>Thu</th><th>Fri</th><th>Sat</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                            <?php
                            for($i = 0; $i < $first_day; $i++) echo "<td class='empty'></td>";
                            for($d = 1; $d <= $days_in_month; $d++) {
                                $current_date = sprintf("%04d-%02d-%02d", $year, $month, $d);
                                $is_today = ($month == $today_m && $d == $today_d && $year == $today_y) ? "today" : "";
                                $has_event = isset($cal_events[$current_date]) ? "has-event" : "";
                                if(($d + $first_day - 1) % 7 == 0 && $d != 1) echo "</tr><tr>";
                                echo "<td class='$is_today $has_event' title='" . (isset($cal_events[$current_date]) ? htmlspecialchars($cal_events[$current_date]['event_title']) : '') . "'>$d</td>";
                            }
                            $remaining = (7 - (($days_in_month + $first_day) % 7)) % 7;
                            for($i = 0; $i < $remaining; $i++) echo "<td class='empty'></td>";
                            ?>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- Events List -->
                <div class="events-card">
                    <div class="events-header">
                        <h3><i class="fas fa-list"></i> Upcoming Events</h3>
                        <button class="btn-add-sm" onclick="openModal()"><i class="fas fa-plus"></i> Add Event</button>
                    </div>
                    <div class="events-list">
                        <?php 
                        $events->data_seek(0);
                        $has_events = false;
                        while($evt = $events->fetch_assoc()): 
                            $has_events = true;
                            $type_colors = [
                                'holiday' => 'holiday',
                                'deadline' => 'deadline',
                                'meeting' => 'meeting',
                                'training' => 'training',
                                'other' => 'other'
                            ];
                            $color_class = $type_colors[$evt['event_type']] ?? 'other';
                            $type_bg_colors = [
                                'holiday' => '#fef2f2; color: #ef4444',
                                'deadline' => '#fefce8; color: #ca8a04',
                                'meeting' => '#eff6ff; color: #3b82f6',
                                'training' => '#f0fdf4; color: #006400',
                                'other' => '#f3f4f6; color: #6b7280'
                            ];
                            $type_style = $type_bg_colors[$evt['event_type']] ?? $type_bg_colors['other'];
                        ?>
                        <div class="event-item">
                            <div class="event-date <?php echo $color_class; ?>">
                                <span class="day"><?php echo date('d', strtotime($evt['event_date'])); ?></span>
                                <span class="month"><?php echo date('M', strtotime($evt['event_date'])); ?></span>
                            </div>
                            <div class="event-info">
                                <h4><?php echo htmlspecialchars($evt['event_title']); ?></h4>
                                <p><?php echo htmlspecialchars($evt['description'] ?: ucfirst($evt['event_type'])); ?></p>
                                <span class="event-type" style="background: <?php echo $type_style; ?>;">
                                    <?php echo ucfirst($evt['event_type']); ?>
                                </span>
                            </div>
                            <div class="event-actions">
                                <a href="calendar_admin.php?edit=<?php echo $evt['id']; ?>" class="btn-action btn-edit" title="Edit"><i class="fas fa-edit"></i></a>
                                <a href="calendar_admin.php?delete=<?php echo $evt['id']; ?>" class="btn-action btn-delete" title="Delete" onclick="return confirm('Delete this event?')"><i class="fas fa-trash"></i></a>
                            </div>
                        </div>
                        <?php endwhile; ?>

                        <?php if(!$has_events): ?>
                        <div class="empty-events">
                            <i class="fas fa-calendar-times"></i>
                            <h4>No Events Yet</h4>
                            <p>Click "Add Event" to schedule your first event.</p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<!-- Event Modal -->
<div class="modal-overlay" id="eventModal" <?php echo $edit_mode ? 'style="display:flex;"' : ''; ?>>
    <div class="modal">
        <div class="modal-header">
            <h3><i class="fas fa-calendar-plus" style="margin-right:10px;"></i><?php echo $edit_mode ? 'Edit Event' : 'Add New Event'; ?></h3>
            <button class="modal-close" onclick="closeModal()"><i class="fas fa-times"></i></button>
        </div>
        <form method="POST" action="">
            <div class="modal-body">
                <?php if($edit_mode): ?>
                <input type="hidden" name="id" value="<?php echo $edit_data['id']; ?>">
                <?php endif; ?>
                <div class="form-group">
                    <label><i class="fas fa-heading"></i>Event Title</label>
                    <input type="text" name="event_title" required value="<?php echo $edit_data['event_title'] ?? ''; ?>" placeholder="e.g. Independence Day">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-calendar-day"></i>Event Date</label>
                    <input type="date" name="event_date" required value="<?php echo $edit_data['event_date'] ?? date('Y-m-d'); ?>">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-tag"></i>Event Type</label>
                    <select name="event_type" required>
                        <option value="holiday" <?php echo ($edit_data['event_type'] ?? '') == 'holiday' ? 'selected' : ''; ?>>Holiday</option>
                        <option value="deadline" <?php echo ($edit_data['event_type'] ?? '') == 'deadline' ? 'selected' : ''; ?>>Deadline</option>
                        <option value="meeting" <?php echo ($edit_data['event_type'] ?? '') == 'meeting' ? 'selected' : ''; ?>>Meeting</option>
                        <option value="training" <?php echo ($edit_data['event_type'] ?? '') == 'training' ? 'selected' : ''; ?>>Training</option>
                        <option value="other" <?php echo ($edit_data['event_type'] ?? '') == 'other' ? 'selected' : ''; ?>>Other</option>
                    </select>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-align-left"></i>Description</label>
                    <textarea name="description" rows="3" placeholder="Add event description..."><?php echo $edit_data['description'] ?? ''; ?></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-cancel" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn-save"><i class="fas fa-save" style="margin-right:6px;"></i><?php echo $edit_mode ? 'Update' : 'Save'; ?> Event</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal() {
    document.getElementById('eventModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}
function closeModal() {
    document.getElementById('eventModal').classList.remove('active');
    document.body.style.overflow = 'auto';
    <?php if($edit_mode): ?>
    window.location.href = 'calendar_admin.php';
    <?php endif; ?>
}
document.getElementById('eventModal').addEventListener('click', function(e) {
    if(e.target === this) closeModal();
});

// Mobile menu toggle
function checkMobile() {
    const toggle = document.getElementById('menuToggle');
    if (window.innerWidth <= 1024) {
        toggle.style.display = 'flex';
    } else {
        toggle.style.display = 'none';
        document.getElementById('sidebar').classList.remove('open');
    }
}
checkMobile();
window.addEventListener('resize', checkMobile);
</script>

</body>
</html>