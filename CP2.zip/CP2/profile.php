<?php
session_start();
require_once 'db_config.php';

requireLogin('employee', 'login_employee.php');

 $page_title = "My Profile - DAR";

 $employee_id = $_SESSION['employee_id'];
 $employee_name = $_SESSION['employee_name'];

// Fetch employee data with prepared statement
 $stmt = $conn->prepare("SELECT * FROM employees WHERE id = ?");
 $stmt->bind_param("i", $employee_id);
 $stmt->execute();
 $result = $stmt->get_result();
 $employee = $result->fetch_assoc();

if (!$employee) {
    die("Employee record not found!");
}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = sanitize($conn, $_POST['email']);
    $phone = sanitize($conn, $_POST['phone']);
    $address = sanitize($conn, $_POST['address']);
    $emergency_contact_name = sanitize($conn, $_POST['emergency_contact_name']);
    $emergency_contact_phone = sanitize($conn, $_POST['emergency_contact_phone']);

    $stmt = $conn->prepare("UPDATE employees SET 
        email = ?, 
        phone = ?, 
        address = ?, 
        emergency_contact_name = ?, 
        emergency_contact_phone = ? 
        WHERE id = ?");
    
    $stmt->bind_param("sssssi", $email, $phone, $address, 
                      $emergency_contact_name, $emergency_contact_phone, 
                      $employee_id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Profile updated successfully.";
        // Refresh data after saving
        $stmt = $conn->prepare("SELECT * FROM employees WHERE id = ?");
        $stmt->bind_param("i", $employee_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $employee = $result->fetch_assoc();
    } else {
        $_SESSION['error'] = "Failed to update profile.";
    }
    
    redirect('profile.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dar-green: #006400;
            --dar-dark-green: #004d00;
            --dar-light-green: #4CAF50;
            --dar-gold: #FFD700;
            --bg-light: #f8faf9;
            --sidebar-bg: #0d3b0d;
            --text-dark: #1a1a2e;
            --text-muted: #6b7280;
            --shadow: 0 4px 20px rgba(0,0,0,0.08);
            --shadow-lg: 0 10px 40px rgba(0,0,0,0.1);
            --radius: 12px;
            --transition: all 0.3s ease;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: var(--bg-light); color: var(--text-dark); }

        .dashboard { display: flex; min-height: 100vh; }

        .sidebar {
            width: 260px; background: var(--sidebar-bg);
            color: white; position: fixed; top: 0; left: 0; bottom: 0;
            overflow-y: auto; z-index: 100;
        }
        .sidebar-header {
            padding: 25px 20px; text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .sidebar-logo {
            width: 55px; height: 55px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 800; font-size: 18px;
            margin: 0 auto 15px;
        }
        .sidebar-header h3 { font-size: 1rem; font-weight: 600; }
        .sidebar-header p { font-size: 0.75rem; opacity: 0.7; margin-top: 3px; }

        .nav-menu { padding: 20px 0; }
        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 14px 25px; color: rgba(255,255,255,0.8);
            text-decoration: none; font-size: 0.9rem; font-weight: 500;
            transition: var(--transition); border-left: 3px solid transparent;
        }
        .nav-item:hover, .nav-item.active {
            background: rgba(255,255,255,0.05);
            color: white; border-left-color: var(--dar-gold);
        }
        .nav-item i { width: 20px; text-align: center; }

        .sidebar-footer {
            position: absolute; bottom: 0; left: 0; right: 0;
            padding: 20px; border-top: 1px solid rgba(255,255,255,0.1);
        }
        .user-info { display: flex; align-items: center; gap: 12px; }
        .user-avatar {
            width: 40px; height: 40px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 700; font-size: 0.9rem;
        }
        .user-details h4 { font-size: 0.85rem; font-weight: 600; }
        .user-details p { font-size: 0.75rem; opacity: 0.6; }
        .logout-btn {
            display: flex; align-items: center; gap: 8px;
            color: rgba(255,255,255,0.7); text-decoration: none;
            font-size: 0.8rem; margin-top: 12px; transition: var(--transition);
        }
        .logout-btn:hover { color: #ef4444; }

        .main-content { flex: 1; margin-left: 260px; min-height: 100vh; }
        .top-bar {
            background: white; padding: 15px 30px;
            display: flex; justify-content: space-between; align-items: center;
            box-shadow: var(--shadow); position: sticky; top: 0; z-index: 50;
        }
        .top-bar h2 { font-size: 1.3rem; font-weight: 700; }

        .content { padding: 30px; }

        .alert {
            padding: 15px 20px; border-radius: 10px; margin-bottom: 25px;
            display: flex; align-items: center; gap: 10px; font-size: 0.95rem;
            animation: slideDown 0.3s ease;
        }
        .alert-success { background: #f0fdf4; color: #16a34a; border: 1px solid #86efac; }
        .alert-error { background: #fef2f2; color: #dc2626; border: 1px solid #fca5a5; }

        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Profile Header */
        .profile-header {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-dark-green));
            color: white; border-radius: var(--radius);
            padding: 40px; margin-bottom: 30px;
            display: flex; align-items: center; gap: 30px;
            box-shadow: var(--shadow-lg);
        }
        .profile-big-avatar {
            width: 110px; height: 110px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-size: 2.5rem; font-weight: 800;
            border: 5px solid rgba(255,255,255,0.2);
            flex-shrink: 0;
        }
        .profile-header-info h2 { font-size: 1.8rem; font-weight: 700; margin-bottom: 5px; }
        .profile-header-info p { opacity: 0.9; font-size: 0.95rem; margin-bottom: 3px; }
        .profile-tags { display: flex; gap: 10px; margin-top: 15px; flex-wrap: wrap; }
        .profile-tag {
            background: rgba(255,255,255,0.15); padding: 6px 16px;
            border-radius: 20px; font-size: 0.8rem; font-weight: 500;
            border: 1px solid rgba(255,255,255,0.1);
            display: flex; align-items: center; gap: 6px;
        }

        /* Details Grid - 3 COLUMNS */
        .details-grid {
            display: grid; grid-template-columns: 1fr 1fr 1fr;
            gap: 25px; margin-bottom: 30px;
        }
        .detail-card {
            background: white; border-radius: var(--radius);
            padding: 28px; box-shadow: var(--shadow);
            border: 1px solid #f0f0f0;
        }
        .detail-card h3 {
            font-size: 1.05rem; color: var(--dar-green);
            margin-bottom: 20px; padding-bottom: 12px;
            border-bottom: 2px solid #f0f0f0;
            display: flex; align-items: center; gap: 10px;
            font-weight: 700;
        }
        .detail-card h3 i { font-size: 0.95rem; }
        .detail-row {
            display: flex; justify-content: space-between; align-items: flex-start;
            padding: 11px 0; border-bottom: 1px solid #f8f8f8;
        }
        .detail-row:last-child { border-bottom: none; }
        .detail-row .label {
            color: var(--text-muted); font-size: 0.85rem;
            flex-shrink: 0; min-width: 110px;
        }
        .detail-row .value {
            font-weight: 600; color: var(--text-dark); font-size: 0.85rem;
            text-align: right; word-break: break-word;
        }
        .value-empty { color: #9ca3af !important; font-style: italic; font-weight: 400 !important; }
        .status-active {
            display: inline-flex; align-items: center; gap: 6px;
            background: #f0fdf4; color: #16a34a; padding: 4px 12px;
            border-radius: 20px; font-size: 0.8rem; font-weight: 600;
        }

        /* Section divider inside card */
        .card-section-title {
            font-size: 0.78rem; font-weight: 700; color: var(--dar-green);
            margin-top: 15px; padding-top: 15px;
            border-top: 2px solid #f0f0f0;
            display: flex; align-items: center; gap: 6px;
            margin-bottom: 5px;
        }

        /* Edit Section */
        .edit-card {
            background: white; border-radius: var(--radius);
            padding: 30px; box-shadow: var(--shadow);
            border: 1px solid #f0f0f0; margin-bottom: 30px;
        }
        .edit-card h3 {
            font-size: 1.05rem; color: var(--dar-green);
            margin-bottom: 10px; display: flex; align-items: center; gap: 10px;
            font-weight: 700;
        }
        .edit-card .subtitle {
            color: var(--text-muted); font-size: 0.9rem; margin-bottom: 25px;
        }
        .section-divider {
            border: none; border-top: 2px dashed #e5e7eb;
            margin: 25px 0;
        }
        .section-label {
            font-size: 0.85rem; font-weight: 600; color: var(--dar-green);
            margin-bottom: 15px; display: flex; align-items: center; gap: 8px;
        }
        .edit-grid {
            display: grid; grid-template-columns: 1fr 1fr;
            gap: 18px;
        }
        .edit-grid .full { grid-column: 1 / -1; }
        .form-group label {
            display: block; margin-bottom: 6px;
            font-weight: 600; font-size: 0.85rem; color: var(--text-dark);
        }
        .form-group label i {
            margin-right: 6px; color: var(--dar-green);
        }
        .form-group input, .form-group textarea {
            width: 100%; padding: 12px 15px;
            border: 2px solid #e5e7eb; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            transition: var(--transition); background: #fafafa;
        }
        .form-group input:focus, .form-group textarea:focus {
            outline: none; border-color: var(--dar-green);
            box-shadow: 0 0 0 4px rgba(0,100,0,0.08);
            background: white;
        }
        .form-group input::placeholder, .form-group textarea::placeholder {
            color: #9ca3af;
        }
        .form-group textarea { resize: vertical; min-height: 80px; }
        .btn-save {
            padding: 12px 35px;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; border: none; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.95rem;
            font-weight: 600; cursor: pointer; transition: var(--transition);
            display: inline-flex; align-items: center; gap: 8px;
        }
        .btn-save:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,100,0,0.3); }

        @media (max-width: 1200px) {
            .details-grid { grid-template-columns: 1fr 1fr; }
        }
        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .main-content { margin-left: 0; }
        }
        @media (max-width: 768px) {
            .profile-header { flex-direction: column; text-align: center; }
            .profile-tags { justify-content: center; }
            .details-grid { grid-template-columns: 1fr; }
            .edit-grid { grid-template-columns: 1fr; }
            .content { padding: 20px; }
            .detail-row { flex-direction: column; gap: 4px; }
            .detail-row .value { text-align: left; }
        }
    </style>
</head>
<body>

    <div class="dashboard">
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">DAR</div>
                <h3>Employee Portal</h3>
                <p>Records Management</p>
            </div>
            <nav class="nav-menu">
                <a href="dashboard_employee.php" class="nav-item"><i class="fas fa-home"></i> Dashboard</a>
                <a href="profile.php" class="nav-item active"><i class="fas fa-user"></i> My Profile</a>
                <a href="document.php" class="nav-item"><i class="fas fa-folder-open"></i> My Documents</a>
                <a href="payslip.php" class="nav-item"><i class="fas fa-file-invoice-dollar"></i> Payslip</a>
                <a href="leave.php" class="nav-item"><i class="fas fa-calendar-minus"></i> Leave Request</a>
                <a href="settings.php" class="nav-item"><i class="fas fa-cog"></i> Settings</a>
            </nav>
            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar"><?php echo strtoupper(substr($employee_name, 0, 1)); ?></div>
                    <div class="user-details">
                        <h4><?php echo htmlspecialchars($employee_name); ?></h4>
                        <p><?php echo htmlspecialchars($employee['position'] ?? 'Employee'); ?></p>
                    </div>
                </div>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </aside>

        <main class="main-content">
            <div class="top-bar">
                <h2><i class="fas fa-user" style="margin-right: 10px; color: var(--dar-green);"></i>My Profile</h2>
            </div>

            <div class="content">
                <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
                <?php endif; ?>

                <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                </div>
                <?php endif; ?>

                <!-- Profile Header -->
                <div class="profile-header">
                    <div class="profile-big-avatar"><?php echo strtoupper(substr($employee['first_name'], 0, 1) . substr($employee['last_name'], 0, 1)); ?></div>
                    <div class="profile-header-info">
                        <h2><?php echo htmlspecialchars($employee['first_name'] . ' ' . (!empty($employee['middle_name']) ? $employee['middle_name'] . ' ' : '') . $employee['last_name'] . (!empty($employee['suffix']) ? ' ' . $employee['suffix'] : '')); ?></h2>
                        <p><i class="fas fa-id-badge" style="margin-right: 8px;"></i><?php echo htmlspecialchars($employee['employee_id']); ?></p>
                        <p><i class="fas fa-building" style="margin-right: 8px;"></i><?php echo htmlspecialchars($employee['department']); ?> — <?php echo htmlspecialchars($employee['position']); ?></p>
                        <div class="profile-tags">
                            <span class="profile-tag"><i class="fas fa-layer-group"></i> SG <?php echo htmlspecialchars($employee['salary_grade'] ?? 'N/A'); ?></span>
                            <span class="profile-tag"><i class="fas fa-briefcase"></i> <?php echo ucfirst($employee['employment_status']); ?></span>
                            <span class="profile-tag"><i class="fas fa-check-circle"></i> <?php echo ucfirst(str_replace('_', ' ', $employee['status'])); ?></span>
                        </div>
                    </div>
                </div>

                <!-- Details Grid - 3 COLUMNS -->
                <div class="details-grid">
                    <!-- Card 1: Personal Information -->
                    <div class="detail-card">
                        <h3><i class="fas fa-user-circle"></i> Personal Information</h3>
                        <div class="detail-row">
                            <span class="label">First Name</span>
                            <span class="value"><?php echo htmlspecialchars($employee['first_name']); ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Middle Name</span>
                            <span class="value <?php echo empty($employee['middle_name']) ? 'value-empty' : ''; ?>">
                                <?php echo !empty($employee['middle_name']) ? htmlspecialchars($employee['middle_name']) : '—'; ?>
                            </span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Last Name</span>
                            <span class="value"><?php echo htmlspecialchars($employee['last_name']); ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Suffix</span>
                            <span class="value <?php echo empty($employee['suffix']) ? 'value-empty' : ''; ?>">
                                <?php echo !empty($employee['suffix']) ? htmlspecialchars($employee['suffix']) : '—'; ?>
                            </span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Date of Birth</span>
                            <span class="value"><?php echo date('F d, Y', strtotime($employee['date_of_birth'])); ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Gender</span>
                            <span class="value"><?php echo htmlspecialchars($employee['gender']); ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Civil Status</span>
                            <span class="value"><?php echo htmlspecialchars($employee['civil_status']); ?></span>
                        </div>
                    </div>

                    <!-- Card 2: Contact Information (NEW!) -->
                    <div class="detail-card">
                        <h3><i class="fas fa-address-book"></i> Contact Information</h3>
                        <div class="detail-row">
                            <span class="label">Email</span>
                            <span class="value <?php echo empty($employee['email']) ? 'value-empty' : ''; ?>">
                                <?php echo !empty($employee['email']) ? htmlspecialchars($employee['email']) : '—'; ?>
                            </span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Phone</span>
                            <span class="value <?php echo empty($employee['phone']) ? 'value-empty' : ''; ?>">
                                <?php echo !empty($employee['phone']) ? htmlspecialchars($employee['phone']) : '—'; ?>
                            </span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Address</span>
                            <span class="value <?php echo empty($employee['address']) ? 'value-empty' : ''; ?>">
                                <?php echo !empty($employee['address']) ? htmlspecialchars($employee['address']) : '—'; ?>
                            </span>
                        </div>
                        
                        <div class="card-section-title">
                            <i class="fas fa-user-shield"></i> Emergency Contact
                        </div>
                        <div class="detail-row">
                            <span class="label">Name</span>
                            <span class="value <?php echo empty($employee['emergency_contact_name']) ? 'value-empty' : ''; ?>">
                                <?php echo !empty($employee['emergency_contact_name']) ? htmlspecialchars($employee['emergency_contact_name']) : '—'; ?>
                            </span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Phone</span>
                            <span class="value <?php echo empty($employee['emergency_contact_phone']) ? 'value-empty' : ''; ?>">
                                <?php echo !empty($employee['emergency_contact_phone']) ? htmlspecialchars($employee['emergency_contact_phone']) : '—'; ?>
                            </span>
                        </div>
                    </div>

                    <!-- Card 3: Employment Details -->
                    <div class="detail-card">
                        <h3><i class="fas fa-briefcase"></i> Employment Details</h3>
                        <div class="detail-row">
                            <span class="label">Employee ID</span>
                            <span class="value"><?php echo htmlspecialchars($employee['employee_id']); ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Department</span>
                            <span class="value"><?php echo htmlspecialchars($employee['department']); ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Position</span>
                            <span class="value"><?php echo htmlspecialchars($employee['position']); ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Employment</span>
                            <span class="value"><?php echo ucfirst($employee['employment_status']); ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Salary Grade</span>
                            <span class="value <?php echo empty($employee['salary_grade']) ? 'value-empty' : ''; ?>">
                                <?php echo !empty($employee['salary_grade']) ? htmlspecialchars($employee['salary_grade']) : '—'; ?>
                            </span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Date Hired</span>
                            <span class="value"><?php echo date('F d, Y', strtotime($employee['date_hired'])); ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Service</span>
                            <span class="value">
                                <?php 
                                $years = floor((time() - strtotime($employee['date_hired'])) / (365.25 * 24 * 60 * 60));
                                echo $years . ' year' . ($years != 1 ? 's' : '');
                                ?>
                            </span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Status</span>
                            <span class="value">
                                <span class="status-active">
                                    <i class="fas fa-circle" style="font-size: 0.45rem;"></i>
                                    <?php echo ucfirst(str_replace('_', ' ', $employee['status'])); ?>
                                </span>
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Editable Contact Section -->
                <div class="edit-card">
                    <h3><i class="fas fa-edit"></i> Update Contact Information</h3>
                    <p class="subtitle">You can update your contact details and emergency contact information.</p>
                    
                    <form method="POST" action="">
                        <div class="section-label">
                            <i class="fas fa-address-card"></i> Contact Details
                        </div>
                        <div class="edit-grid">
                            <div class="form-group">
                                <label><i class="fas fa-envelope"></i>Email Address</label>
                                <input type="email" name="email" 
                                       value="<?php echo htmlspecialchars($employee['email'] ?? ''); ?>" 
                                       placeholder="Enter your email address" required>
                            </div>
                            <div class="form-group">
                                <label><i class="fas fa-phone"></i>Phone Number</label>
                                <input type="tel" name="phone" 
                                       value="<?php echo htmlspecialchars($employee['phone'] ?? ''); ?>" 
                                       placeholder="e.g., 09123456789">
                            </div>
                            <div class="form-group full">
                                <label><i class="fas fa-map-marker-alt"></i>Address</label>
                                <textarea name="address" placeholder="Enter your complete address" required><?php echo htmlspecialchars($employee['address'] ?? ''); ?></textarea>
                            </div>
                        </div>

                        <hr class="section-divider">

                        <div class="section-label">
                            <i class="fas fa-user-shield"></i> Emergency Contact
                        </div>
                        <div class="edit-grid">
                            <div class="form-group">
                                <label><i class="fas fa-user"></i>Emergency Contact Name</label>
                                <input type="text" name="emergency_contact_name" 
                                       value="<?php echo htmlspecialchars($employee['emergency_contact_name'] ?? ''); ?>" 
                                       placeholder="Enter contact person name">
                            </div>
                            <div class="form-group">
                                <label><i class="fas fa-phone-alt"></i>Emergency Contact Phone</label>
                                <input type="tel" name="emergency_contact_phone" 
                                       value="<?php echo htmlspecialchars($employee['emergency_contact_phone'] ?? ''); ?>" 
                                       placeholder="e.g., 09987654321">
                            </div>
                        </div>

                        <div style="margin-top: 25px;">
                            <button type="submit" class="btn-save"><i class="fas fa-save"></i> Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
    </div>

</body>
</html>