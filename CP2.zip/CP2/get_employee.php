<?php
session_start();
require_once 'db_config.php';

header('Content-Type: application/json');

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo json_encode(['error' => 'Invalid employee ID.']);
    exit;
}

 $id = (int)$_GET['id'];
 $result = $conn->query("SELECT * FROM employees WHERE id = $id");

if ($result && $result->num_rows > 0) {
    echo json_encode($result->fetch_assoc());
} else {
    echo json_encode(['error' => 'Employee not found.']);
}