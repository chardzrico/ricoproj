<?php
session_start();
require_once 'db_config.php';

 $page_title = "DAR - Employee Records Management System";
 $current_year = date("Y");

// Calendar Navigation Logic
 $month = isset($_GET['m']) ? (int)$_GET['m'] : date('n');
 $year = isset($_GET['y']) ? (int)$_GET['y'] : date('Y');

if ($month < 1) { $month = 12; $year--; }
if ($month > 12) { $month = 1; $year++; }

 $prev_m = $month - 1; $prev_y = $year;
if ($prev_m < 1) { $prev_m = 12; $prev_y--; }

 $next_m = $month + 1; $next_y = $year;
if ($next_m > 12) { $next_m = 1; $next_y++; }

 $month_name = date('F', mktime(0,0,0, $month, 1, $year));
 $days_in_month = cal_days_in_month(CAL_GREGORIAN, $month, $year);
 $first_day = date('w', mktime(0,0,0, $month, 1, $year));

 $today_m = date('n'); $today_d = date('j'); $today_y = date('Y');

// Initialize default values in case database fails
 $emp_count = 0;
 $dept_count = 0;
 $app_count = 0;
 $vacant_count = 0;
 $events = [];

// Only query database if connection is successful
if (isset($conn) && $conn->ping()) {
    $start_date = "$year-$month-01";
    $end_date = "$year-$month-$days_in_month";
    $event_result = $conn->query("SELECT event_title, event_date, event_type FROM calendar_events WHERE event_date BETWEEN '$start_date' AND '$end_date'");
    if ($event_result) {
        while($row = $event_result->fetch_assoc()) {
            $events[$row['event_date']] = $row;
        }
    }

    $emp_result = $conn->query("SELECT COUNT(*) as total FROM employees WHERE status = 'active'");
    if ($emp_result) $emp_count = $emp_result->fetch_assoc()['total'];

    $dept_result = $conn->query("SELECT COUNT(DISTINCT department) as total FROM employees");
    if ($dept_result) $dept_count = $dept_result->fetch_assoc()['total'];

    $app_result = $conn->query("SELECT COUNT(*) as total FROM applicants WHERE status = 'pending'");
    if ($app_result) $app_count = $app_result->fetch_assoc()['total'];

    $vacant_result = $conn->query("SELECT COUNT(*) as total FROM vacant_positions WHERE status = 'open'");
    if ($vacant_result) $vacant_count = $vacant_result->fetch_assoc()['total'];
}

if ($emp_count == 0) $emp_count = 1200;
if ($dept_count == 0) $dept_count = 15;
if ($vacant_count == 0) $vacant_count = 4;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dar-green: #006400;
            --dar-dark-green: #004d00;
            --dar-light-green: #4CAF50;
            --dar-gold: #FFD700;
            --dar-gold-light: #FFE44D;
            --bg-light: #f8faf9;
            --text-dark: #1a1a2e;
            --text-muted: #6b7280;
            --white: #ffffff;
            --shadow-sm: 0 2px 8px rgba(0,0,0,0.06);
            --shadow: 0 8px 30px rgba(0,0,0,0.08);
            --shadow-lg: 0 20px 50px rgba(0,0,0,0.12);
            --radius: 16px;
            --radius-sm: 10px;
            --transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--bg-light);
            color: var(--text-dark);
            line-height: 1.6;
            overflow-x: hidden;
        }

        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: #f1f1f1; }
        ::-webkit-scrollbar-thumb { background: var(--dar-green); border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--dar-dark-green); }

/* ===== HEADER / NAVBAR ===== */
header {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 1000;
    padding: 18px 50px;
    display: flex;
    align-items: right;
    justify-content: right;
    background: rgba(255,255,255,0.98);
    backdrop-filter: blur(20px);
    transition: padding 0.4s ease, box-shadow 0.4s ease;
    border-bottom: 1px solid rgba(0,100,0,0.08);
    box-shadow: 0 2px 20px rgba(0,0,0,0.04);
}
header.scrolled {
    background: rgba(255,255,255,0.98);
    padding: 14px 50px;
    box-shadow: 0 4px 30px rgba(0,0,0,0.08);
    border-bottom: 1px solid rgba(0,100,0,0.08);
}

/* Logo sa navbar — gamit ang header.png */
.header-logo {
    display: flex;
    align-items: center;
    gap: 16px;
    position: absolute;
    left: 50px;
    top: 50%;
    transform: translateY(-50%);
    text-decoration: none;
    transition: var(--transition);
}
.header-logo img {
    height: 62px;
    width: auto;
    object-fit: contain;
    transition: var(--transition);
    filter: drop-shadow(0 2px 6px rgba(0,0,0,0.1));
}
header.scrolled .header-logo img {
    height: 54px;
    filter: drop-shadow(0 2px 6px rgba(0,0,0,0.1));
}
.header-logo-text {
    display: flex;
    flex-direction: column;
    line-height: 1.15;
}
.header-logo-text .dar-abbr {
    font-size: 1.4rem;
    font-weight: 800;
    color: var(--dar-green);
    letter-spacing: 2px;
    transition: var(--transition);
}
.header-logo-text .dar-full {
    font-size: 0.7rem;
    font-weight: 500;
    color: var(--text-muted);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    transition: var(--transition);
}

header.scrolled .header-logo-text .dar-abbr { color: var(--dar-green); }
header.scrolled .header-logo-text .dar-full { color: var(--text-muted); }

/* Nav links */
nav {
    display: flex;
    justify-content: center;
}
nav ul {
    list-style: none;
    display: flex;
    gap: 10px;
    align-items: center;
}
nav ul li a {
    color: var(--dar-green);
    text-decoration: none;
    font-weight: 600;
    transition: var(--transition);
    font-size: 1.02rem;
    padding: 12px 26px;
    border-radius: 30px;
    position: relative;
    overflow: hidden;
    letter-spacing: 0.3px;
}
nav ul li a::before {
    content: '';
    position: absolute;
    bottom: 6px;
    left: 50%;
    width: 0;
    height: 2.5px;
    background: var(--dar-gold);
    transition: var(--transition);
    transform: translateX(-50%);
    border-radius: 2px;
}
nav ul li a:hover::before { width: 60%; }
nav ul li a:hover { color: var(--dar-gold); background: rgba(255,215,0,0.06); }
nav ul li a.active {
    background: rgba(0,100,0,0.1);
    color: var(--dar-green);
    font-weight: 700;
}

header.scrolled nav ul li a { color: var(--dar-green); }
header.scrolled nav ul li a:hover { color: var(--dar-gold); background: rgba(255,215,0,0.06); }
header.scrolled nav ul li a.active {
    background: rgba(0,100,0,0.1);
    color: var(--dar-green);
}

.mobile-menu-btn {
    display: none;
    font-size: 1.6rem;
    cursor: pointer;
    color: var(--dar-green);
    position: absolute;
    right: 40px;
    top: 50%;
    transform: translateY(-50%);
}

header.scrolled .mobile-menu-btn { color: var(--dar-green); }

   
.hero {
   
    background: 
        linear-gradient(to bottom, rgba(0,0,0,0.40) 0%, rgba(0,0,0,0.55) 100%),
        url('back.jpg') no-repeat center center/cover;
   
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    text-align: center;
    color: var(--white);
    padding: 170px 20px 80px;
    position: relative;
    overflow: hidden;
}
        
        .hero::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
        }
      
        .hero-logo {
            width: 110px;
            height: 110px;
            margin-bottom: 30px;
            filter: brightness(0) invert(1) drop-shadow(0 8px 25px rgba(0,0,0,0.4));
            animation: fadeInDown 0.8s ease;
            object-fit: contain;
        }
        .hero-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(255,215,0,0.15);
            border: 1px solid rgba(255,215,0,0.3);
            padding: 8px 20px;
            border-radius: 50px;
            font-size: 0.85rem;
            margin-bottom: 25px;
            backdrop-filter: blur(10px);
            animation: fadeInDown 0.8s ease 0.1s both;
        }
        .hero h2 {
            font-size: 3.8rem;
            margin-bottom: 20px;
            font-weight: 800;
            line-height: 1.1;
            animation: fadeInUp 0.8s ease 0.2s both;
            text-shadow: 0 4px 20px rgba(0,0,0,0.3);
        }
        .hero h2 span { color: var(--dar-gold); }
        .hero p {
            font-size: 1.2rem;
            max-width: 700px;
            margin-bottom: 40px;
            font-weight: 300;
            opacity: 0.95;
            animation: fadeInUp 0.8s ease 0.4s both;
        }
        .hero-buttons {
            display: flex;
            gap: 20px;
            animation: fadeInUp 0.8s ease 0.6s both;
            flex-wrap: wrap;
            justify-content: center;
        }
        .btn {
            background: linear-gradient(135deg, var(--dar-gold), var(--dar-gold-light));
            color: var(--dar-green);
            padding: 14px 35px;
            text-decoration: none;
            font-weight: 700;
            border-radius: 50px;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 10px;
            box-shadow: 0 8px 25px rgba(255,215,0,0.35);
            border: none;
            cursor: pointer;
            font-size: 1rem;
            font-family: 'Poppins', sans-serif;
            position: relative;
            overflow: hidden;
        }
        .btn::after {
            content: '';
            position: absolute;
            top: 50%; left: 50%;
            width: 0; height: 0;
            background: rgba(255,255,255,0.3);
            border-radius: 50%;
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }
        .btn:hover::after { width: 300px; height: 300px; }
        .btn:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 35px rgba(255,215,0,0.5);
        }
        .btn-outline {
            background: transparent;
            color: white;
            border: 2px solid rgba(255,255,255,0.5);
            box-shadow: none;
        }
        .btn-outline::after { display: none; }
        .btn-outline:hover {
            background: rgba(255,255,255,0.1);
            border-color: white;
            box-shadow: 0 8px 25px rgba(0,0,0,0.2);
        }

        /* ===== STATS BAR ===== */
        .stats-bar {
            background: var(--white);
            display: flex;
            justify-content: center;
            gap: 0;
            padding: 0;
            box-shadow: var(--shadow-lg);
            flex-wrap: wrap;
            margin: -50px auto 0;
            max-width: 1000px;
            border-radius: var(--radius);
            position: relative;
            z-index: 10;
            overflow: hidden;
        }
        .stat-item {
            text-align: center;
            padding: 40px 50px;
            flex: 1;
            min-width: 200px;
            position: relative;
            transition: var(--transition);
        }
        .stat-item:not(:last-child)::after {
            content: '';
            position: absolute;
            right: 0; top: 25%; bottom: 25%;
            width: 1px;
            background: linear-gradient(to bottom, transparent, #e5e7eb, transparent);
        }
        .stat-item:hover { background: var(--bg-light); }
        .stat-icon { font-size: 2rem; color: var(--dar-light-green); margin-bottom: 10px; }
        .stat-item h3 {
            font-size: 2.5rem;
            color: var(--dar-green);
            margin: 0;
            font-weight: 800;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .stat-item p { color: var(--text-muted); margin: 5px 0 0; font-size: 0.9rem; font-weight: 500; }

        /* ===== SECTIONS COMMON ===== */
        .container { max-width: 1200px; margin: 0 auto; padding: 100px 20px; }
        .section-header { text-align: center; margin-bottom: 60px; }
        .section-badge {
            display: inline-block;
            background: rgba(0,100,0,0.08);
            color: var(--dar-green);
            padding: 6px 18px;
            border-radius: 50px;
            font-size: 0.8rem;
            font-weight: 600;
            margin-bottom: 15px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .section-title {
            color: var(--text-dark);
            font-size: 2.8rem;
            font-weight: 800;
            margin-bottom: 15px;
            line-height: 1.2;
        }
        .section-subtitle {
            max-width: 600px;
            margin: 0 auto;
            color: var(--text-muted);
            font-size: 1.1rem;
        }

        /* ===== FEATURES ===== */
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 30px;
        }
        .feature-card {
            background: var(--white);
            padding: 40px 35px;
            border-radius: var(--radius);
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
            border: 1px solid #f0f0f0;
            position: relative;
            overflow: hidden;
        }
        .feature-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; width: 100%; height: 4px;
            background: linear-gradient(90deg, var(--dar-green), var(--dar-light-green));
            transform: scaleX(0);
            transform-origin: left;
            transition: transform 0.4s ease;
        }
        .feature-card:hover::before { transform: scaleX(1); }
        .feature-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-lg);
            border-color: transparent;
        }
        .feature-icon {
            width: 65px; height: 65px;
            background: linear-gradient(135deg, rgba(0,100,0,0.08), rgba(76,175,80,0.08));
            border-radius: var(--radius-sm);
            display: flex; align-items: center; justify-content: center;
            font-size: 1.8rem;
            color: var(--dar-green);
            margin-bottom: 25px;
            transition: var(--transition);
        }
        .feature-card:hover .feature-icon {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white;
            transform: scale(1.1) rotate(5deg);
        }
        .feature-card h3 { color: var(--text-dark); margin-bottom: 12px; font-size: 1.3rem; font-weight: 700; }
        .feature-card p { color: var(--text-muted); font-size: 0.95rem; line-height: 1.7; }

        /* ===== CALENDAR ===== */
        .calendar-section { background: linear-gradient(180deg, #f0f8f0 0%, var(--bg-light) 100%); }
        .calendar-wrapper {
            max-width: 550px;
            margin: 0 auto;
            background: var(--white);
            border-radius: var(--radius);
            padding: 35px;
            box-shadow: var(--shadow);
            border: 1px solid #e8e8e8;
        }
        .calendar-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        .cal-btn {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: var(--white);
            padding: 10px 20px;
            text-decoration: none;
            border-radius: var(--radius-sm);
            font-weight: 600;
            transition: var(--transition);
            font-size: 0.9rem;
            display: inline-flex; align-items: center; gap: 6px;
            border: none; cursor: pointer;
            font-family: 'Poppins', sans-serif;
        }
        .cal-btn:hover { transform: translateX(3px); box-shadow: 0 4px 15px rgba(0,100,0,0.3); }
        .cal-btn:first-child:hover { transform: translateX(-3px); }
        .calendar-header h3 {
            color: var(--dar-green);
            margin: 0;
            text-align: center;
            font-size: 1.4rem;
            font-weight: 700;
        }
        .cal-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 4px;
            table-layout: fixed;
        }
        .cal-table th {
            font-size: 0.75rem;
            color: var(--text-muted);
            padding: 12px 0;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .cal-table td {
            text-align: center;
            font-size: 0.95rem;
            padding: 14px 0;
            border-radius: var(--radius-sm);
            transition: var(--transition);
            cursor: pointer;
            position: relative;
        }
        .cal-table td:hover:not(.empty) { background: rgba(0,100,0,0.08); color: var(--dar-green); }
        .cal-table td.today {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green)) !important;
            color: var(--white) !important;
            font-weight: 700;
            box-shadow: 0 4px 15px rgba(0,100,0,0.3);
        }
        .cal-table td.has-event::after {
            content: '';
            position: absolute;
            bottom: 4px; left: 50%;
            transform: translateX(-50%);
            width: 5px; height: 5px;
            background: var(--dar-gold);
            border-radius: 50%;
        }
        .cal-table td.empty { cursor: default; }
        .calendar-note {
            margin-top: 25px;
            text-align: center;
            color: var(--text-muted);
            font-size: 0.9rem;
            padding: 15px;
            background: #f8faf9;
            border-radius: var(--radius-sm);
            border-left: 4px solid var(--dar-gold);
        }
        .event-list {
            margin-top: 20px;
            padding: 15px;
            background: linear-gradient(135deg, rgba(0,100,0,0.03), rgba(255,215,0,0.05));
            border-radius: var(--radius-sm);
        }
        .event-item {
            display: flex; align-items: center; gap: 10px;
            padding: 8px 0; font-size: 0.85rem;
            border-bottom: 1px dashed #e5e7eb;
        }
        .event-item:last-child { border-bottom: none; }
        .event-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
        .event-dot.holiday { background: #ef4444; }
        .event-dot.deadline { background: #f59e0b; }
        .event-dot.meeting { background: #3b82f6; }
        .event-dot.other { background: var(--dar-green); }

        /* ===== HIRING ===== */
        .hiring-section {
            background: linear-gradient(135deg, #f0f8f0, #e8f5e9);
            border-top: 1px solid #e1e1e1;
            position: relative;
            overflow: hidden;
        }
        .hiring-section::before {
            content: '';
            position: absolute;
            top: -100px; right: -100px;
            width: 400px; height: 400px;
            background: rgba(0,100,0,0.03);
            border-radius: 50%;
        }
        .hiring-container {
            max-width: 1100px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 60px;
            align-items: center;
        }
        .hiring-text h2 {
            color: var(--dar-green);
            font-size: 3rem;
            margin-bottom: 20px;
            font-weight: 800;
            line-height: 1.1;
        }
        .hiring-text h2 span { color: var(--dar-gold); }
        .hiring-text p { font-size: 1.1rem; margin-bottom: 30px; color: #555; line-height: 1.8; }
        .hiring-stats { display: flex; gap: 30px; margin-bottom: 30px; }
        .hiring-stat h4 { font-size: 1.8rem; color: var(--dar-green); font-weight: 800; }
        .hiring-stat p { font-size: 0.85rem; color: var(--text-muted); margin: 0; }
        .hiring-visual {
            position: relative;
            border-radius: var(--radius);
            overflow: hidden;
            box-shadow: var(--shadow-lg);
            transform: perspective(1000px) rotateY(-5deg);
            transition: var(--transition);
        }
        .hiring-visual:hover { transform: perspective(1000px) rotateY(0deg); }
        .hiring-visual img { width: 100%; height: 100%; object-fit: cover; display: block; min-height: 400px; }
        .apply-overlay {
            position: absolute;
            bottom: 25px; left: 25px; right: 25px;
            background: rgba(255, 255, 255, 0.98);
            padding: 20px 25px;
            border-radius: var(--radius-sm);
            box-shadow: var(--shadow);
            display: flex; justify-content: space-between; align-items: center;
        }
        .apply-overlay a {
            color: var(--dar-green);
            text-decoration: none;
            font-weight: 700;
            font-size: 1rem;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: var(--transition);
        }
        .apply-overlay a:hover { gap: 15px; color: var(--dar-dark-green); }
        .vacant-badge {
            background: linear-gradient(135deg, var(--dar-gold), var(--dar-gold-light));
            color: var(--dar-green);
            padding: 6px 16px;
            border-radius: 50px;
            font-size: 0.8rem;
            font-weight: 700;
        }

        .bids-awards {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-dark-green));
            color: var(--white);
            padding: 50px 40px;
            text-align: center;
            border-radius: var(--radius);
            margin: 60px auto 0;
            max-width: 1000px;
            position: relative;
            overflow: hidden;
        }
        .bids-awards::before {
            content: '';
            position: absolute;
            top: -50%; left: -50%;
            width: 200%; height: 200%;
            background: radial-gradient(circle, rgba(255,215,0,0.1) 0%, transparent 70%);
        }
        .bids-awards h3 { font-size: 2rem; margin-bottom: 12px; position: relative; font-weight: 700; }
        .bids-awards p { margin-bottom: 25px; font-size: 1rem; opacity: 0.9; position: relative; }
        .btn-procurement {
            background: var(--white);
            color: var(--dar-green);
            padding: 12px 30px;
            text-decoration: none;
            border-radius: 50px;
            font-weight: 700;
            transition: var(--transition);
            display: inline-block;
            position: relative;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }
        .btn-procurement:hover {
            background: var(--dar-gold);
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.3);
        }

        /* ===== LOGIN PORTAL ===== */
        .login-portal-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 28px;
            max-width: 1200px;
            margin: 0 auto;
        }
        .portal-card {
            background: var(--white);
            padding: 45px 30px 40px;
            border-radius: var(--radius);
            box-shadow: var(--shadow-sm);
            text-align: center;
            transition: var(--transition);
            border-top: 5px solid var(--dar-green);
            position: relative;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .portal-card::after {
            content: '';
            position: absolute;
            bottom: 0; left: 0; right: 0; height: 0;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            transition: height 0.4s ease;
            z-index: 0;
        }
        .portal-card:hover::after { height: 100%; }
        .portal-card:hover > * { position: relative; z-index: 1; }
        .portal-card:hover { transform: translateY(-10px); box-shadow: var(--shadow-lg); border-color: transparent; }
        .portal-icon {
            width: 76px; height: 76px;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.8rem;
            color: white;
            margin-bottom: 22px;
            transition: var(--transition);
            flex-shrink: 0;
        }
        .portal-card:hover .portal-icon {
            background: white;
            color: var(--dar-green);
            transform: scale(1.1);
        }
        .portal-card h3 {
            color: var(--text-dark);
            margin-bottom: 12px;
            font-size: 1.35rem;
            font-weight: 700;
            transition: color 0.4s ease;
        }
        .portal-card:hover h3 { color: #fff; }
        .portal-card p {
            color: var(--text-muted);
            margin-bottom: 28px;
            font-size: 0.9rem;
            line-height: 1.7;
            transition: color 0.4s ease;
            flex-grow: 1;
        }
        .portal-card:hover p { color: rgba(255,255,255,0.85); }
        .btn-portal {
            display: inline-block;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: var(--white);
            padding: 12px 32px;
            text-decoration: none;
            border-radius: 50px;
            font-weight: 600;
            transition: var(--transition);
            font-size: 0.92rem;
        }
        .portal-card:hover .btn-portal {
            background: white;
            color: var(--dar-green);
        }
        .btn-portal:hover { transform: translateY(-2px); }

        /* ===== CONTACT ===== */
        .contact-wrapper {
            display: grid;
            grid-template-columns: 1fr 1.5fr;
            gap: 40px;
            max-width: 1000px;
            margin: 0 auto;
        }
        .contact-info, .contact-form {
            padding: 40px;
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
        }
        .contact-info h3, .contact-form h3 {
            color: var(--dar-green);
            margin-bottom: 25px;
            font-size: 1.5rem;
            font-weight: 700;
        }
        .contact-item {
            display: flex; align-items: flex-start; gap: 15px;
            margin-bottom: 25px; padding-bottom: 20px;
            border-bottom: 1px solid #f0f0f0;
        }
        .contact-item:last-child { border-bottom: none; margin-bottom: 0; padding-bottom: 0; }
        .contact-icon {
            width: 45px; height: 45px;
            background: linear-gradient(135deg, rgba(0,100,0,0.08), rgba(76,175,80,0.08));
            border-radius: var(--radius-sm);
            display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-size: 1.1rem; flex-shrink: 0;
        }
        .contact-item div strong { display: block; margin-bottom: 4px; color: var(--text-dark); }
        .contact-item div span { color: var(--text-muted); font-size: 0.9rem; }
        .form-group { margin-bottom: 20px; }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--text-dark);
            font-size: 0.9rem;
        }
        .form-group input, .form-group textarea {
            width: 100%;
            padding: 14px 18px;
            border: 2px solid #e5e7eb;
            border-radius: var(--radius-sm);
            font-family: 'Poppins', sans-serif;
            font-size: 0.95rem;
            transition: var(--transition);
            background: #fafafa;
        }
        .form-group input:focus, .form-group textarea:focus {
            outline: none;
            border-color: var(--dar-green);
            background: white;
            box-shadow: 0 0 0 4px rgba(0,100,0,0.08);
        }
        .form-group textarea { resize: vertical; min-height: 120px; }

      
        footer {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-dark-green));
            color: var(--white);
            text-align: center;
            padding: 60px 20px 30px;
            position: relative;
            overflow: hidden;
        }
        footer::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; height: 4px;
            background: linear-gradient(90deg, var(--dar-gold), var(--dar-gold-light), var(--dar-gold));
        }
        .footer-content { max-width: 800px; margin: 0 auto; }
        .footer-logo-img {
            height: 65px;
            width: auto;
            object-fit: contain;
            margin-bottom: 15px;
            filter: brightness(0) invert(1);
            opacity: 0.9;
        }
        footer p { margin-bottom: 10px; font-size: 0.95rem; opacity: 0.9; }
        footer .researchers { font-style: italic; opacity: 0.7; font-size: 0.9rem; margin-top: 20px; }
        .footer-links {
            display: flex; justify-content: center; gap: 30px; margin: 25px 0;
            flex-wrap: wrap;
        }
        .footer-links a {
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            font-size: 0.85rem;
            transition: var(--transition);
        }
        .footer-links a:hover { color: var(--dar-gold); }
        .footer-bottom {
            margin-top: 30px; padding-top: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
            font-size: 0.8rem; opacity: 0.6;
        }

        /* ===== ANIMATIONS ===== */
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .reveal {
            opacity: 0; transform: translateY(40px);
            transition: all 0.8s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .reveal.active { opacity: 1; transform: translateY(0); }

        /* ===== RESPONSIVE ===== */
        @media (max-width: 1024px) {
            header { padding: 14px 30px; }
            .header-logo { left: 30px; }
            .header-logo img { height: 52px; }
            header.scrolled .header-logo img { height: 46px; }
            .header-logo-text .dar-abbr { font-size: 1.2rem; }
            nav ul li a { font-size: 0.92rem; padding: 10px 20px; }
            .login-portal-grid {
                grid-template-columns: repeat(3, 1fr);
                gap: 20px;
                max-width: 100%;
                padding: 0 10px;
            }
            .portal-card { padding: 35px 20px 30px; }
            .portal-icon { width: 64px; height: 64px; font-size: 1.5rem; }
            .portal-card h3 { font-size: 1.15rem; }
            .portal-card p { font-size: 0.82rem; margin-bottom: 20px; }
            .btn-portal { padding: 10px 24px; font-size: 0.85rem; }
        }

        @media (max-width: 768px) {
            header { padding: 12px 20px; }
            .header-logo img { height: 44px; }
            header.scrolled .header-logo img { height: 40px; }
            .header-logo-text { display: none; }
            .hero { padding: 120px 20px 60px; }
            nav ul { display: none; }
            .mobile-menu-btn { display: block; }
            .hero h2 { font-size: 2.2rem; }
            .hero p { font-size: 1rem; }
            .hero-logo { width: 80px; height: 80px; }
            .stats-bar { margin: -30px 15px 0; }
            .stat-item { padding: 25px 20px; min-width: 150px; }
            .stat-item h3 { font-size: 1.8rem; }
            .section-title { font-size: 2rem; }
            .hiring-text h2 { font-size: 2rem; }
            .hiring-container, .contact-wrapper { grid-template-columns: 1fr; }
            .features-grid { grid-template-columns: 1fr; }
            .login-portal-grid {
                grid-template-columns: 1fr;
                max-width: 420px;
                margin: 0 auto;
                gap: 24px;
                padding: 0;
            }
            .portal-card { padding: 40px 30px 35px; }
            .portal-icon { width: 76px; height: 76px; font-size: 1.8rem; }
            .portal-card h3 { font-size: 1.35rem; }
            .portal-card p { font-size: 0.9rem; }
            .btn-portal { padding: 12px 32px; font-size: 0.92rem; }
        }
    </style>
</head>
<body>

    <!-- ===== HEADER===== -->
    <header id="header">
        <a href="#home" class="header-logo">
            <img src="header.png" alt="DAR Header Logo">
        </a>
        <nav>
            <ul>
                <li><a href="#home" class="active"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="#calendar">Calendar</a></li>
                <li><a href="#hiring">Careers</a></li>
                <li><a href="#login">Login</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
        </nav>
        <div class="mobile-menu-btn"><i class="fas fa-bars"></i></div>
    </header>

    <!-- ===== HERO ===== -->
    <section class="hero" id="home">
        
        
        <h2>Employee Records<br><span>Management System</span></h2>
        <p>A centralized digital platform designed to improve the efficiency, accuracy, and security of managing employee information for the Department of Agrarian Reform.</p>
         <div class="hero-badge">
            <i class="fas fa-shield-alt"></i> Government of the Philippines — Official
        </div>
        <div class="hero-buttons">
            <a href="#login" class="btn"><i class="fas fa-sign-in-alt"></i> Access System</a>
            <a href="#features" class="btn btn-outline"><i class="fas fa-info-circle"></i> Learn More</a>
        </div>
    </section>

   

    <!-- ===== CALENDAR ===== -->
    <section class="container calendar-section" id="calendar">
        <div class="section-header reveal">
            <div class="section-badge">Schedule</div>
            <h2 class="section-title">DAR Calendar</h2>
            <p class="section-subtitle">Stay updated with important dates, deadlines, and government holidays.</p>
        </div>
        <div class="calendar-wrapper reveal">
            <div class="calendar-nav">
                <a href="?m=<?php echo $prev_m; ?>&y=<?php echo $prev_y; ?>#calendar" class="cal-btn"><i class="fas fa-chevron-left"></i></a>
                <div class="calendar-header">
                    <h3><?php echo $month_name . " " . $year; ?></h3>
                </div>
                <a href="?m=<?php echo $next_m; ?>&y=<?php echo $next_y; ?>#calendar" class="cal-btn"><i class="fas fa-chevron-right"></i></a>
            </div>
            <table class="cal-table">
                <tr>
                    <th>Sun</th><th>Mon</th><th>Tue</th><th>Wed</th><th>Thu</th><th>Fri</th><th>Sat</th>
                </tr>
                <tr>
                <?php
                for($i = 0; $i < $first_day; $i++) {
                    echo "<td class='empty'></td>";
                }
                for($d = 1; $d <= $days_in_month; $d++):
                    $current_date = sprintf("%04d-%02d-%02d", $year, $month, $d);
                    $is_today = ($month == $today_m && $d == $today_d && $year == $today_y) ? "today" : "";
                    $has_event = isset($events[$current_date]) ? "has-event" : "";
                    $event_title = isset($events[$current_date]) ? "title='" . htmlspecialchars($events[$current_date]['event_title']) . "'" : "";
                    if(($d + $first_day - 1) % 7 == 0 && $d != 1) {
                        echo "</tr><tr>";
                    }
                    echo "<td class='$is_today $has_event' $event_title>$d</td>";
                endfor;
                $remaining = (7 - (($days_in_month + $first_day) % 7)) % 7;
                for($i = 0; $i < $remaining; $i++) {
                    echo "<td class='empty'></td>";
                }
                ?>
                </tr>
            </table>
            <?php if(!empty($events)): ?>
            <div class="event-list">
                <?php foreach($events as $date => $event):
                    $event_type_class = $event['event_type'];
                ?>
                <div class="event-item">
                    <div class="event-dot <?php echo $event_type_class; ?>"></div>
                    <span><strong><?php echo date('M d', strtotime($date)); ?></strong> — <?php echo htmlspecialchars($event['event_title']); ?></span>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="calendar-note">
                <i class="fas fa-info-circle" style="color: var(--dar-gold); margin-right: 8px;"></i>
                No scheduled events for <?php echo $month_name; ?> <?php echo $year; ?>.
            </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== HIRING ===== -->
    <section class="hiring-section" id="hiring">
        <div class="container" style="padding-bottom: 0;">
            <div class="hiring-container">
                <div class="hiring-text reveal">
                    <div class="section-badge" style="margin-bottom: 15px;">Join Our Team</div>
                    <h2>We Are <span>Hiring!</span></h2>
                    <p>The Department of Agrarian Reform is looking for passionate individuals to join our team. Be part of our mission to serve Filipino farmers and rural communities.</p>
                    <div class="hiring-stats">
                        <div class="hiring-stat">
                            <h4><?php echo $vacant_count; ?></h4>
                            <p>Open Positions</p>
                        </div>
                        <div class="hiring-stat">
                            <h4><?php echo $app_count; ?></h4>
                            <p>Pending Applications</p>
                        </div>
                    </div>
                    <a href="vacant_positions.php" class="btn"><i class="fas fa-briefcase"></i> View Vacant Positions</a>
                </div>
                <div class="hiring-visual reveal">
                    <img src="hiring.jpg" alt="DAR Hiring">
                    <div class="apply-overlay">
                        <a href="applicant_register.php"><i class="fas fa-paper-plane"></i> APPLY NOW</a>
                        <span class="vacant-badge"><?php echo $vacant_count; ?> Open</span>
                    </div>
                </div>
            </div>
        </div>
       
        </div>
    </section>

    <!-- ===== LOGIN PORTAL ===== -->
    <section class="container" id="login">
        <div class="section-header reveal">
            <div class="section-badge">Secure Access</div>
            <h2 class="section-title">System Access Portal</h2>
            <p class="section-subtitle">Select your role to proceed to your respective login page.</p>
        </div>
        <div class="login-portal-grid">
            <div class="portal-card reveal">
                <div class="portal-icon"><i class="fas fa-user-shield"></i></div>
                <h3>Admin</h3>
                <p>For System Administrators and HR Personnel managing records, reports, and system settings.</p>
                <a href="login_admin.php" class="btn-portal"><i class="fas fa-sign-in-alt" style="margin-right: 8px;"></i>Go to Admin Login</a>
            </div>
            <div class="portal-card reveal">
                <div class="portal-icon"><i class="fas fa-user-tie"></i></div>
                <h3>Employee</h3>
                <p>For DAR Employees to view personal profiles, employment history, and download documents.</p>
                <a href="login_employee.php" class="btn-portal"><i class="fas fa-sign-in-alt" style="margin-right: 8px;"></i>Go to Employee Login</a>
            </div>
            <div class="portal-card reveal">
                <div class="portal-icon"><i class="fas fa-file-signature"></i></div>
                <h3>Applicant</h3>
                <p>For Job Applicants to apply for vacant positions and track application status.</p>
                <a href="login_applicant.php" class="btn-portal"><i class="fas fa-sign-in-alt" style="margin-right: 8px;"></i>Go to Applicant Login</a>
            </div>
        </div>
    </section>

    <!-- ===== CONTACT ===== -->
    <section class="container" id="contact">
        <div class="section-header reveal">
            <div class="section-badge">Get in Touch</div>
            <h2 class="section-title">Contact Us</h2>
            <p class="section-subtitle">Have questions or inquiries? Reach out to us and we'll get back to you as soon as possible.</p>
        </div>
        <div class="contact-wrapper reveal">
            <div class="contact-info">
                <h3><i class="fas fa-address-card" style="margin-right: 10px;"></i>Contact Information</h3>
                <div class="contact-item">
                    <div class="contact-icon"><i class="fas fa-map-marker-alt"></i></div>
                    <div>
                        <strong>Address</strong>
                        <span>Department of Agrarian Reform, Elliptical Road, Diliman, Quezon City, Philippines</span>
                    </div>
                </div>
                <div class="contact-item">
                    <div class="contact-icon"><i class="fas fa-phone-alt"></i></div>
                    <div>
                        <strong>Phone</strong>
                        <span>(02) 8926-8218</span>
                    </div>
                </div>
                <div class="contact-item">
                    <div class="contact-icon"><i class="fas fa-envelope"></i></div>
                    <div>
                        <strong>Email</strong>
                        <span>records@dar.gov.ph</span>
                    </div>
                </div>
                <div class="contact-item">
                    <div class="contact-icon"><i class="fas fa-clock"></i></div>
                    <div>
                        <strong>Office Hours</strong>
                        <span>Monday to Friday, 8:00 AM - 5:00 PM</span>
                    </div>
                </div>
            </div>
            <div class="contact-form">
                <h3><i class="fas fa-paper-plane" style="margin-right: 10px;"></i>Send a Message</h3>
                <form action="send_message.php" method="POST" id="contactForm">
                    <div class="form-group">
                        <label for="name"><i class="fas fa-user" style="margin-right: 6px; color: var(--dar-green);"></i>Full Name</label>
                        <input type="text" id="name" name="name" placeholder="Juan Dela Cruz" required>
                    </div>
                    <div class="form-group">
                        <label for="email"><i class="fas fa-envelope" style="margin-right: 6px; color: var(--dar-green);"></i>Email Address</label>
                        <input type="email" id="email" name="email" placeholder="juan@example.com" required>
                    </div>
                    <div class="form-group">
                        <label for="message"><i class="fas fa-comment" style="margin-right: 6px; color: var(--dar-green);"></i>Message</label>
                        <textarea id="message" name="message" placeholder="Type your message or inquiry here..." required></textarea>
                    </div>
                    <button type="submit" class="btn" style="width: 100%;">
                        <i class="fas fa-paper-plane"></i> Send Message
                    </button>
                </form>
            </div>
        </div>
    </section>

    <!-- ===== FOOTER ===== -->
    <footer>
        <div class="footer-content">
            <img src="logo.png" alt="DAR Logo" class="footer-logo-img">
            <p style="font-size: 1.1rem; font-weight: 600; margin-bottom: 5px;">Department of Agrarian Reform</p>
            <p style="font-size: 0.9rem; opacity: 0.7;">Employee Records Management System</p>
            <div class="footer-links">
                <a href="#home">Home</a>
                <a href="#calendar">Calendar</a>
                <a href="#hiring">Careers</a>
                <a href="#login">Login</a>
                <a href="#contact">Contact</a>
            </div>
            <p>&copy; <?php echo date("Y"); ?> Department of Agrarian Reform. All Rights Reserved.</p>
        </div>
    </footer>

    <script>
        // Header scroll effect
        window.addEventListener('scroll', function() {
            const header = document.getElementById('header');
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });

        // Active nav link on scroll
        const sections = document.querySelectorAll('section[id]');
        const navLinks = document.querySelectorAll('nav ul li a');

        window.addEventListener('scroll', function() {
            let current = '';
            sections.forEach(section => {
                const sectionTop = section.offsetTop - 120;
                if (window.scrollY >= sectionTop) {
                    current = section.getAttribute('id');
                }
            });
            navLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === '#' + current) {
                    link.classList.add('active');
                }
            });
        });

        // Scroll reveal animation
        const revealElements = document.querySelectorAll('.reveal');
        const revealOnScroll = function() {
            revealElements.forEach(el => {
                const windowHeight = window.innerHeight;
                const elementTop = el.getBoundingClientRect().top;
                const revealPoint = 150;
                if (elementTop < windowHeight - revealPoint) {
                    el.classList.add('active');
                }
            });
        };
        window.addEventListener('scroll', revealOnScroll);
        window.addEventListener('load', revealOnScroll);

        // Smooth scroll
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            });
        });

        // Mobile menu toggle
        const mobileBtn = document.querySelector('.mobile-menu-btn');
        const navUl = document.querySelector('nav ul');
        if (mobileBtn) {
            mobileBtn.addEventListener('click', function() {
                if (navUl.style.display === 'flex') {
                    navUl.style.display = 'none';
                    mobileBtn.innerHTML = '<i class="fas fa-bars"></i>';
                } else {
                    navUl.style.display = 'flex';
                    navUl.style.flexDirection = 'column';
                    navUl.style.position = 'absolute';
                    navUl.style.top = '100%';
                    navUl.style.left = '0';
                    navUl.style.right = '0';
                    navUl.style.background = 'rgba(255,255,255,0.98)';
                    navUl.style.padding = '20px';
                    navUl.style.boxShadow = '0 10px 30px rgba(0,0,0,0.1)';
                    navUl.style.borderRadius = '0 0 16px 16px';
                    mobileBtn.innerHTML = '<i class="fas fa-times"></i>';
                }
            });
        }
    </script>
</body>
</html>