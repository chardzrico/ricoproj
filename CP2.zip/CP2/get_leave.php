<?php
session_start();
require_once 'db_config.php';

header('Content-Type: application/json');

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo json_encode(['error' => 'Invalid request.']);
    exit;
}

 $id = (int)$_GET['id'];

 $result = $conn->query("SELECT lr.*, e.first_name, e.last_name, e.employee_id as emp_id, e.department, e.position, 
    u.admin_name as action_by_name
    FROM leave_requests lr 
    LEFT JOIN employees e ON lr.employee_id = e.id 
    LEFT JOIN admins u ON lr.action_by = u.id 
    WHERE lr.id = $id");

if ($result && $result->num_rows > 0) {
    echo json_encode($result->fetch_assoc());
} else {
    echo json_encode(['error' => 'Leave request not found.']);
}