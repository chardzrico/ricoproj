<?php
session_start();
require_once 'db_config.php';

requireLogin('admin', 'login_admin.php');

 $page_title = "Training Certificates - DAR";
 $admin_id = $_SESSION['admin_id'];
 $admin_name = $_SESSION['admin_name'];
 $role = $_SESSION['admin_role'] ?? 'Admin';

 $divisions = [
    'Office of the PARO',
    'Support-to-Operations Division',
    'Land Tenure Improvement Division',
    'Program Beneficiaries Development Division',
    'Legal Division',
    'Department of Agrarian Reform Adjudication Board',
    'Other'
];

// Handle file upload
 $upload_error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {

    if ($_POST['action'] == 'add_training') {
        $emp_id = (int)$_POST['employee_id'];
        $title = sanitize($conn, $_POST['training_title']);
        $start_date = sanitize($conn, $_POST['training_date']);
        $end_date = !empty($_POST['training_end_date']) ? sanitize($conn, $_POST['training_end_date']) : "NULL";
        $venue = sanitize($conn, $_POST['venue']);
        $division = sanitize($conn, $_POST['division']);
        $hours = (int)$_POST['hours'];
        $remarks = sanitize($conn, $_POST['remarks'] ?? '');
        $cert_file = '';

        if (isset($_FILES['certificate']) && $_FILES['certificate']['error'] == 0) {
            $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
            $ext = strtolower(pathinfo($_FILES['certificate']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, $allowed)) {
                $filename = 'cert_' . $emp_id . '_' . time() . '.' . $ext;
                $upload_dir = 'uploads/certificates/';
                if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
                move_uploaded_file($_FILES['certificate']['tmp_name'], $upload_dir . $filename);
                $cert_file = $upload_dir . $filename;
            } else {
                $upload_error = 'Only PDF, JPG, and PNG files are allowed.';
            }
        }

        if (empty($upload_error)) {
            $end_sql = $end_date === "NULL" ? "NULL" : "'$end_date'";
            $conn->query("INSERT INTO employee_trainings 
                (employee_id, training_title, training_date, training_end_date, venue, division, hours, certificate_file, remarks, created_by) 
                VALUES ($emp_id, '$title', '$start_date', $end_sql, '$venue', '$division', $hours, '$cert_file', '$remarks', $admin_id)");
            $_SESSION['success'] = "Training added successfully.";
            redirect('trainings.php?emp=' . $emp_id);
        }
    }

    if ($_POST['action'] == 'delete_training') {
        $tid = (int)$_POST['training_id'];
        $emp_id = (int)$_POST['emp_id'];
        // Delete file if exists
        $file = $conn->query("SELECT certificate_file FROM employee_trainings WHERE id = $tid")->fetch_assoc();
        if ($file && $file['certificate_file'] && file_exists($file['certificate_file'])) {
            unlink($file['certificate_file']);
        }
        $conn->query("DELETE FROM employee_trainings WHERE id = $tid");
        $_SESSION['success'] = "Training deleted.";
        redirect('trainings.php?emp=' . $emp_id);
    }
}

// Search or selected employee
 $selected_employee = null;
 $trainings = null;

if (isset($_GET['emp']) && is_numeric($_GET['emp'])) {
    $emp_id = (int)$_GET['emp'];
    $result = $conn->query("SELECT * FROM employees WHERE id = $emp_id");
    if ($result && $result->num_rows > 0) {
        $selected_employee = $result->fetch_assoc();
        $trainings = $conn->query("SELECT * FROM employee_trainings WHERE employee_id = $emp_id ORDER BY training_date DESC");
    }
}

// Search employees
 $search_results = [];
if (isset($_GET['q']) && !empty($_GET['q'])) {
    $q = sanitize($conn, $_GET['q']);
    $search_results = $conn->query("SELECT * FROM employees WHERE 
        first_name LIKE '%$q%' OR last_name LIKE '%$q%' OR employee_id LIKE '%$q%' 
        ORDER BY last_name, first_name LIMIT 20");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dar-green: #006400;
            --dar-dark-green: #004d00;
            --dar-light-green: #4CAF50;
            --dar-gold: #FFD700;
            --bg-light: #f8faf9;
            --sidebar-bg: #0d3b0d;
            --text-dark: #1a1a2e;
            --text-muted: #6b7280;
            --white: #ffffff;
            --shadow: 0 4px 20px rgba(0,0,0,0.08);
            --shadow-lg: 0 10px 40px rgba(0,0,0,0.12);
            --radius: 12px;
            --transition: all 0.3s ease;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: var(--bg-light); color: var(--text-dark); }
        .dashboard { display: flex; min-height: 100vh; }

        /* ===== SIDEBAR (Exact match sa dashboard_admin.php) ===== */
        .sidebar {
            width: 260px; background: var(--sidebar-bg);
            color: white; position: fixed; top: 0; left: 0; bottom: 0;
            z-index: 100; transition: var(--transition); display: flex; flex-direction: column;
        }
        .sidebar-header {
            padding: 25px 20px; text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1); flex-shrink: 0;
        }
        .sidebar-logo {
            width: 55px; height: 55px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 800; font-size: 18px; margin: 0 auto 15px;
        }
        .sidebar-header h3 { font-size: 1rem; font-weight: 600; }
        .sidebar-header p { font-size: 0.75rem; opacity: 0.7; margin-top: 3px; }
        .nav-menu { padding: 20px 0; flex: 1; overflow-y: auto; }
        .nav-menu::-webkit-scrollbar { width: 4px; }
        .nav-menu::-webkit-scrollbar-track { background: transparent; }
        .nav-menu::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 4px; }
        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 14px 25px; color: rgba(255,255,255,0.8);
            text-decoration: none; font-size: 0.9rem; font-weight: 500;
            transition: var(--transition); border-left: 3px solid transparent; cursor: pointer;
        }
        .nav-item:hover, .nav-item.active {
            background: rgba(255,255,255,0.05); color: white; border-left-color: var(--dar-gold);
        }
        .nav-item i { width: 20px; text-align: center; font-size: 1rem; }
        .nav-divider { height: 1px; background: rgba(255,255,255,0.08); margin: 10px 25px; }
        .nav-label {
            font-size: 0.68rem; font-weight: 600; text-transform: uppercase;
            letter-spacing: 1.5px; color: rgba(255,255,255,0.35); padding: 10px 25px 5px;
        }
        .sidebar-footer {
            padding: 20px; border-top: 1px solid rgba(255,255,255,0.1); flex-shrink: 0;
        }
        .user-info { display: flex; align-items: center; gap: 12px; }
        .user-avatar {
            width: 40px; height: 40px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 700; font-size: 0.9rem;
        }
        .user-details h4 { font-size: 0.85rem; font-weight: 600; }
        .user-details p { font-size: 0.75rem; opacity: 0.6; }
        .logout-btn {
            display: flex; align-items: center; gap: 8px;
            color: rgba(255,255,255,0.7); text-decoration: none;
            font-size: 0.8rem; margin-top: 12px; transition: var(--transition);
        }
        .logout-btn:hover { color: #ef4444; }

        /* ===== MAIN ===== */
        .main-content { flex: 1; margin-left: 260px; min-height: 100vh; }
        .top-bar {
            background: white; padding: 15px 30px;
            display: flex; justify-content: space-between; align-items: center;
            box-shadow: var(--shadow); position: sticky; top: 0; z-index: 50;
        }
        .top-bar h2 { font-size: 1.3rem; font-weight: 700; }
        .top-bar-actions { display: flex; align-items: center; gap: 15px; }
        .content { padding: 30px; }

        .alert {
            padding: 15px 20px; border-radius: 10px; margin-bottom: 25px;
            display: flex; align-items: center; gap: 10px; font-size: 0.95rem;
        }
        .alert-success { background: #f0fdf4; color: #16a34a; border: 1px solid #86efac; }
        .alert-error { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }

        /* Search Section */
        .search-section {
            background: white; border-radius: var(--radius);
            padding: 35px; box-shadow: var(--shadow);
            border: 1px solid #f0f0f0; margin-bottom: 30px;
        }
        .search-section h3 {
            font-size: 1.1rem; font-weight: 700; color: var(--dar-green);
            margin-bottom: 8px;
        }
        .search-section p { color: var(--text-muted); font-size: 0.9rem; margin-bottom: 20px; }
        .search-bar { display: flex; gap: 12px; }
        .search-bar input {
            flex: 1; padding: 14px 18px;
            border: 2px solid #e5e7eb; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.95rem;
            transition: var(--transition);
        }
        .search-bar input:focus {
            outline: none; border-color: var(--dar-green);
            box-shadow: 0 0 0 4px rgba(0,100,0,0.08);
        }
        .btn-search {
            padding: 14px 30px;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; border: none; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.95rem;
            font-weight: 600; cursor: pointer; transition: var(--transition);
            display: flex; align-items: center; gap: 8px; white-space: nowrap;
        }
        .btn-search:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,100,0,0.3); }

        .search-result-item {
            display: flex; align-items: center; gap: 14px;
            padding: 14px 20px; cursor: pointer;
            transition: var(--transition); text-decoration: none; color: var(--text-dark);
            border-radius: 8px; margin-bottom: 4px;
        }
        .search-result-item:hover { background: #f0fdf4; }
        .sr-avatar {
            width: 40px; height: 40px; border-radius: 50%;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            display: flex; align-items: center; justify-content: center;
            color: white; font-weight: 700; font-size: 0.8rem; flex-shrink: 0;
        }
        .sr-info h4 { font-size: 0.9rem; font-weight: 600; }
        .sr-info p { font-size: 0.78rem; color: var(--text-muted); }

        /* Employee Profile Banner */
        .emp-banner {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-dark-green));
            color: white; border-radius: var(--radius);
            padding: 30px 35px; margin-bottom: 25px;
            display: flex; align-items: center; gap: 25px;
            box-shadow: 0 8px 32px rgba(0,100,0,0.25);
        }
        .emp-banner-avatar {
            width: 75px; height: 75px; border-radius: 50%;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-size: 1.8rem; font-weight: 800;
            border: 4px solid rgba(255,255,255,0.2); flex-shrink: 0;
        }
        .emp-banner-info h2 { font-size: 1.4rem; font-weight: 700; margin-bottom: 4px; }
        .emp-banner-info p { opacity: 0.9; font-size: 0.9rem; margin-bottom: 2px; }
        .emp-banner-tags { display: flex; gap: 10px; margin-top: 10px; flex-wrap: wrap; }
        .emp-banner-tag {
            background: rgba(255,255,255,0.15); padding: 5px 14px;
            border-radius: 20px; font-size: 0.78rem;
            border: 1px solid rgba(255,255,255,0.1);
        }

        /* Action Bar */
        .training-action-bar {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 20px; flex-wrap: wrap; gap: 12px;
        }
        .training-stats { display: flex; gap: 20px; }
        .t-stat {
            display: flex; align-items: center; gap: 8px;
            font-size: 0.9rem; color: var(--text-muted);
        }
        .t-stat strong { color: var(--dar-green); font-size: 1.2rem; }
        .action-btns { display: flex; gap: 10px; }
        .btn-add-training {
            padding: 11px 22px;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; border: none; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.88rem;
            font-weight: 600; cursor: pointer; transition: var(--transition);
            display: flex; align-items: center; gap: 8px;
        }
        .btn-add-training:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,100,0,0.3); }
        .btn-generate {
            padding: 11px 22px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            color: var(--dar-green); border: none; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.88rem;
            font-weight: 700; cursor: pointer; transition: var(--transition);
            display: flex; align-items: center; gap: 8px;
        }
        .btn-generate:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(255,215,0,0.4); }
        .btn-back {
            padding: 11px 22px;
            background: white; color: var(--text-dark);
            border: 2px solid #e5e7eb; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.88rem;
            font-weight: 600; cursor: pointer; transition: var(--transition);
            display: flex; align-items: center; gap: 8px;
            text-decoration: none;
        }
        .btn-back:hover { border-color: var(--dar-green); color: var(--dar-green); }

        /* Training Table */
        .training-table-card {
            background: white; border-radius: var(--radius);
            box-shadow: var(--shadow); overflow: hidden;
            border: 1px solid #f0f0f0;
        }
        .training-table { width: 100%; border-collapse: collapse; }
        .training-table th {
            text-align: left; padding: 14px 20px;
            font-size: 0.78rem; font-weight: 600; color: var(--text-muted);
            text-transform: uppercase; letter-spacing: 0.5px;
            background: #fafafa; border-bottom: 1px solid #f0f0f0;
        }
        .training-table td {
            padding: 14px 20px; font-size: 0.88rem;
            border-bottom: 1px solid #f8f8f8; vertical-align: middle;
        }
        .training-table tr:hover td { background: #fafafa; }
        .division-tag {
            display: inline-block; padding: 4px 12px;
            background: #f0fdf4; color: var(--dar-green);
            border-radius: 20px; font-size: 0.75rem; font-weight: 600;
        }
        .cert-badge {
            display: inline-flex; align-items: center; gap: 5px;
            padding: 4px 10px; border-radius: 6px;
            font-size: 0.78rem; font-weight: 600;
        }
        .cert-has { background: #eff6ff; color: #3b82f6; }
        .cert-none { background: #f8f8f8; color: #aaa; }
        .btn-tbl {
            width: 32px; height: 32px; border-radius: 8px;
            border: none; cursor: pointer; display: inline-flex;
            align-items: center; justify-content: center;
            font-size: 0.85rem; transition: var(--transition);
            text-decoration: none; margin-right: 4px;
        }
        .btn-view-cert { background: #eff6ff; color: #3b82f6; }
        .btn-view-cert:hover { background: #3b82f6; color: white; }
        .btn-del-training { background: #fef2f2; color: #ef4444; }
        .btn-del-training:hover { background: #ef4444; color: white; }

        .empty-training {
            text-align: center; padding: 50px 20px; color: var(--text-muted);
        }
        .empty-training i { font-size: 2.5rem; opacity: 0.3; margin-bottom: 12px; display: block; }

        /* Modal */
        .modal-overlay {
            display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.5); z-index: 1000;
            justify-content: center; align-items: center;
            padding: 20px; backdrop-filter: blur(5px);
        }
        .modal-overlay.active { display: flex; }
        .modal {
            background: white; border-radius: var(--radius);
            max-width: 650px; width: 100%; max-height: 90vh;
            overflow-y: auto; box-shadow: var(--shadow-lg);
            animation: modalIn 0.3s ease;
        }
        @keyframes modalIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }
        .modal-header {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; padding: 22px 25px; display: flex;
            justify-content: space-between; align-items: center;
        }
        .modal-header h3 { font-size: 1.2rem; font-weight: 700; }
        .modal-close {
            background: none; border: none; color: white;
            font-size: 1.5rem; cursor: pointer;
        }
        .modal-body { padding: 25px; }
        .modal-footer {
            padding: 18px 25px; border-top: 1px solid #f0f0f0;
            display: flex; justify-content: flex-end; gap: 10px;
        }
        .form-group { margin-bottom: 18px; }
        .form-group label {
            display: block; margin-bottom: 6px;
            font-weight: 600; font-size: 0.85rem;
        }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%; padding: 12px 15px;
            border: 2px solid #e5e7eb; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            transition: var(--transition); background: #fafafa;
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            outline: none; border-color: var(--dar-green);
            box-shadow: 0 0 0 4px rgba(0,100,0,0.08); background: white;
        }
        .form-group textarea { resize: vertical; min-height: 70px; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        .file-upload {
            border: 2px dashed #d1d5db; border-radius: 10px;
            padding: 25px; text-align: center; cursor: pointer;
            transition: var(--transition); background: #fafafa;
        }
        .file-upload:hover { border-color: var(--dar-green); background: #f0fdf4; }
        .file-upload i { font-size: 2rem; color: #ccc; margin-bottom: 8px; }
        .file-upload p { font-size: 0.85rem; color: var(--text-muted); }
        .file-upload small { color: #aaa; font-size: 0.75rem; }
        .file-upload input[type="file"] { display: none; }
        .btn-cancel {
            padding: 11px 22px; border: 2px solid #e5e7eb;
            background: white; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            font-weight: 600; cursor: pointer; transition: var(--transition);
        }
        .btn-cancel:hover { border-color: var(--dar-green); color: var(--dar-green); }
        .btn-save {
            padding: 11px 28px;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; border: none; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            font-weight: 600; cursor: pointer; transition: var(--transition);
        }
        .btn-save:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,100,0,0.3); }

        @media print {
            .sidebar, .top-bar { display: none !important; }
            .main-content { margin-left: 0 !important; }
        }
        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; }
        }
        @media (max-width: 768px) {
            .emp-banner { flex-direction: column; text-align: center; }
            .emp-banner-tags { justify-content: center; }
            .training-action-bar { flex-direction: column; align-items: stretch; }
            .action-btns { flex-wrap: wrap; }
            .form-row { grid-template-columns: 1fr; }
            .content { padding: 20px; }
        }
    </style>
</head>
<body>

<div class="dashboard">
    <!-- ===== SIDEBAR (Exact copy ng dashboard_admin.php) ===== -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">DAR</div>
            <h3>Admin Dashboard</h3>
            <p>Employee Records Management</p>
        </div>
        <nav class="nav-menu">
            <a href="dashboard_admin.php" class="nav-item"><i class="fas fa-home"></i> Dashboard</a>
            <div class="nav-divider"></div>
            <div class="nav-label">People</div>
            <a href="employees.php" class="nav-item"><i class="fas fa-users"></i> Employees</a>
            <div class="nav-divider"></div>
            <div class="nav-label">Recruitment</div>
            <a href="positions.php" class="nav-item"><i class="fas fa-briefcase"></i> Vacant Positions</a>
            <a href="applications.php" class="nav-item"><i class="fas fa-file-alt"></i> Job Applications</a>
            <div class="nav-divider"></div>
            <div class="nav-label">Records</div>
            <a href="trainings.php" class="nav-item active"><i class="fas fa-graduation-cap"></i> Trainings</a>
            <a href="document_tracking.php" class="nav-item"><i class="fas fa-exchange-alt"></i> Doc Tracking</a>
            <a href="documents.php" class="nav-item"><i class="fas fa-folder-open"></i> Documents</a>
            <div class="nav-divider"></div>
            <div class="nav-label">System</div>
            <a href="reports.php" class="nav-item"><i class="fas fa-chart-bar"></i> Reports</a>
            <a href="calendar_admin.php" class="nav-item"><i class="fas fa-calendar-alt"></i> Calendar</a>
            <a href="settings.php" class="nav-item"><i class="fas fa-cog"></i> Settings</a>
        </nav>
        <div class="sidebar-footer">
            <div class="user-info">
                <div class="user-avatar"><?php echo strtoupper(substr($admin_name, 0, 1)); ?></div>
                <div class="user-details">
                    <h4><?php echo htmlspecialchars($admin_name); ?></h4>
                    <p><?php echo ucfirst($role); ?></p>
                </div>
            </div>
            <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </aside>

    <!-- ===== MAIN ===== -->
    <main class="main-content">
        <div class="top-bar">
            <div style="display:flex;align-items:center;gap:12px;">
                <button class="btn-back" style="display:none;padding:8px 10px;border-radius:8px;border:1.5px solid #e5e7eb;background:transparent;cursor:pointer;margin:0;" id="menuToggle" onclick="document.getElementById('sidebar').classList.toggle('open')">
                    <i class="fas fa-bars"></i>
                </button>
                <h2><i class="fas fa-graduation-cap" style="margin-right:10px;color:var(--dar-green);"></i>Training Certificates</h2>
            </div>
            <div class="top-bar-actions">
                <span style="font-size:0.88rem;color:var(--text-muted);font-weight:500;">
                    <i class="fas fa-calendar-day" style="margin-right:6px;"></i><?php echo date('l, F d, Y'); ?>
                </span>
            </div>
        </div>

        <div class="content">
            <?php if(isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
            <?php endif; ?>
            <?php if($upload_error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?php echo $upload_error; ?>
            </div>
            <?php endif; ?>

            <?php if(!$selected_employee): ?>
            <!-- SEARCH EMPLOYEE -->
            <div class="search-section">
                <h3><i class="fas fa-search" style="margin-right:8px;"></i>Search Employee</h3>
                <p>Search by name or employee ID to manage their training records.</p>
                <form method="GET" action="trainings.php">
                    <div class="search-bar">
                        <input type="text" name="q" placeholder="Type employee name or ID..." value="<?php echo isset($_GET['q']) ? htmlspecialchars($_GET['q']) : ''; ?>" autofocus>
                        <button type="submit" class="btn-search"><i class="fas fa-search"></i> Search</button>
                    </div>
                </form>
                <?php if(!empty($search_results) && $search_results->num_rows > 0): ?>
                <div style="margin-top:20px;">
                    <p style="font-size:0.85rem;color:var(--text-muted);margin-bottom:10px;"><?php echo $search_results->num_rows; ?> result(s) found</p>
                    <?php while($sr = $search_results->fetch_assoc()): ?>
                    <a href="trainings.php?emp=<?php echo $sr['id']; ?>" class="search-result-item">
                        <div class="sr-avatar"><?php echo strtoupper(substr($sr['first_name'], 0, 1) . substr($sr['last_name'], 0, 1)); ?></div>
                        <div class="sr-info">
                            <h4><?php echo htmlspecialchars($sr['first_name'] . ' ' . $sr['last_name']); ?></h4>
                            <p><?php echo htmlspecialchars($sr['employee_id']); ?> &bull; <?php echo htmlspecialchars($sr['department']); ?> &bull; <?php echo htmlspecialchars($sr['position']); ?></p>
                        </div>
                        <i class="fas fa-chevron-right" style="margin-left:auto;color:#ccc;"></i>
                    </a>
                    <?php endwhile; ?>
                </div>
                <?php elseif(isset($_GET['q']) && !empty($_GET['q'])): ?>
                <div style="text-align:center;padding:30px;color:var(--text-muted);">
                    <i class="fas fa-user-slash" style="font-size:2rem;opacity:0.3;margin-bottom:10px;display:block;"></i>
                    <p>No employee found matching "<strong><?php echo htmlspecialchars($_GET['q']); ?></strong>"</p>
                </div>
                <?php endif; ?>
            </div>

            <?php else: ?>
            <!-- EMPLOYEE SELECTED -->
            <a href="trainings.php" class="btn-back" style="margin-bottom:20px;display:inline-flex;">
                <i class="fas fa-arrow-left"></i> Back to Search
            </a>

            <div class="emp-banner">
                <div class="emp-banner-avatar"><?php echo strtoupper(substr($selected_employee['first_name'], 0, 1) . substr($selected_employee['last_name'], 0, 1)); ?></div>
                <div class="emp-banner-info">
                    <h2><?php echo htmlspecialchars($selected_employee['first_name'] . ' ' . $selected_employee['last_name']); ?></h2>
                    <p><i class="fas fa-id-badge" style="margin-right:6px;"></i><?php echo htmlspecialchars($selected_employee['employee_id']); ?></p>
                    <p><i class="fas fa-building" style="margin-right:6px;"></i><?php echo htmlspecialchars($selected_employee['department']); ?> — <?php echo htmlspecialchars($selected_employee['position']); ?></p>
                    <div class="emp-banner-tags">
                        <span class="emp-banner-tag"><i class="fas fa-layer-group" style="margin-right:5px;"></i>SG <?php echo htmlspecialchars($selected_employee['salary_grade'] ?? '—'); ?></span>
                        <span class="emp-banner-tag"><i class="fas fa-briefcase" style="margin-right:5px;"></i><?php echo ucfirst($selected_employee['employment_status']); ?></span>
                    </div>
                </div>
            </div>

            <!-- Action Bar -->
            <?php
            $total_trainings = $trainings ? $trainings->num_rows : 0;
            $total_hours = 0;
            $with_cert = 0;
            if ($trainings && $total_trainings > 0) {
                $trainings->data_seek(0);
                while($t = $trainings->fetch_assoc()) {
                    $total_hours += $t['hours'];
                    if (!empty($t['certificate_file'])) $with_cert++;
                }
                $trainings->data_seek(0);
            }
            ?>
            <div class="training-action-bar">
                <div class="training-stats">
                    <div class="t-stat"><strong><?php echo $total_trainings; ?></strong> Trainings</div>
                    <div class="t-stat"><strong><?php echo $total_hours; ?></strong> Total Hours</div>
                    <div class="t-stat"><strong><?php echo $with_cert; ?></strong> With Certs</div>
                </div>
                <div class="action-btns">
                    <button class="btn-generate" onclick="window.open('generate_training_cert.php?emp=<?php echo $selected_employee['id']; ?>')">
                        <i class="fas fa-print"></i> Generate Certification
                    </button>
                    <button class="btn-add-training" onclick="openModal()">
                        <i class="fas fa-plus"></i> Add Training
                    </button>
                </div>
            </div>

            <!-- Training Table -->
            <div class="training-table-card">
                <?php if($trainings && $total_trainings > 0): ?>
                <table class="training-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Training Title</th>
                            <th>Date</th>
                            <th>Division</th>
                            <th>Hours</th>
                            <th>Certificate</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $ctr = 1; while($tr = $trainings->fetch_assoc()):
                            $date_range = date('M d, Y', strtotime($tr['training_date']));
                            if ($tr['training_end_date'] && $tr['training_end_date'] != $tr['training_date']) {
                                $date_range .= ' — ' . date('M d, Y', strtotime($tr['training_end_date']));
                            }
                        ?>
                        <tr>
                            <td style="font-weight:600;color:var(--text-muted);"><?php echo $ctr++; ?></td>
                            <td>
                                <div style="font-weight:600;"><?php echo htmlspecialchars($tr['training_title']); ?></div>
                                <?php if($tr['venue']): ?>
                                <div style="font-size:0.78rem;color:var(--text-muted);"><i class="fas fa-map-marker-alt" style="margin-right:4px;"></i><?php echo htmlspecialchars($tr['venue']); ?></div>
                                <?php endif; ?>
                            </td>
                            <td style="font-size:0.85rem;"><?php echo $date_range; ?></td>
                            <td><span class="division-tag"><?php echo htmlspecialchars($tr['division']); ?></span></td>
                            <td style="font-weight:600;"><?php echo $tr['hours']; ?> hrs</td>
                            <td>
                                <?php if(!empty($tr['certificate_file'])): ?>
                                <a href="<?php echo htmlspecialchars($tr['certificate_file']); ?>" target="_blank" class="cert-badge cert-has"><i class="fas fa-file-pdf"></i> View</a>
                                <?php else: ?>
                                <span class="cert-badge cert-none"><i class="fas fa-times"></i> None</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(!empty($tr['certificate_file'])): ?>
                                <a href="<?php echo htmlspecialchars($tr['certificate_file']); ?>" download class="btn-tbl btn-view-cert" title="Download"><i class="fas fa-download"></i></a>
                                <?php endif; ?>
                                <form method="POST" action="" style="display:inline;" onsubmit="return confirm('Delete this training record?')">
                                    <input type="hidden" name="action" value="delete_training">
                                    <input type="hidden" name="training_id" value="<?php echo $tr['id']; ?>">
                                    <input type="hidden" name="emp_id" value="<?php echo $selected_employee['id']; ?>">
                                    <button type="submit" class="btn-tbl btn-del-training" title="Delete"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
                <?php else: ?>
                <div class="empty-training">
                    <i class="fas fa-graduation-cap"></i>
                    <h4 style="font-size:1.05rem;margin-bottom:5px;">No Training Records Yet</h4>
                    <p>Click "Add Training" to start recording this employee's trainings.</p>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </main>
</div>

<!-- Add Training Modal -->
<div class="modal-overlay" id="addModal">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="fas fa-graduation-cap" style="margin-right:10px;"></i>Add Training Record</h3>
            <button class="modal-close" onclick="closeModal()"><i class="fas fa-times"></i></button>
        </div>
        <form method="POST" action="" enctype="multipart/form-data">
            <input type="hidden" name="action" value="add_training">
            <input type="hidden" name="employee_id" value="<?php echo $selected_employee['id'] ?? ''; ?>">
            <div class="modal-body">
                <div class="form-group">
                    <label><i class="fas fa-book" style="margin-right:6px;color:var(--dar-green);"></i>Training Title</label>
                    <input type="text" name="training_title" required placeholder="e.g., Seminar on Land Reform">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-calendar" style="margin-right:6px;color:var(--dar-green);"></i>Start Date</label>
                        <input type="date" name="training_date" required>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-calendar-check" style="margin-right:6px;color:var(--dar-green);"></i>End Date <small style="color:#aaa;">(if multi-day)</small></label>
                        <input type="date" name="training_end_date">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-map-marker-alt" style="margin-right:6px;color:var(--dar-green);"></i>Venue</label>
                        <input type="text" name="venue" placeholder="e.g., DAR Central Office">
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-clock" style="margin-right:6px;color:var(--dar-green);"></i>Hours</label>
                        <input type="number" name="hours" min="0" value="8" required>
                    </div>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-building" style="margin-right:6px;color:var(--dar-green);"></i>Division / Office</label>
                    <select name="division" required>
                        <option value="">Select Division</option>
                        <?php foreach($divisions as $div): ?>
                        <option value="<?php echo $div; ?>"><?php echo $div; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-file-upload" style="margin-right:6px;color:var(--dar-green);"></i>Certificate File <small style="color:#aaa;">(PDF, JPG, PNG — optional)</small></label>
                    <div class="file-upload" onclick="document.getElementById('certFile').click()">
                        <i class="fas fa-cloud-upload-alt" id="fileIcon"></i>
                        <p id="fileLabel">Click to upload certificate</p>
                        <small>Max 5MB</small>
                        <input type="file" name="certificate" id="certFile" accept=".pdf,.jpg,.jpeg,.png" onchange="showFileName(this)">
                    </div>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-comment" style="margin-right:6px;color:var(--dar-green);"></i>Remarks <small style="color:#aaa;">(optional)</small></label>
                    <textarea name="remarks" placeholder="Additional notes..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-cancel" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn-save"><i class="fas fa-save" style="margin-right:6px;"></i>Save Training</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal() {
    document.getElementById('addModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}
function closeModal() {
    document.getElementById('addModal').classList.remove('active');
    document.body.style.overflow = 'auto';
}
function showFileName(input) {
    const label = document.getElementById('fileLabel');
    const icon = document.getElementById('fileIcon');
    if (input.files.length > 0) {
        label.textContent = input.files[0].name;
        label.style.color = 'var(--dar-green)';
        label.style.fontWeight = '600';
        icon.style.color = 'var(--dar-green)';
    } else {
        label.textContent = 'Click to upload certificate';
        label.style.color = '';
        label.style.fontWeight = '';
        icon.style.color = '';
    }
}
document.getElementById('addModal').addEventListener('click', function(e) {
    if (e.target === this) closeModal();
});

// Mobile menu toggle
function checkMobile() {
    const toggle = document.getElementById('menuToggle');
    if (window.innerWidth <= 1024) {
        toggle.style.display = 'flex';
    } else {
        toggle.style.display = 'none';
        document.getElementById('sidebar').classList.remove('open');
    }
}
checkMobile();
window.addEventListener('resize', checkMobile);
</script>

</body>
</html>