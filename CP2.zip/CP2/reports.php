<?php
session_start();
require_once 'db_config.php';

requireLogin('admin', 'login_admin.php');
 $page_title = "Reports - DAR";

 $admin_id = $_SESSION['admin_id'];
 $admin_name = $_SESSION['admin_name'];
 $role = $_SESSION['admin_role'] ?? 'Admin';

// === SAFE COUNT HELPER ===
function safeCount($conn, $table) {
    try {
        $result = $conn->query("SELECT COUNT(*) as c FROM `$table`");
        if ($result && $result->num_rows > 0) {
            return (int)$result->fetch_assoc()['c'];
        }
    } catch (Exception $e) {
        // Table might not exist — silently return 0
    }
    return 0;
}

// === SAFE QUERY HELPER ===
function safeQuery($conn, $sql) {
    try {
        $result = $conn->query($sql);
        if ($result && $result->num_rows > 0) {
            return $result;
        }
    } catch (Exception $e) {
        // Query might fail — return null
    }
    return null;
}

// === TOTAL COUNTS ===
 $total_employees = safeCount($conn, 'employees');
 $total_applicants = safeCount($conn, 'applicants');
 $total_applications = safeCount($conn, 'job_applications');
 $total_positions = safeCount($conn, 'vacant_positions');
 $total_trainings = safeCount($conn, 'trainings');

// === APPLICATION STATUS BREAKDOWN ===
 $status_result = safeQuery($conn, "SELECT status, COUNT(*) as c FROM job_applications GROUP BY status");
 $status_data = [];
 $status_labels_map = [
    'submitted' => 'Submitted',
    'under_review' => 'Under Review',
    'shortlisted' => 'Shortlisted',
    'interview' => 'Interview',
    'exam' => 'Exam',
    'hired' => 'Hired',
    'approved' => 'Approved',
    'rejected' => 'Rejected'
];
if ($status_result) {
    while ($row = $status_result->fetch_assoc()) {
        $label = $status_labels_map[$row['status']] ?? ucfirst(str_replace('_', ' ', $row['status']));
        $status_data[$row['status']] = ['label' => $label, 'count' => (int)$row['c']];
    }
}

// === APPLICATIONS BY DEPARTMENT ===
 $dept_result = safeQuery($conn, "
    SELECT vp.department, COUNT(*) as c 
    FROM job_applications ja 
    JOIN vacant_positions vp ON vp.id = ja.position_id 
    GROUP BY vp.department 
    ORDER BY c DESC
");
 $dept_data = [];
if ($dept_result) {
    while ($row = $dept_result->fetch_assoc()) {
        $dept_data[] = ['department' => $row['department'] ?? 'Unassigned', 'count' => (int)$row['c']];
    }
}

// === MONTHLY APPLICATION TREND (last 12 months) ===
 $monthly_result = safeQuery($conn, "
    SELECT DATE_FORMAT(applied_at, '%Y-%m') as month, COUNT(*) as c 
    FROM job_applications 
    WHERE applied_at >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
    GROUP BY month 
    ORDER BY month ASC
");
 $monthly_data = [];
 $month_labels = [];
if ($monthly_result) {
    while ($row = $monthly_result->fetch_assoc()) {
        $month_labels[] = date('M Y', strtotime($row['month'] . '-01'));
        $monthly_data[] = (int)$row['c'];
    }
}
// Fill missing months
if (!empty($month_labels)) {
    $start = strtotime($month_labels[0] . '-01');
    $end = strtotime('first day of this month');
    $filled_labels = [];
    $filled_data = [];
    $monthly_assoc = array_combine($month_labels, $monthly_data);
    while ($start <= $end) {
        $key = date('M Y', $start);
        $filled_labels[] = $key;
        $filled_data[] = $monthly_assoc[$key] ?? 0;
        $start = strtotime('+1 month', $start);
    }
    $month_labels = $filled_labels;
    $monthly_data = $filled_data;
}

// === EDUCATION LEVEL BREAKDOWN ===
 $edu_result = safeQuery($conn, "SELECT education_level, COUNT(*) as c FROM applicants GROUP BY education_level ORDER BY c DESC");
 $edu_data = [];
if ($edu_result) {
    while ($row = $edu_result->fetch_assoc()) {
        $edu_data[] = ['level' => $row['education_level'] ?? 'Unknown', 'count' => (int)$row['c']];
    }
}

// === EMPLOYMENT TYPE FROM VACANT POSITIONS ===
 $emptype_result = safeQuery($conn, "SELECT employment_type, COUNT(*) as c FROM vacant_positions GROUP BY employment_type ORDER BY c DESC");
 $emptype_data = [];
if ($emptype_result) {
    while ($row = $emptype_result->fetch_assoc()) {
        $emptype_data[] = ['type' => $row['employment_type'] ?? 'Unknown', 'count' => (int)$row['c']];
    }
}

// === EMPLOYEES BY DEPARTMENT ===
 $emp_dept_result = safeQuery($conn, "SELECT department, COUNT(*) as c FROM employees WHERE department IS NOT NULL AND department != '' GROUP BY department ORDER BY c DESC");
 $emp_dept_data = [];
if ($emp_dept_result) {
    while ($row = $emp_dept_result->fetch_assoc()) {
        $emp_dept_data[] = ['department' => $row['department'], 'count' => (int)$row['c']];
    }
}

// === RECENT HIRED (last 30 days) ===
 $recent_hired = safeQuery($conn, "
    SELECT ja.application_code, a.first_name, a.last_name, a.middle_name, vp.position_title, vp.department, ja.updated_at
    FROM job_applications ja
    JOIN applicants a ON a.id = ja.applicant_id
    JOIN vacant_positions vp ON vp.id = ja.position_id
    WHERE ja.status IN ('hired', 'approved')
    ORDER BY ja.updated_at DESC
    LIMIT 10
");

// === TOP POSITIONS BY APPLICATIONS ===
 $top_positions = safeQuery($conn, "
    SELECT vp.position_title, vp.department, COUNT(*) as c
    FROM job_applications ja
    JOIN vacant_positions vp ON vp.id = ja.position_id
    GROUP BY vp.position_title, vp.department
    ORDER BY c DESC
    LIMIT 8
");

// === GENDER DISTRIBUTION ===
 $gender_result = safeQuery($conn, "SELECT gender, COUNT(*) as c FROM applicants GROUP BY gender");
 $gender_data = [];
if ($gender_result) {
    while ($row = $gender_result->fetch_assoc()) {
        $g = $row['gender'] ?? 'Unknown';
        $gender_data[$g] = (int)$row['c'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <style>
        :root {
            --dar-green: #006400;
            --dar-dark-green: #004d00;
            --dar-light-green: #4CAF50;
            --dar-gold: #FFD700;
            --bg-light: #f8faf9;
            --sidebar-bg: #0d3b0d;
            --text-dark: #1a1a2e;
            --text-muted: #6b7280;
            --shadow: 0 4px 20px rgba(0,0,0,0.08);
            --shadow-lg: 0 10px 40px rgba(0,0,0,0.1);
            --radius: 12px;
            --transition: all 0.3s ease;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: var(--bg-light); color: var(--text-dark); }
        .dashboard { display: flex; min-height: 100vh; }

        /* === SIDEBAR === */
        .sidebar {
            width: 260px; background: var(--sidebar-bg);
            color: white; position: fixed; top: 0; left: 0; bottom: 0;
            z-index: 100; transition: var(--transition);
            display: flex; flex-direction: column;
        }
        .sidebar-header {
            padding: 25px 20px; text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1); flex-shrink: 0;
        }
        .sidebar-logo {
            width: 55px; height: 55px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 800; font-size: 18px; margin: 0 auto 15px;
        }
        .sidebar-header h3 { font-size: 1rem; font-weight: 600; }
        .sidebar-header p { font-size: 0.75rem; opacity: 0.7; margin-top: 3px; }
        .nav-menu { padding: 20px 0; flex: 1; overflow-y: auto; }
        .nav-menu::-webkit-scrollbar { width: 4px; }
        .nav-menu::-webkit-scrollbar-track { background: transparent; }
        .nav-menu::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 4px; }
        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 14px 25px; color: rgba(255,255,255,0.8);
            text-decoration: none; font-size: 0.9rem; font-weight: 500;
            transition: var(--transition); border-left: 3px solid transparent; cursor: pointer;
        }
        .nav-item:hover, .nav-item.active {
            background: rgba(255,255,255,0.05);
            color: white; border-left-color: var(--dar-gold);
        }
        .nav-item i { width: 20px; text-align: center; font-size: 1rem; }
        .nav-divider { height: 1px; background: rgba(255,255,255,0.08); margin: 10px 25px; }
        .nav-label {
            font-size: 0.68rem; font-weight: 600; text-transform: uppercase;
            letter-spacing: 1.5px; color: rgba(255,255,255,0.35); padding: 10px 25px 5px;
        }
        .sidebar-footer {
            padding: 20px; border-top: 1px solid rgba(255,255,255,0.1); flex-shrink: 0;
        }
        .user-info { display: flex; align-items: center; gap: 12px; }
        .user-avatar {
            width: 40px; height: 40px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 700; font-size: 0.9rem;
        }
        .user-details h4 { font-size: 0.85rem; font-weight: 600; }
        .user-details p { font-size: 0.75rem; opacity: 0.6; }
        .logout-btn {
            display: flex; align-items: center; gap: 8px;
            color: rgba(255,255,255,0.7); text-decoration: none;
            font-size: 0.8rem; margin-top: 12px; transition: var(--transition);
        }
        .logout-btn:hover { color: #ef4444; }

        /* === MAIN === */
        .main-content { flex: 1; margin-left: 260px; min-height: 100vh; }
        .top-bar {
            background: white; padding: 15px 30px;
            display: flex; justify-content: space-between; align-items: center;
            box-shadow: var(--shadow); position: sticky; top: 0; z-index: 50;
        }
        .top-bar h2 { font-size: 1.3rem; font-weight: 700; }
        .top-bar-actions { display: flex; gap: 10px; align-items: center; }
        .btn-print {
            padding: 9px 20px; border: 2px solid var(--dar-green);
            background: white; border-radius: 10px; color: var(--dar-green);
            font-family: 'Poppins', sans-serif; font-size: 0.85rem; font-weight: 600;
            cursor: pointer; transition: var(--transition); display: flex; align-items: center; gap: 8px;
        }
        .btn-print:hover { background: var(--dar-green); color: white; }
        .content { padding: 30px; }

        /* === SUMMARY CARDS === */
        .summary-grid {
            display: grid; grid-template-columns: repeat(5, 1fr); gap: 16px; margin-bottom: 30px;
        }
        .summary-card {
            background: white; border-radius: var(--radius); padding: 22px 20px;
            box-shadow: var(--shadow); border: 1px solid #f0f0f0;
            transition: var(--transition); position: relative; overflow: hidden;
        }
        .summary-card::after {
            content: ''; position: absolute; top: 0; right: 0;
            width: 80px; height: 80px; border-radius: 50%;
            opacity: 0.06; transform: translate(20px, -20px);
        }
        .summary-card:hover { transform: translateY(-4px); box-shadow: var(--shadow-lg); }
        .summary-card .sc-icon {
            width: 46px; height: 46px; border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.1rem; margin-bottom: 14px;
        }
        .summary-card h3 { font-size: 1.8rem; font-weight: 800; line-height: 1; margin-bottom: 4px; }
        .summary-card p { font-size: 0.78rem; color: var(--text-muted); font-weight: 500; }

        .sc-employees .sc-icon { background: #eff6ff; color: #3b82f6; }
        .sc-employees h3 { color: #3b82f6; }
        .sc-employees::after { background: #3b82f6; }

        .sc-applicants .sc-icon { background: #f0fdf4; color: #16a34a; }
        .sc-applicants h3 { color: #16a34a; }
        .sc-applicants::after { background: #16a34a; }

        .sc-applications .sc-icon { background: #fefce8; color: #ca8a04; }
        .sc-applications h3 { color: #ca8a04; }
        .sc-applications::after { background: #ca8a04; }

        .sc-positions .sc-icon { background: #faf5ff; color: #a855f7; }
        .sc-positions h3 { color: #a855f7; }
        .sc-positions::after { background: #a855f7; }

        .sc-trainings .sc-icon { background: #ecfeff; color: #0891b2; }
        .sc-trainings h3 { color: #0891b2; }
        .sc-trainings::after { background: #0891b2; }

        /* === CHART GRID === */
        .chart-grid {
            display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px;
        }
        .chart-card {
            background: white; border-radius: var(--radius);
            box-shadow: var(--shadow); border: 1px solid #f0f0f0;
            overflow: hidden;
        }
        .chart-card-header {
            padding: 20px 24px 0; display: flex; justify-content: space-between; align-items: center;
        }
        .chart-card-header h4 {
            font-size: 0.95rem; font-weight: 700; color: var(--text-dark);
            display: flex; align-items: center; gap: 8px;
        }
        .chart-card-header h4 i { color: var(--dar-green); font-size: 0.9rem; }
        .chart-card-body { padding: 16px 24px 24px; }
        .chart-card-body canvas { max-height: 300px; }
        .chart-full { grid-column: 1 / -1; }

        /* === TABLE === */
        .table-card {
            background: white; border-radius: var(--radius);
            box-shadow: var(--shadow); overflow: hidden; margin-bottom: 30px;
        }
        .table-card-header {
            padding: 20px 24px; border-bottom: 1px solid #f0f0f0;
            display: flex; justify-content: space-between; align-items: center;
        }
        .table-card-header h4 {
            font-size: 0.95rem; font-weight: 700; color: var(--text-dark);
            display: flex; align-items: center; gap: 8px;
        }
        .table-card-header h4 i { color: var(--dar-green); }
        .data-table { width: 100%; border-collapse: collapse; }
        .data-table th {
            text-align: left; padding: 12px 20px; font-size: 0.75rem; font-weight: 600;
            color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px;
            background: #fafafa; border-bottom: 1px solid #f0f0f0; white-space: nowrap;
        }
        .data-table td {
            padding: 12px 20px; font-size: 0.87rem;
            border-bottom: 1px solid #f8f8f8; vertical-align: middle;
        }
        .data-table tr:hover td { background: #fafafa; }
        .data-table tr:last-child td { border-bottom: none; }

        .app-code {
            font-family: monospace; font-size: 0.8rem; color: var(--dar-green);
            font-weight: 600; background: rgba(0,100,0,0.06); padding: 3px 8px; border-radius: 4px;
        }
        .dept-tag {
            padding: 3px 10px; border-radius: 6px; font-size: 0.78rem; font-weight: 500;
            background: rgba(62,168,212,0.1); color: #3b82f6; white-space: nowrap;
        }

        /* === HORIZONTAL BAR STATS === */
        .hbar-list { display: flex; flex-direction: column; gap: 14px; }
        .hbar-item {}
        .hbar-item .hbar-label {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 5px; font-size: 0.82rem;
        }
        .hbar-item .hbar-label span:first-child { font-weight: 600; color: var(--text-dark); }
        .hbar-item .hbar-label span:last-child { font-weight: 700; color: var(--dar-green); }
        .hbar-track {
            width: 100%; height: 10px; background: #f0f0f0; border-radius: 10px; overflow: hidden;
        }
        .hbar-fill {
            height: 100%; border-radius: 10px; transition: width 1s ease;
        }

        /* === PIPELINE VISUAL === */
        .pipeline-container {
            display: flex; align-items: center; gap: 0; padding: 10px 0;
        }
        .pipeline-step {
            flex: 1; text-align: center; position: relative;
        }
        .pipeline-step .pipe-dot {
            width: 44px; height: 44px; border-radius: 50%; margin: 0 auto 8px;
            display: flex; align-items: center; justify-content: center;
            font-size: 0.9rem; font-weight: 800; color: white; position: relative; z-index: 2;
        }
        .pipeline-step .pipe-label {
            font-size: 0.7rem; font-weight: 600; color: var(--text-muted);
            text-transform: uppercase; letter-spacing: 0.3px;
        }
        .pipeline-step .pipe-count {
            font-size: 1rem; font-weight: 800; color: var(--text-dark); display: block; margin-top: 2px;
        }
        .pipeline-connector {
            flex: 0 0 30px; height: 3px; background: #e5e7eb; margin-bottom: 40px;
        }

        /* === NO DATA === */
        .no-data {
            text-align: center; padding: 40px 20px; color: var(--text-muted);
        }
        .no-data i { font-size: 2rem; display: block; margin-bottom: 10px; opacity: 0.3; }

        /* === PRINT === */
        @media print {
            .sidebar, .top-bar, .btn-print { display: none !important; }
            .main-content { margin-left: 0 !important; }
            .content { padding: 10px !important; }
            .summary-card, .chart-card, .table-card { break-inside: avoid; box-shadow: none !important; border: 1px solid #ddd; }
            body { background: white; }
        }

        @media (max-width: 1280px) {
            .chart-grid { grid-template-columns: 1fr; }
        }
        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; }
            .summary-grid { grid-template-columns: repeat(3, 1fr); }
        }
        @media (max-width: 768px) {
            .content { padding: 20px; }
            .summary-grid { grid-template-columns: repeat(2, 1fr); }
            .pipeline-container { flex-wrap: wrap; }
            .pipeline-connector { display: none; }
            .pipeline-step { flex: 0 0 33.33%; margin-bottom: 15px; }
        }
    </style>
</head>
<body>

<div class="dashboard">
    <!-- SIDEBAR -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">DAR</div>
            <h3>Admin Dashboard</h3>
            <p>Employee Records Management</p>
        </div>
        <nav class="nav-menu">
            <a href="dashboard_admin.php" class="nav-item"><i class="fas fa-home"></i> Dashboard</a>
            <div class="nav-divider"></div>
            <div class="nav-label">People</div>
            <a href="employees.php" class="nav-item"><i class="fas fa-users"></i> Employees</a>
            <a href="applicants.php" class="nav-item"><i class="fas fa-user-plus"></i> Applicants</a>
            <div class="nav-divider"></div>
            <div class="nav-label">Recruitment</div>
            <a href="positions.php" class="nav-item"><i class="fas fa-briefcase"></i> Vacant Positions</a>
            <a href="applications.php" class="nav-item"><i class="fas fa-file-alt"></i> Job Applications</a>
            <div class="nav-divider"></div>
            <div class="nav-label">Records</div>
            <a href="trainings.php" class="nav-item"><i class="fas fa-graduation-cap"></i> Trainings</a>
            <a href="document_tracking.php" class="nav-item"><i class="fas fa-exchange-alt"></i> Doc Tracking</a>
            <a href="documents.php" class="nav-item"><i class="fas fa-folder-open"></i> Documents</a>
            <div class="nav-divider"></div>
            <div class="nav-label">System</div>
            <a href="reports.php" class="nav-item active"><i class="fas fa-chart-bar"></i> Reports</a>
            <a href="calendar_admin.php" class="nav-item"><i class="fas fa-calendar-alt"></i> Calendar</a>
            <a href="settings.php" class="nav-item"><i class="fas fa-cog"></i> Settings</a>
        </nav>
        <div class="sidebar-footer">
            <div class="user-info">
                <div class="user-avatar"><?php echo strtoupper(substr($admin_name, 0, 1)); ?></div>
                <div class="user-details">
                    <h4><?php echo htmlspecialchars($admin_name); ?></h4>
                    <p><?php echo ucfirst($role); ?></p>
                </div>
            </div>
            <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </aside>

    <!-- MAIN CONTENT -->
    <main class="main-content">
        <div class="top-bar">
            <h2><i class="fas fa-chart-bar" style="margin-right:10px;color:var(--dar-green);"></i>Reports & Analytics</h2>
            <div class="top-bar-actions">
                <button class="btn-print" onclick="window.print()"><i class="fas fa-print"></i> Print Report</button>
            </div>
        </div>

        <div class="content">

            <!-- SUMMARY CARDS -->
            <div class="summary-grid">
                <div class="summary-card sc-employees">
                    <div class="sc-icon"><i class="fas fa-users"></i></div>
                    <h3><?php echo number_format($total_employees); ?></h3>
                    <p>Total Employees</p>
                </div>
                <div class="summary-card sc-applicants">
                    <div class="sc-icon"><i class="fas fa-user-plus"></i></div>
                    <h3><?php echo number_format($total_applicants); ?></h3>
                    <p>Total Applicants</p>
                </div>
                <div class="summary-card sc-applications">
                    <div class="sc-icon"><i class="fas fa-file-alt"></i></div>
                    <h3><?php echo number_format($total_applications); ?></h3>
                    <p>Job Applications</p>
                </div>
                <div class="summary-card sc-positions">
                    <div class="sc-icon"><i class="fas fa-briefcase"></i></div>
                    <h3><?php echo number_format($total_positions); ?></h3>
                    <p>Vacant Positions</p>
                </div>
                <div class="summary-card sc-trainings">
                    <div class="sc-icon"><i class="fas fa-graduation-cap"></i></div>
                    <h3><?php echo number_format($total_trainings); ?></h3>
                    <p>Trainings</p>
                </div>
            </div>

            <!-- APPLICATION PIPELINE -->
            <div class="chart-card" style="margin-bottom:30px;">
                <div class="chart-card-header">
                    <h4><i class="fas fa-stream"></i> Application Pipeline</h4>
                </div>
                <div class="chart-card-body">
                    <?php
                    $pipe_statuses = [
                        'submitted'    => ['label' => 'Submitted',    'color' => '#ca8a04'],
                        'under_review' => ['label' => 'Under Review', 'color' => '#3b82f6'],
                        'shortlisted'  => ['label' => 'Shortlisted',  'color' => '#d97706'],
                        'interview'    => ['label' => 'Interview',    'color' => '#7c3aed'],
                        'exam'         => ['label' => 'Exam',         'color' => '#0891b2'],
                        'hired'        => ['label' => 'Hired',        'color' => '#16a34a'],
                    ];
                    ?>
                    <div class="pipeline-container">
                        <?php $pipeFirst = true; foreach ($pipe_statuses as $key => $ps):
                            $cnt = isset($status_data[$key]) ? $status_data[$key]['count'] : 0;
                            if (!$pipeFirst): ?>
                                <div class="pipeline-connector" style="background: linear-gradient(90deg, <?php echo $pipe_prev_color; ?>, <?php echo $ps['color']; ?>);"></div>
                            <?php endif; $pipeFirst = false; $pipe_prev_color = $ps['color']; ?>
                            <div class="pipeline-step">
                                <div class="pipe-dot" style="background:<?php echo $ps['color']; ?>;"><?php echo $cnt; ?></div>
                                <div class="pipe-label"><?php echo $ps['label']; ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- CHART ROW 1: Doughnut + Bar -->
            <div class="chart-grid">
                <div class="chart-card">
                    <div class="chart-card-header">
                        <h4><i class="fas fa-chart-pie"></i> Application Status</h4>
                    </div>
                    <div class="chart-card-body" style="display:flex;justify-content:center;">
                        <canvas id="statusChart" style="max-width:320px;max-height:320px;"></canvas>
                    </div>
                </div>
                <div class="chart-card">
                    <div class="chart-card-header">
                        <h4><i class="fas fa-chart-bar"></i> Applications by Department</h4>
                    </div>
                    <div class="chart-card-body">
                        <canvas id="deptChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- CHART ROW 2: Line (full width) -->
            <div class="chart-grid">
                <div class="chart-card chart-full">
                    <div class="chart-card-header">
                        <h4><i class="fas fa-chart-line"></i> Monthly Application Trend</h4>
                    </div>
                    <div class="chart-card-body">
                        <canvas id="trendChart" style="max-height:280px;"></canvas>
                    </div>
                </div>
            </div>

            <!-- CHART ROW 3: Education + Employment Type -->
            <div class="chart-grid">
                <div class="chart-card">
                    <div class="chart-card-header">
                        <h4><i class="fas fa-graduation-cap"></i> Education Level</h4>
                    </div>
                    <div class="chart-card-body">
                        <canvas id="eduChart"></canvas>
                    </div>
                </div>
                <div class="chart-card">
                    <div class="chart-card-header">
                        <h4><i class="fas fa-clock"></i> Employment Type</h4>
                    </div>
                    <div class="chart-card-body">
                        <canvas id="empTypeChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- CHART ROW 4: Gender + Employees by Dept -->
            <div class="chart-grid">
                <div class="chart-card">
                    <div class="chart-card-header">
                        <h4><i class="fas fa-venus-mars"></i> Applicant Gender</h4>
                    </div>
                    <div class="chart-card-body" style="display:flex;justify-content:center;">
                        <canvas id="genderChart" style="max-width:260px;max-height:260px;"></canvas>
                    </div>
                </div>
                <div class="chart-card">
                    <div class="chart-card-header">
                        <h4><i class="fas fa-building"></i> Employees by Department</h4>
                    </div>
                    <div class="chart-card-body">
                        <?php if (!empty($emp_dept_data)):
                            $max_emp = max(array_column($emp_dept_data, 'count'));
                            $bar_colors = ['#006400','#3b82f6','#ca8a04','#a855f7','#0891b2','#ef4444','#16a34a','#f59e0b'];
                        ?>
                        <div class="hbar-list">
                            <?php foreach ($emp_dept_data as $i => $ed):
                                $pct = $max_emp > 0 ? round(($ed['count'] / $max_emp) * 100) : 0;
                                $clr = $bar_colors[$i % count($bar_colors)];
                            ?>
                            <div class="hbar-item">
                                <div class="hbar-label">
                                    <span><?php echo htmlspecialchars($ed['department']); ?></span>
                                    <span><?php echo $ed['count']; ?></span>
                                </div>
                                <div class="hbar-track">
                                    <div class="hbar-fill" style="width:<?php echo $pct; ?>%;background:<?php echo $clr; ?>;"></div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php else: ?>
                            <div class="no-data"><i class="fas fa-inbox"></i>No employee data available.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- TOP POSITIONS TABLE -->
            <?php if ($top_positions && $top_positions->num_rows > 0): ?>
            <div class="table-card">
                <div class="table-card-header">
                    <h4><i class="fas fa-trophy"></i> Top Positions by Applications</h4>
                </div>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Position Title</th>
                            <th>Department</th>
                            <th>Applications</th>
                            <th>Share</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $rank = 1; while ($tp = $top_positions->fetch_assoc()):
                            $share = $total_applications > 0 ? round(($tp['c'] / $total_applications) * 100, 1) : 0;
                        ?>
                        <tr>
                            <td><strong style="color:var(--dar-green);"><?php echo $rank++; ?></strong></td>
                            <td style="font-weight:600;"><?php echo htmlspecialchars($tp['position_title']); ?></td>
                            <td><span class="dept-tag"><?php echo htmlspecialchars($tp['department']); ?></span></td>
                            <td><strong><?php echo $tp['c']; ?></strong></td>
                            <td>
                                <div style="display:flex;align-items:center;gap:10px;">
                                    <div style="flex:1;height:8px;background:#f0f0f0;border-radius:8px;overflow:hidden;">
                                        <div style="height:100%;width:<?php echo $share; ?>%;background:var(--dar-green);border-radius:8px;"></div>
                                    </div>
                                    <span style="font-size:0.82rem;font-weight:600;color:var(--dar-green);min-width:40px;"><?php echo $share; ?>%</span>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>

            <!-- RECENT HIRED TABLE -->
            <?php if ($recent_hired && $recent_hired->num_rows > 0): ?>
            <div class="table-card">
                <div class="table-card-header">
                    <h4><i class="fas fa-user-check"></i> Recently Hired / Approved</h4>
                </div>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>App Code</th>
                            <th>Name</th>
                            <th>Position</th>
                            <th>Department</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($rh = $recent_hired->fetch_assoc()):
                            $rh_name = trim(($rh['first_name'] ?? '') . ' ' . ($rh['middle_name'] ?? '') . ' ' . ($rh['last_name'] ?? ''));
                        ?>
                        <tr>
                            <td><span class="app-code"><?php echo htmlspecialchars($rh['application_code']); ?></span></td>
                            <td style="font-weight:600;"><?php echo htmlspecialchars($rh_name); ?></td>
                            <td><?php echo htmlspecialchars($rh['position_title']); ?></td>
                            <td><span class="dept-tag"><?php echo htmlspecialchars($rh['department']); ?></span></td>
                            <td style="color:var(--text-muted);font-size:0.85rem;"><?php echo $rh['updated_at'] ? date('M d, Y', strtotime($rh['updated_at'])) : '—'; ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>

        </div>
    </main>
</div>

<script>
Chart.defaults.font.family = "'Poppins', sans-serif";
Chart.defaults.font.size = 12;
Chart.defaults.color = '#6b7280';
Chart.defaults.plugins.legend.labels.usePointStyle = true;
Chart.defaults.plugins.legend.labels.pointStyleWidth = 10;
Chart.defaults.plugins.legend.labels.padding = 16;

// === 1. APPLICATION STATUS DOUGHNUT ===
const statusKeys = <?php echo json_encode(array_keys($status_data)); ?>;
const statusLabelsArr = <?php echo json_encode(array_column($status_data, 'label')); ?>;
const statusCountsArr = <?php echo json_encode(array_column($status_data, 'count')); ?>;
const statusColors = {
    'submitted': '#ca8a04',
    'under_review': '#3b82f6',
    'shortlisted': '#d97706',
    'interview': '#7c3aed',
    'exam': '#0891b2',
    'hired': '#16a34a',
    'approved': '#16a34a',
    'rejected': '#ef4444'
};
const statusColorArr = statusKeys.map(k => statusColors[k] || '#9ca3af');

if (statusLabelsArr.length > 0) {
    new Chart(document.getElementById('statusChart'), {
        type: 'doughnut',
        data: {
            labels: statusLabelsArr,
            datasets: [{
                data: statusCountsArr,
                backgroundColor: statusColorArr,
                borderWidth: 2,
                borderColor: '#fff',
                hoverOffset: 8
            }]
        },
        options: {
            responsive: true,
            cutout: '65%',
            plugins: {
                legend: { position: 'bottom', labels: { font: { size: 11, weight: 500 }, padding: 12 } }
            }
        }
    });
}

// === 2. APPLICATIONS BY DEPARTMENT (BAR) ===
const deptLabels = <?php echo json_encode(array_column($dept_data, 'department')); ?>;
const deptCounts = <?php echo json_encode(array_column($dept_data, 'count')); ?>;
const deptBarColors = ['#006400','#3b82f6','#ca8a04','#a855f7','#0891b2','#ef4444','#16a34a','#f59e0b','#ec4899','#6366f1'];

if (deptLabels.length > 0) {
    new Chart(document.getElementById('deptChart'), {
        type: 'bar',
        data: {
            labels: deptLabels,
            datasets: [{
                label: 'Applications',
                data: deptCounts,
                backgroundColor: deptLabels.map((_, i) => deptBarColors[i % deptBarColors.length] + '22'),
                borderColor: deptLabels.map((_, i) => deptBarColors[i % deptBarColors.length]),
                borderWidth: 2,
                borderRadius: 8,
                borderSkipped: false,
                maxBarThickness: 50
            }]
        },
        options: {
            responsive: true,
            indexAxis: 'y',
            plugins: { legend: { display: false } },
            scales: {
                x: { grid: { color: '#f3f4f6' }, ticks: { font: { size: 11 } } },
                y: { grid: { display: false }, ticks: { font: { size: 11, weight: 600 } } }
            }
        }
    });
}

// === 3. MONTHLY TREND (LINE) ===
const monthLabels = <?php echo json_encode($month_labels); ?>;
const monthCounts = <?php echo json_encode($monthly_data); ?>;

if (monthLabels.length > 0) {
    new Chart(document.getElementById('trendChart'), {
        type: 'line',
        data: {
            labels: monthLabels,
            datasets: [{
                label: 'Applications',
                data: monthCounts,
                borderColor: '#006400',
                backgroundColor: 'rgba(0,100,0,0.08)',
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#006400',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 7
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: {
                x: { grid: { display: false }, ticks: { font: { size: 11 } } },
                y: { beginAtZero: true, grid: { color: '#f3f4f6' }, ticks: { stepSize: 1, font: { size: 11 } } }
            }
        }
    });
}

// === 4. EDUCATION LEVEL (BAR) ===
const eduLabels = <?php echo json_encode(array_column($edu_data, 'level')); ?>;
const eduCounts = <?php echo json_encode(array_column($edu_data, 'count')); ?>;

if (eduLabels.length > 0) {
    new Chart(document.getElementById('eduChart'), {
        type: 'bar',
        data: {
            labels: eduLabels,
            datasets: [{
                label: 'Applicants',
                data: eduCounts,
                backgroundColor: '#4CAF5033',
                borderColor: '#4CAF50',
                borderWidth: 2,
                borderRadius: 8,
                borderSkipped: false,
                maxBarThickness: 60
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: {
                x: { grid: { display: false }, ticks: { font: { size: 10, weight: 500 }, maxRotation: 45 } },
                y: { beginAtZero: true, grid: { color: '#f3f4f6' }, ticks: { stepSize: 1, font: { size: 11 } } }
            }
        }
    });
}

// === 5. EMPLOYMENT TYPE (PIE) ===
const empTypeLabels = <?php echo json_encode(array_column($emptype_data, 'type')); ?>;
const empTypeCounts = <?php echo json_encode(array_column($emptype_data, 'count')); ?>;
const empTypeColors = ['#006400','#3b82f6','#ca8a04','#a855f7','#0891b2','#ef4444'];

if (empTypeLabels.length > 0) {
    new Chart(document.getElementById('empTypeChart'), {
        type: 'pie',
        data: {
            labels: empTypeLabels,
            datasets: [{
                data: empTypeCounts,
                backgroundColor: empTypeLabels.map((_, i) => empTypeColors[i % empTypeColors.length] + 'cc'),
                borderColor: '#fff',
                borderWidth: 3,
                hoverOffset: 8
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'bottom', labels: { font: { size: 11, weight: 500 }, padding: 14 } }
            }
        }
    });
}

// === 6. GENDER (DOUGHNUT) ===
const genderLabels = <?php echo json_encode(array_keys($gender_data)); ?>;
const genderCounts = <?php echo json_encode(array_values($gender_data)); ?>;
const genderColors = { 'Male': '#3b82f6', 'Female': '#ec4899', 'Other': '#a855f7' };
const genderColorArr = genderLabels.map(g => genderColors[g] || '#9ca3af');

if (genderLabels.length > 0) {
    new Chart(document.getElementById('genderChart'), {
        type: 'doughnut',
        data: {
            labels: genderLabels,
            datasets: [{
                data: genderCounts,
                backgroundColor: genderColorArr,
                borderWidth: 2,
                borderColor: '#fff',
                hoverOffset: 8
            }]
        },
        options: {
            responsive: true,
            cutout: '60%',
            plugins: {
                legend: { position: 'bottom', labels: { font: { size: 12, weight: 600 }, padding: 16 } }
            }
        }
    });
}
</script>

</body>
</html>