<?php
session_start();
require_once 'db_config.php';

requireLogin('admin', 'login_admin.php');
 $page_title = "Manage Employees - DAR";

 $admin_id = $_SESSION['admin_id'];
 $admin_name = $_SESSION['admin_name'];
 $role = $_SESSION['admin_role'] ?? 'Admin';

// Handle View - fetch single employee
 $view_data = null;
if (isset($_GET['view']) && is_numeric($_GET['view'])) {
    $view_id = (int)$_GET['view'];
    $view_result = $conn->query("SELECT * FROM employees WHERE id = $view_id");
    if ($view_result && $view_result->num_rows > 0) {
        $view_data = $view_result->fetch_assoc();
    }
}

// Handle Delete
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM employees WHERE id = $id");
    $_SESSION['success'] = "Employee deleted successfully.";
    redirect('employees.php');
}

// Handle Add/Edit
 $edit_mode = false;
 $edit_data = null;

if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $edit_mode = true;
    $edit_id = (int)$_GET['edit'];
    $edit_result = $conn->query("SELECT * FROM employees WHERE id = $edit_id");
    $edit_data = $edit_result->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $employee_id = sanitize($conn, $_POST['employee_id']);
    $first_name = sanitize($conn, $_POST['first_name']);
    $middle_name = sanitize($conn, $_POST['middle_name'] ?? '');
    $last_name = sanitize($conn, $_POST['last_name']);
    $suffix = sanitize($conn, $_POST['suffix'] ?? '');
    $date_of_birth = sanitize($conn, $_POST['date_of_birth']);
    $gender = sanitize($conn, $_POST['gender']);
    $civil_status = sanitize($conn, $_POST['civil_status']);
    $email = sanitize($conn, $_POST['email']);
    $phone = sanitize($conn, $_POST['phone']);
    $address = sanitize($conn, $_POST['address']);
    $emergency_contact_name = sanitize($conn, $_POST['emergency_contact_name'] ?? '');
    $emergency_contact_phone = sanitize($conn, $_POST['emergency_contact_phone'] ?? '');
    $department = sanitize($conn, $_POST['department']);
    $position = sanitize($conn, $_POST['position']);
    $employment_status = sanitize($conn, $_POST['employment_status']);
    $salary_grade = sanitize($conn, $_POST['salary_grade'] ?? '');
    $date_hired = sanitize($conn, $_POST['date_hired']);
    $username = sanitize($conn, $_POST['username']);
    $status = sanitize($conn, $_POST['status']);
    $raw_password = $_POST['password'] ?? '';

    if (isset($_POST['id']) && !empty($_POST['id'])) {
        // Update
        $id = (int)$_POST['id'];
        $sql = "UPDATE employees SET 
                employee_id = '$employee_id', first_name = '$first_name', middle_name = '$middle_name',
                last_name = '$last_name', suffix = '$suffix', date_of_birth = '$date_of_birth',
                gender = '$gender', civil_status = '$civil_status', email = '$email',
                phone = '$phone', address = '$address', emergency_contact_name = '$emergency_contact_name',
                emergency_contact_phone = '$emergency_contact_phone', department = '$department',
                position = '$position', employment_status = '$employment_status', salary_grade = '$salary_grade',
                date_hired = '$date_hired', username = '$username', status = '$status'
                WHERE id = $id";
        $conn->query($sql);

        // Only touch the password if the admin actually typed a new one
        if (!empty($raw_password)) {
            $hashed = password_hash($raw_password, PASSWORD_DEFAULT);
            $conn->query("UPDATE employees SET password = '$hashed' WHERE id = $id");
        }
        $_SESSION['success'] = "Employee updated successfully.";
    } else {
        // Insert - use the password typed in the form, or fall back to a default
        $used_default = empty($raw_password);
        $password = password_hash($used_default ? 'password123' : $raw_password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO employees (employee_id, first_name, middle_name, last_name, suffix,
                date_of_birth, gender, civil_status, email, phone, address,
                emergency_contact_name, emergency_contact_phone, department, position,
                employment_status, salary_grade, date_hired, username, password, status, created_by)
                VALUES ('$employee_id', '$first_name', '$middle_name', '$last_name', '$suffix',
                '$date_of_birth', '$gender', '$civil_status', '$email', '$phone', '$address',
                '$emergency_contact_name', '$emergency_contact_phone', '$department', '$position',
                '$employment_status', '$salary_grade', '$date_hired', '$username', '$password', '$status', $admin_id)";
        $conn->query($sql);
        $_SESSION['success'] = $used_default
            ? "Employee added successfully. Default password: password123"
            : "Employee added successfully.";
    }
    redirect('employees.php');
}

// Fetch all employees
 $employees = $conn->query("SELECT * FROM employees ORDER BY created_at DESC");

// Fetch departments for dropdown
 $departments = $conn->query("SELECT DISTINCT department FROM employees ORDER BY department");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dar-green: #006400;
            --dar-dark-green: #004d00;
            --dar-light-green: #4CAF50;
            --dar-gold: #FFD700;
            --bg-light: #f8faf9;
            --sidebar-bg: #0d3b0d;
            --text-dark: #1a1a2e;
            --text-muted: #6b7280;
            --shadow: 0 4px 20px rgba(0,0,0,0.08);
            --shadow-lg: 0 10px 40px rgba(0,0,0,0.1);
            --radius: 12px;
            --transition: all 0.3s ease;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: var(--bg-light); color: var(--text-dark); }

        .dashboard { display: flex; min-height: 100vh; }

        .sidebar {
            width: 260px; background: var(--sidebar-bg);
            color: white; position: fixed; top: 0; left: 0; bottom: 0;
            z-index: 100; transition: var(--transition);
            display: flex; flex-direction: column;
        }
        .sidebar-header {
            padding: 25px 20px; text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            flex-shrink: 0;
        }
        .sidebar-logo {
            width: 55px; height: 55px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 800; font-size: 18px;
            margin: 0 auto 15px;
        }
        .sidebar-header h3 { font-size: 1rem; font-weight: 600; }
        .sidebar-header p { font-size: 0.75rem; opacity: 0.7; margin-top: 3px; }

        .nav-menu {
            padding: 20px 0;
            flex: 1;
            overflow-y: auto;
        }
        .nav-menu::-webkit-scrollbar { width: 4px; }
        .nav-menu::-webkit-scrollbar-track { background: transparent; }
        .nav-menu::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 4px; }
        .nav-menu::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.25); }

        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 14px 25px; color: rgba(255,255,255,0.8);
            text-decoration: none; font-size: 0.9rem; font-weight: 500;
            transition: var(--transition); border-left: 3px solid transparent;
            cursor: pointer;
        }
        .nav-item:hover, .nav-item.active {
            background: rgba(255,255,255,0.05);
            color: white; border-left-color: var(--dar-gold);
        }
        .nav-item i { width: 20px; text-align: center; font-size: 1rem; }

        .nav-divider {
            height: 1px; background: rgba(255,255,255,0.08);
            margin: 10px 25px;
        }
        .nav-label {
            font-size: 0.68rem; font-weight: 600;
            text-transform: uppercase; letter-spacing: 1.5px;
            color: rgba(255,255,255,0.35); padding: 10px 25px 5px;
        }

        .sidebar-footer {
            padding: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
            flex-shrink: 0;
        }
        .user-info { display: flex; align-items: center; gap: 12px; }
        .user-avatar {
            width: 40px; height: 40px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 700; font-size: 0.9rem;
        }
        .user-details h4 { font-size: 0.85rem; font-weight: 600; }
        .user-details p { font-size: 0.75rem; opacity: 0.6; }
        .logout-btn {
            display: flex; align-items: center; gap: 8px;
            color: rgba(255,255,255,0.7); text-decoration: none;
            font-size: 0.8rem; margin-top: 12px; transition: var(--transition);
        }
        .logout-btn:hover { color: #ef4444; }

        .main-content { flex: 1; margin-left: 260px; min-height: 100vh; }
        .top-bar {
            background: white; padding: 15px 30px;
            display: flex; justify-content: space-between; align-items: center;
            box-shadow: var(--shadow); position: sticky; top: 0; z-index: 50;
        }
        .top-bar h2 { font-size: 1.3rem; font-weight: 700; }

        .content { padding: 30px; }

        /* Alert Messages */
        .alert {
            padding: 15px 20px; border-radius: 10px; margin-bottom: 25px;
            display: flex; align-items: center; gap: 10px; font-size: 0.95rem;
        }
        .alert-success { background: #f0fdf4; color: #16a34a; border: 1px solid #86efac; }
        .alert-error { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }

        /* Action Bar */
        .action-bar {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 25px; flex-wrap: wrap; gap: 15px;
        }
        .search-box {
            display: flex; align-items: center; gap: 10px;
            background: white; padding: 10px 15px; border-radius: 10px;
            box-shadow: var(--shadow); border: 1px solid #f0f0f0;
        }
        .search-box input {
            border: none; outline: none; font-family: 'Poppins', sans-serif;
            font-size: 0.9rem; width: 250px;
        }
        .btn-add {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; padding: 12px 25px; border: none; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.95rem; font-weight: 600;
            cursor: pointer; display: flex; align-items: center; gap: 8px;
            transition: var(--transition); text-decoration: none;
        }
        .btn-add:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,100,0,0.3); }

        /* Table */
        .table-card {
            background: white; border-radius: var(--radius);
            box-shadow: var(--shadow); overflow: hidden;
        }
        .data-table { width: 100%; border-collapse: collapse; }
        .data-table th {
            text-align: left; padding: 14px 20px;
            font-size: 0.8rem; font-weight: 600; color: var(--text-muted);
            text-transform: uppercase; letter-spacing: 0.5px;
            background: #fafafa; border-bottom: 1px solid #f0f0f0;
        }
        .data-table td {
            padding: 14px 20px; font-size: 0.9rem;
            border-bottom: 1px solid #f8f8f8;
        }
        .data-table tr:hover td { background: #fafafa; }
        .user-cell {
            display: flex; align-items: center; gap: 12px;
        }
        .user-avatar-sm {
            width: 36px; height: 36px; border-radius: 50%;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            display: flex; align-items: center; justify-content: center;
            color: white; font-weight: 600; font-size: 0.8rem;
        }
        .status-badge {
            display: inline-block; padding: 4px 12px;
            border-radius: 20px; font-size: 0.75rem; font-weight: 600;
        }
        .status-active { background: #f0fdf4; color: #16a34a; }
        .status-inactive { background: #f1f5f9; color: #64748b; }
        .status-on_leave { background: #fefce8; color: #ca8a04; }

        .action-btns { display: flex; gap: 6px; }
        .btn-action {
            width: 32px; height: 32px; border-radius: 8px;
            border: none; cursor: pointer; display: flex;
            align-items: center; justify-content: center;
            font-size: 0.85rem; transition: var(--transition);
            text-decoration: none;
        }
        .btn-view { background: #f0fdf4; color: #16a34a; }
        .btn-view:hover { background: #16a34a; color: white; }
        .btn-edit { background: #eff6ff; color: #3b82f6; }
        .btn-edit:hover { background: #3b82f6; color: white; }
        .btn-delete { background: #fef2f2; color: #ef4444; }
        .btn-delete:hover { background: #ef4444; color: white; }

        /* Modal */
        .modal-overlay {
            display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.5); z-index: 1000;
            justify-content: center; align-items: center;
            padding: 20px; backdrop-filter: blur(5px);
        }
        .modal-overlay.active { display: flex; }
        .modal {
            background: white; border-radius: var(--radius);
            max-width: 800px; width: 100%; max-height: 90vh;
            overflow-y: auto; box-shadow: var(--shadow-lg);
            animation: modalIn 0.3s ease;
        }
        @keyframes modalIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }
        .modal-header {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; padding: 25px; display: flex;
            justify-content: space-between; align-items: center;
        }
        .modal-header h3 { font-size: 1.3rem; font-weight: 700; }
        .modal-close {
            background: none; border: none; color: white;
            font-size: 1.5rem; cursor: pointer;
        }
        .modal-body { padding: 25px; }
        .form-grid {
            display: grid; grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        .form-group.full { grid-column: 1 / -1; }
        .form-group label {
            display: block; margin-bottom: 6px;
            font-weight: 600; font-size: 0.85rem; color: var(--text-dark);
        }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%; padding: 12px 15px;
            border: 2px solid #e5e7eb; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            transition: var(--transition);
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            outline: none; border-color: var(--dar-green);
            box-shadow: 0 0 0 4px rgba(0,100,0,0.08);
        }
        .form-group textarea { resize: vertical; min-height: 80px; }
        .modal-footer {
            padding: 20px 25px; border-top: 1px solid #f0f0f0;
            display: flex; justify-content: flex-end; gap: 10px;
        }
        .btn-cancel {
            padding: 12px 25px; border: 2px solid #e5e7eb;
            background: white; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            font-weight: 600; cursor: pointer; transition: var(--transition);
        }
        .btn-cancel:hover { border-color: var(--dar-green); color: var(--dar-green); }
        .btn-save {
            padding: 12px 30px;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; border: none; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            font-weight: 600; cursor: pointer; transition: var(--transition);
        }
        .btn-save:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,100,0,0.3); }

        /* View Modal Styles */
        .view-modal-body { padding: 0; }
        .view-profile-header {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-dark-green));
            padding: 35px 30px; text-align: center; color: white;
            position: relative;
        }
        .view-avatar {
            width: 90px; height: 90px; border-radius: 50%;
            background: rgba(255,255,255,0.2); border: 4px solid rgba(255,255,255,0.4);
            display: flex; align-items: center; justify-content: center;
            font-size: 2rem; font-weight: 800; margin: 0 auto 15px;
            color: white;
        }
        .view-profile-header h3 { font-size: 1.4rem; font-weight: 700; margin-bottom: 5px; }
        .view-profile-header p { font-size: 0.9rem; opacity: 0.85; }
        .view-profile-header .view-id-badge {
            display: inline-block; background: rgba(255,215,0,0.2);
            border: 1px solid rgba(255,215,0,0.4); padding: 5px 16px;
            border-radius: 20px; font-size: 0.8rem; font-weight: 600;
            color: var(--dar-gold); margin-top: 10px;
        }
        .view-section {
            padding: 25px 30px;
            border-bottom: 1px solid #f0f0f0;
        }
        .view-section:last-child { border-bottom: none; }
        .view-section-title {
            font-size: 0.95rem; font-weight: 700; color: var(--dar-green);
            margin-bottom: 18px; display: flex; align-items: center; gap: 8px;
            text-transform: uppercase; letter-spacing: 0.5px;
        }
        .view-section-title i { font-size: 0.85rem; }
        .view-grid {
            display: grid; grid-template-columns: 1fr 1fr;
            gap: 16px;
        }
        .view-field label {
            display: block; font-size: 0.75rem; font-weight: 600;
            color: var(--text-muted); text-transform: uppercase;
            letter-spacing: 0.5px; margin-bottom: 4px;
        }
        .view-field p {
            font-size: 0.92rem; font-weight: 500; color: var(--text-dark);
            line-height: 1.5;
        }
        .view-field.full { grid-column: 1 / -1; }
        .view-status-row {
            display: flex; gap: 12px; flex-wrap: wrap; margin-top: 5px;
        }
        .view-status-tag {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 6px 14px; border-radius: 20px;
            font-size: 0.8rem; font-weight: 600;
        }
        .view-status-tag.active-tag { background: #f0fdf4; color: #16a34a; }
        .view-status-tag.inactive-tag { background: #f1f5f9; color: #64748b; }
        .view-status-tag.leave-tag { background: #fefce8; color: #ca8a04; }
        .view-status-tag.retired-tag { background: #fef2f2; color: #dc2626; }

        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; }
        }
        @media (max-width: 768px) {
            .form-grid { grid-template-columns: 1fr; }
            .view-grid { grid-template-columns: 1fr; }
            .content { padding: 20px; }
            .action-bar { flex-direction: column; align-items: stretch; }
            .search-box { width: 100%; }
            .search-box input { width: 100%; }
            .view-section { padding: 20px; }
            .view-profile-header { padding: 25px 20px; }
        }
    </style>
</head>
<body>

    <div class="dashboard">
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">DAR</div>
                <h3>Admin Dashboard</h3>
                <p>Employee Records Management</p>
            </div>

            <nav class="nav-menu">
                <a href="dashboard_admin.php" class="nav-item">
                    <i class="fas fa-home"></i> Dashboard
                </a>

                <div class="nav-divider"></div>
                <div class="nav-label">People</div>

                <a href="employees.php" class="nav-item active">
                    <i class="fas fa-users"></i> Employees
                </a>
                

                <div class="nav-divider"></div>
                <div class="nav-label">Recruitment</div>

                <a href="positions.php" class="nav-item">
                    <i class="fas fa-briefcase"></i> Vacant Positions
                </a>
                <a href="applications.php" class="nav-item">
                    <i class="fas fa-file-alt"></i> Job Applications
                </a>

                <div class="nav-divider"></div>
                <div class="nav-label">Records</div>

                <a href="trainings.php" class="nav-item">
                    <i class="fas fa-graduation-cap"></i> Trainings
                </a>
                <a href="document_tracking.php" class="nav-item">
                    <i class="fas fa-exchange-alt"></i> Doc Tracking
                </a>
                <a href="documents.php" class="nav-item">
                    <i class="fas fa-folder-open"></i> Documents
                </a>

                <div class="nav-divider"></div>
                <div class="nav-label">System</div>

                <a href="reports.php" class="nav-item">
                    <i class="fas fa-chart-bar"></i> Reports
                </a>
                <a href="calendar_admin.php" class="nav-item">
                    <i class="fas fa-calendar-alt"></i> Calendar
                </a>
                <a href="settings.php" class="nav-item">
                    <i class="fas fa-cog"></i> Settings
                </a>
            </nav>

            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar"><?php echo strtoupper(substr($admin_name, 0, 1)); ?></div>
                    <div class="user-details">
                        <h4><?php echo htmlspecialchars($admin_name); ?></h4>
                        <p><?php echo ucfirst($role); ?></p>
                    </div>
                </div>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </aside>

        <main class="main-content">
            <div class="top-bar">
                <h2><i class="fas fa-users" style="margin-right: 10px; color: var(--dar-green);"></i>Manage Employees</h2>
            </div>

            <div class="content">
                <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
                <?php endif; ?>

                <div class="action-bar">
                    <div class="search-box">
                        <i class="fas fa-search" style="color: var(--text-muted);"></i>
                        <input type="text" id="searchInput" placeholder="Search employees..." onkeyup="searchTable()">
                    </div>
                    <button class="btn-add" onclick="openModal()">
                        <i class="fas fa-plus"></i> Add Employee
                    </button>
                </div>

                <div class="table-card">
                    <table class="data-table" id="employeesTable">
                        <thead>
                            <tr>
                                <th>Employee</th>
                                <th>ID</th>
                                <th>Department</th>
                                <th>Position</th>
                                <th>Status</th>
                                <th>Date Hired</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($emp = $employees->fetch_assoc()): ?>
                            <tr>
                                <td>
                                    <div class="user-cell">
                                        <div class="user-avatar-sm"><?php echo strtoupper(substr($emp['first_name'], 0, 1) . substr($emp['last_name'], 0, 1)); ?></div>
                                        <span style="font-weight: 600;"><?php echo htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']); ?></span>
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($emp['employee_id']); ?></td>
                                <td><?php echo htmlspecialchars($emp['department']); ?></td>
                                <td><?php echo htmlspecialchars($emp['position']); ?></td>
                                <td><span class="status-badge status-<?php echo $emp['status']; ?>"><?php echo ucwords(str_replace('_', ' ', $emp['status'])); ?></span></td>
                                <td><?php echo date('M d, Y', strtotime($emp['date_hired'])); ?></td>
                                <td>
                                    <div class="action-btns">
                                        <button class="btn-action btn-view" title="View" onclick="viewEmployee(<?php echo $emp['id']; ?>)"><i class="fas fa-eye"></i></button>
                                        <a href="employees.php?edit=<?php echo $emp['id']; ?>" class="btn-action btn-edit" title="Edit"><i class="fas fa-edit"></i></a>
                                        <a href="employees.php?delete=<?php echo $emp['id']; ?>" class="btn-action btn-delete" title="Delete" onclick="return confirm('Are you sure you want to delete this employee?')"><i class="fas fa-trash"></i></a>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <!-- Add/Edit Modal -->
    <div class="modal-overlay" id="employeeModal" <?php echo $edit_mode ? 'style="display:flex;"' : ''; ?>>
        <div class="modal">
            <div class="modal-header">
                <h3><i class="fas fa-user-plus" style="margin-right: 10px;"></i><?php echo $edit_mode ? 'Edit Employee' : 'Add New Employee'; ?></h3>
                <button class="modal-close" onclick="closeModal()"><i class="fas fa-times"></i></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <div class="form-grid">
                        <?php if($edit_mode): ?>
                        <input type="hidden" name="id" value="<?php echo $edit_data['id']; ?>">
                        <?php endif; ?>

                        <div class="form-group">
                            <label>Employee ID</label>
                            <input type="text" name="employee_id" required value="<?php echo $edit_data['employee_id'] ?? 'DAR-' . date('Y') . '-' . str_pad(rand(1,9999), 4, '0', STR_PAD_LEFT); ?>">
                        </div>
                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" name="username" required value="<?php echo $edit_data['username'] ?? ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>Password<?php echo $edit_mode ? ' (leave blank to keep current)' : ''; ?></label>
                            <input type="password" name="password" placeholder="<?php echo $edit_mode ? 'Leave blank to keep current password' : 'Set a login password (optional, defaults to password123)'; ?>" autocomplete="new-password">
                        </div>
                        <div class="form-group">
                            <label>First Name</label>
                            <input type="text" name="first_name" required value="<?php echo $edit_data['first_name'] ?? ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>Middle Name</label>
                            <input type="text" name="middle_name" value="<?php echo $edit_data['middle_name'] ?? ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>Last Name</label>
                            <input type="text" name="last_name" required value="<?php echo $edit_data['last_name'] ?? ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>Suffix</label>
                            <input type="text" name="suffix" placeholder="Jr., Sr., III" value="<?php echo $edit_data['suffix'] ?? ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>Date of Birth</label>
                            <input type="date" name="date_of_birth" required value="<?php echo $edit_data['date_of_birth'] ?? ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>Gender</label>
                            <select name="gender" required>
                                <option value="">Select</option>
                                <option value="Male" <?php echo ($edit_data['gender'] ?? '') == 'Male' ? 'selected' : ''; ?>>Male</option>
                                <option value="Female" <?php echo ($edit_data['gender'] ?? '') == 'Female' ? 'selected' : ''; ?>>Female</option>
                                <option value="Other" <?php echo ($edit_data['gender'] ?? '') == 'Other' ? 'selected' : ''; ?>>Other</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Civil Status</label>
                            <select name="civil_status" required>
                                <option value="">Select</option>
                                <option value="Single" <?php echo ($edit_data['civil_status'] ?? '') == 'Single' ? 'selected' : ''; ?>>Single</option>
                                <option value="Married" <?php echo ($edit_data['civil_status'] ?? '') == 'Married' ? 'selected' : ''; ?>>Married</option>
                                <option value="Widowed" <?php echo ($edit_data['civil_status'] ?? '') == 'Widowed' ? 'selected' : ''; ?>>Widowed</option>
                                <option value="Separated" <?php echo ($edit_data['civil_status'] ?? '') == 'Separated' ? 'selected' : ''; ?>>Seperated</option>
                                                                <option value="Divorced" <?php echo ($edit_data['civil_status'] ?? '') == 'Divorced' ? 'selected' : ''; ?>>Divorced</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" required value="<?php echo $edit_data['email'] ?? ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>Phone</label>
                            <input type="tel" name="phone" value="<?php echo $edit_data['phone'] ?? ''; ?>">
                        </div>
                        <div class="form-group full">
                            <label>Address</label>
                            <textarea name="address" required><?php echo $edit_data['address'] ?? ''; ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>Emergency Contact Name</label>
                            <input type="text" name="emergency_contact_name" value="<?php echo $edit_data['emergency_contact_name'] ?? ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>Emergency Contact Phone</label>
                            <input type="tel" name="emergency_contact_phone" value="<?php echo $edit_data['emergency_contact_phone'] ?? ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>Department</label>
                            <input type="text" name="department" required value="<?php echo $edit_data['department'] ?? ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>Position</label>
                            <input type="text" name="position" required value="<?php echo $edit_data['position'] ?? ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>Employment Status</label>
                            <select name="employment_status" required>
                                <option value="">Select</option>
                                <option value="Permanent" <?php echo ($edit_data['employment_status'] ?? '') == 'Permanent' ? 'selected' : ''; ?>>Permanent</option>
                                <option value="Temporary" <?php echo ($edit_data['employment_status'] ?? '') == 'Temporary' ? 'selected' : ''; ?>>Temporary</option>
                                <option value="Contractual" <?php echo ($edit_data['employment_status'] ?? '') == 'Contractual' ? 'selected' : ''; ?>>Contractual</option>
                                <option value="Casual" <?php echo ($edit_data['employment_status'] ?? '') == 'Casual' ? 'selected' : ''; ?>>Casual</option>
                                <option value="Job Order" <?php echo ($edit_data['employment_status'] ?? '') == 'Job Order' ? 'selected' : ''; ?>>Job Order</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Salary Grade</label>
                            <input type="text" name="salary_grade" value="<?php echo $edit_data['salary_grade'] ?? ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>Date Hired</label>
                            <input type="date" name="date_hired" required value="<?php echo $edit_data['date_hired'] ?? date('Y-m-d'); ?>">
                        </div>
                        <div class="form-group">
                            <label>Status</label>
                            <select name="status" required>
                                <option value="active" <?php echo ($edit_data['status'] ?? '') == 'active' ? 'selected' : ''; ?>>Active</option>
                                <option value="inactive" <?php echo ($edit_data['status'] ?? '') == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                <option value="on_leave" <?php echo ($edit_data['status'] ?? '') == 'on_leave' ? 'selected' : ''; ?>>On Leave</option>
                                <option value="retired" <?php echo ($edit_data['status'] ?? '') == 'retired' ? 'selected' : ''; ?>>Retired</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-cancel" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn-save"><i class="fas fa-save" style="margin-right: 8px;"></i><?php echo $edit_mode ? 'Update' : 'Save'; ?> Employee</button>
                </div>
            </form>
        </div>
    </div>

    <!-- View Employee Modal -->
    <div class="modal-overlay" id="viewModal">
        <div class="modal" style="max-width: 700px;">
            <div class="modal-header" style="background: linear-gradient(135deg, var(--dar-green), var(--dar-dark-green));">
                <h3><i class="fas fa-user" style="margin-right: 10px;"></i>Employee Profile</h3>
                <button class="modal-close" onclick="closeViewModal()"><i class="fas fa-times"></i></button>
            </div>
            <div class="view-modal-body" id="viewModalBody">
                <div style="padding: 60px; text-align: center; color: var(--text-muted);">
                    <i class="fas fa-spinner fa-spin" style="font-size: 2rem; margin-bottom: 15px; display: block;"></i>
                    Loading employee data...
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-cancel" onclick="closeViewModal()">Close</button>
                <button type="button" class="btn-save" id="viewEditBtn">
                    <i class="fas fa-edit" style="margin-right: 8px;"></i>Edit Employee
                </button>
            </div>
        </div>
    </div>

    <script>
        function openModal() {
            document.getElementById('employeeModal').classList.add('active');
            document.body.style.overflow = 'hidden';
        }
        function closeModal() {
            document.getElementById('employeeModal').classList.remove('active');
            document.body.style.overflow = 'auto';
            <?php if($edit_mode): ?>
            window.location.href = 'employees.php';
            <?php endif; ?>
        }

        function viewEmployee(id) {
            const body = document.getElementById('viewModalBody');
            body.innerHTML = '<div style="padding: 60px; text-align: center; color: var(--text-muted);"><i class="fas fa-spinner fa-spin" style="font-size: 2rem; margin-bottom: 15px; display: block;"></i>Loading employee data...</div>';
            document.getElementById('viewModal').classList.add('active');
            document.body.style.overflow = 'hidden';

            fetch('get_employee.php?id=' + id)
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        body.innerHTML = '<div style="padding: 60px; text-align: center; color: #ef4444;"><i class="fas fa-exclamation-triangle" style="font-size: 2rem; margin-bottom: 15px; display: block;"></i>' + data.error + '</div>';
                        return;
                    }

                    const initials = data.first_name.charAt(0).toUpperCase() + data.last_name.charAt(0).toUpperCase();
                    const fullName = data.first_name + ' ' + (data.middle_name ? data.middle_name + ' ' : '') + data.last_name + (data.suffix ? ' ' + data.suffix : '');

                    let statusClass = 'active-tag';
                    let statusLabel = data.status.charAt(0).toUpperCase() + data.status.slice(1).replace('_', ' ');
                    if (data.status === 'inactive') { statusClass = 'inactive-tag'; }
                    else if (data.status === 'on_leave') { statusClass = 'leave-tag'; }
                    else if (data.status === 'retired') { statusClass = 'retired-tag'; }

                    body.innerHTML = `
                        <div class="view-profile-header">
                            <div class="view-avatar">${initials}</div>
                            <h3>${fullName}</h3>
                            <p>${data.position} — ${data.department}</p>
                            <div class="view-id-badge"><i class="fas fa-id-badge" style="margin-right: 5px;"></i>${data.employee_id}</div>
                        </div>
                        <div class="view-section">
                            <div class="view-section-title"><i class="fas fa-user"></i> Personal Information</div>
                            <div class="view-grid">
                                <div class="view-field">
                                    <label>First Name</label>
                                    <p>${data.first_name || '—'}</p>
                                </div>
                                <div class="view-field">
                                    <label>Middle Name</label>
                                    <p>${data.middle_name || '—'}</p>
                                </div>
                                <div class="view-field">
                                    <label>Last Name</label>
                                    <p>${data.last_name || '—'}</p>
                                </div>
                                <div class="view-field">
                                    <label>Suffix</label>
                                    <p>${data.suffix || '—'}</p>
                                </div>
                                <div class="view-field">
                                    <label>Date of Birth</label>
                                    <p>${data.date_of_birth ? formatDate(data.date_of_birth) : '—'}</p>
                                </div>
                                <div class="view-field">
                                    <label>Gender</label>
                                    <p>${data.gender || '—'}</p>
                                </div>
                                <div class="view-field">
                                    <label>Civil Status</label>
                                    <p>${data.civil_status || '—'}</p>
                                </div>
                                <div class="view-field">
                                    <label>Username</label>
                                    <p>${data.username || '—'}</p>
                                </div>
                            </div>
                        </div>
                        <div class="view-section">
                            <div class="view-section-title"><i class="fas fa-phone-alt"></i> Contact Information</div>
                            <div class="view-grid">
                                <div class="view-field">
                                    <label>Email</label>
                                    <p>${data.email || '—'}</p>
                                </div>
                                <div class="view-field">
                                    <label>Phone</label>
                                    <p>${data.phone || '—'}</p>
                                </div>
                                <div class="view-field full">
                                    <label>Address</label>
                                    <p>${data.address || '—'}</p>
                                </div>
                                <div class="view-field">
                                    <label>Emergency Contact</label>
                                    <p>${data.emergency_contact_name || '—'}</p>
                                </div>
                                <div class="view-field">
                                    <label>Emergency Phone</label>
                                    <p>${data.emergency_contact_phone || '—'}</p>
                                </div>
                            </div>
                        </div>
                        <div class="view-section">
                            <div class="view-section-title"><i class="fas fa-briefcase"></i> Employment Details</div>
                            <div class="view-grid">
                                <div class="view-field">
                                    <label>Department</label>
                                    <p>${data.department || '—'}</p>
                                </div>
                                <div class="view-field">
                                    <label>Position</label>
                                    <p>${data.position || '—'}</p>
                                </div>
                                <div class="view-field">
                                    <label>Employment Status</label>
                                    <p>${data.employment_status || '—'}</p>
                                </div>
                                <div class="view-field">
                                    <label>Salary Grade</label>
                                    <p>${data.salary_grade || '—'}</p>
                                </div>
                                <div class="view-field">
                                    <label>Date Hired</label>
                                    <p>${data.date_hired ? formatDate(data.date_hired) : '—'}</p>
                                </div>
                                <div class="view-field">
                                    <label>Status</label>
                                    <div class="view-status-row">
                                        <span class="view-status-tag ${statusClass}"><i class="fas fa-circle" style="font-size: 0.5rem;"></i> ${statusLabel}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;

                    document.getElementById('viewEditBtn').onclick = function() {
                        window.location.href = 'employees.php?edit=' + data.id;
                    };
                })
                .catch(error => {
                    body.innerHTML = '<div style="padding: 60px; text-align: center; color: #ef4444;"><i class="fas fa-exclamation-triangle" style="font-size: 2rem; margin-bottom: 15px; display: block;"></i>Failed to load employee data.</div>';
                });
        }

        function closeViewModal() {
            document.getElementById('viewModal').classList.remove('active');
            document.body.style.overflow = 'auto';
        }

        function formatDate(dateStr) {
            const options = { year: 'numeric', month: 'long', day: 'numeric' };
            return new Date(dateStr).toLocaleDateString('en-US', options);
        }

        function searchTable() {
            const input = document.getElementById('searchInput').value.toLowerCase();
            const rows = document.querySelectorAll('#employeesTable tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(input) ? '' : 'none';
            });
        }

        // Close modals on overlay click
        document.getElementById('employeeModal').addEventListener('click', function(e) {
            if(e.target === this) closeModal();
        });
        document.getElementById('viewModal').addEventListener('click', function(e) {
            if(e.target === this) closeViewModal();
        });
    </script>

</body>
</html>