<?php
session_start();
require_once 'db_config.php';

requireLogin('admin', 'login_admin.php');

 $page_title = "Document Tracking - DAR";
 $admin_id = $_SESSION['admin_id'];
 $admin_name = $_SESSION['admin_name'];
 $role = $_SESSION['admin_role'] ?? 'Admin';

 $divisions = [
    'Office of the PARO',
    'Support-to-Operations Division',
    'Land Tenure Improvement Division',
    'Program Beneficiaries Development Division',
    'Legal Division',
    'Department of Agrarian Reform Adjudication Board',
    'Records Section',
    'Admin Division'
];

 $doc_types = ['Memorandum', 'Letter', 'Report', 'Request', 'Circular', 'Order', 'Others'];

// Handle new document
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {

    if ($_POST['action'] == 'new_document') {
        $tracking_num = 'DAR-' . date('Y') . '-' . str_pad(rand(1, 99999), 5, '0', STR_PAD_LEFT);
        $doc_type = sanitize($conn, $_POST['doc_type']);
        $subject = sanitize($conn, $_POST['subject']);
        $source = sanitize($conn, $_POST['source_from']);
        $received_by = sanitize($conn, $_POST['received_by']);
        $date_received = sanitize($conn, $_POST['date_received']);
        $division = sanitize($conn, $_POST['division']);
        $handler = sanitize($conn, $_POST['handler']);
        $priority = sanitize($conn, $_POST['priority']);
        $remarks = sanitize($conn, $_POST['remarks'] ?? '');

        $conn->query("INSERT INTO tracked_documents 
            (tracking_number, document_type, subject, source_from, received_by, date_received, current_status, current_division, current_handler, priority, remarks, created_by) 
            VALUES ('$tracking_num', '$doc_type', '$subject', '$source', '$received_by', '$date_received', 'received', '$division', '$handler', '$priority', '$remarks', $admin_id)");

        $doc_id = $conn->insert_id;
        $conn->query("INSERT INTO document_logs (document_id, action, from_division, to_division, action_by, remarks) 
            VALUES ($doc_id, 'received', 'External/Source', '$division', '$received_by', '$remarks')");

        $_SESSION['success'] = "Document logged successfully. Tracking #: $tracking_num";
        redirect('document_tracking.php?doc=' . $doc_id);
    }

    if ($_POST['action'] == 'add_action') {
        $doc_id = (int)$_POST['doc_id'];
        $action = sanitize($conn, $_POST['log_action']);
        $to_div = sanitize($conn, $_POST['to_division']);
        $handler = sanitize($conn, $_POST['handler']);
        $log_remarks = sanitize($conn, $_POST['log_remarks'] ?? '');

        $status_map = [
            'received' => 'received',
            'forwarded' => 'forwarded',
            'processing' => 'processing',
            'approved' => 'completed',
            'returned' => 'returned',
            'completed' => 'completed',
            'on_hold' => 'on_hold'
        ];
        $new_status = $status_map[$action] ?? 'processing';

        // Get current division for log
        $current = $conn->query("SELECT current_division FROM tracked_documents WHERE id = $doc_id")->fetch_assoc();
        $from_div = $current['current_division'] ?? '';

        $conn->query("UPDATE tracked_documents SET current_status = '$new_status', current_division = '$to_div', current_handler = '$handler' WHERE id = $doc_id");
        $conn->query("INSERT INTO document_logs (document_id, action, from_division, to_division, action_by, remarks) 
            VALUES ($doc_id, '$action', '$from_div', '$to_div', '$handler', '$log_remarks')");

        $_SESSION['success'] = "Action logged successfully.";
        redirect('document_tracking.php?doc=' . $doc_id);
    }
}

// View single document
 $view_doc = null;
 $doc_logs = null;

if (isset($_GET['doc']) && is_numeric($_GET['doc'])) {
    $doc_id = (int)$_GET['doc'];
    $result = $conn->query("SELECT * FROM tracked_documents WHERE id = $doc_id");
    if ($result && $result->num_rows > 0) {
        $view_doc = $result->fetch_assoc();
        $doc_logs = $conn->query("SELECT * FROM document_logs WHERE document_id = $doc_id ORDER BY created_at DESC");
    }
}

// Fetch recent documents for list
 $recent_docs = $conn->query("SELECT * FROM tracked_documents ORDER BY created_at DESC LIMIT 50");

// Stats
 $stat_received = $conn->query("SELECT COUNT(*) as c FROM tracked_documents WHERE current_status = 'received'")->fetch_assoc()['c'];
 $stat_processing = $conn->query("SELECT COUNT(*) as c FROM tracked_documents WHERE current_status = 'processing'")->fetch_assoc()['c'];
 $stat_forwarded = $conn->query("SELECT COUNT(*) as c FROM tracked_documents WHERE current_status = 'forwarded'")->fetch_assoc()['c'];
 $stat_completed = $conn->query("SELECT COUNT(*) as c FROM tracked_documents WHERE current_status = 'completed'")->fetch_assoc()['c'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dar-green: #006400; --dar-dark-green: #004d00; --dar-light-green: #4CAF50;
            --dar-gold: #FFD700; --bg-light: #f8faf9; --sidebar-bg: #0d3b0d;
            --text-dark: #1a1a2e; --text-muted: #6b7280;
            --shadow: 0 4px 20px rgba(0,0,0,0.08); --shadow-lg: 0 10px 40px rgba(0,0,0,0.1);
            --radius: 12px; --transition: all 0.3s ease;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: var(--bg-light); color: var(--text-dark); }
        .dashboard { display: flex; min-height: 100vh; }

        /* ===== SIDEBAR (matched with employees.php) ===== */
        .sidebar {
            width: 260px; background: var(--sidebar-bg);
            color: white; position: fixed; top: 0; left: 0; bottom: 0;
            z-index: 100; transition: var(--transition);
            display: flex; flex-direction: column;
        }
        .sidebar-header {
            padding: 25px 20px; text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            flex-shrink: 0;
        }
        .sidebar-logo {
            width: 55px; height: 55px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 800; font-size: 18px;
            margin: 0 auto 15px;
        }
        .sidebar-header h3 { font-size: 1rem; font-weight: 600; }
        .sidebar-header p { font-size: 0.75rem; opacity: 0.7; margin-top: 3px; }

        .nav-menu {
            padding: 20px 0;
            flex: 1;
            overflow-y: auto;
        }
        .nav-menu::-webkit-scrollbar { width: 4px; }
        .nav-menu::-webkit-scrollbar-track { background: transparent; }
        .nav-menu::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 4px; }
        .nav-menu::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.25); }

        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 14px 25px; color: rgba(255,255,255,0.8);
            text-decoration: none; font-size: 0.9rem; font-weight: 500;
            transition: var(--transition); border-left: 3px solid transparent;
            cursor: pointer;
        }
        .nav-item:hover, .nav-item.active {
            background: rgba(255,255,255,0.05);
            color: white; border-left-color: var(--dar-gold);
        }
        .nav-item i { width: 20px; text-align: center; font-size: 1rem; }

        .nav-divider {
            height: 1px; background: rgba(255,255,255,0.08);
            margin: 10px 25px;
        }
        .nav-label {
            font-size: 0.68rem; font-weight: 600;
            text-transform: uppercase; letter-spacing: 1.5px;
            color: rgba(255,255,255,0.35); padding: 10px 25px 5px;
        }

        .sidebar-footer {
            padding: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
            flex-shrink: 0;
        }
        .user-info { display: flex; align-items: center; gap: 12px; }
        .user-avatar {
            width: 40px; height: 40px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 700; font-size: 0.9rem;
        }
        .user-details h4 { font-size: 0.85rem; font-weight: 600; }
        .user-details p { font-size: 0.75rem; opacity: 0.6; }
        .logout-btn {
            display: flex; align-items: center; gap: 8px;
            color: rgba(255,255,255,0.7); text-decoration: none;
            font-size: 0.8rem; margin-top: 12px; transition: var(--transition);
        }
        .logout-btn:hover { color: #ef4444; }

        /* ===== MAIN CONTENT ===== */
        .main-content { flex: 1; margin-left: 260px; min-height: 100vh; }
        .top-bar { background: white; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center; box-shadow: var(--shadow); position: sticky; top: 0; z-index: 50; }
        .top-bar h2 { font-size: 1.3rem; font-weight: 700; }
        .content { padding: 30px; }

        .alert { padding: 15px 20px; border-radius: 10px; margin-bottom: 25px; display: flex; align-items: center; gap: 10px; font-size: 0.95rem; }
        .alert-success { background: #f0fdf4; color: #16a34a; border: 1px solid #86efac; }

        /* Stats */
        .dt-stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 18px; margin-bottom: 30px; }
        .dt-stat { background: white; border-radius: var(--radius); padding: 20px; box-shadow: var(--shadow); border: 1px solid #f0f0f0; display: flex; align-items: center; gap: 14px; }
        .dt-stat-icon { width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; flex-shrink: 0; }
        .dt-stat h4 { font-size: 1.4rem; font-weight: 800; }
        .dt-stat p { font-size: 0.78rem; color: var(--text-muted); }

        /* Grid Layout */
        .dt-grid { display: grid; grid-template-columns: 1fr 1.2fr; gap: 25px; }
        .dt-card { background: white; border-radius: var(--radius); box-shadow: var(--shadow); border: 1px solid #f0f0f0; overflow: hidden; }
        .dt-card-header { padding: 18px 22px; border-bottom: 1px solid #f0f0f0; display: flex; align-items: center; gap: 10px; }
        .dt-card-header h3 { font-size: 1rem; font-weight: 700; color: var(--dar-green); }
        .dt-card-body { padding: 22px; }

        /* Form */
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 600; font-size: 0.83rem; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 11px 14px; border: 2px solid #e5e7eb; border-radius: 8px; font-family: 'Poppins', sans-serif; font-size: 0.88rem; transition: var(--transition); background: #fafafa; }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus { outline: none; border-color: var(--dar-green); box-shadow: 0 0 0 4px rgba(0,100,0,0.08); background: white; }
        .form-group textarea { resize: vertical; min-height: 60px; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .btn-submit { width: 100%; padding: 12px; background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green)); color: white; border: none; border-radius: 10px; font-family: 'Poppins', sans-serif; font-size: 0.92rem; font-weight: 600; cursor: pointer; transition: var(--transition); display: flex; align-items: center; justify-content: center; gap: 8px; }
        .btn-submit:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,100,0,0.3); }

        /* Document List */
        .doc-list-item { display: flex; align-items: center; gap: 14px; padding: 14px 22px; border-bottom: 1px solid #f8f8f8; transition: var(--transition); cursor: pointer; text-decoration: none; color: var(--text-dark); }
        .doc-list-item:hover { background: #f0fdf4; }
        .doc-list-item:last-child { border-bottom: none; }
        .doc-type-icon { width: 42px; height: 42px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 1rem; flex-shrink: 0; }
        .doc-list-info { flex: 1; }
        .doc-list-info h4 { font-size: 0.88rem; font-weight: 600; margin-bottom: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 350px; }
        .doc-list-info p { font-size: 0.75rem; color: var(--text-muted); }
        .doc-status-tag { padding: 4px 12px; border-radius: 20px; font-size: 0.72rem; font-weight: 600; white-space: nowrap; }
        .st-received { background: #eff6ff; color: #3b82f6; }
        .st-processing { background: #fefce8; color: #ca8a04; }
        .st-forwarded { background: #f5f3ff; color: #7c3aed; }
        .st-completed { background: #f0fdf4; color: #16a34a; }
        .st-returned { background: #fef2f2; color: #ef4444; }
        .st-on_hold { background: #f1f5f9; color: #64748b; }
        .priority-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
        .priority-routine { background: #d1d5db; }
        .priority-urgent { background: #ef4444; }
        .priority-confidential { background: #7c3aed; }

        /* Document Detail View */
        .doc-detail-header { background: linear-gradient(135deg, var(--dar-green), var(--dar-dark-green)); color: white; padding: 25px 30px; }
        .doc-detail-header h2 { font-size: 1.2rem; font-weight: 700; margin-bottom: 5px; }
        .doc-detail-header p { opacity: 0.9; font-size: 0.88rem; }
        .doc-detail-tags { display: flex; gap: 10px; margin-top: 12px; flex-wrap: wrap; }
        .doc-detail-tag { background: rgba(255,255,255,0.15); padding: 5px 14px; border-radius: 20px; font-size: 0.78rem; border: 1px solid rgba(255,255,255,0.1); }
        .doc-info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; padding: 22px 30px; border-bottom: 1px solid #f0f0f0; }
        .doc-info-field label { display: block; font-size: 0.72rem; font-weight: 600; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 3px; }
        .doc-info-field p { font-size: 0.9rem; font-weight: 600; }

        /* Timeline */
        .timeline { padding: 25px 30px; }
        .timeline h3 { font-size: 1rem; font-weight: 700; color: var(--dar-green); margin-bottom: 20px; }
        .timeline-item { display: flex; gap: 16px; padding-bottom: 25px; position: relative; }
        .timeline-item:last-child { padding-bottom: 0; }
        .timeline-item:not(:last-child)::before { content: ''; position: absolute; left: 17px; top: 36px; bottom: 0; width: 2px; background: #e5e7eb; }
        .timeline-dot { width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.8rem; flex-shrink: 0; z-index: 1; }
        .timeline-content { flex: 1; }
        .timeline-content h4 { font-size: 0.9rem; font-weight: 600; margin-bottom: 3px; }
        .timeline-content p { font-size: 0.82rem; color: var(--text-muted); line-height: 1.6; }
        .timeline-content .time { font-size: 0.75rem; color: #aaa; margin-top: 4px; }

        /* Log Action Form */
        .log-form { padding: 22px 30px; background: #f8faf9; border-top: 1px solid #f0f0f0; }
        .log-form h3 { font-size: 1rem; font-weight: 700; color: var(--dar-green); margin-bottom: 15px; }
        .btn-back { padding: 10px 20px; background: white; color: var(--text-dark); border: 2px solid #e5e7eb; border-radius: 8px; font-family: 'Poppins', sans-serif; font-size: 0.85rem; font-weight: 600; cursor: pointer; transition: var(--transition); display: inline-flex; align-items: center; gap: 8px; text-decoration: none; margin-bottom: 20px; }
        .btn-back:hover { border-color: var(--dar-green); color: var(--dar-green); }

        .empty-list { text-align: center; padding: 40px 20px; color: var(--text-muted); }
        .empty-list i { font-size: 2rem; opacity: 0.3; margin-bottom: 10px; display: block; }

        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; }
        }
        @media (max-width: 768px) {
            .dt-grid { grid-template-columns: 1fr; }
            .form-row { grid-template-columns: 1fr; }
            .doc-info-grid { grid-template-columns: 1fr; }
            .content { padding: 20px; }
        }
    </style>
</head>
<body>

<div class="dashboard">
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">DAR</div>
            <h3>Admin Dashboard</h3>
            <p>Employee Records Management</p>
        </div>

        <nav class="nav-menu">
            <a href="dashboard_admin.php" class="nav-item">
                <i class="fas fa-home"></i> Dashboard
            </a>

            <div class="nav-divider"></div>
            <div class="nav-label">People</div>

            <a href="employees.php" class="nav-item">
                <i class="fas fa-users"></i> Employees
            </a>

            <div class="nav-divider"></div>
            <div class="nav-label">Recruitment</div>

            <a href="positions.php" class="nav-item">
                <i class="fas fa-briefcase"></i> Vacant Positions
            </a>
            <a href="applications.php" class="nav-item">
                <i class="fas fa-file-alt"></i> Job Applications
            </a>

            <div class="nav-divider"></div>
            <div class="nav-label">Records</div>

            <a href="trainings.php" class="nav-item">
                <i class="fas fa-graduation-cap"></i> Trainings
            </a>
            <a href="document_tracking.php" class="nav-item active">
                <i class="fas fa-exchange-alt"></i> Doc Tracking
            </a>
            <a href="documents.php" class="nav-item">
                <i class="fas fa-folder-open"></i> Documents
            </a>

            <div class="nav-divider"></div>
            <div class="nav-label">System</div>

            <a href="reports.php" class="nav-item">
                <i class="fas fa-chart-bar"></i> Reports
            </a>
            <a href="calendar_admin.php" class="nav-item">
                <i class="fas fa-calendar-alt"></i> Calendar
            </a>
            <a href="settings.php" class="nav-item">
                <i class="fas fa-cog"></i> Settings
            </a>
        </nav>

        <div class="sidebar-footer">
            <div class="user-info">
                <div class="user-avatar"><?php echo strtoupper(substr($admin_name, 0, 1)); ?></div>
                <div class="user-details">
                    <h4><?php echo htmlspecialchars($admin_name); ?></h4>
                    <p><?php echo ucfirst($role); ?></p>
                </div>
            </div>
            <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </aside>

    <main class="main-content">
        <div class="top-bar">
            <h2><i class="fas fa-exchange-alt" style="margin-right: 10px; color: var(--dar-green);"></i>Document Tracking</h2>
        </div>

        <div class="content">
            <?php if(isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
            <?php endif; ?>

            <?php if($view_doc): ?>
            <!-- DOCUMENT DETAIL VIEW -->
            <a href="document_tracking.php" class="btn-back"><i class="fas fa-arrow-left"></i> Back to Tracking</a>

            <div class="dt-card" style="margin-bottom: 25px;">
                <div class="doc-detail-header">
                    <h2><?php echo htmlspecialchars($view_doc['subject']); ?></h2>
                    <p><i class="fas fa-barcode" style="margin-right: 6px;"></i>Tracking #: <?php echo htmlspecialchars($view_doc['tracking_number']); ?></p>
                    <div class="doc-detail-tags">
                        <span class="doc-detail-tag"><i class="fas fa-file-alt" style="margin-right: 5px;"></i><?php echo htmlspecialchars($view_doc['document_type']); ?></span>
                        <span class="doc-detail-tag doc-status-tag st-<?php echo $view_doc['current_status']; ?>"><i class="fas fa-circle" style="font-size: 0.4rem; margin-right: 4px;"></i><?php echo ucfirst(str_replace('_', ' ', $view_doc['current_status'])); ?></span>
                        <span class="doc-detail-tag"><i class="fas fa-flag" style="margin-right: 5px;"></i><?php echo ucfirst($view_doc['priority']); ?></span>
                    </div>
                </div>
                <div class="doc-info-grid">
                    <div class="doc-info-field"><label>Source / From</label><p><?php echo htmlspecialchars($view_doc['source_from'] ?? '—'); ?></p></div>
                    <div class="doc-info-field"><label>Received By</label><p><?php echo htmlspecialchars($view_doc['received_by']); ?></p></div>
                    <div class="doc-info-field"><label>Date Received</label><p><?php echo date('F d, Y', strtotime($view_doc['date_received'])); ?></p></div>
                    <div class="doc-info-field"><label>Current Division</label><p><?php echo htmlspecialchars($view_doc['current_division']); ?></p></div>
                    <div class="doc-info-field"><label>Current Handler</label><p><?php echo htmlspecialchars($view_doc['current_handler'] ?? '—'); ?></p></div>
                    <div class="doc-info-field"><label>Remarks</label><p><?php echo htmlspecialchars($view_doc['remarks'] ?? 'None'); ?></p></div>
                </div>

                <!-- Timeline -->
                <div class="timeline">
                    <h3><i class="fas fa-history" style="margin-right: 8px;"></i>Action Timeline</h3>
                    <?php if($doc_logs && $doc_logs->num_rows > 0):
                        $action_icons = [
                            'received' => ['fa-inbox', '#3b82f6', '#eff6ff'],
                            'forwarded' => ['fa-share', '#7c3aed', '#f5f3ff'],
                            'processing' => ['fa-cog', '#ca8a04', '#fefce8'],
                            'approved' => ['fa-check-double', '#16a34a', '#f0fdf4'],
                            'completed' => ['fa-check-circle', '#16a34a', '#f0fdf4'],
                            'returned' => ['fa-undo', '#ef4444', '#fef2f2'],
                            'on_hold' => ['fa-pause', '#64748b', '#f1f5f9'],
                        ];
                        while($log = $doc_logs->fetch_assoc()):
                            $ai = $action_icons[$log['action']] ?? ['fa-circle', '#6b7280', '#f8f8f8'];
                    ?>
                    <div class="timeline-item">
                        <div class="timeline-dot" style="background: <?php echo $ai[2]; ?>; color: <?php echo $ai[1]; ?>;"><i class="fas <?php echo $ai[0]; ?>"></i></div>
                        <div class="timeline-content">
                            <h4><?php echo ucfirst($log['action']); ?></h4>
                            <p>
                                <?php if($log['from_division']): ?>From: <strong><?php echo htmlspecialchars($log['from_division']); ?></strong><br><?php endif; ?>
                                <?php if($log['to_division']): ?>To: <strong><?php echo htmlspecialchars($log['to_division']); ?></strong><br><?php endif; ?>
                                By: <strong><?php echo htmlspecialchars($log['action_by']); ?></strong>
                                <?php if($log['remarks']): ?><br>Remarks: <?php echo htmlspecialchars($log['remarks']); ?><?php endif; ?>
                            </p>
                            <div class="time"><i class="fas fa-clock"></i> <?php echo date('M d, Y h:i A', strtotime($log['created_at'])); ?></div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                    <?php else: ?>
                    <p style="text-align: center; color: var(--text-muted); padding: 20px;">No actions logged yet.</p>
                    <?php endif; ?>
                </div>

                <!-- Log Action Form -->
                <div class="log-form">
                    <h3><i class="fas fa-plus-circle" style="margin-right: 8px;"></i>Log New Action</h3>
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="add_action">
                        <input type="hidden" name="doc_id" value="<?php echo $view_doc['id']; ?>">
                        <div class="form-row">
                            <div class="form-group">
                                <label>Action</label>
                                <select name="log_action" required>
                                    <option value="">Select action</option>
                                    <option value="forwarded">Forwarded</option>
                                    <option value="processing">Processing</option>
                                    <option value="approved">Approved</option>
                                    <option value="completed">Completed</option>
                                    <option value="returned">Returned</option>
                                    <option value="on_hold">On Hold</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Forward To (Division)</label>
                                <select name="to_division" required>
                                    <option value="">Select division</option>
                                    <?php foreach($divisions as $div): ?>
                                    <option value="<?php echo $div; ?>" <?php echo $view_doc['current_division'] == $div ? 'selected' : ''; ?>><?php echo $div; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Handler / Action By</label>
                                <input type="text" name="handler" value="<?php echo htmlspecialchars($admin_name); ?>" required>
                            </div>
                            <div class="form-group">
                                <label>Remarks <small style="color:#aaa;">(optional)</small></label>
                                <input type="text" name="log_remarks" placeholder="Additional notes...">
                            </div>
                        </div>
                        <button type="submit" class="btn-submit" style="margin-top: 5px;"><i class="fas fa-save"></i> Log Action</button>
                    </form>
                </div>
            </div>

            <?php else: ?>
            <!-- MAIN TRACKING VIEW -->
            <!-- Stats -->
            <div class="dt-stats">
                <div class="dt-stat">
                    <div class="dt-stat-icon" style="background: #eff6ff; color: #3b82f6;"><i class="fas fa-inbox"></i></div>
                    <div><h4 style="color: #3b82f6;"><?php echo $stat_received; ?></h4><p>Received</p></div>
                </div>
                <div class="dt-stat">
                    <div class="dt-stat-icon" style="background: #fefce8; color: #ca8a04;"><i class="fas fa-cog"></i></div>
                    <div><h4 style="color: #ca8a04;"><?php echo $stat_processing; ?></h4><p>Processing</p></div>
                </div>
                <div class="dt-stat">
                    <div class="dt-stat-icon" style="background: #f5f3ff; color: #7c3aed;"><i class="fas fa-share"></i></div>
                    <div><h4 style="color: #7c3aed;"><?php echo $stat_forwarded; ?></h4><p>Forwarded</p></div>
                </div>
                <div class="dt-stat">
                    <div class="dt-stat-icon" style="background: #f0fdf4; color: #16a34a;"><i class="fas fa-check-circle"></i></div>
                    <div><h4 style="color: #16a34a;"><?php echo $stat_completed; ?></h4><p>Completed</p></div>
                </div>
            </div>

            <!-- Grid: Form + List -->
            <div class="dt-grid">
                <!-- New Document Form -->
                <div class="dt-card">
                    <div class="dt-card-header"><i class="fas fa-plus-circle" style="color: var(--dar-green);"></i><h3>Log New Document</h3></div>
                    <div class="dt-card-body">
                        <form method="POST" action="">
                            <input type="hidden" name="action" value="new_document">
                            <div class="form-group">
                                <label><i class="fas fa-file-alt" style="margin-right: 5px; color: var(--dar-green);"></i>Document Type</label>
                                <select name="doc_type" required>
                                    <option value="">Select type</option>
                                    <?php foreach($doc_types as $dt): ?>
                                    <option value="<?php echo $dt; ?>"><?php echo $dt; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label><i class="fas fa-heading" style="margin-right: 5px; color: var(--dar-green);"></i>Subject / Title</label>
                                <input type="text" name="subject" required placeholder="Document subject...">
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label><i class="fas fa-user" style="margin-right: 5px; color: var(--dar-green);"></i>Source / From</label>
                                    <input type="text" name="source_from" placeholder="Who sent this?">
                                </div>
                                <div class="form-group">
                                    <label><i class="fas fa-user-check" style="margin-right: 5px; color: var(--dar-green);"></i>Received By</label>
                                    <input type="text" name="received_by" value="<?php echo htmlspecialchars($admin_name); ?>" required>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label><i class="fas fa-calendar" style="margin-right: 5px; color: var(--dar-green);"></i>Date Received</label>
                                    <input type="date" name="date_received" value="<?php echo date('Y-m-d'); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label><i class="fas fa-flag" style="margin-right: 5px; color: var(--dar-green);"></i>Priority</label>
                                    <select name="priority">
                                        <option value="routine">Routine</option>
                                        <option value="urgent">Urgent</option>
                                        <option value="confidential">Confidential</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label><i class="fas fa-building" style="margin-right: 5px; color: var(--dar-green);"></i>Assign to Division</label>
                                <select name="division" required>
                                    <option value="">Select division</option>
                                    <?php foreach($divisions as $div): ?>
                                    <option value="<?php echo $div; ?>"><?php echo $div; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label><i class="fas fa-user-tie" style="margin-right: 5px; color: var(--dar-green);"></i>Assigned Handler</label>
                                <input type="text" name="handler" placeholder="Person assigned">
                            </div>
                            <div class="form-group">
                                <label><i class="fas fa-comment" style="margin-right: 5px; color: var(--dar-green);"></i>Remarks <small style="color:#aaa;">(optional)</small></label>
                                <textarea name="remarks" placeholder="Initial notes..."></textarea>
                            </div>
                            <button type="submit" class="btn-submit"><i class="fas fa-save"></i> Log Document</button>
                        </form>
                    </div>
                </div>

                <!-- Recent Documents List -->
                <div class="dt-card">
                    <div class="dt-card-header"><i class="fas fa-list" style="color: var(--dar-green);"></i><h3>Recent Documents</h3></div>
                    <div>
                        <?php if($recent_docs->num_rows > 0): ?>
                            <?php while($doc = $recent_docs->fetch_assoc()): ?>
                            <a href="document_tracking.php?doc=<?php echo $doc['id']; ?>" class="doc-list-item">
                                <div class="priority-dot priority-<?php echo $doc['priority']; ?>"></div>
                                <div class="doc-type-icon" style="background: #f0fdf4; color: var(--dar-green);"><i class="fas fa-file-alt"></i></div>
                                <div class="doc-list-info">
                                    <h4><?php echo htmlspecialchars($doc['subject']); ?></h4>
                                    <p><?php echo htmlspecialchars($doc['tracking_number']); ?> • <?php echo date('M d, Y', strtotime($doc['date_received'])); ?> • <?php echo htmlspecialchars($doc['current_division']); ?></p>
                                </div>
                                <span class="doc-status-tag st-<?php echo $doc['current_status']; ?>"><?php echo ucfirst(str_replace('_', ' ', $doc['current_status'])); ?></span>
                            </a>
                            <?php endwhile; ?>
                        <?php else: ?>
                        <div class="empty-list"><i class="fas fa-inbox"></i><h4>No documents tracked yet</h4><p>Log a new document to get started.</p></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </main>
</div>

</body>
</html>