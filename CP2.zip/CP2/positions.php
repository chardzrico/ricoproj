<?php
session_start();
require_once 'db_config.php';

requireLogin('admin', 'login_admin.php');
 $page_title = "Manage Positions - DAR";

 $admin_id = $_SESSION['admin_id'];
 $admin_name = $_SESSION['admin_name'];
 $role = $_SESSION['admin_role'] ?? 'Admin';

// Handle Delete
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM vacant_positions WHERE id = $id");
    $_SESSION['success'] = "Position deleted successfully.";
    redirect('positions.php');
}

// Handle Add/Edit
 $edit_mode = false;
 $edit_data = null;

if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $edit_mode = true;
    $edit_id = (int)$_GET['edit'];
    $edit_result = $conn->query("SELECT * FROM vacant_positions WHERE id = $edit_id");
    $edit_data = $edit_result->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $position_code = sanitize($conn, $_POST['position_code']);
    $position_title = sanitize($conn, $_POST['position_title']);
    $department = sanitize($conn, $_POST['department']);
    $salary_grade = sanitize($conn, $_POST['salary_grade']);
    $monthly_salary = (float)$_POST['monthly_salary'];
    $employment_type = sanitize($conn, $_POST['employment_type']);
    $plantilla_item_no = sanitize($conn, $_POST['plantilla_item_no']);
    $qualifications = sanitize($conn, $_POST['qualifications']);
    $requirements = sanitize($conn, $_POST['requirements']);
    $number_of_slots = (int)$_POST['number_of_slots'];
    $date_posted = sanitize($conn, $_POST['date_posted']);
    $deadline = sanitize($conn, $_POST['deadline']);
    $status = sanitize($conn, $_POST['status']);

    if (isset($_POST['id']) && !empty($_POST['id'])) {
        $id = (int)$_POST['id'];
        $sql = "UPDATE vacant_positions SET 
                position_code = '$position_code', position_title = '$position_title',
                department = '$department', salary_grade = '$salary_grade',
                monthly_salary = $monthly_salary, employment_type = '$employment_type',
                plantilla_item_no = '$plantilla_item_no', qualifications = '$qualifications',
                requirements = '$requirements', number_of_slots = $number_of_slots,
                date_posted = '$date_posted', deadline = '$deadline', status = '$status'
                WHERE id = $id";
        $conn->query($sql);
        $_SESSION['success'] = "Position updated successfully.";
    } else {
        $sql = "INSERT INTO vacant_positions (position_code, position_title, department, salary_grade,
                monthly_salary, employment_type, plantilla_item_no, qualifications, requirements,
                number_of_slots, date_posted, deadline, status, posted_by)
                VALUES ('$position_code', '$position_title', '$department', '$salary_grade',
                $monthly_salary, '$employment_type', '$plantilla_item_no', '$qualifications',
                '$requirements', $number_of_slots, '$date_posted', '$deadline', '$status', $admin_id)";
        $conn->query($sql);
        $_SESSION['success'] = "Position added successfully.";
    }
    redirect('positions.php');
}

 $positions = $conn->query("SELECT vp.*, a.full_name as posted_by_name 
                           FROM vacant_positions vp 
                           LEFT JOIN admins a ON vp.posted_by = a.id 
                           ORDER BY vp.created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dar-green: #006400;
            --dar-dark-green: #004d00;
            --dar-light-green: #4CAF50;
            --dar-gold: #FFD700;
            --bg-light: #f8faf9;
            --sidebar-bg: #0d3b0d;
            --text-dark: #1a1a2e;
            --text-muted: #6b7280;
            --shadow: 0 4px 20px rgba(0,0,0,0.08);
            --shadow-lg: 0 10px 40px rgba(0,0,0,0.1);
            --radius: 12px;
            --transition: all 0.3s ease;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: var(--bg-light); color: var(--text-dark); }

        .dashboard { display: flex; min-height: 100vh; }

        /* ===== SIDEBAR (matched with employees.php) ===== */
        .sidebar {
            width: 260px; background: var(--sidebar-bg);
            color: white; position: fixed; top: 0; left: 0; bottom: 0;
            z-index: 100; transition: var(--transition);
            display: flex; flex-direction: column;
        }
        .sidebar-header {
            padding: 25px 20px; text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            flex-shrink: 0;
        }
        .sidebar-logo {
            width: 55px; height: 55px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 800; font-size: 18px;
            margin: 0 auto 15px;
        }
        .sidebar-header h3 { font-size: 1rem; font-weight: 600; }
        .sidebar-header p { font-size: 0.75rem; opacity: 0.7; margin-top: 3px; }

        .nav-menu {
            padding: 20px 0;
            flex: 1;
            overflow-y: auto;
        }
        .nav-menu::-webkit-scrollbar { width: 4px; }
        .nav-menu::-webkit-scrollbar-track { background: transparent; }
        .nav-menu::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 4px; }
        .nav-menu::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.25); }

        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 14px 25px; color: rgba(255,255,255,0.8);
            text-decoration: none; font-size: 0.9rem; font-weight: 500;
            transition: var(--transition); border-left: 3px solid transparent;
            cursor: pointer;
        }
        .nav-item:hover, .nav-item.active {
            background: rgba(255,255,255,0.05);
            color: white; border-left-color: var(--dar-gold);
        }
        .nav-item i { width: 20px; text-align: center; font-size: 1rem; }

        .nav-divider {
            height: 1px; background: rgba(255,255,255,0.08);
            margin: 10px 25px;
        }
        .nav-label {
            font-size: 0.68rem; font-weight: 600;
            text-transform: uppercase; letter-spacing: 1.5px;
            color: rgba(255,255,255,0.35); padding: 10px 25px 5px;
        }

        .sidebar-footer {
            padding: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
            flex-shrink: 0;
        }
        .user-info { display: flex; align-items: center; gap: 12px; }
        .user-avatar {
            width: 40px; height: 40px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 700; font-size: 0.9rem;
        }
        .user-details h4 { font-size: 0.85rem; font-weight: 600; }
        .user-details p { font-size: 0.75rem; opacity: 0.6; }
        .logout-btn {
            display: flex; align-items: center; gap: 8px;
            color: rgba(255,255,255,0.7); text-decoration: none;
            font-size: 0.8rem; margin-top: 12px; transition: var(--transition);
        }
        .logout-btn:hover { color: #ef4444; }

        /* ===== MAIN CONTENT ===== */
        .main-content { flex: 1; margin-left: 260px; min-height: 100vh; }
        .top-bar {
            background: white; padding: 15px 30px;
            display: flex; justify-content: space-between; align-items: center;
            box-shadow: var(--shadow); position: sticky; top: 0; z-index: 50;
        }
        .top-bar h2 { font-size: 1.3rem; font-weight: 700; }
        .content { padding: 30px; }

        .alert {
            padding: 15px 20px; border-radius: 10px; margin-bottom: 25px;
            display: flex; align-items: center; gap: 10px; font-size: 0.95rem;
        }
        .alert-success { background: #f0fdf4; color: #16a34a; border: 1px solid #86efac; }

        .action-bar {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 25px; flex-wrap: wrap; gap: 15px;
        }
        .search-box {
            display: flex; align-items: center; gap: 10px;
            background: white; padding: 10px 15px; border-radius: 10px;
            box-shadow: var(--shadow); border: 1px solid #f0f0f0;
        }
        .search-box input {
            border: none; outline: none; font-family: 'Poppins', sans-serif;
            font-size: 0.9rem; width: 250px;
        }
        .btn-add {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; padding: 12px 25px; border: none; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.95rem; font-weight: 600;
            cursor: pointer; display: flex; align-items: center; gap: 8px;
            transition: var(--transition); text-decoration: none;
        }
        .btn-add:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,100,0,0.3); }

        .table-card {
            background: white; border-radius: var(--radius);
            box-shadow: var(--shadow); overflow: hidden;
        }
        .data-table { width: 100%; border-collapse: collapse; }
        .data-table th {
            text-align: left; padding: 14px 20px;
            font-size: 0.8rem; font-weight: 600; color: var(--text-muted);
            text-transform: uppercase; letter-spacing: 0.5px;
            background: #fafafa; border-bottom: 1px solid #f0f0f0;
        }
        .data-table td {
            padding: 14px 20px; font-size: 0.9rem;
            border-bottom: 1px solid #f8f8f8;
        }
        .data-table tr:hover td { background: #fafafa; }
        .salary { color: var(--dar-green); font-weight: 700; }
        .status-badge {
            display: inline-block; padding: 4px 12px;
            border-radius: 20px; font-size: 0.75rem; font-weight: 600;
        }
        .status-open { background: #f0fdf4; color: #16a34a; }
        .status-closed { background: #f1f5f9; color: #64748b; }
        .status-filled { background: #eff6ff; color: #3b82f6; }

        .action-btns { display: flex; gap: 6px; }
        .btn-action {
            width: 32px; height: 32px; border-radius: 8px;
            border: none; cursor: pointer; display: flex;
            align-items: center; justify-content: center;
            font-size: 0.85rem; transition: var(--transition); text-decoration: none;
        }
        .btn-edit { background: #eff6ff; color: #3b82f6; }
        .btn-edit:hover { background: #3b82f6; color: white; }
        .btn-delete { background: #fef2f2; color: #ef4444; }
        .btn-delete:hover { background: #ef4444; color: white; }

        /* ===== MODAL ===== */
        .modal-overlay {
            display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.5); z-index: 1000;
            justify-content: center; align-items: center;
            padding: 20px; backdrop-filter: blur(5px);
        }
        .modal-overlay.active { display: flex; }
        .modal {
            background: white; border-radius: var(--radius);
            max-width: 700px; width: 100%; max-height: 90vh;
            overflow-y: auto; box-shadow: var(--shadow-lg);
            animation: modalIn 0.3s ease;
        }
        @keyframes modalIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }
        .modal-header {
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; padding: 25px; display: flex;
            justify-content: space-between; align-items: center;
        }
        .modal-header h3 { font-size: 1.3rem; font-weight: 700; }
        .modal-close {
            background: none; border: none; color: white;
            font-size: 1.5rem; cursor: pointer;
        }
        .modal-body { padding: 25px; }
        .form-grid {
            display: grid; grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        .form-group.full { grid-column: 1 / -1; }
        .form-group label {
            display: block; margin-bottom: 6px;
            font-weight: 600; font-size: 0.85rem; color: var(--text-dark);
        }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%; padding: 12px 15px;
            border: 2px solid #e5e7eb; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            transition: var(--transition);
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            outline: none; border-color: var(--dar-green);
            box-shadow: 0 0 0 4px rgba(0,100,0,0.08);
        }
        .form-group textarea { resize: vertical; min-height: 80px; }
        .modal-footer {
            padding: 20px 25px; border-top: 1px solid #f0f0f0;
            display: flex; justify-content: flex-end; gap: 10px;
        }
        .btn-cancel {
            padding: 12px 25px; border: 2px solid #e5e7eb;
            background: white; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            font-weight: 600; cursor: pointer; transition: var(--transition);
        }
        .btn-cancel:hover { border-color: var(--dar-green); color: var(--dar-green); }
        .btn-save {
            padding: 12px 30px;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; border: none; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            font-weight: 600; cursor: pointer; transition: var(--transition);
        }
        .btn-save:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,100,0,0.3); }

        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; }
        }
        @media (max-width: 768px) {
            .form-grid { grid-template-columns: 1fr; }
            .content { padding: 20px; }
            .action-bar { flex-direction: column; align-items: stretch; }
            .search-box { width: 100%; }
            .search-box input { width: 100%; }
        }
    </style>
</head>
<body>

    <div class="dashboard">
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">DAR</div>
                <h3>Admin Dashboard</h3>
                <p>Employee Records Management</p>
            </div>

            <nav class="nav-menu">
                <a href="dashboard_admin.php" class="nav-item">
                    <i class="fas fa-home"></i> Dashboard
                </a>

                <div class="nav-divider"></div>
                <div class="nav-label">People</div>

                <a href="employees.php" class="nav-item">
                    <i class="fas fa-users"></i> Employees
                </a>

                <div class="nav-divider"></div>
                <div class="nav-label">Recruitment</div>

                <a href="positions.php" class="nav-item active">
                    <i class="fas fa-briefcase"></i> Vacant Positions
                </a>
                <a href="applications.php" class="nav-item">
                    <i class="fas fa-file-alt"></i> Job Applications
                </a>

                <div class="nav-divider"></div>
                <div class="nav-label">Records</div>

                <a href="trainings.php" class="nav-item">
                    <i class="fas fa-graduation-cap"></i> Trainings
                </a>
                <a href="document_tracking.php" class="nav-item">
                    <i class="fas fa-exchange-alt"></i> Doc Tracking
                </a>
                <a href="documents.php" class="nav-item">
                    <i class="fas fa-folder-open"></i> Documents
                </a>

                <div class="nav-divider"></div>
                <div class="nav-label">System</div>

                <a href="reports.php" class="nav-item">
                    <i class="fas fa-chart-bar"></i> Reports
                </a>
                <a href="calendar_admin.php" class="nav-item">
                    <i class="fas fa-calendar-alt"></i> Calendar
                </a>
                <a href="settings.php" class="nav-item">
                    <i class="fas fa-cog"></i> Settings
                </a>
            </nav>

            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar"><?php echo strtoupper(substr($admin_name, 0, 1)); ?></div>
                    <div class="user-details">
                        <h4><?php echo htmlspecialchars($admin_name); ?></h4>
                        <p><?php echo ucfirst($role); ?></p>
                    </div>
                </div>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </aside>

        <main class="main-content">
            <div class="top-bar">
                <h2><i class="fas fa-briefcase" style="margin-right: 10px; color: var(--dar-green);"></i>Manage Vacant Positions</h2>
            </div>

            <div class="content">
                <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
                <?php endif; ?>

                <div class="action-bar">
                    <div class="search-box">
                        <i class="fas fa-search" style="color: var(--text-muted);"></i>
                        <input type="text" id="searchInput" placeholder="Search positions..." onkeyup="searchTable()">
                    </div>
                    <button class="btn-add" onclick="openModal()">
                        <i class="fas fa-plus"></i> Add Position
                    </button>
                </div>

                <div class="table-card">
                    <table class="data-table" id="positionsTable">
                        <thead>
                            <tr>
                                <th>Position Code</th>
                                <th>Title</th>
                                <th>Department</th>
                                <th>Salary</th>
                                <th>Slots</th>
                                <th>Deadline</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($pos = $positions->fetch_assoc()): ?>
                            <tr>
                                <td><span style="font-family: monospace; font-size: 0.85rem;"><?php echo htmlspecialchars($pos['position_code']); ?></span></td>
                                <td style="font-weight: 600;"><?php echo htmlspecialchars($pos['position_title']); ?></td>
                                <td><?php echo htmlspecialchars($pos['department']); ?></td>
                                <td class="salary">₱<?php echo number_format($pos['monthly_salary'], 2); ?></td>
                                <td><?php echo $pos['number_of_slots']; ?></td>
                                <td><?php echo date('M d, Y', strtotime($pos['deadline'])); ?></td>
                                <td><span class="status-badge status-<?php echo $pos['status']; ?>"><?php echo ucfirst($pos['status']); ?></span></td>
                                <td>
                                    <div class="action-btns">
                                        <a href="positions.php?edit=<?php echo $pos['id']; ?>" class="btn-action btn-edit" title="Edit"><i class="fas fa-edit"></i></a>
                                        <a href="positions.php?delete=<?php echo $pos['id']; ?>" class="btn-action btn-delete" title="Delete" onclick="return confirm('Delete this position?')"><i class="fas fa-trash"></i></a>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <!-- Modal -->
    <div class="modal-overlay" id="positionModal" <?php echo $edit_mode ? 'style="display:flex;"' : ''; ?>>
        <div class="modal">
            <div class="modal-header">
                <h3><i class="fas fa-briefcase" style="margin-right: 10px;"></i><?php echo $edit_mode ? 'Edit Position' : 'Add New Position'; ?></h3>
                <button class="modal-close" onclick="closeModal()"><i class="fas fa-times"></i></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <div class="form-grid">
                        <?php if($edit_mode): ?>
                        <input type="hidden" name="id" value="<?php echo $edit_data['id']; ?>">
                        <?php endif; ?>

                        <div class="form-group">
                            <label>Position Code</label>
                            <input type="text" name="position_code" required value="<?php echo $edit_data['position_code'] ?? 'DAR-' . strtoupper(substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 3)) . '-' . rand(100, 999); ?>">
                        </div>
                        <div class="form-group">
                            <label>Plantilla Item No.</label>
                            <input type="text" name="plantilla_item_no" value="<?php echo $edit_data['plantilla_item_no'] ?? ''; ?>">
                        </div>
                        <div class="form-group full">
                            <label>Position Title</label>
                            <input type="text" name="position_title" required value="<?php echo $edit_data['position_title'] ?? ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>Department</label>
                            <input type="text" name="department" required value="<?php echo $edit_data['department'] ?? ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>Salary Grade</label>
                            <input type="text" name="salary_grade" required value="<?php echo $edit_data['salary_grade'] ?? ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>Monthly Salary</label>
                            <input type="number" name="monthly_salary" step="0.01" required value="<?php echo $edit_data['monthly_salary'] ?? ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>Employment Type</label>
                            <select name="employment_type" required>
                                <option value="">Select</option>
                                <option value="Permanent" <?php echo ($edit_data['employment_type'] ?? '') == 'Permanent' ? 'selected' : ''; ?>>Permanent</option>
                                <option value="Temporary" <?php echo ($edit_data['employment_type'] ?? '') == 'Temporary' ? 'selected' : ''; ?>>Temporary</option>
                                <option value="Contractual" <?php echo ($edit_data['employment_type'] ?? '') == 'Contractual' ? 'selected' : ''; ?>>Contractual</option>
                                <option value="Casual" <?php echo ($edit_data['employment_type'] ?? '') == 'Casual' ? 'selected' : ''; ?>>Casual</option>
                                <option value="Job Order" <?php echo ($edit_data['employment_type'] ?? '') == 'Job Order' ? 'selected' : ''; ?>>Job Order</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Number of Slots</label>
                            <input type="number" name="number_of_slots" min="1" required value="<?php echo $edit_data['number_of_slots'] ?? '1'; ?>">
                        </div>
                        <div class="form-group">
                            <label>Date Posted</label>
                            <input type="date" name="date_posted" required value="<?php echo $edit_data['date_posted'] ?? date('Y-m-d'); ?>">
                        </div>
                        <div class="form-group">
                            <label>Application Deadline</label>
                            <input type="date" name="deadline" required value="<?php echo $edit_data['deadline'] ?? ''; ?>">
                        </div>
                        <div class="form-group full">
                            <label>Qualifications</label>
                            <textarea name="qualifications" required placeholder="Enter qualifications separated by periods or new lines"><?php echo $edit_data['qualifications'] ?? ''; ?></textarea>
                        </div>
                        <div class="form-group full">
                            <label>Requirements (comma-separated)</label>
                            <textarea name="requirements" required placeholder="e.g. Updated Resume, Transcript of Records, Diploma, NBI Clearance"><?php echo $edit_data['requirements'] ?? ''; ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>Status</label>
                            <select name="status" required>
                                <option value="open" <?php echo ($edit_data['status'] ?? '') == 'open' ? 'selected' : ''; ?>>Open</option>
                                <option value="closed" <?php echo ($edit_data['status'] ?? '') == 'closed' ? 'selected' : ''; ?>>Closed</option>
                                <option value="filled" <?php echo ($edit_data['status'] ?? '') == 'filled' ? 'selected' : ''; ?>>Filled</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-cancel" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn-save"><i class="fas fa-save" style="margin-right: 8px;"></i><?php echo $edit_mode ? 'Update' : 'Save'; ?> Position</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openModal() {
            document.getElementById('positionModal').classList.add('active');
            document.body.style.overflow = 'hidden';
        }
        function closeModal() {
            document.getElementById('positionModal').classList.remove('active');
            document.body.style.overflow = 'auto';
            <?php if($edit_mode): ?>
            window.location.href = 'positions.php';
            <?php endif; ?>
        }
        function searchTable() {
            const input = document.getElementById('searchInput').value.toLowerCase();
            const rows = document.querySelectorAll('#positionsTable tbody tr');
            rows.forEach(row => {
                row.style.display = row.textContent.toLowerCase().includes(input) ? '' : 'none';
            });
        }
        document.getElementById('positionModal').addEventListener('click', function(e) {
            if(e.target === this) closeModal();
        });
    </script>

</body>
</html>