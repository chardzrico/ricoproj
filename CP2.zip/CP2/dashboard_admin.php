<?php
session_start();
require_once 'db_config.php';

requireLogin('admin', 'login_admin.php');
 $page_title = "Admin Dashboard - DAR";

 $admin_id = $_SESSION['admin_id'];
 $admin_name = $_SESSION['admin_name'];
 $role = $_SESSION['admin_role'] ?? 'Admin';

// === SAFE HELPERS ===
function safeCount($conn, $sql) {
    try {
        $r = $conn->query($sql);
        if ($r && $r->num_rows > 0) return (int)$r->fetch_assoc()['total'];
    } catch (Exception $e) {}
    return 0;
}
function safeQuery($conn, $sql) {
    try {
        $r = $conn->query($sql);
        if ($r && $r->num_rows > 0) return $r;
    } catch (Exception $e) {}
    return null;
}

// === CHECK WHICH COLUMNS EXIST IN job_applications ===
 $ja_cols = [];
 $col_check = safeQuery($conn, "SHOW COLUMNS FROM job_applications");
if ($col_check) {
    while ($c = $col_check->fetch_assoc()) {
        $ja_cols[] = $c['Field'];
    }
}
 $has_applied_at = in_array('applied_at', $ja_cols);
 $has_created_at = in_array('created_at', $ja_cols);
 $date_col = $has_applied_at ? 'applied_at' : ($has_created_at ? 'created_at' : 'id');

// === STATISTICS ===
 $total_employees    = safeCount($conn, "SELECT COUNT(*) as total FROM employees");
 $total_applicants   = safeCount($conn, "SELECT COUNT(*) as total FROM applicants");
 $total_positions    = safeCount($conn, "SELECT COUNT(*) as total FROM vacant_positions WHERE status = 'open'");
 $pending_apps       = safeCount($conn, "SELECT COUNT(*) as total FROM job_applications WHERE status = 'submitted'");
 $total_departments  = safeCount($conn, "SELECT COUNT(DISTINCT department) as total FROM employees WHERE department IS NOT NULL AND department != ''");
 $active_employees   = safeCount($conn, "SELECT COUNT(*) as total FROM employees WHERE status = 'active'");
 $on_leave           = safeCount($conn, "SELECT COUNT(*) as total FROM employees WHERE status = 'on_leave'");
 $new_applicants_month = safeCount($conn, "SELECT COUNT(*) as total FROM applicants WHERE MONTH(created_at) = MONTH(CURRENT_DATE()) AND YEAR(created_at) = YEAR(CURRENT_DATE())");
 $total_trainings    = safeCount($conn, "SELECT COUNT(*) as total FROM employee_trainings");
 $active_docs        = safeCount($conn, "SELECT COUNT(*) as total FROM tracked_documents WHERE current_status IN ('received','processing','forwarded')");
 $total_applications = safeCount($conn, "SELECT COUNT(*) as total FROM job_applications");
 $shortlisted_count  = safeCount($conn, "SELECT COUNT(*) as total FROM job_applications WHERE status = 'shortlisted'");
 $interview_count    = safeCount($conn, "SELECT COUNT(*) as total FROM job_applications WHERE status = 'interview'");
 $exam_count         = safeCount($conn, "SELECT COUNT(*) as total FROM job_applications WHERE status = 'exam'");
 $hired_count        = safeCount($conn, "SELECT COUNT(*) as total FROM job_applications WHERE status IN ('hired','approved')");
 $under_review_count = safeCount($conn, "SELECT COUNT(*) as total FROM job_applications WHERE status = 'under_review'");

// === DEPARTMENT CHART DATA ===
 $dept_chart_data = safeQuery($conn, "SELECT department, COUNT(*) as total FROM employees WHERE department IS NOT NULL AND department != '' GROUP BY department ORDER BY total DESC LIMIT 8");
 $dept_labels = []; $dept_counts = [];
if ($dept_chart_data) {
    while ($row = $dept_chart_data->fetch_assoc()) {
        $dn = $row['department'];
        if (strlen($dn) > 18) $dn = substr($dn, 0, 16) . '...';
        $dept_labels[] = $dn;
        $dept_counts[] = (int)$row['total'];
    }
}

// === APPLICATION STATUS DATA ===
 $status_result = safeQuery($conn, "SELECT status, COUNT(*) as c FROM job_applications GROUP BY status");
 $status_data = [];
 $status_labels_map = [
    'submitted' => 'Submitted', 'under_review' => 'Under Review',
    'shortlisted' => 'Shortlisted', 'interview' => 'Interview',
    'exam' => 'Exam', 'hired' => 'Hired', 'approved' => 'Approved', 'rejected' => 'Rejected'
];
if ($status_result) {
    while ($row = $status_result->fetch_assoc()) {
        $label = $status_labels_map[$row['status']] ?? ucfirst(str_replace('_', ' ', $row['status']));
        $status_data[$row['status']] = ['label' => $label, 'count' => (int)$row['c']];
    }
}

// === MONTHLY TREND — uses correct date column ===
 $monthly_result = safeQuery($conn, "
    SELECT DATE_FORMAT(`$date_col`, '%Y-%m') as month, COUNT(*) as c 
    FROM job_applications 
    WHERE `$date_col` >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
    GROUP BY month ORDER BY month ASC
");
 $month_labels = []; $monthly_data = [];
if ($monthly_result) {
    while ($row = $monthly_result->fetch_assoc()) {
        $month_labels[] = date('M Y', strtotime($row['month'] . '-01'));
        $monthly_data[] = (int)$row['c'];
    }
}
// Fill missing months
if (!empty($month_labels)) {
    $start = strtotime($month_labels[0] . '-01');
    $end = strtotime('first day of this month');
    $fl = []; $fd = []; $assoc = array_combine($month_labels, $monthly_data);
    while ($start <= $end) {
        $key = date('M Y', $start);
        $fl[] = $key; $fd[] = $assoc[$key] ?? 0;
        $start = strtotime('+1 month', $start);
    }
    $month_labels = $fl; $monthly_data = $fd;
}

// === GENDER DATA ===
 $gender_result = safeQuery($conn, "SELECT gender, COUNT(*) as c FROM employees WHERE gender IS NOT NULL AND gender != '' GROUP BY gender");
 $gender_data = [];
if ($gender_result) {
    while ($row = $gender_result->fetch_assoc()) {
        $gender_data[$row['gender']] = (int)$row['c'];
    }
}

// === RECENT EMPLOYEES ===
 $recent_employees = safeQuery($conn, "SELECT * FROM employees ORDER BY created_at DESC LIMIT 5");

// === RECENT APPLICANTS ===
 $recent_applicants = safeQuery($conn, "
    SELECT a.*, p.position_title 
    FROM applicants a 
    LEFT JOIN job_applications ja ON a.id = ja.applicant_id 
    LEFT JOIN vacant_positions p ON ja.position_id = p.id 
    ORDER BY a.created_at DESC LIMIT 5
");

// === RECENT LOGS ===
 $recent_logs = safeQuery($conn, "SELECT * FROM system_logs WHERE user_type = 'admin' ORDER BY created_at DESC LIMIT 8");

// === GREETING ===
 $hour = date('H');
if ($hour < 12) $greeting = 'Good Morning';
elseif ($hour < 17) $greeting = 'Good Afternoon';
else $greeting = 'Good Evening';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <style>
        :root {
            --dar-green: #006400;
            --dar-dark-green: #004d00;
            --dar-light-green: #4CAF50;
            --dar-gold: #FFD700;
            --bg-light: #f8faf9;
            --sidebar-bg: #0d3b0d;
            --text-dark: #1a1a2e;
            --text-muted: #6b7280;
            --white: #ffffff;
            --shadow: 0 4px 20px rgba(0,0,0,0.08);
            --shadow-lg: 0 10px 40px rgba(0,0,0,0.12);
            --radius: 12px;
            --transition: all 0.3s ease;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: var(--bg-light); color: var(--text-dark); }
        .dashboard { display: flex; min-height: 100vh; }

        .sidebar {
            width: 260px; background: var(--sidebar-bg);
            color: white; position: fixed; top: 0; left: 0; bottom: 0;
            z-index: 100; transition: var(--transition); display: flex; flex-direction: column;
        }
        .sidebar-header {
            padding: 25px 20px; text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1); flex-shrink: 0;
        }
        .sidebar-logo {
            width: 55px; height: 55px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 800; font-size: 18px; margin: 0 auto 15px;
        }
        .sidebar-header h3 { font-size: 1rem; font-weight: 600; }
        .sidebar-header p { font-size: 0.75rem; opacity: 0.7; margin-top: 3px; }
        .nav-menu { padding: 20px 0; flex: 1; overflow-y: auto; }
        .nav-menu::-webkit-scrollbar { width: 4px; }
        .nav-menu::-webkit-scrollbar-track { background: transparent; }
        .nav-menu::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 4px; }
        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 14px 25px; color: rgba(255,255,255,0.8);
            text-decoration: none; font-size: 0.9rem; font-weight: 500;
            transition: var(--transition); border-left: 3px solid transparent; cursor: pointer;
        }
        .nav-item:hover, .nav-item.active {
            background: rgba(255,255,255,0.05); color: white; border-left-color: var(--dar-gold);
        }
        .nav-item i { width: 20px; text-align: center; font-size: 1rem; }
        .nav-divider { height: 1px; background: rgba(255,255,255,0.08); margin: 10px 25px; }
        .nav-label {
            font-size: 0.68rem; font-weight: 600; text-transform: uppercase;
            letter-spacing: 1.5px; color: rgba(255,255,255,0.35); padding: 10px 25px 5px;
        }
        .sidebar-footer {
            padding: 20px; border-top: 1px solid rgba(255,255,255,0.1); flex-shrink: 0;
        }
        .user-info { display: flex; align-items: center; gap: 12px; }
        .user-avatar {
            width: 40px; height: 40px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 700; font-size: 0.9rem;
        }
        .user-details h4 { font-size: 0.85rem; font-weight: 600; }
        .user-details p { font-size: 0.75rem; opacity: 0.6; }
        .logout-btn {
            display: flex; align-items: center; gap: 8px;
            color: rgba(255,255,255,0.7); text-decoration: none;
            font-size: 0.8rem; margin-top: 12px; transition: var(--transition);
        }
        .logout-btn:hover { color: #ef4444; }

        .main-content { flex: 1; margin-left: 260px; min-height: 100vh; }
        .top-bar {
            background: white; padding: 15px 30px;
            display: flex; justify-content: space-between; align-items: center;
            box-shadow: var(--shadow); position: sticky; top: 0; z-index: 50;
        }
        .top-bar h2 { font-size: 1.3rem; font-weight: 700; }
        .top-bar-actions { display: flex; align-items: center; gap: 15px; }
        .notification-btn {
            width: 40px; height: 40px; border-radius: 10px;
            background: var(--bg-light); border: none;
            display: flex; align-items: center; justify-content: center;
            color: var(--text-muted); cursor: pointer; position: relative; transition: var(--transition);
        }
        .notification-btn:hover { background: #e8f5e9; color: var(--dar-green); }
        .notification-badge {
            position: absolute; top: -2px; right: -2px;
            width: 18px; height: 18px; background: #ef4444;
            color: white; font-size: 0.65rem; font-weight: 700;
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
        }
        .content { padding: 30px; }

        /* GREETING */
        .greeting-banner {
            background: linear-gradient(135deg, var(--dar-green) 0%, var(--dar-dark-green) 50%, #003300 100%);
            border-radius: var(--radius); padding: 32px 36px;
            margin-bottom: 28px; position: relative; overflow: hidden;
            display: flex; justify-content: space-between; align-items: center;
            box-shadow: 0 8px 32px rgba(0,100,0,0.25);
        }
        .greeting-banner::before {
            content: ''; position: absolute; top: -60%; right: -5%;
            width: 400px; height: 400px; border-radius: 50%; background: rgba(255,255,255,0.04);
        }
        .greeting-banner::after {
            content: ''; position: absolute; bottom: -40%; right: 10%;
            width: 250px; height: 250px; border-radius: 50%; background: rgba(255,215,0,0.06);
        }
        .greeting-text { position: relative; z-index: 2; }
        .greeting-text h2 { color: white; font-size: 1.6rem; font-weight: 700; margin-bottom: 6px; }
        .greeting-text h2 span { color: var(--dar-gold); }
        .greeting-text p { color: rgba(255,255,255,0.7); font-size: 0.9rem; }
        .greeting-stats { display: flex; gap: 30px; position: relative; z-index: 2; }
        .greeting-stat { text-align: center; }
        .greeting-stat h3 { color: var(--dar-gold); font-size: 1.6rem; font-weight: 800; }
        .greeting-stat small { color: rgba(255,255,255,0.6); font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.5px; }

        /* STAT CARDS */
        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 18px; margin-bottom: 28px; }
        .stat-card {
            background: white; border-radius: var(--radius);
            padding: 22px; box-shadow: var(--shadow);
            display: flex; align-items: center; gap: 16px;
            transition: var(--transition); border: 1px solid #f0f0f0;
            text-decoration: none; color: var(--text-dark); position: relative; overflow: hidden;
        }
        .stat-card:hover { transform: translateY(-4px); box-shadow: var(--shadow-lg); }
        .stat-card::after {
            content: ''; position: absolute; top: 0; right: 0;
            width: 60px; height: 60px; border-radius: 50%; opacity: 0.05; transform: translate(15px, -15px);
        }
        .stat-icon {
            width: 52px; height: 52px; border-radius: 14px;
            display: flex; align-items: center; justify-content: center; font-size: 1.2rem; flex-shrink: 0;
        }
        .stat-icon.blue   { background: #eff6ff; color: #3b82f6; }
        .stat-icon.green  { background: #f0fdf4; color: #16a34a; }
        .stat-icon.gold   { background: #fefce8; color: #ca8a04; }
        .stat-icon.red    { background: #fef2f2; color: #ef4444; }
        .stat-icon.purple { background: #faf5ff; color: #a855f7; }
        .stat-icon.teal   { background: #f0fdfa; color: #14b8a6; }
        .stat-icon.orange { background: #fff7ed; color: #f97316; }
        .stat-icon.cyan   { background: #ecfeff; color: #0891b2; }
        .stat-card.sc-blue::after   { background: #3b82f6; }
        .stat-card.sc-green::after  { background: #16a34a; }
        .stat-card.sc-gold::after   { background: #ca8a04; }
        .stat-card.sc-purple::after { background: #a855f7; }
        .stat-card.sc-teal::after   { background: #14b8a6; }
        .stat-card.sc-orange::after { background: #f97316; }
        .stat-card.sc-cyan::after   { background: #0891b2; }
        .stat-card.sc-red::after    { background: #ef4444; }
        .stat-info h3 { font-size: 1.5rem; font-weight: 800; line-height: 1; }
        .stat-info p { font-size: 0.78rem; color: var(--text-muted); margin-top: 3px; }

        /* PIPELINE */
        .pipeline-card {
            background: white; border-radius: var(--radius);
            box-shadow: var(--shadow); border: 1px solid #f0f0f0; margin-bottom: 28px; overflow: hidden;
        }
        .pipeline-header {
            padding: 18px 24px; border-bottom: 1px solid #f0f0f0;
            display: flex; justify-content: space-between; align-items: center;
        }
        .pipeline-header h4 { font-size: 0.95rem; font-weight: 700; display: flex; align-items: center; gap: 8px; }
        .pipeline-header h4 i { color: var(--dar-green); }
        .pipeline-header a { color: var(--dar-green); text-decoration: none; font-size: 0.82rem; font-weight: 600; }
        .pipeline-body { padding: 24px; }
        .pipeline-flow { display: flex; align-items: center; justify-content: center; gap: 0; }
        .pipe-step { flex: 1; text-align: center; max-width: 160px; }
        .pipe-circle {
            width: 52px; height: 52px; border-radius: 50%; margin: 0 auto 10px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1rem; font-weight: 800; color: white;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15); transition: var(--transition);
        }
        .pipe-step:hover .pipe-circle { transform: scale(1.1); box-shadow: 0 6px 20px rgba(0,0,0,0.2); }
        .pipe-label { font-size: 0.68rem; font-weight: 600; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.3px; }
        .pipe-count { font-size: 0.72rem; color: var(--text-muted); margin-top: 2px; }
        .pipe-arrow {
            flex: 0 0 40px; display: flex; align-items: center; justify-content: center;
            margin-bottom: 36px; color: #d1d5db; font-size: 1.1rem;
        }

        /* CHARTS */
        .charts-grid { display: grid; grid-template-columns: 3fr 2fr; gap: 22px; margin-bottom: 28px; }
        .charts-row-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 22px; margin-bottom: 28px; }
        .card {
            background: white; border-radius: var(--radius);
            box-shadow: var(--shadow); border: 1px solid #f0f0f0; overflow: hidden;
        }
        .card-header {
            padding: 18px 24px; border-bottom: 1px solid #f0f0f0;
            display: flex; justify-content: space-between; align-items: center;
        }
        .card-header h3 { font-size: 0.95rem; font-weight: 700; display: flex; align-items: center; gap: 8px; }
        .card-header h3 i { color: var(--dar-green); font-size: 0.9rem; }
        .card-header .view-all { color: var(--dar-green); text-decoration: none; font-size: 0.82rem; font-weight: 600; }
        .card-body { padding: 0; }
        .card-body-padded { padding: 24px; }

        /* CHART EMPTY STATE */
        .chart-empty {
            display: flex; flex-direction: column; align-items: center; justify-content: center;
            padding: 60px 20px; color: var(--text-muted); text-align: center;
        }
        .chart-empty i { font-size: 2.5rem; opacity: 0.15; margin-bottom: 14px; }
        .chart-empty h4 { font-size: 0.92rem; font-weight: 600; color: var(--text-dark); margin-bottom: 4px; }
        .chart-empty p { font-size: 0.8rem; }

        /* TABLES */
        .data-table { width: 100%; border-collapse: collapse; }
        .data-table th {
            text-align: left; padding: 12px 24px;
            font-size: 0.75rem; font-weight: 600; color: var(--text-muted);
            text-transform: uppercase; letter-spacing: 0.5px;
            background: #fafafa; border-bottom: 1px solid #f0f0f0; white-space: nowrap;
        }
        .data-table td {
            padding: 12px 24px; font-size: 0.87rem;
            border-bottom: 1px solid #f8f8f8; vertical-align: middle;
        }
        .data-table tr:hover td { background: #fafafa; }
        .data-table tr:last-child td { border-bottom: none; }

        .status-badge {
            display: inline-flex; align-items: center; gap: 5px;
            padding: 4px 12px; border-radius: 20px; font-size: 0.72rem; font-weight: 600; white-space: nowrap;
        }
        .status-badge .dot { width: 6px; height: 6px; border-radius: 50%; background: currentColor; }
        .status-active      { background: #f0fdf4; color: #16a34a; }
        .status-on_leave     { background: #fefce8; color: #ca8a04; }
        .status-submitted    { background: #fefce8; color: #ca8a04; }
        .status-under_review { background: #eff6ff; color: #3b82f6; }
        .status-shortlisted  { background: #fffbeb; color: #d97706; }
        .status-interview    { background: #f5f3ff; color: #7c3aed; }
        .status-exam         { background: #ecfeff; color: #0891b2; }
        .status-hired        { background: #f0fdf4; color: #16a34a; }
        .status-approved     { background: #f0fdf4; color: #16a34a; }
        .status-inactive     { background: #f1f5f9; color: #64748b; }

        .user-cell { display: flex; align-items: center; gap: 12px; }
        .user-avatar-sm {
            width: 36px; height: 36px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            color: white; font-weight: 600; font-size: 0.78rem; flex-shrink: 0;
        }
        .avatar-green  { background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green)); }
        .avatar-blue   { background: linear-gradient(135deg, #3b82f6, #60a5fa); }

        /* QUICK LINKS */
        .quick-links-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 28px; }
        .quick-link {
            background: white; border-radius: var(--radius);
            padding: 20px; box-shadow: var(--shadow); border: 1px solid #f0f0f0;
            text-decoration: none; color: var(--text-dark); transition: var(--transition);
            display: flex; align-items: center; gap: 14px;
        }
        .quick-link:hover { transform: translateY(-3px); box-shadow: var(--shadow-lg); border-color: var(--dar-light-green); }
        .quick-link-icon {
            width: 46px; height: 46px; border-radius: 12px;
            display: flex; align-items: center; justify-content: center; font-size: 1.1rem; flex-shrink: 0;
        }
        .quick-link h4 { font-size: 0.88rem; font-weight: 600; margin-bottom: 2px; }
        .quick-link p { font-size: 0.72rem; color: var(--text-muted); }

        /* ACTIVITY LOG */
        .activity-list { padding: 8px 0; }
        .activity-item { display: flex; align-items: flex-start; gap: 14px; padding: 12px 24px; transition: var(--transition); }
        .activity-item:hover { background: #fafafa; }
        .activity-dot { width: 8px; height: 8px; border-radius: 50%; margin-top: 6px; flex-shrink: 0; }
        .activity-text { flex: 1; }
        .activity-text p { font-size: 0.85rem; color: var(--text-dark); line-height: 1.4; }
        .activity-text p strong { font-weight: 600; }
        .activity-text small { font-size: 0.72rem; color: var(--text-muted); }

        /* PROGRESS BARS */
        .progress-item { margin-bottom: 18px; }
        .progress-item:last-child { margin-bottom: 0; }
        .progress-label { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; font-size: 0.85rem; }
        .progress-label span:first-child { color: var(--text-muted); font-weight: 500; }
        .progress-label span:last-child { font-weight: 700; }
        .progress-track { width: 100%; height: 8px; background: #f0f0f0; border-radius: 8px; overflow: hidden; }
        .progress-fill { height: 100%; border-radius: 8px; transition: width 1.2s ease; }

        /* EMPTY STATE */
        .empty-state { text-align: center; padding: 50px 20px; color: var(--text-muted); }
        .empty-state i { font-size: 2.5rem; opacity: 0.2; display: block; margin-bottom: 12px; }
        .empty-state p { font-size: 0.9rem; }

        @media print {
            .sidebar, .top-bar { display: none !important; }
            .main-content { margin-left: 0 !important; }
        }
        @media (max-width: 1280px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .quick-links-grid { grid-template-columns: repeat(2, 1fr); }
        }
        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; }
            .charts-grid, .charts-row-2 { grid-template-columns: 1fr; }
            .greeting-banner { flex-direction: column; gap: 20px; text-align: center; }
            .greeting-stats { justify-content: center; }
            .pipeline-flow { flex-wrap: wrap; }
            .pipe-arrow { display: none; }
            .pipe-step { flex: 0 0 33.33%; margin-bottom: 12px; }
        }
        @media (max-width: 768px) {
            .content { padding: 20px; }
            .stats-grid { grid-template-columns: 1fr 1fr; gap: 12px; }
            .quick-links-grid { grid-template-columns: 1fr; }
            .greeting-stats { gap: 16px; }
            .greeting-stat h3 { font-size: 1.2rem; }
            .data-table th, .data-table td { padding: 10px 14px; font-size: 0.8rem; }
        }
    </style>
</head>
<body>

<div class="dashboard">
    <!-- SIDEBAR -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">DAR</div>
            <h3>Admin Dashboard</h3>
            <p>Employee Records Management</p>
        </div>
        <nav class="nav-menu">
            <a href="dashboard_admin.php" class="nav-item active"><i class="fas fa-home"></i> Dashboard</a>
            <div class="nav-divider"></div>
            <div class="nav-label">People</div>
            <a href="employees.php" class="nav-item"><i class="fas fa-users"></i> Employees</a>
            <div class="nav-divider"></div>
            <div class="nav-label">Recruitment</div>
            <a href="positions.php" class="nav-item"><i class="fas fa-briefcase"></i> Vacant Positions</a>
            <a href="applications.php" class="nav-item"><i class="fas fa-file-alt"></i> Job Applications</a>
            <div class="nav-divider"></div>
            <div class="nav-label">Records</div>
            <a href="trainings.php" class="nav-item"><i class="fas fa-graduation-cap"></i> Trainings</a>
            <a href="document_tracking.php" class="nav-item"><i class="fas fa-exchange-alt"></i> Doc Tracking</a>
            <a href="documents.php" class="nav-item"><i class="fas fa-folder-open"></i> Documents</a>
            <div class="nav-divider"></div>
            <div class="nav-label">System</div>
            <a href="reports.php" class="nav-item"><i class="fas fa-chart-bar"></i> Reports</a>
            <a href="calendar_admin.php" class="nav-item"><i class="fas fa-calendar-alt"></i> Calendar</a>
            <a href="settings.php" class="nav-item"><i class="fas fa-cog"></i> Settings</a>
        </nav>
        <div class="sidebar-footer">
            <div class="user-info">
                <div class="user-avatar"><?php echo strtoupper(substr($admin_name, 0, 1)); ?></div>
                <div class="user-details">
                    <h4><?php echo htmlspecialchars($admin_name); ?></h4>
                    <p><?php echo ucfirst($role); ?></p>
                </div>
            </div>
            <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </aside>

    <!-- MAIN -->
    <main class="main-content">
        <div class="top-bar">
            <h2><i class="fas fa-tachometer-alt" style="margin-right:10px;color:var(--dar-green);"></i>Dashboard</h2>
            <div class="top-bar-actions">
                <button class="notification-btn" title="Notifications">
                    <i class="fas fa-bell"></i>
                    <span class="notification-badge"><?php echo $pending_apps > 0 ? $pending_apps : 0; ?></span>
                </button>
                <span style="font-size:0.88rem;color:var(--text-muted);font-weight:500;">
                    <i class="fas fa-calendar-day" style="margin-right:6px;"></i><?php echo date('l, F d, Y'); ?>
                </span>
            </div>
        </div>

        <div class="content">

            <!-- GREETING -->
            <div class="greeting-banner">
                <div class="greeting-text">
                    <h2><?php echo $greeting; ?>, <span><?php echo htmlspecialchars($admin_name); ?></span>!</h2>
                    <p>Here's what's happening with your workforce today.</p>
                </div>
                <div class="greeting-stats">
                    <div class="greeting-stat"><h3><?php echo number_format($total_employees); ?></h3><small>Employees</small></div>
                    <div class="greeting-stat"><h3><?php echo number_format($pending_apps); ?></h3><small>Pending</small></div>
                    <div class="greeting-stat"><h3><?php echo number_format($hired_count); ?></h3><small>Hired</small></div>
                    <div class="greeting-stat"><h3><?php echo number_format($total_positions); ?></h3><small>Vacancies</small></div>
                </div>
            </div>

            <!-- STATS -->
            <div class="stats-grid">
                <a href="employees.php" class="stat-card sc-blue">
                    <div class="stat-icon blue"><i class="fas fa-users"></i></div>
                    <div class="stat-info"><h3><?php echo number_format($total_employees); ?></h3><p>Total Employees</p></div>
                </a>
                <a href="applicants.php" class="stat-card sc-green">
                    <div class="stat-icon green"><i class="fas fa-user-plus"></i></div>
                    <div class="stat-info"><h3><?php echo number_format($total_applicants); ?></h3><p>Total Applicants</p></div>
                </a>
                <a href="applications.php" class="stat-card sc-gold">
                    <div class="stat-icon gold"><i class="fas fa-file-alt"></i></div>
                    <div class="stat-info"><h3><?php echo number_format($pending_apps); ?></h3><p>Pending Apps</p></div>
                </a>
                <a href="positions.php" class="stat-card sc-purple">
                    <div class="stat-icon purple"><i class="fas fa-briefcase"></i></div>
                    <div class="stat-info"><h3><?php echo number_format($total_positions); ?></h3><p>Open Positions</p></div>
                </a>
                <a href="applications.php" class="stat-card sc-teal">
                    <div class="stat-icon teal"><i class="fas fa-clipboard-check"></i></div>
                    <div class="stat-info"><h3><?php echo number_format($shortlisted_count); ?></h3><p>Shortlisted</p></div>
                </a>
                <a href="applications.php" class="stat-card sc-cyan">
                    <div class="stat-icon cyan"><i class="fas fa-comments"></i></div>
                    <div class="stat-info"><h3><?php echo number_format($interview_count); ?></h3><p>For Interview</p></div>
                </a>
                <a href="trainings.php" class="stat-card sc-orange">
                    <div class="stat-icon orange"><i class="fas fa-graduation-cap"></i></div>
                    <div class="stat-info"><h3><?php echo number_format($total_trainings); ?></h3><p>Trainings</p></div>
                </a>
                <a href="document_tracking.php" class="stat-card sc-red">
                    <div class="stat-icon red"><i class="fas fa-exchange-alt"></i></div>
                    <div class="stat-info"><h3><?php echo number_format($active_docs); ?></h3><p>Active Docs</p></div>
                </a>
            </div>

            <!-- PIPELINE -->
            <div class="pipeline-card">
                <div class="pipeline-header">
                    <h4><i class="fas fa-stream"></i> Recruitment Pipeline</h4>
                    <a href="applications.php">View All <i class="fas fa-arrow-right" style="margin-left:4px;"></i></a>
                </div>
                <div class="pipeline-body">
                    <div class="pipeline-flow">
                        <?php
                        $pipe_steps = [
                            'submitted'    => ['label' => 'Submitted',    'color' => '#ca8a04', 'count' => $pending_apps],
                            'under_review' => ['label' => 'Under Review', 'color' => '#3b82f6', 'count' => $under_review_count],
                            'shortlisted'  => ['label' => 'Shortlisted',  'color' => '#d97706', 'count' => $shortlisted_count],
                            'interview'    => ['label' => 'Interview',    'color' => '#7c3aed', 'count' => $interview_count],
                            'exam'         => ['label' => 'Exam',         'color' => '#0891b2', 'count' => $exam_count],
                            'hired'        => ['label' => 'Hired',        'color' => '#16a34a', 'count' => $hired_count],
                        ];
                        $first = true;
                        foreach ($pipe_steps as $step):
                            if (!$first): ?><div class="pipe-arrow"><i class="fas fa-chevron-right"></i></div><?php endif; $first = false; ?>
                            <div class="pipe-step">
                                <div class="pipe-circle" style="background:<?php echo $step['color']; ?>;"><?php echo $step['count']; ?></div>
                                <div class="pipe-label"><?php echo $step['label']; ?></div>
                                <div class="pipe-count"><?php echo $step['count']; ?> applicant<?php echo $step['count'] != 1 ? 's' : ''; ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- QUICK LINKS -->
            <div class="quick-links-grid">
                <a href="employees.php" class="quick-link">
                    <div class="quick-link-icon" style="background:#eff6ff;color:#3b82f6;"><i class="fas fa-user-plus"></i></div>
                    <div><h4>Add Employee</h4><p>Register new staff</p></div>
                </a>
                <a href="positions.php" class="quick-link">
                    <div class="quick-link-icon" style="background:#fefce8;color:#ca8a04;"><i class="fas fa-briefcase"></i></div>
                    <div><h4>Post Vacancy</h4><p>Add vacant position</p></div>
                </a>
                <a href="trainings.php" class="quick-link">
                    <div class="quick-link-icon" style="background:#faf5ff;color:#a855f7;"><i class="fas fa-graduation-cap"></i></div>
                    <div><h4>Schedule Training</h4><p>Plan employee training</p></div>
                </a>
                <a href="document_tracking.php" class="quick-link">
                    <div class="quick-link-icon" style="background:#fff7ed;color:#f97316;"><i class="fas fa-exchange-alt"></i></div>
                    <div><h4>Track Document</h4><p>Log incoming docs</p></div>
                </a>
            </div>

            <!-- CHARTS ROW 1 -->
            <div class="charts-grid">
                <!-- Dept Chart -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-building"></i> Employees by Department</h3>
                    </div>
                    <?php if (!empty($dept_labels)): ?>
                    <div class="card-body-padded">
                        <div style="position:relative;height:300px;"><canvas id="deptChart"></canvas></div>
                    </div>
                    <?php else: ?>
                    <div class="chart-empty">
                        <i class="fas fa-building"></i>
                        <h4>No Department Data</h4>
                        <p>Add employees with department info to see this chart.</p>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Trend Chart -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-chart-line"></i> Application Trend</h3>
                    </div>
                    <?php if (!empty($month_labels)): ?>
                    <div class="card-body-padded">
                        <div style="position:relative;height:300px;"><canvas id="trendChart"></canvas></div>
                    </div>
                    <?php else: ?>
                    <div class="chart-empty">
                        <i class="fas fa-chart-line"></i>
                        <h4>No Application Trend</h4>
                        <p>Applications will appear here once applicants start applying.</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- CHARTS ROW 2 -->
            <div class="charts-row-2">
                <!-- Status Pie -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-chart-pie"></i> Application Status</h3>
                    </div>
                    <?php if (!empty($status_data)): ?>
                    <div class="card-body-padded" style="display:flex;justify-content:center;">
                        <div style="position:relative;max-width:280px;max-height:280px;width:100%;">
                            <canvas id="statusPieChart"></canvas>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="chart-empty">
                        <i class="fas fa-chart-pie"></i>
                        <h4>No Status Data</h4>
                        <p>Receive job applications to see the status breakdown.</p>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Workforce Overview -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-tachometer-alt"></i> Workforce Overview</h3>
                    </div>
                    <div class="card-body-padded">
                        <?php
                        $inactive_emp = max($total_employees - $active_employees - $on_leave, 0);
                        $active_pct = $total_employees > 0 ? round(($active_employees / $total_employees) * 100) : 0;
                        $leave_pct  = $total_employees > 0 ? round(($on_leave / $total_employees) * 100) : 0;
                        $inact_pct  = $total_employees > 0 ? round(($inactive_emp / $total_employees) * 100) : 0;
                        $new_pct    = min($new_applicants_month * 5, 100);
                        ?>
                        <div class="progress-item">
                            <div class="progress-label">
                                <span><i class="fas fa-circle" style="color:#16a34a;font-size:0.5rem;margin-right:6px;"></i>Active Employees</span>
                                <span style="color:#16a34a;"><?php echo $active_employees; ?> (<?php echo $active_pct; ?>%)</span>
                            </div>
                            <div class="progress-track">
                                <div class="progress-fill" style="width:<?php echo $active_pct; ?>%;background:linear-gradient(90deg,#16a34a,#4ade80);"></div>
                            </div>
                        </div>
                        <div class="progress-item">
                            <div class="progress-label">
                                <span><i class="fas fa-circle" style="color:#ca8a04;font-size:0.5rem;margin-right:6px;"></i>On Leave</span>
                                <span style="color:#ca8a04;"><?php echo $on_leave; ?> (<?php echo $leave_pct; ?>%)</span>
                            </div>
                            <div class="progress-track">
                                <div class="progress-fill" style="width:<?php echo max($leave_pct, 2); ?>%;background:linear-gradient(90deg,#ca8a04,#fbbf24);"></div>
                            </div>
                        </div>
                        <div class="progress-item">
                            <div class="progress-label">
                                <span><i class="fas fa-circle" style="color:#64748b;font-size:0.5rem;margin-right:6px;"></i>Inactive</span>
                                <span style="color:#64748b;"><?php echo $inactive_emp; ?> (<?php echo $inact_pct; ?>%)</span>
                            </div>
                            <div class="progress-track">
                                <div class="progress-fill" style="width:<?php echo max($inact_pct, 2); ?>%;background:linear-gradient(90deg,#64748b,#94a3b8);"></div>
                            </div>
                        </div>
                        <div style="border-top:1px solid #f0f0f0;margin:20px 0;padding-top:18px;">
                            <div class="progress-item">
                                <div class="progress-label">
                                    <span><i class="fas fa-circle" style="color:#3b82f6;font-size:0.5rem;margin-right:6px;"></i>New Applicants (This Month)</span>
                                    <span style="color:#3b82f6;"><?php echo $new_applicants_month; ?></span>
                                </div>
                                <div class="progress-track">
                                    <div class="progress-fill" style="width:<?php echo $new_pct; ?>%;background:linear-gradient(90deg,#3b82f6,#60a5fa);"></div>
                                </div>
                            </div>
                            <div class="progress-item">
                                <div class="progress-label">
                                    <span><i class="fas fa-circle" style="color:#a855f7;font-size:0.5rem;margin-right:6px;"></i>Departments</span>
                                    <span style="color:#a855f7;"><?php echo $total_departments; ?></span>
                                </div>
                                <div class="progress-track">
                                    <div class="progress-fill" style="width:<?php echo min($total_departments * 8, 100); ?>%;background:linear-gradient(90deg,#a855f7,#c084fc);"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- RECENT EMPLOYEES -->
            <div class="card" style="margin-bottom:22px;">
                <div class="card-header">
                    <h3><i class="fas fa-users"></i> Recent Employees</h3>
                    <a href="employees.php" class="view-all">View All <i class="fas fa-arrow-right" style="margin-left:4px;"></i></a>
                </div>
                <div class="card-body">
                    <?php if ($recent_employees && $recent_employees->num_rows > 0): ?>
                    <table class="data-table">
                        <thead>
                            <tr><th>Employee</th><th>Employee ID</th><th>Department</th><th>Position</th><th>Status</th><th>Date Hired</th></tr>
                        </thead>
                        <tbody>
                            <?php while($emp = $recent_employees->fetch_assoc()): ?>
                            <tr>
                                <td>
                                    <div class="user-cell">
                                        <div class="user-avatar-sm avatar-green"><?php echo strtoupper(substr($emp['first_name'], 0, 1) . substr($emp['last_name'], 0, 1)); ?></div>
                                        <span style="font-weight:600;"><?php echo htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']); ?></span>
                                    </div>
                                </td>
                                <td style="font-family:monospace;font-size:0.82rem;color:var(--dar-green);"><?php echo htmlspecialchars($emp['employee_id'] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($emp['department'] ?? '—'); ?></td>
                                <td><?php echo htmlspecialchars($emp['position'] ?? '—'); ?></td>
                                <td><span class="status-badge status-<?php echo $emp['status'] ?? 'active'; ?>"><span class="dot"></span> <?php echo ucfirst(str_replace('_', ' ', $emp['status'] ?? 'active')); ?></span></td>
                                <td style="color:var(--text-muted);font-size:0.85rem;"><?php echo !empty($emp['date_hired']) ? date('M d, Y', strtotime($emp['date_hired'])) : '—'; ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <div class="empty-state"><i class="fas fa-users"></i><p>No employees recorded yet.</p></div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- TWO-COLUMN BOTTOM -->
            <div class="charts-row-2">
                <!-- Recent Applicants -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-user-plus"></i> Recent Applicants</h3>
                        <a href="applicants.php" class="view-all">View All <i class="fas fa-arrow-right" style="margin-left:4px;"></i></a>
                    </div>
                    <div class="card-body">
                        <?php if ($recent_applicants && $recent_applicants->num_rows > 0): ?>
                        <table class="data-table">
                            <thead><tr><th>Applicant</th><th>Position</th><th>Date</th></tr></thead>
                            <tbody>
                                <?php while($app = $recent_applicants->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <div class="user-cell">
                                            <div class="user-avatar-sm avatar-blue"><?php echo strtoupper(substr($app['first_name'], 0, 1) . substr($app['last_name'], 0, 1)); ?></div>
                                            <div>
                                                <div style="font-weight:600;font-size:0.85rem;"><?php echo htmlspecialchars($app['first_name'] . ' ' . $app['last_name']); ?></div>
                                                <div style="font-size:0.72rem;color:var(--text-muted);"><?php echo htmlspecialchars($app['education_level'] ?? ''); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td style="font-size:0.84rem;"><?php echo htmlspecialchars($app['position_title'] ?? 'N/A'); ?></td>
                                    <td style="color:var(--text-muted);font-size:0.82rem;white-space:nowrap;"><?php echo date('M d, Y', strtotime($app['created_at'])); ?></td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                        <div class="empty-state"><i class="fas fa-user-plus"></i><p>No applicants yet.</p></div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Activity Log -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-history"></i> Recent Activity</h3>
                    </div>
                    <div class="card-body">
                        <?php if ($recent_logs && $recent_logs->num_rows > 0): ?>
                        <div class="activity-list">
                            <?php
                            $log_colors = ['#16a34a','#3b82f6','#ca8a04','#a855f7','#0891b2','#ef4444','#f97316','#ec4899'];
                            $li = 0;
                            while($log = $recent_logs->fetch_assoc()):
                                $li++;
                                $dot_color = $log_colors[($li - 1) % count($log_colors)];
                            ?>
                            <div class="activity-item">
                                <div class="activity-dot" style="background:<?php echo $dot_color; ?>;"></div>
                                <div class="activity-text">
                                    <p><strong>Admin #<?php echo $log['user_id']; ?></strong> — <?php echo htmlspecialchars($log['action']); ?></p>
                                    <small><i class="fas fa-clock" style="margin-right:4px;"></i><?php echo date('M d, Y h:i A', strtotime($log['created_at'])); ?></small>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                        <?php else: ?>
                        <div class="empty-state"><i class="fas fa-history"></i><p>No activity logs yet.</p></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div>
    </main>
</div>

<script>
Chart.defaults.font.family = "'Poppins', sans-serif";
Chart.defaults.font.size = 12;
Chart.defaults.color = '#6b7280';

<?php if (!empty($dept_labels)): ?>
new Chart(document.getElementById('deptChart'), {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($dept_labels); ?>,
        datasets: [{
            label: 'Employees',
            data: <?php echo json_encode($dept_counts); ?>,
            backgroundColor: <?php echo json_encode(array_map(function($i) { return ['#006400cc','#3b82f6cc','#ca8a04cc','#a855f7cc','#0891b2cc','#ef4444cc','#f97316cc','#ec4899cc'][$i % 8]; }, array_keys($dept_labels))); ?>,
            borderColor: <?php echo json_encode(array_map(function($i) { return ['#006400','#3b82f6','#ca8a04','#a855f7','#0891b2','#ef4444','#f97316','#ec4899'][$i % 8]; }, array_keys($dept_labels))); ?>,
            borderWidth: 2, borderRadius: 8, borderSkipped: false, maxBarThickness: 50
        }]
    },
    options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            x: { grid: { display: false }, ticks: { font: { size: 11, weight: 500 } } },
            y: { beginAtZero: true, grid: { color: '#f3f4f6' }, ticks: { stepSize: 5, font: { size: 11 } } }
        }
    }
});
<?php endif; ?>

<?php if (!empty($month_labels)): ?>
new Chart(document.getElementById('trendChart'), {
    type: 'line',
    data: {
        labels: <?php echo json_encode($month_labels); ?>,
        datasets: [{
            label: 'Applications',
            data: <?php echo json_encode($monthly_data); ?>,
            borderColor: '#006400', backgroundColor: 'rgba(0,100,0,0.08)',
            borderWidth: 3, fill: true, tension: 0.4,
            pointBackgroundColor: '#006400', pointBorderColor: '#fff',
            pointBorderWidth: 2, pointRadius: 5, pointHoverRadius: 7
        }]
    },
    options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            x: { grid: { display: false }, ticks: { font: { size: 11 } } },
            y: { beginAtZero: true, grid: { color: '#f3f4f6' }, ticks: { stepSize: 1, font: { size: 11 } } }
        }
    }
});
<?php endif; ?>

<?php if (!empty($status_data)): ?>
new Chart(document.getElementById('statusPieChart'), {
    type: 'doughnut',
    data: {
        labels: <?php echo json_encode(array_column($status_data, 'label')); ?>,
        datasets: [{
            data: <?php echo json_encode(array_column($status_data, 'count')); ?>,
            backgroundColor: <?php
                $sKeys = array_keys($status_data);
                $sColors = ['submitted'=>'#ca8a04','under_review'=>'#3b82f6','shortlisted'=>'#d97706','interview'=>'#7c3aed','exam'=>'#0891b2','hired'=>'#16a34a','approved'=>'#16a34a','rejected'=>'#ef4444'];
                echo json_encode(array_map(function($k) use ($sColors) { return $sColors[$k] ?? '#9ca3af'; }, $sKeys));
            ?>,
            borderWidth: 2, borderColor: '#fff', hoverOffset: 8
        }]
    },
    options: {
        responsive: true, cutout: '62%',
        plugins: {
            legend: { position: 'bottom', labels: { font: { size: 10, weight: 500 }, padding: 10, usePointStyle: true, pointStyleWidth: 8 } }
        }
    }
});
<?php endif; ?>
</script>

</body>
</html>