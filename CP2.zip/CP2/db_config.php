<?php

 $conn = new mysqli("localhost", "root", "ricopogi18jr", "dar_employee_system");
if ($conn->connect_error) die("Database connection failed.");
 $conn->set_charset("utf8mb4");

function sanitize($conn, $data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

function redirect($url) {
    header("Location: $url"); exit();
}

function showAlert($msg, $type = 'success') {
    $c = $type == 'error' ? '#f44336' : '#4CAF50';
    echo "<div style='position:fixed;top:20px;right:20px;z-index:9999;background:$c;color:#fff;padding:12px 20px;border-radius:8px;font-family:sans-serif;box-shadow:0 2px 10px rgba(0,0,0,.2)'>$msg <span onclick='this.parentElement.remove()' style='margin-left:12px;cursor:pointer'>×</span></div><script>setTimeout(()=>{document.querySelector('[style*=z-index]')?.remove()},4000)</script>";
}

function isLoggedIn($type) {
    return !empty($_SESSION[$type . '_id']);
}

function requireLogin($type, $url) {
    if (!isLoggedIn($type)) { $_SESSION['error'] = "Please login first."; redirect($url); }
}
?>