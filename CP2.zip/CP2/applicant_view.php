<?php
session_start();
require_once 'db_config.php';

requireLogin('admin', 'login_admin.php');
 $page_title = "Applicant Details - DAR";

if (isset($_GET['approve']) && is_numeric($_GET['approve'])) {
    $id = (int)$_GET['approve'];
    $conn->query("UPDATE applicants SET status = 'approved' WHERE id = $id");
    $_SESSION['success'] = "Applicant approved successfully.";
    redirect('applicant_view.php?id=' . $id);
}

if (isset($_GET['reject']) && is_numeric($_GET['reject'])) {
    $id = (int)$_GET['reject'];
    $conn->query("UPDATE applicants SET status = 'rejected' WHERE id = $id");
    $_SESSION['success'] = "Applicant rejected.";
    redirect('applicant_view.php?id=' . $id);
}

if (isset($_GET['restore']) && is_numeric($_GET['restore'])) {
    $id = (int)$_GET['restore'];
    $conn->query("UPDATE applicants SET status = 'pending' WHERE id = $id");
    $_SESSION['success'] = "Applicant status reset to pending.";
    redirect('applicant_view.php?id=' . $id);
}

if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM applicants WHERE id = $id");
    $_SESSION['success'] = "Applicant deleted successfully.";
    redirect('applicants.php');
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    redirect('applicants.php');
}

 $id = (int)$_GET['id'];
 $applicant = $conn->query("SELECT * FROM applicants WHERE id = $id");

if ($applicant->num_rows == 0) {
    $_SESSION['error'] = "Applicant not found.";
    redirect('applicants.php');
}

 $app = $applicant->fetch_assoc();

 $applications = $conn->query("SELECT ja.*, p.position_title, p.department, p.employment_type 
                              FROM job_applications ja 
                              LEFT JOIN vacant_positions p ON ja.position_id = p.id 
                              WHERE ja.applicant_id = $id ORDER BY ja.applied_at DESC");

 $documents = $conn->query("SELECT * FROM applicant_documents WHERE applicant_id = $id ORDER BY uploaded_at DESC");
 $experiences = $conn->query("SELECT * FROM applicant_experience WHERE applicant_id = $id ORDER BY start_date DESC");
 $education = $conn->query("SELECT * FROM applicant_education WHERE applicant_id = $id ORDER BY year_graduated DESC");
 $logs = $conn->query("SELECT * FROM system_logs WHERE user_type = 'applicant' AND user_id = $id ORDER BY created_at DESC LIMIT 10");

// Helper function - check if field exists and has value
function hasValue($arr, $key) {
    return isset($arr[$key]) && !empty(trim($arr[$key]));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dar-green: #006400;
            --dar-dark-green: #004d00;
            --dar-light-green: #4CAF50;
            --dar-gold: #FFD700;
            --bg-light: #f4f6f5;
            --sidebar-bg: #0a2e0a;
            --text-dark: #111827;
            --text-body: #374151;
            --text-muted: #6b7280;
            --text-light: #9ca3af;
            --border: #e5e7eb;
            --border-light: #f3f4f6;
            --shadow-sm: 0 1px 2px rgba(0,0,0,0.04);
            --shadow: 0 1px 8px rgba(0,0,0,0.06);
            --radius: 12px;
            --radius-sm: 8px;
            --transition: all 0.2s ease;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-light);
            color: var(--text-body);
            -webkit-font-smoothing: antialiased;
            font-size: 14px;
            line-height: 1.5;
            letter-spacing: -0.01em;
        }

        .dashboard { display: flex; min-height: 100vh; }

        .sidebar {
            width: 256px;
            background: var(--sidebar-bg);
            color: white;
            position: fixed;
            top: 0; left: 0; bottom: 0;
            overflow-y: auto;
            z-index: 100;
            display: flex;
            flex-direction: column;
        }
        .sidebar::-webkit-scrollbar { width: 3px; }
        .sidebar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.12); border-radius: 3px; }

        .sidebar-header {
            padding: 24px 20px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.07);
            flex-shrink: 0;
        }
        .sidebar-logo {
            width: 48px; height: 48px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            color: var(--dar-green);
            font-weight: 800; font-size: 14px;
            margin: 0 auto 12px;
            box-shadow: 0 4px 12px rgba(255,215,0,0.2);
        }
        .sidebar-header h3 { font-size: 13px; font-weight: 600; }
        .sidebar-header p { font-size: 10px; opacity: 0.4; margin-top: 3px; }

        .nav-menu { padding: 12px 0; flex: 1; }
        .nav-label {
            padding: 14px 22px 6px;
            font-size: 9px; font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            color: rgba(255,255,255,0.25);
        }
        .nav-item {
            display: flex; align-items: center; gap: 11px;
            padding: 9px 22px;
            color: rgba(255,255,255,0.55);
            text-decoration: none;
            font-size: 12.5px; font-weight: 500;
            transition: var(--transition);
            border-left: 3px solid transparent;
            margin: 1px 0;
        }
        .nav-item:hover { background: rgba(255,255,255,0.05); color: rgba(255,255,255,0.85); }
        .nav-item.active { background: rgba(255,255,255,0.05); color: white; border-left-color: var(--dar-gold); }
        .nav-item i { width: 16px; text-align: center; font-size: 12px; }

        .sidebar-footer {
            padding: 16px 20px;
            border-top: 1px solid rgba(255,255,255,0.07);
            flex-shrink: 0;
        }
        .user-info { display: flex; align-items: center; gap: 10px; }
        .user-avatar {
            width: 34px; height: 34px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 8px;
            display: flex; align-items: center; justify-content: center;
            color: var(--dar-green);
            font-weight: 700; font-size: 12px;
        }
        .user-details h4 { font-size: 11.5px; font-weight: 600; }
        .user-details p { font-size: 10px; opacity: 0.45; }
        .logout-btn {
            display: flex; align-items: center; gap: 7px;
            color: rgba(255,255,255,0.4);
            text-decoration: none;
            font-size: 11px; font-weight: 500;
            margin-top: 12px;
            transition: var(--transition);
        }
        .logout-btn:hover { color: #f87171; }

        .main-content { flex: 1; margin-left: 256px; min-height: 100vh; }

        .top-bar {
            background: white;
            padding: 0 28px;
            height: 56px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border);
            position: sticky; top: 0; z-index: 50;
        }
        .top-bar-left { display: flex; align-items: center; gap: 10px; }
        .top-bar h2 { font-size: 14px; font-weight: 700; color: var(--text-dark); }
        .top-bar h2 i { color: var(--dar-green); margin-right: 8px; font-size: 13px; }

        .content { padding: 24px 28px 40px; }

        .alert {
            padding: 12px 16px;
            border-radius: var(--radius-sm);
            margin-bottom: 20px;
            display: flex; align-items: center; gap: 10px;
            font-size: 13px; font-weight: 500;
        }
        .alert-success { background: #ecfdf5; color: #059669; border: 1px solid #a7f3d0; }
        .alert-error { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }
        .alert i { font-size: 14px; }

        .btn-back {
            display: inline-flex; align-items: center; gap: 7px;
            color: var(--text-body); text-decoration: none;
            font-size: 12.5px; font-weight: 600;
            margin-bottom: 20px;
            transition: var(--transition);
            padding: 7px 14px;
            border-radius: var(--radius-sm);
            background: white;
            border: 1px solid var(--border);
        }
        .btn-back:hover { border-color: var(--dar-green); color: var(--dar-green); }
        .btn-back i { font-size: 11px; }

        .status-badge {
            display: inline-flex; align-items: center; gap: 5px;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 11px; font-weight: 600;
        }
        .status-badge i { font-size: 4px; }
        .status-pending { background: #fefce8; color: #b45309; }
        .status-approved { background: #ecfdf5; color: #059669; }
        .status-rejected { background: #fef2f2; color: #dc2626; }
        .status-hired { background: #eff6ff; color: #2563eb; }
        .status-under-review { background: #f5f3ff; color: #7c3aed; }

        .profile-header {
            background: white;
            border-radius: var(--radius);
            border: 1px solid var(--border);
            overflow: hidden;
            margin-bottom: 20px;
        }
        .profile-banner {
            height: 100px;
            background: linear-gradient(135deg, var(--dar-green) 0%, var(--dar-dark-green) 60%, #003300 100%);
            position: relative;
        }
        .profile-banner::after {
            content: '';
            position: absolute; top: 0; left: 0; right: 0; bottom: 0;
            background-image: radial-gradient(rgba(255,255,255,0.05) 1px, transparent 1px);
            background-size: 20px 20px;
        }

        .profile-body {
            padding: 0 28px 24px;
            margin-top: -42px;
            position: relative;
            z-index: 2;
            display: flex;
            align-items: flex-end;
            gap: 20px;
        }
        .profile-avatar-lg {
            width: 84px; height: 84px;
            border-radius: 14px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            display: flex; align-items: center; justify-content: center;
            color: var(--dar-green);
            font-weight: 800; font-size: 22px;
            border: 3px solid white;
            box-shadow: 0 2px 12px rgba(0,0,0,0.1);
            flex-shrink: 0;
        }
        .profile-main { flex: 1; padding-bottom: 2px; min-width: 0; }
        .profile-main h2 {
            font-size: 18px; font-weight: 700;
            color: var(--text-dark);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .profile-sub {
            color: var(--text-muted);
            font-size: 12px;
            margin-top: 3px;
            display: flex; align-items: center; gap: 7px;
            flex-wrap: wrap;
        }
        .profile-sub .dot { width: 3px; height: 3px; background: var(--text-light); border-radius: 50%; }
        .meta-tags { display: flex; gap: 6px; margin-top: 10px; flex-wrap: wrap; }
        .meta-tag {
            display: inline-flex; align-items: center; gap: 5px;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 11px; font-weight: 500;
            background: #f9fafb; color: var(--text-muted);
            border: 1px solid var(--border);
        }
        .meta-tag i { font-size: 9px; color: var(--text-light); }

        .profile-actions {
            display: flex; gap: 6px; padding-bottom: 2px; flex-shrink: 0; flex-wrap: wrap;
            justify-content: flex-end;
        }
        .btn-action-lg {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 8px 16px;
            border-radius: var(--radius-sm);
            text-decoration: none;
            font-size: 12px; font-weight: 600;
            transition: var(--transition);
            border: none; cursor: pointer;
            font-family: 'Inter', sans-serif;
            white-space: nowrap;
        }
        .btn-action-lg i { font-size: 11px; }
        .btn-approve-lg { background: #059669; color: white; }
        .btn-approve-lg:hover { background: #047857; box-shadow: 0 2px 8px rgba(5,150,105,0.3); }
        .btn-reject-lg { background: #dc2626; color: white; }
        .btn-reject-lg:hover { background: #b91c1c; box-shadow: 0 2px 8px rgba(220,38,38,0.3); }
        .btn-restore-lg { background: #d97706; color: white; }
        .btn-restore-lg:hover { background: #b45309; box-shadow: 0 2px 8px rgba(217,119,6,0.3); }
        .btn-delete-lg { background: white; color: #dc2626; border: 1px solid #fecaca; }
        .btn-delete-lg:hover { background: #fef2f2; border-color: #fca5a5; }

        .cards-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 16px; margin-bottom: 16px;
        }
        .info-card {
            background: white;
            border-radius: var(--radius);
            border: 1px solid var(--border);
            overflow: hidden;
        }
        .info-card-full { grid-column: 1 / -1; }

        .card-header {
            padding: 14px 20px;
            border-bottom: 1px solid var(--border);
            display: flex; align-items: center; gap: 10px;
        }
        .card-header-icon {
            width: 30px; height: 30px;
            border-radius: 7px;
            display: flex; align-items: center; justify-content: center;
            font-size: 12px;
        }
        .icon-green { background: #ecfdf5; color: #059669; }
        .icon-blue { background: #eff6ff; color: #2563eb; }
        .icon-gold { background: #fffbeb; color: #d97706; }
        .icon-purple { background: #f5f3ff; color: #7c3aed; }
        .icon-red { background: #fef2f2; color: #dc2626; }
        .icon-teal { background: #f0fdfa; color: #0d9488; }
        .icon-gray { background: #f9fafb; color: #6b7280; }

        .card-header h3 { font-size: 13px; font-weight: 650; color: var(--text-dark); }
        .card-count {
            margin-left: auto;
            font-size: 11px;
            color: var(--text-light);
            font-weight: 500;
            background: #f9fafb;
            padding: 2px 8px;
            border-radius: 5px;
        }
        .card-body { padding: 4px 20px 16px; }

        .info-row {
            display: flex;
            align-items: baseline;
            padding: 9px 0;
            border-bottom: 1px solid var(--border-light);
            gap: 12px;
        }
        .info-row:last-child { border-bottom: none; }
        .info-label {
            color: var(--text-muted);
            font-size: 12px; font-weight: 500;
            min-width: 120px;
            flex-shrink: 0;
        }
        .info-value {
            font-size: 12.5px; font-weight: 500;
            color: var(--text-dark);
            text-align: right;
            word-break: break-word;
            line-height: 1.5;
            flex: 1;
        }

        .inner-table { width: 100%; border-collapse: collapse; }
        .inner-table th {
            text-align: left; padding: 10px 16px;
            font-size: 10px; font-weight: 650;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.8px;
            background: #fafbfc;
            border-bottom: 1px solid var(--border);
        }
        .inner-table td {
            padding: 11px 16px;
            font-size: 12.5px;
            border-bottom: 1px solid var(--border-light);
            vertical-align: middle;
        }
        .inner-table tbody tr:hover td { background: #fafbfc; }
        .inner-table tbody tr:last-child td { border-bottom: none; }

        .doc-item {
            display: flex; align-items: center; justify-content: space-between;
            padding: 10px 12px;
            border: 1px solid var(--border-light);
            border-radius: var(--radius-sm);
            margin-bottom: 6px;
            transition: var(--transition);
            gap: 10px;
        }
        .doc-item:last-child { margin-bottom: 0; }
        .doc-item:hover { border-color: var(--border); background: #fafbfc; }
        .doc-info { display: flex; align-items: center; gap: 10px; min-width: 0; }
        .doc-icon {
            width: 36px; height: 36px;
            border-radius: 8px;
            display: flex; align-items: center; justify-content: center;
            font-size: 14px;
        }
        .doc-pdf { background: #fef2f2; color: #dc2626; }
        .doc-img { background: #eff6ff; color: #2563eb; }
        .doc-file { background: #f3f4f6; color: #6b7280; }
        .doc-name {
            font-weight: 600; font-size: 12px;
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        }
        .doc-date { font-size: 10.5px; color: var(--text-light); margin-top: 1px; }
        .btn-download {
            display: inline-flex; align-items: center; gap: 5px;
            padding: 6px 14px;
            border-radius: 6px;
            background: var(--dar-green); color: white;
            text-decoration: none;
            font-size: 11px; font-weight: 600;
            transition: var(--transition);
            white-space: nowrap;
        }
        .btn-download:hover { background: var(--dar-dark-green); }
        .btn-download i { font-size: 10px; }

        .exp-item { padding: 12px 0; border-bottom: 1px solid var(--border-light); }
        .exp-item:last-child { border-bottom: none; }
        .exp-position { font-weight: 600; font-size: 12.5px; color: var(--text-dark); }
        .exp-company { font-size: 12px; color: var(--dar-green); font-weight: 500; margin-top: 1px; }
        .exp-date { font-size: 11px; color: var(--text-light); margin-top: 3px; display: flex; align-items: center; gap: 5px; }
        .exp-desc { font-size: 12px; color: var(--text-muted); margin-top: 6px; line-height: 1.6; }

        .edu-item { padding: 12px 0; border-bottom: 1px solid var(--border-light); }
        .edu-item:last-child { border-bottom: none; }
        .edu-level { font-size: 10px; font-weight: 600; color: #d97706; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 2px; }
        .edu-degree { font-weight: 600; font-size: 12.5px; color: var(--text-dark); }
        .edu-school { font-size: 12px; color: var(--text-muted); margin-top: 1px; }
        .edu-year { font-size: 11px; color: var(--text-light); margin-top: 2px; }

        .timeline { padding: 4px 0; }
        .timeline-item { display: flex; gap: 12px; padding-bottom: 14px; position: relative; }
        .timeline-item:last-child { padding-bottom: 0; }
        .timeline-item:not(:last-child)::after {
            content: ''; position: absolute;
            left: 11px; top: 24px; bottom: 0;
            width: 1px; background: var(--border);
        }
        .timeline-dot {
            width: 24px; height: 24px;
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 5px;
            background: #f3f4f6; color: var(--text-light);
        }
        .timeline-content h4 { font-size: 12px; font-weight: 600; }
        .timeline-content p { font-size: 11px; color: var(--text-light); margin-top: 2px; }

        .empty-state { text-align: center; padding: 30px 16px; color: var(--text-light); }
        .empty-state i { font-size: 24px; margin-bottom: 10px; opacity: 0.3; display: block; }
        .empty-state p { font-size: 12.5px; }

        .modal-overlay {
            display: none; position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.4);
            backdrop-filter: blur(3px);
            z-index: 1000;
            align-items: center; justify-content: center;
        }
        .modal-overlay.show { display: flex; }
        .modal-box {
            background: white; border-radius: 14px; padding: 32px;
            max-width: 380px; width: 90%; text-align: center;
            box-shadow: 0 20px 50px rgba(0,0,0,0.18);
            animation: modalIn 0.2s ease;
        }
        @keyframes modalIn {
            from { transform: scale(0.95); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }
        .modal-icon {
            width: 52px; height: 52px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 22px; margin: 0 auto 16px;
        }
        .modal-icon.danger { background: #fef2f2; color: #dc2626; }
        .modal-box h3 { font-size: 15px; font-weight: 700; margin-bottom: 6px; }
        .modal-box p { font-size: 13px; color: var(--text-muted); margin-bottom: 24px; line-height: 1.6; }
        .modal-btns { display: flex; gap: 8px; justify-content: center; }
        .modal-btn {
            padding: 9px 24px; border-radius: var(--radius-sm);
            font-family: 'Inter', sans-serif;
            font-size: 12.5px; font-weight: 600;
            cursor: pointer; transition: var(--transition);
            border: none; text-decoration: none;
            display: inline-flex; align-items: center; gap: 6px;
        }
        .modal-btn-cancel { background: #f3f4f6; color: var(--text-dark); }
        .modal-btn-cancel:hover { background: #e5e7eb; }
        .modal-btn-danger { background: #dc2626; color: white; }
        .modal-btn-danger:hover { background: #b91c1c; box-shadow: 0 2px 8px rgba(220,38,38,0.3); }

        @media (max-width: 1200px) { .cards-grid { grid-template-columns: 1fr; } }
        @media (max-width: 1024px) { .sidebar { transform: translateX(-100%); } .main-content { margin-left: 0; } }
        @media (max-width: 768px) {
            .content { padding: 16px; }
            .top-bar { padding: 0 16px; }
            .profile-body { flex-direction: column; align-items: flex-start; padding: 0 20px 20px; gap: 14px; }
            .profile-avatar-lg { width: 68px; height: 68px; font-size: 18px; }
            .profile-main h2 { font-size: 16px; white-space: normal; }
            .profile-actions { width: 100%; }
            .btn-action-lg { flex: 1; justify-content: center; padding: 8px 10px; font-size: 11px; }
            .info-row { flex-direction: column; gap: 2px; }
            .info-label { min-width: unset; }
            .info-value { text-align: left; }
        }
    </style>
</head>
<body>

    <div class="dashboard">
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">DAR</div>
                <h3>Admin Dashboard</h3>
                <p>Employee Records Management</p>
            </div>
            <nav class="nav-menu">
                <div class="nav-label">Main</div>
                <a href="dashboard_admin.php" class="nav-item"><i class="fas fa-home"></i> Dashboard</a>
                <div class="nav-label">Management</div>
                <a href="employees.php" class="nav-item"><i class="fas fa-users"></i> Employees</a>
                <a href="applicants.php" class="nav-item active"><i class="fas fa-user-plus"></i> Applicants</a>
                <a href="positions.php" class="nav-item"><i class="fas fa-briefcase"></i> Vacant Positions</a>
                <a href="applications.php" class="nav-item"><i class="fas fa-file-alt"></i> Job Applications</a>
                <a href="documents.php" class="nav-item"><i class="fas fa-folder-open"></i> Documents</a>
                <div class="nav-label">System</div>
                <a href="reports.php" class="nav-item"><i class="fas fa-chart-bar"></i> Reports</a>
                <a href="calendar_admin.php" class="nav-item"><i class="fas fa-calendar-alt"></i> Calendar</a>
                <a href="settings.php" class="nav-item"><i class="fas fa-cog"></i> Settings</a>
            </nav>
            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['admin_name'], 0, 1)); ?></div>
                    <div class="user-details">
                        <h4><?php echo htmlspecialchars($_SESSION['admin_name']); ?></h4>
                        <p><?php echo ucfirst($_SESSION['admin_role'] ?? 'Admin'); ?></p>
                    </div>
                </div>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </aside>

        <main class="main-content">
            <div class="top-bar">
                <div class="top-bar-left">
                    <h2><i class="fas fa-user"></i>Applicant Details</h2>
                </div>
                <span class="status-badge status-<?php echo $app['status']; ?>">
                    <i class="fas fa-circle"></i>
                    <?php echo ucfirst($app['status']); ?>
                </span>
            </div>

            <div class="content">
                <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
                <?php endif; ?>

                <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                </div>
                <?php endif; ?>

                <a href="applicants.php" class="btn-back">
                    <i class="fas fa-arrow-left"></i> Back to Applicants
                </a>

                <!-- PROFILE HEADER -->
                <div class="profile-header">
                    <div class="profile-banner"></div>
                    <div class="profile-body">
                        <div class="profile-avatar-lg">
                            <?php echo strtoupper(substr($app['first_name'], 0, 1) . substr($app['last_name'], 0, 1)); ?>
                        </div>
                        <div class="profile-main">
                            <h2><?php echo htmlspecialchars(ucwords(strtolower($app['first_name'] . ' ' . ($app['middle_name'] ?? '') . ' ' . $app['last_name']))); ?></h2>
                            <div class="profile-sub">
                                <span><?php echo htmlspecialchars($app['applicant_id']); ?></span>
                                <span class="dot"></span>
                                <span>Applied <?php echo date('F d, Y', strtotime($app['created_at'])); ?></span>
                            </div>
                            <div class="meta-tags">
                                <?php if(hasValue($app, 'education_level')): ?>
                                <span class="meta-tag"><i class="fas fa-graduation-cap"></i> <?php echo htmlspecialchars($app['education_level']); ?></span>
                                <?php endif; ?>
                                <?php if(hasValue($app, 'phone')): ?>
                                <span class="meta-tag"><i class="fas fa-phone"></i> <?php echo htmlspecialchars($app['phone']); ?></span>
                                <?php endif; ?>
                                <?php if(hasValue($app, 'email')): ?>
                                <span class="meta-tag"><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($app['email']); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="profile-actions">
                            <?php if($app['status'] == 'pending'): ?>
                            <a href="applicant_view.php?approve=<?php echo $app['id']; ?>" class="btn-action-lg btn-approve-lg" onclick="return confirm('Approve this applicant?')">
                                <i class="fas fa-check"></i> Approve
                            </a>
                            <a href="applicant_view.php?reject=<?php echo $app['id']; ?>" class="btn-action-lg btn-reject-lg" onclick="return confirm('Reject this applicant?')">
                                <i class="fas fa-times"></i> Reject
                            </a>
                            <?php elseif($app['status'] == 'approved' || $app['status'] == 'rejected'): ?>
                            <a href="applicant_view.php?restore=<?php echo $app['id']; ?>" class="btn-action-lg btn-restore-lg" onclick="return confirm('Reset status to pending?')">
                                <i class="fas fa-undo"></i> Reset
                            </a>
                            <?php endif; ?>
                            <button type="button" class="btn-action-lg btn-delete-lg" onclick="showDeleteModal()">
                                <i class="fas fa-trash-alt"></i> Delete
                            </button>
                        </div>
                    </div>
                </div>

                <!-- CARDS GRID -->
                <div class="cards-grid">

                    <!-- Personal Information - ONLY shows fields with data -->
                    <div class="info-card">
                        <div class="card-header">
                            <div class="card-header-icon icon-green"><i class="fas fa-user"></i></div>
                            <h3>Personal Information</h3>
                        </div>
                        <div class="card-body">
                            <div class="info-row">
                                <span class="info-label">Full Name</span>
                                <span class="info-value"><?php 
                                    $fullName = trim($app['first_name'] . ' ' . ($app['middle_name'] ?? '') . ' ' . $app['last_name'] . ' ' . ($app['suffix'] ?? ''));
                                    echo htmlspecialchars(ucwords(strtolower($fullName))); 
                                ?></span>
                            </div>
                            <?php if(hasValue($app, 'date_of_birth')): ?>
                            <div class="info-row">
                                <span class="info-label">Date of Birth</span>
                                <span class="info-value"><?php echo date('F d, Y', strtotime($app['date_of_birth'])); ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if(hasValue($app, 'gender')): ?>
                            <div class="info-row">
                                <span class="info-label">Gender</span>
                                <span class="info-value"><?php echo ucfirst($app['gender']); ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if(hasValue($app, 'civil_status')): ?>
                            <div class="info-row">
                                <span class="info-label">Civil Status</span>
                                <span class="info-value"><?php echo ucfirst($app['civil_status']); ?></span>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Contact Information - ONLY shows fields with data -->
                    <div class="info-card">
                        <div class="card-header">
                            <div class="card-header-icon icon-blue"><i class="fas fa-address-book"></i></div>
                            <h3>Contact Information</h3>
                        </div>
                        <div class="card-body">
                            <?php if(hasValue($app, 'email')): ?>
                            <div class="info-row">
                                <span class="info-label">Email Address</span>
                                <span class="info-value"><?php echo htmlspecialchars($app['email']); ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if(hasValue($app, 'phone')): ?>
                            <div class="info-row">
                                <span class="info-label">Phone Number</span>
                                <span class="info-value"><?php echo htmlspecialchars($app['phone']); ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if(hasValue($app, 'present_address')): ?>
                            <div class="info-row">
                                <span class="info-label">Present Address</span>
                                <span class="info-value"><?php echo htmlspecialchars($app['present_address']); ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if(hasValue($app, 'permanent_address')): ?>
                            <div class="info-row">
                                <span class="info-label">Permanent Address</span>
                                <span class="info-value"><?php echo htmlspecialchars($app['permanent_address']); ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if(hasValue($app, 'region')): ?>
                            <div class="info-row">
                                <span class="info-label">Region</span>
                                <span class="info-value"><?php echo htmlspecialchars($app['region']); ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if(hasValue($app, 'province')): ?>
                            <div class="info-row">
                                <span class="info-label">Province</span>
                                <span class="info-value"><?php echo htmlspecialchars($app['province']); ?></span>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Education - ONLY from applicant_education table, no duplicates -->
                    <?php if($education && $education->num_rows > 0): ?>
                    <div class="info-card">
                        <div class="card-header">
                            <div class="card-header-icon icon-gold"><i class="fas fa-graduation-cap"></i></div>
                            <h3>Education</h3>
                            <span class="card-count"><?php echo $education->num_rows; ?></span>
                        </div>
                        <div class="card-body">
                            <?php while($edu = $education->fetch_assoc()): ?>
                            <div class="edu-item">
                                <?php if(hasValue($edu, 'level')): ?>
                                <div class="edu-level"><?php echo htmlspecialchars($edu['level']); ?></div>
                                <?php endif; ?>
                                <?php if(hasValue($edu, 'degree')): ?>
                                <div class="edu-degree"><?php echo htmlspecialchars($edu['degree']); ?></div>
                                <?php endif; ?>
                                <?php if(hasValue($edu, 'school')): ?>
                                <div class="edu-school"><?php echo htmlspecialchars($edu['school']); ?></div>
                                <?php endif; ?>
                                <div class="edu-year">
                                    <?php 
                                        $years = '';
                                        if(hasValue($edu, 'year_from')) $years .= htmlspecialchars($edu['year_from']);
                                        if(hasValue($edu, 'year_to')) $years .= ($years ? ' – ' : '') . htmlspecialchars($edu['year_to']);
                                        if(hasValue($edu, 'year_graduated')) $years = 'Graduated: ' . htmlspecialchars($edu['year_graduated']);
                                        echo $years ?: 'No year specified';
                                    ?>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Work Experience - ONLY from applicant_experience table -->
                    <?php if($experiences && $experiences->num_rows > 0): ?>
                    <div class="info-card">
                        <div class="card-header">
                            <div class="card-header-icon icon-purple"><i class="fas fa-briefcase"></i></div>
                            <h3>Work Experience</h3>
                            <span class="card-count"><?php echo $experiences->num_rows; ?></span>
                        </div>
                        <div class="card-body">
                            <?php while($exp = $experiences->fetch_assoc()): ?>
                            <div class="exp-item">
                                <?php if(hasValue($exp, 'position')): ?>
                                <div class="exp-position"><?php echo htmlspecialchars($exp['position']); ?></div>
                                <?php endif; ?>
                                <?php if(hasValue($exp, 'company')): ?>
                                <div class="exp-company"><?php echo htmlspecialchars($exp['company']); ?></div>
                                <?php endif; ?>
                                <div class="exp-date">
                                    <i class="fas fa-calendar-alt"></i>
                                    <?php echo date('M Y', strtotime($exp['start_date'])); ?> – 
                                    <?php echo !empty($exp['end_date']) ? date('M Y', strtotime($exp['end_date'])) : 'Present'; ?>
                                </div>
                                <?php if(hasValue($exp, 'description')): ?>
                                <div class="exp-desc"><?php echo htmlspecialchars($exp['description']); ?></div>
                                <?php endif; ?>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Job Applications -->
                    <div class="info-card info-card-full">
                        <div class="card-header">
                            <div class="card-header-icon icon-teal"><i class="fas fa-file-alt"></i></div>
                            <h3>Job Applications</h3>
                            <span class="card-count"><?php echo $applications ? $applications->num_rows : 0; ?></span>
                        </div>
                        <div class="card-body" style="padding: 0;">
                            <?php if($applications && $applications->num_rows > 0): ?>
                            <table class="inner-table">
                                <thead>
                                    <tr>
                                        <th>Application Code</th>
                                        <th>Position</th>
                                        <th>Department</th>
                                        <th>Type</th>
                                        <th>Status</th>
                                        <th>Date Applied</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($ja = $applications->fetch_assoc()): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($ja['application_code'] ?? 'N/A'); ?></strong></td>
                                        <td><?php echo htmlspecialchars($ja['position_title'] ?? 'N/A'); ?></td>
                                        <td><?php echo htmlspecialchars($ja['department'] ?? 'N/A'); ?></td>
                                        <td><?php echo htmlspecialchars($ja['employment_type'] ?? 'N/A'); ?></td>
                                        <td><span class="status-badge status-<?php echo $ja['status']; ?>"><?php echo ucfirst($ja['status']); ?></span></td>
                                        <td><?php echo date('M d, Y', strtotime($ja['applied_at'])); ?></td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                            <?php else: ?>
                            <div class="empty-state">
                                <i class="fas fa-file-alt"></i>
                                <p>No job applications submitted yet.</p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Uploaded Documents -->
                    <?php if($documents && $documents->num_rows > 0): ?>
                    <div class="info-card">
                        <div class="card-header">
                            <div class="card-header-icon icon-blue"><i class="fas fa-folder-open"></i></div>
                            <h3>Uploaded Documents</h3>
                            <span class="card-count"><?php echo $documents->num_rows; ?> file(s)</span>
                        </div>
                        <div class="card-body">
                            <?php while($doc = $documents->fetch_assoc()):
                                $ext = strtolower(pathinfo($doc['file_name'], PATHINFO_EXTENSION));
                                $iconClass = 'doc-file'; $faIcon = 'fa-file';
                                if($ext == 'pdf') { $iconClass = 'doc-pdf'; $faIcon = 'fa-file-pdf'; }
                                elseif(in_array($ext, ['jpg','jpeg','png','gif'])) { $iconClass = 'doc-img'; $faIcon = 'fa-file-image'; }
                            ?>
                            <div class="doc-item">
                                <div class="doc-info">
                                    <div class="doc-icon <?php echo $iconClass; ?>"><i class="fas <?php echo $faIcon; ?>"></i></div>
                                    <div>
                                        <div class="doc-name"><?php echo htmlspecialchars($doc['document_type'] ?? $doc['file_name']); ?></div>
                                        <div class="doc-date"><?php echo date('M d, Y', strtotime($doc['uploaded_at'])); ?> · <?php echo strtoupper($ext); ?></div>
                                    </div>
                                </div>
                                <a href="uploads/applicants/<?php echo htmlspecialchars($doc['file_name']); ?>" class="btn-download" target="_blank">
                                    <i class="fas fa-download"></i> View
                                </a>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Account & Activity -->
                    <div class="info-card">
                        <div class="card-header">
                            <div class="card-header-icon icon-gray"><i class="fas fa-history"></i></div>
                            <h3>Account & Activity</h3>
                        </div>
                        <div class="card-body">
                            <div class="info-row">
                                <span class="info-label">Account Status</span>
                                <span class="info-value"><span class="status-badge status-<?php echo $app['status']; ?>"><?php echo ucfirst($app['status']); ?></span></span>
                            </div>
                            <div class="info-row">
                                <span class="info-label">Registered On</span>
                                <span class="info-value"><?php echo date('F d, Y g:i A', strtotime($app['created_at'])); ?></span>
                            </div>

                            <?php if($logs && $logs->num_rows > 0): ?>
                            <div style="margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border);">
                                <h4 style="font-size: 12px; font-weight: 650; margin-bottom: 8px; color: var(--text-dark);">Recent Activity</h4>
                                <div class="timeline">
                                    <?php while($log = $logs->fetch_assoc()): ?>
                                    <div class="timeline-item">
                                        <div class="timeline-dot"><i class="fas fa-circle"></i></div>
                                        <div class="timeline-content">
                                            <h4><?php echo htmlspecialchars($log['action'] ?? 'Unknown action'); ?></h4>
                                            <p><?php echo date('M d, Y g:i A', strtotime($log['created_at'])); ?></p>
                                        </div>
                                    </div>
                                    <?php endwhile; ?>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>
            </div>
        </main>
    </div>

    <!-- DELETE MODAL -->
    <div class="modal-overlay" id="deleteModal">
        <div class="modal-box">
            <div class="modal-icon danger"><i class="fas fa-exclamation-triangle"></i></div>
            <h3>Delete Applicant?</h3>
            <p>This action cannot be undone. The applicant and all associated data will be permanently removed.</p>
            <div class="modal-btns">
                <button class="modal-btn modal-btn-cancel" onclick="hideDeleteModal()">Cancel</button>
                <a href="applicant_view.php?delete=<?php echo $app['id']; ?>" class="modal-btn modal-btn-danger"><i class="fas fa-trash-alt"></i> Delete</a>
            </div>
        </div>
    </div>

    <script>
        function showDeleteModal() { document.getElementById('deleteModal').classList.add('show'); }
        function hideDeleteModal() { document.getElementById('deleteModal').classList.remove('show'); }
        document.getElementById('deleteModal').addEventListener('click', function(e) { if (e.target === this) hideDeleteModal(); });
    </script>

</body>
</html>