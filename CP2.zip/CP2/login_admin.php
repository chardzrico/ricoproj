<?php
session_start();
require_once 'db_config.php';

 $page_title = "Admin Login - DAR";

if (isset($_SESSION['admin_id'])) {
    redirect('dashboard_admin.php');
}

 $error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = sanitize($conn, $_POST['username']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, full_name, username, password, role, status FROM admins WHERE username = ? OR email = ?");
    $stmt->bind_param("ss", $username, $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $admin = $result->fetch_assoc();
        if (password_verify($password, $admin['password'])) {
            if ($admin['status'] == 'active') {
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_name'] = $admin['full_name'];
                $_SESSION['admin_role'] = $admin['role'];
                $_SESSION['admin_username'] = $admin['username'];

                // Update last login
                $conn->query("UPDATE admins SET last_login = NOW() WHERE id = " . $admin['id']);

                // Log the login
                $conn->query("INSERT INTO system_logs (user_type, user_id, action, ip_address, user_agent) 
                              VALUES ('admin', " . $admin['id'] . ", 'Admin login successful', '" . $_SERVER['REMOTE_ADDR'] . "', '" . sanitize($conn, $_SERVER['HTTP_USER_AGENT']) . "')");

                redirect('dashboard_admin.php');
            } else {
                $error = "Your account has been deactivated. Please contact the system administrator.";
            }
        } else {
            $error = "Invalid username or password.";
        }
    } else {
        $error = "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dar-green: #006400;
            --dar-dark-green: #004d00;
            --dar-light-green: #4CAF50;
            --dar-gold: #FFD700;
            --dar-gold-light: #FFE44D;
            --text-dark: #1a1a2e;
            --text-muted: #6b7280;
            --white: #ffffff;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-dark-green));
            padding: 20px;
        }

        .login-container {
            display: flex;
            width: 100%;
            max-width: 1000px;
            min-height: 600px;
            background: var(--white);
            border-radius: 24px;
            overflow: hidden;
            box-shadow: 0 25px 80px rgba(0,0,0,0.3);
        }

        /* Left side - Image */
        .login-visual {
            flex: 1;
            position: relative;
            overflow: hidden;
            min-height: 100%;
        }

        .login-visual img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .login-visual-overlay {
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: linear-gradient(
                180deg,
                rgba(0, 60, 0, 0.3) 0%,
                rgba(0, 80, 0, 0.7) 100%
            );
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
            padding: 40px;
            color: var(--white);
        }

        .visual-logo {
            width: 60px;
            height: 60px;
            background: var(--dar-gold);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
            font-size: 1.5rem;
            color: var(--dar-green);
        }

        .login-visual-overlay h2 {
            font-size: 2rem;
            font-weight: 800;
            margin-bottom: 12px;
        }

        .login-visual-overlay p {
            font-size: 0.95rem;
            line-height: 1.7;
            opacity: 0.9;
            max-width: 320px;
        }

        /* Right side - Form */
        .login-form-wrapper {
            flex: 1;
            padding: 60px 50px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: var(--dar-green);
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 600;
            margin-bottom: 30px;
            transition: all 0.3s ease;
        }

        .back-link:hover {
            gap: 12px;
            color: var(--dar-dark-green);
        }

        .login-form-wrapper h1 {
            font-size: 2rem;
            color: var(--text-dark);
            font-weight: 800;
            margin-bottom: 10px;
        }

        .login-form-wrapper .subtitle {
            color: var(--text-muted);
            font-size: 0.95rem;
            margin-bottom: 35px;
            line-height: 1.6;
        }

        .form-group {
            margin-bottom: 22px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--text-dark);
            font-size: 0.9rem;
        }

        .input-wrapper {
            position: relative;
        }

        .input-wrapper i.input-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            font-size: 1rem;
            pointer-events: none;
        }

        .input-wrapper input {
            width: 100%;
            padding: 14px 50px 14px 48px;
            border: 2px solid #e5e7eb;
            border-radius: 12px;
            font-family: 'Poppins', sans-serif;
            font-size: 0.95rem;
            transition: all 0.3s ease;
            background: #fafafa;
        }

        .input-wrapper input:focus {
            outline: none;
            border-color: var(--dar-green);
            background: var(--white);
            box-shadow: 0 0 0 4px rgba(0, 100, 0, 0.08);
        }

        .input-wrapper input::placeholder {
            color: #aaa;
        }

        .toggle-password {
            position: absolute;
            right: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            cursor: pointer;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            padding: 5px;
            border-radius: 6px;
            background: transparent;
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
        }

        .toggle-password:hover {
            color: var(--dar-green);
            background: rgba(0, 100, 0, 0.08);
        }

        .toggle-password.active {
            color: var(--dar-green);
        }

        .btn-login {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: var(--white);
            border: none;
            border-radius: 12px;
            font-family: 'Poppins', sans-serif;
            font-size: 1rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-top: 10px;
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0, 100, 0, 0.35);
        }

        .error-msg {
            background: #fef2f2;
            border: 1px solid #fecaca;
            color: #dc2626;
            padding: 14px 18px;
            border-radius: 12px;
            margin-bottom: 22px;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 500;
        }

        .demo-creds {
            margin-top: 25px;
            padding: 18px;
            background: #f8faf9;
            border-radius: 12px;
            border-left: 4px solid var(--dar-gold);
        }

        .demo-creds h4 {
            font-size: 0.85rem;
            color: var(--dar-green);
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .demo-creds p {
            font-size: 0.8rem;
            color: var(--text-muted);
            margin-bottom: 3px;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .login-container {
                flex-direction: column;
                max-width: 450px;
            }

            .login-visual {
                min-height: 200px;
                max-height: 250px;
            }

            .login-visual-overlay {
                padding: 25px;
            }

            .login-visual-overlay h2 {
                font-size: 1.5rem;
            }

            .login-form-wrapper {
                padding: 35px 30px;
            }
        }
    </style>
</head>
<body>

    <div class="login-container">
        <!-- Left Side: Image -->
        <div class="login-visual">
            <img src="picadmin.jpg" alt="DAR Admin">
            <div class="login-visual-overlay">
                <div class="visual-logo">
                    <i class="fas fa-user-shield"></i>
                </div>
                <h2>Admin Portal</h2>
                <p>Secure access for system administrators and HR personnel. Manage employee records, generate reports, and oversee system operations.</p>
            </div>
        </div>

        <!-- Right Side: Form -->
        <div class="login-form-wrapper">
            <a href="index.php" class="back-link">
                <i class="fas fa-arrow-left"></i> Back to Home
            </a>

            <h1>Welcome Back, Admin</h1>
            <p class="subtitle">Please enter your credentials to access the admin dashboard.</p>

            <?php if($error): ?>
            <div class="error-msg">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
            </div>
            <?php endif; ?>

            <form method="POST" action="" autocomplete="off">
                <input type="hidden" name="prevent_autofill_username" value="">
                <input type="hidden" name="prevent_autofill_password" value="">
                
                <div class="form-group">
                    <label for="username">Username or Email</label>
                    <div class="input-wrapper">
                        <i class="fas fa-user input-icon"></i>
                        <input type="text" id="username" name="username" placeholder="Enter username or email" required autofocus autocomplete="off" autocomplete="new-username" readonly onfocus="this.removeAttribute('readonly')">
                    </div>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="input-wrapper">
                        <i class="fas fa-lock input-icon"></i>
                        <input type="password" id="password" name="password" placeholder="Enter password" required autocomplete="off" autocomplete="new-password" readonly onfocus="this.removeAttribute('readonly')">
                        <button type="button" class="toggle-password" onclick="togglePassword()" aria-label="Toggle password visibility">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>

                <button type="submit" class="btn-login">
                    <i class="fas fa-sign-in-alt"></i> Login
                </button>
            </form>

            <div class="demo-creds">
                <h4><i class="fas fa-info-circle"></i> Demo Credentials</h4>
                <p><strong>Admin:</strong> admin / password</p>
                <p><strong>HR:</strong> hradmin / password</p>
            </div>
        </div>
    </div>

    <script>
        // Clear any autofilled values on page load
        document.addEventListener('DOMContentLoaded', function() {
            const inputs = document.querySelectorAll('input[type="text"], input[type="password"]');
            inputs.forEach(function(input) {
                input.value = '';
            });
        });

        function togglePassword() {
            const pass = document.getElementById('password');
            const btn = document.querySelector('.toggle-password');
            const icon = btn.querySelector('i');
            
            if (pass.type === 'password') {
                pass.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
                btn.classList.add('active');
            } else {
                pass.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
                btn.classList.remove('active');
            }
        }
    </script>

</body>
</html>