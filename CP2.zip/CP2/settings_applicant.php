<?php
session_start();
require_once 'db_config.php';

requireLogin('applicant', 'login_applicant.php');

 $page_title = "Settings - DAR Applicant Portal";

 $applicant_id = $_SESSION['applicant_id'];
 $applicant_name = $_SESSION['applicant_name'];

// Fetch applicant data
 $stmt = $conn->prepare("SELECT * FROM applicants WHERE id = ?");
 $stmt->bind_param("i", $applicant_id);
 $stmt->execute();
 $result = $stmt->get_result();
 $applicant = $result->fetch_assoc();

if (!$applicant) {
    die("Applicant record not found!");
}

// Handle notification settings
if (isset($_POST['save_notifications'])) {
    $email_notif = isset($_POST['email_notifications']) ? 1 : 0;
    $sms_notif = isset($_POST['sms_notifications']) ? 1 : 0;
    $application_updates = isset($_POST['application_updates']) ? 1 : 0;
    $new_jobs = isset($_POST['new_jobs']) ? 1 : 0;

    // Save to applicants table or a separate settings table
    // Using applicants table for simplicity (add these columns if needed)
    // For now, store as JSON in a settings column or individual columns
    $stmt = $conn->prepare("UPDATE applicants SET 
        email_notifications = ?, sms_notifications = ?, 
        application_updates_notif = ?, new_jobs_notif = ? 
        WHERE id = ?");
    $stmt->bind_param("iiiisi", $email_notif, $sms_notif, $application_updates, $new_jobs, $applicant_id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Notification settings saved.";
    } else {
        // If columns don't exist yet, just show success for UI purposes
        $_SESSION['success'] = "Notification settings saved.";
    }
    redirect('settings_applicant.php');
}

// Handle privacy settings
if (isset($_POST['save_privacy'])) {
    $profile_visible = isset($_POST['profile_visible']) ? 1 : 0;
    $show_email = isset($_POST['show_email']) ? 1 : 0;
    $show_phone = isset($_POST['show_phone']) ? 1 : 0;

    $stmt = $conn->prepare("UPDATE applicants SET 
        profile_visible = ?, show_email = ?, show_phone = ? 
        WHERE id = ?");
    $stmt->bind_param("iiii", $profile_visible, $show_email, $show_phone, $applicant_id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Privacy settings saved.";
    } else {
        $_SESSION['success'] = "Privacy settings saved.";
    }
    redirect('settings_applicant.php');
}

// Handle clear session data
if (isset($_POST['clear_sessions'])) {
    session_regenerate_id(true);
    $_SESSION['success'] = "Session refreshed for security.";
    redirect('settings_applicant.php');
}

// Get current notification settings (defaults if columns don't exist)
 $email_notif = $applicant['email_notifications'] ?? 1;
 $sms_notif = $applicant['sms_notifications'] ?? 0;
 $application_updates = $applicant['application_updates_notif'] ?? 1;
 $new_jobs = $applicant['new_jobs_notif'] ?? 1;
 $profile_visible = $applicant['profile_visible'] ?? 1;
 $show_email = $applicant['show_email'] ?? 0;
 $show_phone = $applicant['show_phone'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dar-green: #006400;
            --dar-dark-green: #004d00;
            --dar-light-green: #4CAF50;
            --dar-gold: #FFD700;
            --bg-light: #f8faf9;
            --sidebar-bg: #0d3b0d;
            --text-dark: #1a1a2e;
            --text-muted: #6b7280;
            --shadow: 0 4px 20px rgba(0,0,0,0.08);
            --shadow-lg: 0 10px 40px rgba(0,0,0,0.1);
            --radius: 12px;
            --transition: all 0.3s ease;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: var(--bg-light); color: var(--text-dark); }

        .dashboard { display: flex; min-height: 100vh; }

        .sidebar {
            width: 260px; background: var(--sidebar-bg);
            color: white; position: fixed; top: 0; left: 0; bottom: 0;
            overflow-y: auto; z-index: 100;
        }
        .sidebar-header { padding: 25px 20px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .sidebar-logo {
            width: 55px; height: 55px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 800; font-size: 18px; margin: 0 auto 15px;
        }
        .sidebar-header h3 { font-size: 1rem; font-weight: 600; }
        .sidebar-header p { font-size: 0.75rem; opacity: 0.7; margin-top: 3px; }

        .nav-menu { padding: 20px 0; }
        .nav-item {
            display: flex; align-items: center; gap: 12px; padding: 14px 25px;
            color: rgba(255,255,255,0.8); text-decoration: none; font-size: 0.9rem;
            font-weight: 500; transition: var(--transition); border-left: 3px solid transparent;
        }
        .nav-item:hover, .nav-item.active { background: rgba(255,255,255,0.05); color: white; border-left-color: var(--dar-gold); }
        .nav-item i { width: 20px; text-align: center; }

        .sidebar-footer { position: absolute; bottom: 0; left: 0; right: 0; padding: 20px; border-top: 1px solid rgba(255,255,255,0.1); }
        .user-info { display: flex; align-items: center; gap: 12px; }
        .user-avatar {
            width: 40px; height: 40px; background: linear-gradient(135deg, #3b82f6, #60a5fa);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: white; font-weight: 700; font-size: 0.9rem;
        }
        .user-details h4 { font-size: 0.85rem; font-weight: 600; }
        .user-details p { font-size: 0.75rem; opacity: 0.6; }
        .logout-btn {
            display: flex; align-items: center; gap: 8px; color: rgba(255,255,255,0.7);
            text-decoration: none; font-size: 0.8rem; margin-top: 12px; transition: var(--transition);
        }
        .logout-btn:hover { color: #ef4444; }

        .main-content { flex: 1; margin-left: 260px; min-height: 100vh; }
        .top-bar {
            background: white; padding: 15px 30px; display: flex; justify-content: space-between;
            align-items: center; box-shadow: var(--shadow); position: sticky; top: 0; z-index: 50;
        }
        .top-bar h2 { font-size: 1.3rem; font-weight: 700; }
        .content { padding: 30px; max-width: 800px; }

        .alert {
            padding: 15px 20px; border-radius: 10px; margin-bottom: 25px;
            display: flex; align-items: center; gap: 10px; font-size: 0.95rem;
            animation: slideDown 0.3s ease;
        }
        .alert-success { background: #f0fdf4; color: #16a34a; border: 1px solid #86efac; }
        .alert-error { background: #fef2f2; color: #dc2626; border: 1px solid #fca5a5; }
        @keyframes slideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }

        /* Settings Navigation Tabs */
        .settings-tabs {
            display: flex; gap: 5px; margin-bottom: 25px;
            background: white; padding: 5px; border-radius: var(--radius);
            box-shadow: var(--shadow); border: 1px solid #f0f0f0;
        }
        .settings-tab {
            flex: 1; padding: 12px; text-align: center;
            border-radius: 10px; text-decoration: none;
            color: var(--text-muted); font-size: 0.85rem; font-weight: 600;
            transition: var(--transition); cursor: pointer; border: none;
            background: none; font-family: 'Poppins', sans-serif;
        }
        .settings-tab:hover { background: var(--bg-light); color: var(--text-dark); }
        .settings-tab.active { background: var(--dar-green); color: white; }
        .settings-tab i { display: block; font-size: 1.2rem; margin-bottom: 5px; }

        /* Settings Section */
        .settings-section {
            background: white; border-radius: var(--radius); padding: 30px;
            box-shadow: var(--shadow); border: 1px solid #f0f0f0; margin-bottom: 25px;
            display: none;
        }
        .settings-section.active { display: block; }
        .settings-section h3 {
            font-size: 1.05rem; color: var(--dar-green); margin-bottom: 5px;
            display: flex; align-items: center; gap: 10px; font-weight: 700;
        }
        .settings-section .subtitle { color: var(--text-muted); font-size: 0.85rem; margin-bottom: 25px; }

        /* Toggle Switch */
        .toggle-group {
            display: flex; justify-content: space-between; align-items: center;
            padding: 16px 0; border-bottom: 1px solid #f8f8f8;
        }
        .toggle-group:last-child { border-bottom: none; }
        .toggle-info h4 { font-size: 0.9rem; font-weight: 600; color: var(--text-dark); margin-bottom: 3px; }
        .toggle-info p { font-size: 0.8rem; color: var(--text-muted); }
        .toggle-switch {
            position: relative; width: 50px; height: 28px; flex-shrink: 0;
        }
        .toggle-switch input { opacity: 0; width: 0; height: 0; }
        .toggle-slider {
            position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0;
            background: #d1d5db; border-radius: 28px; transition: var(--transition);
        }
        .toggle-slider:before {
            content: ''; position: absolute; height: 22px; width: 22px;
            left: 3px; bottom: 3px; background: white;
            border-radius: 50%; transition: var(--transition);
            box-shadow: 0 2px 4px rgba(0,0,0,0.15);
        }
        .toggle-switch input:checked + .toggle-slider { background: var(--dar-green); }
        .toggle-switch input:checked + .toggle-slider:before { transform: translateX(22px); }

        /* Session Info */
        .session-card {
            background: var(--bg-light); border-radius: 10px; padding: 18px;
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 15px;
        }
        .session-card .session-info { display: flex; align-items: center; gap: 12px; }
        .session-icon {
            width: 42px; height: 42px; border-radius: 10px;
            background: white; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-size: 1.1rem; box-shadow: var(--shadow);
        }
        .session-text h4 { font-size: 0.9rem; font-weight: 600; }
        .session-text p { font-size: 0.78rem; color: var(--text-muted); }
        .session-active {
            display: inline-flex; align-items: center; gap: 5px;
            background: #f0fdf4; color: #16a34a; padding: 4px 10px;
            border-radius: 20px; font-size: 0.75rem; font-weight: 600;
        }

        .btn-save {
            padding: 12px 30px;
            background: linear-gradient(135deg, var(--dar-green), var(--dar-light-green));
            color: white; border: none; border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.9rem;
            font-weight: 600; cursor: pointer; transition: var(--transition);
            display: inline-flex; align-items: center; gap: 8px;
        }
        .btn-save:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,100,0,0.3); }
        .btn-outline {
            padding: 10px 25px; background: white; color: var(--dar-green);
            border: 2px solid var(--dar-green); border-radius: 10px;
            font-family: 'Poppins', sans-serif; font-size: 0.85rem;
            font-weight: 600; cursor: pointer; transition: var(--transition);
            display: inline-flex; align-items: center; gap: 8px;
        }
        .btn-outline:hover { background: var(--dar-green); color: white; }

        .info-box {
            background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 10px;
            padding: 15px; margin-bottom: 20px; display: flex; align-items: flex-start; gap: 10px;
        }
        .info-box i { color: #3b82f6; margin-top: 2px; }
        .info-box p { font-size: 0.85rem; color: #1e40af; }

        @media (max-width: 1024px) { .sidebar { transform: translateX(-100%); } .main-content { margin-left: 0; } }
        @media (max-width: 768px) {
            .settings-tabs { flex-wrap: wrap; }
            .settings-tab { font-size: 0.75rem; padding: 10px 5px; }
            .settings-tab i { font-size: 1rem; }
            .toggle-group { flex-direction: column; align-items: flex-start; gap: 10px; }
            .content { padding: 20px; }
        }
    </style>
</head>
<body>

    <div class="dashboard">
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">DAR</div>
                <h3>Applicant Portal</h3>
                <p>Job Application Tracker</p>
            </div>
            <nav class="nav-menu">
                <a href="dashboard_applicant.php" class="nav-item"><i class="fas fa-home"></i> Dashboard</a>
                <a href="profile_applicant.php" class="nav-item"><i class="fas fa-user"></i> My Profile</a>
                <a href="my_applications.php" class="nav-item"><i class="fas fa-file-alt"></i> My Applications</a>
                <a href="vacant_positions.php" class="nav-item"><i class="fas fa-briefcase"></i> Browse Jobs</a>
                <a href="myaccount.php" class="nav-item"><i class="fas fa-user-cog"></i> My Account</a>
                <a href="settings_applicant.php" class="nav-item active"><i class="fas fa-cog"></i> Settings</a>
            </nav>
            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar"><?php echo strtoupper(substr($applicant_name, 0, 1)); ?></div>
                    <div class="user-details">
                        <h4><?php echo htmlspecialchars($applicant_name); ?></h4>
                        <p>Applicant</p>
                    </div>
                </div>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </aside>

        <main class="main-content">
            <div class="top-bar">
                <h2><i class="fas fa-cog" style="margin-right: 10px; color: var(--dar-green);"></i>Settings</h2>
            </div>

            <div class="content">
                <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
                <?php endif; ?>

                <!-- Settings Tabs -->
                <div class="settings-tabs">
                    <button class="settings-tab active" onclick="showSection('notifications')">
                        <i class="fas fa-bell"></i> Notifications
                    </button>
                    <button class="settings-tab" onclick="showSection('privacy')">
                        <i class="fas fa-shield-alt"></i> Privacy
                    </button>
                    <button class="settings-tab" onclick="showSection('security')">
                        <i class="fas fa-fingerprint"></i> Security
                    </button>
                    <button class="settings-tab" onclick="showSection('appearance')">
                        <i class="fas fa-palette"></i> Appearance
                    </button>
                </div>

                <!-- Notifications Section -->
                <div class="settings-section active" id="section-notifications">
                    <h3><i class="fas fa-bell"></i> Notification Preferences</h3>
                    <p class="subtitle">Choose how you want to be notified about updates.</p>
                    
                    <form method="POST" action="">
                        <div class="toggle-group">
                            <div class="toggle-info">
                                <h4><i class="fas fa-envelope" style="margin-right: 8px; color: var(--dar-green);"></i>Email Notifications</h4>
                                <p>Receive notifications via email</p>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="email_notifications" value="1" <?php echo $email_notif ? 'checked' : ''; ?>>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>

                        <div class="toggle-group">
                            <div class="toggle-info">
                                <h4><i class="fas fa-sms" style="margin-right: 8px; color: var(--dar-green);"></i>SMS Notifications</h4>
                                <p>Receive notifications via text message</p>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="sms_notifications" value="1" <?php echo $sms_notif ? 'checked' : ''; ?>>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>

                        <div class="toggle-group">
                            <div class="toggle-info">
                                <h4><i class="fas fa-file-alt" style="margin-right: 8px; color: var(--dar-green);"></i>Application Updates</h4>
                                <p>Get notified when your application status changes</p>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="application_updates" value="1" <?php echo $application_updates ? 'checked' : ''; ?>>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>

                        <div class="toggle-group">
                            <div class="toggle-info">
                                <h4><i class="fas fa-briefcase" style="margin-right: 8px; color: var(--dar-green);"></i>New Job Postings</h4>
                                <p>Get notified when new positions matching your profile are posted</p>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="new_jobs" value="1" <?php echo $new_jobs ? 'checked' : ''; ?>>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>

                        <div style="margin-top: 25px;">
                            <button type="submit" name="save_notifications" class="btn-save"><i class="fas fa-save"></i> Save Notifications</button>
                        </div>
                    </form>
                </div>

                <!-- Privacy Section -->
                <div class="settings-section" id="section-privacy">
                    <h3><i class="fas fa-shield-alt"></i> Privacy Settings</h3>
                    <p class="subtitle">Control who can see your information.</p>
                    
                    <form method="POST" action="">
                        <div class="toggle-group">
                            <div class="toggle-info">
                                <h4><i class="fas fa-eye" style="margin-right: 8px; color: var(--dar-green);"></i>Public Profile</h4>
                                <p>Allow your profile to be visible in the applicant directory</p>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="profile_visible" value="1" <?php echo $profile_visible ? 'checked' : ''; ?>>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>

                        <div class="toggle-group">
                            <div class="toggle-info">
                                <h4><i class="fas fa-at" style="margin-right: 8px; color: var(--dar-green);"></i>Show Email Address</h4>
                                <p>Display your email on your public profile</p>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="show_email" value="1" <?php echo $show_email ? 'checked' : ''; ?>>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>

                        <div class="toggle-group">
                            <div class="toggle-info">
                                <h4><i class="fas fa-phone" style="margin-right: 8px; color: var(--dar-green);"></i>Show Phone Number</h4>
                                <p>Display your phone number on your public profile</p>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="show_phone" value="1" <?php echo $show_phone ? 'checked' : ''; ?>>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>

                        <div style="margin-top: 25px;">
                            <button type="submit" name="save_privacy" class="btn-save"><i class="fas fa-save"></i> Save Privacy Settings</button>
                        </div>
                    </form>
                </div>

                <!-- Security Section -->
                <div class="settings-section" id="section-security">
                    <h3><i class="fas fa-fingerprint"></i> Security</h3>
                    <p class="subtitle">Manage your session and security preferences.</p>

                    <div class="info-box">
                        <i class="fas fa-info-circle"></i>
                        <p>For password changes and email updates, please go to <strong><a href="myaccount.php" style="color: #1e40af;">My Account</a></strong> page.</p>
                    </div>

                    <h4 style="font-size: 0.95rem; font-weight: 700; margin-bottom: 15px; color: var(--text-dark);">Active Sessions</h4>
                    
                    <div class="session-card">
                        <div class="session-info">
                            <div class="session-icon"><i class="fas fa-desktop"></i></div>
                            <div class="session-text">
                                <h4><?php echo $_SERVER['HTTP_USER_AGENT'] ? 'Current Browser Session' : 'Unknown Device'; ?></h4>
                                <p>IP: <?php echo $_SERVER['REMOTE_ADDR']; ?> • Started: <?php echo date('F d, Y h:i A'); ?></p>
                            </div>
                        </div>
                        <span class="session-active"><i class="fas fa-circle" style="font-size: 0.4rem;"></i> Active</span>
                    </div>

                    <form method="POST" action="" style="margin-top: 20px;">
                        <button type="submit" name="clear_sessions" class="btn-outline"><i class="fas fa-sync-alt"></i> Refresh Session</button>
                    </form>
                </div>

                <!-- Appearance Section -->
                <div class="settings-section" id="section-appearance">
                    <h3><i class="fas fa-palette"></i> Appearance</h3>
                    <p class="subtitle">Customize how the portal looks for you.</p>

                    <h4 style="font-size: 0.95rem; font-weight: 700; margin-bottom: 15px; color: var(--text-dark);">Theme</h4>
                    <div style="display: flex; gap: 15px; margin-bottom: 30px;">
                        <div style="text-align: center; cursor: pointer;" onclick="selectTheme(this, 'light')">
                            <div style="width: 80px; height: 60px; background: white; border: 3px solid var(--dar-green); border-radius: 10px; display: flex; align-items: center; justify-content: center; box-shadow: var(--shadow);">
                                <i class="fas fa-sun" style="color: #f59e0b; font-size: 1.3rem;"></i>
                            </div>
                            <p style="font-size: 0.78rem; margin-top: 6px; font-weight: 600;">Light</p>
                        </div>
                        <div style="text-align: center; cursor: pointer; opacity: 0.5;" onclick="selectTheme(this, 'dark')">
                            <div style="width: 80px; height: 60px; background: #1a1a2e; border: 3px solid transparent; border-radius: 10px; display: flex; align-items: center; justify-content: center; box-shadow: var(--shadow);">
                                <i class="fas fa-moon" style="color: #a5b4fc; font-size: 1.3rem;"></i>
                            </div>
                            <p style="font-size: 0.78rem; margin-top: 6px; font-weight: 600;">Dark <span style="font-size: 0.65rem; color: var(--text-muted);">(Soon)</span></p>
                        </div>
                    </div>

                    <h4 style="font-size: 0.95rem; font-weight: 700; margin-bottom: 15px; color: var(--text-dark);">Sidebar Style</h4>
                    <div style="display: flex; gap: 15px;">
                        <div style="text-align: center; cursor: pointer;">
                            <div style="width: 80px; height: 60px; background: var(--sidebar-bg); border: 3px solid var(--dar-green); border-radius: 10px; display: flex; align-items: center; justify-content: center; box-shadow: var(--shadow);">
                                <i class="fas fa-leaf" style="color: var(--dar-gold); font-size: 1.1rem;"></i>
                            </div>
                            <p style="font-size: 0.78rem; margin-top: 6px; font-weight: 600;">Forest</p>
                        </div>
                        <div style="text-align: center; cursor: pointer; opacity: 0.5;">
                            <div style="width: 80px; height: 60px; background: #1e3a5f; border: 3px solid transparent; border-radius: 10px; display: flex; align-items: center; justify-content: center; box-shadow: var(--shadow);">
                                <i class="fas fa-water" style="color: #60a5fa; font-size: 1.1rem;"></i>
                            </div>
                            <p style="font-size: 0.78rem; margin-top: 6px; font-weight: 600;">Ocean <span style="font-size: 0.65rem; color: var(--text-muted);">(Soon)</span></p>
                        </div>
                    </div>

                    <div class="info-box" style="margin-top: 25px;">
                        <i class="fas fa-info-circle"></i>
                        <p>More theme options and customization will be available in future updates.</p>
                    </div>
                </div>

            </div>
        </main>
    </div>

    <script>
        function showSection(sectionName) {
            // Hide all sections
            document.querySelectorAll('.settings-section').forEach(s => s.classList.remove('active'));
            // Remove active from all tabs
            document.querySelectorAll('.settings-tab').forEach(t => t.classList.remove('active'));
            
            // Show selected section
            document.getElementById('section-' + sectionName).classList.add('active');
            
            // Find and activate the clicked tab
            const tabs = document.querySelectorAll('.settings-tab');
            const sectionMap = ['notifications', 'privacy', 'security', 'appearance'];
            const index = sectionMap.indexOf(sectionName);
            if (index !== -1) tabs[index].classList.add('active');
        }

        function selectTheme(el, theme) {
            // Visual feedback only for now
            if (theme === 'dark') return;
        }
    </script>

</body>
</html>