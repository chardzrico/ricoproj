<?php
session_start();
require_once 'db_config.php';

requireLogin('admin', 'login_admin.php');
$page_title = "Contact Messages - DAR";

// Handle status update
if (isset($_GET['mark_read']) && is_numeric($_GET['mark_read'])) {
    $id = (int)$_GET['mark_read'];
    $conn->query("UPDATE contact_messages SET status = 'read' WHERE id = $id");
    redirect('messages.php');
}

if (isset($_GET['mark_replied']) && is_numeric($_GET['mark_replied'])) {
    $id = (int)$_GET['mark_replied'];
    $conn->query("UPDATE contact_messages SET status = 'replied', replied_at = NOW() WHERE id = $id");
    redirect('messages.php');
}

if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM contact_messages WHERE id = $id");
    $_SESSION['success'] = "Message deleted.";
    redirect('messages.php');
}

$messages = $conn->query("SELECT * FROM contact_messages ORDER BY created_at DESC");

// Count unread
$unread_count = $conn->query("SELECT COUNT(*) as total FROM contact_messages WHERE status = 'unread'")->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --dar-green: #006400;
            --dar-dark-green: #004d00;
            --dar-light-green: #4CAF50;
            --dar-gold: #FFD700;
            --bg-light: #f8faf9;
            --sidebar-bg: #0d3b0d;
            --text-dark: #1a1a2e;
            --text-muted: #6b7280;
            --shadow: 0 4px 20px rgba(0,0,0,0.08);
            --radius: 12px;
            --transition: all 0.3s ease;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: var(--bg-light); color: var(--text-dark); }

        .dashboard { display: flex; min-height: 100vh; }
        .sidebar {
            width: 260px; background: var(--sidebar-bg);
            color: white; position: fixed; top: 0; left: 0; bottom: 0;
            overflow-y: auto; z-index: 100;
        }
        .sidebar-header {
            padding: 25px 20px; text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .sidebar-logo {
            width: 55px; height: 55px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 800; font-size: 18px;
            margin: 0 auto 15px;
        }
        .sidebar-header h3 { font-size: 1rem; font-weight: 600; }
        .nav-menu { padding: 20px 0; }
        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 14px 25px; color: rgba(255,255,255,0.8);
            text-decoration: none; font-size: 0.9rem; font-weight: 500;
            transition: var(--transition); border-left: 3px solid transparent;
        }
        .nav-item:hover, .nav-item.active {
            background: rgba(255,255,255,0.05);
            color: white; border-left-color: var(--dar-gold);
        }
        .nav-item i { width: 20px; text-align: center; }
        .sidebar-footer {
            position: absolute; bottom: 0; left: 0; right: 0;
            padding: 20px; border-top: 1px solid rgba(255,255,255,0.1);
        }
        .user-info { display: flex; align-items: center; gap: 12px; }
        .user-avatar {
            width: 40px; height: 40px;
            background: linear-gradient(135deg, var(--dar-gold), #FFE44D);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--dar-green); font-weight: 700; font-size: 0.9rem;
        }
        .logout-btn {
            display: flex; align-items: center; gap: 8px;
            color: rgba(255,255,255,0.7); text-decoration: none;
            font-size: 0.8rem; margin-top: 12px;
        }
        .logout-btn:hover { color: #ef4444; }

        .main-content { flex: 1; margin-left: 260px; min-height: 100vh; }
        .top-bar {
            background: white; padding: 15px 30px;
            display: flex; justify-content: space-between; align-items: center;
            box-shadow: var(--shadow); position: sticky; top: 0; z-index: 50;
        }
        .top-bar h2 { font-size: 1.3rem; font-weight: 700; }
        .content { padding: 30px; }

        .alert {
            padding: 15px 20px; border-radius: 10px; margin-bottom: 25px;
            display: flex; align-items: center; gap: 10px; font-size: 0.95rem;
        }
        .alert-success { background: #f0fdf4; color: #16a34a; border: 1px solid #86efac; }

        .stats-bar {
            display: grid; grid-template-columns: repeat(3, 1fr);
            gap: 20px; margin-bottom: 25px;
        }
        .stat-card {
            background: white; border-radius: var(--radius);
            padding: 20px; box-shadow: var(--shadow);
            text-align: center;
        }
        .stat-card h3 { font-size: 2rem; font-weight: 800; color: var(--dar-green); }
        .stat-card p { color: var(--text-muted); font-size: 0.9rem; }

        .messages-list {
            display: flex; flex-direction: column; gap: 15px;
        }
        .message-card {
            background: white; border-radius: var(--radius);
            box-shadow: var(--shadow); padding: 20px 25px;
            border-left: 4px solid #e5e7eb;
            transition: var(--transition);
        }
        .message-card:hover { box-shadow: var(--shadow-lg); }
        .message-card.unread { border-left-color: var(--dar-green); background: #fafafa; }
        .message-card.read { border-left-color: #3b82f6; }
        .message-card.replied { border-left-color: var(--dar-light-green); }
        .message-header {
            display: flex; justify-content: space-between; align-items: flex-start;
            margin-bottom: 12px;
        }
        .message-sender h4 { font-size: 1rem; font-weight: 600; }
        .message-sender p { font-size: 0.85rem; color: var(--text-muted); }
        .message-date { font-size: 0.8rem; color: var(--text-muted); }
        .message-body {
            color: var(--text-dark); font-size: 0.95rem;
            line-height: 1.6; margin-bottom: 15px;
            padding: 15px; background: #f8faf9; border-radius: 8px;
        }
        .message-actions {
            display: flex; gap: 10px;
        }
        .msg-btn {
            padding: 8px 16px; border-radius: 8px;
            font-size: 0.85rem; font-weight: 600;
            text-decoration: none; display: inline-flex;
            align-items: center; gap: 6px; transition: var(--transition);
        }
        .btn-read { background: #eff6ff; color: #3b82f6; }
        .btn-read:hover { background: #3b82f6; color: white; }
        .btn-reply { background: #f0fdf4; color: var(--dar-green); }
        .btn-reply:hover { background: var(--dar-green); color: white; }
        .btn-del { background: #fef2f2; color: #ef4444; }
        .btn-del:hover { background: #ef4444; color: white; }

        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .main-content { margin-left: 0; }
        }
        @media (max-width: 768px) {
            .stats-bar { grid-template-columns: 1fr; }
            .content { padding: 20px; }
        }
    </style>
</head>
<body>

    <div class="dashboard">
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">DAR</div>
                <h3>Admin Dashboard</h3>
                <p>Employee Records Management</p>
            </div>
            <nav class="nav-menu">
                <a href="dashboard_admin.php" class="nav-item"><i class="fas fa-home"></i> Dashboard</a>
                <a href="employees.php" class="nav-item"><i class="fas fa-users"></i> Employees</a>
                <a href="applicants.php" class="nav-item"><i class="fas fa-user-plus"></i> Applicants</a>
                <a href="positions.php" class="nav-item"><i class="fas fa-briefcase"></i> Vacant Positions</a>
                <a href="applications.php" class="nav-item"><i class="fas fa-file-alt"></i> Job Applications</a>
                <a href="documents.php" class="nav-item"><i class="fas fa-folder-open"></i> Documents</a>
                <a href="messages.php" class="nav-item active"><i class="fas fa-envelope"></i> Messages <?php if($unread_count > 0): ?><span style="background: #ef4444; color: white; padding: 2px 8px; border-radius: 10px; font-size: 0.7rem; margin-left: 5px;"><?php echo $unread_count; ?></span><?php endif; ?></a>
                <a href="reports.php" class="nav-item"><i class="fas fa-chart-bar"></i> Reports</a>
                <a href="calendar_admin.php" class="nav-item"><i class="fas fa-calendar-alt"></i> Calendar</a>
                <a href="settings.php" class="nav-item"><i class="fas fa-cog"></i> Settings</a>
            </nav>
            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['admin_name'], 0, 1)); ?></div>
                    <div class="user-details">
                        <h4><?php echo htmlspecialchars($_SESSION['admin_name']); ?></h4>
                        <p><?php echo ucfirst($_SESSION['admin_role']); ?></p>
                    </div>
                </div>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </aside>

        <main class="main-content">
            <div class="top-bar">
                <h2><i class="fas fa-envelope" style="margin-right: 10px; color: var(--dar-green);"></i>Contact Messages</h2>
            </div>

            <div class="content">
                <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
                <?php endif; ?>

                <div class="stats-bar">
                    <div class="stat-card">
                        <h3><?php echo $conn->query("SELECT COUNT(*) as total FROM contact_messages")->fetch_assoc()['total']; ?></h3>
                        <p>Total Messages</p>
                    </div>
                    <div class="stat-card">
                        <h3 style="color: #ef4444;"><?php echo $unread_count; ?></h3>
                        <p>Unread</p>
                    </div>
                    <div class="stat-card">
                        <h3 style="color: #3b82f6;"><?php echo $conn->query("SELECT COUNT(*) as total FROM contact_messages WHERE status = 'replied'")->fetch_assoc()['total']; ?></h3>
                        <p>Replied</p>
                    </div>
                </div>

                <div class="messages-list">
                    <?php while($msg = $messages->fetch_assoc()): ?>
                    <div class="message-card <?php echo $msg['status']; ?>">
                        <div class="message-header">
                            <div class="message-sender">
                                <h4><i class="fas fa-user" style="margin-right: 8px; color: var(--dar-green);"></i><?php echo htmlspecialchars($msg['full_name']); ?></h4>
                                <p><i class="fas fa-envelope" style="margin-right: 6px;"></i><?php echo htmlspecialchars($msg['email']); ?></p>
                            </div>
                            <div class="message-date">
                                <i class="fas fa-clock" style="margin-right: 5px;"></i><?php echo date('M d, Y h:i A', strtotime($msg['created_at'])); ?>
                                <?php if($msg['status'] == 'unread'): ?>
                                <span style="display: inline-block; background: #ef4444; color: white; padding: 2px 10px; border-radius: 10px; font-size: 0.7rem; margin-left: 10px;">NEW</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="message-body">
                            <?php echo nl2br(htmlspecialchars($msg['message'])); ?>
                        </div>
                        <div class="message-actions">
                            <?php if($msg['status'] == 'unread'): ?>
                            <a href="messages.php?mark_read=<?php echo $msg['id']; ?>" class="msg-btn btn-read"><i class="fas fa-check"></i> Mark as Read</a>
                            <?php endif; ?>
                            <?php if($msg['status'] != 'replied'): ?>
                            <a href="mailto:<?php echo $msg['email']; ?>" class="msg-btn btn-reply"><i class="fas fa-reply"></i> Reply via Email</a>
                            <a href="messages.php?mark_replied=<?php echo $msg['id']; ?>" class="msg-btn btn-reply"><i class="fas fa-check-double"></i> Mark Replied</a>
                            <?php endif; ?>
                            <a href="messages.php?delete=<?php echo $msg['id']; ?>" class="msg-btn btn-del" onclick="return confirm('Delete this message?')"><i class="fas fa-trash"></i> Delete</a>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </main>
    </div>

</body>
</html>